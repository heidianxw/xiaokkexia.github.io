<?php
//{"ret":0,"data":{"parters":[],"count":2}}
$array = array();
$array['ret'] = 1;
$array['data'] = array('parters'=>array(array('id'=>2,'avatar'=>'http://wx.qlogo.cn/mmopen/Ex6oU3E9tQIkz0PBKT40ZwghHJGuicIoumRRVEABXicuxq8ltNU1jlgP3CJdh0Mueckib04HMkicDdptZRKrs1Fo8XPOwhtJ0Xpo/0','nick_name'=>'赞木')),'count'=>2);

die(json_encode($array));
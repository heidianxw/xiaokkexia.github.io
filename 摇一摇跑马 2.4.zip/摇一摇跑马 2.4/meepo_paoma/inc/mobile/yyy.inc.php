<?php
include MODULE_ROOT.'/inc/mobile/__init.php';	
$node_js = $this->module['config'];
$socket_url = $node_js['socket_url'];
if(empty($socket_url)){
	message('请先配置nodejs服务器参数');
}
include $this->template('app_shake');
<?php
/**
 * 摇一摇跑马模块定义
 *
 * @author Meepo_zam
 * @url http://bbs.we7.cc/
 */
defined('IN_IA') or exit('Access Denied');
class Meepo_paomaModule extends WeModule {
	public $reply_table = 'meepo_paoma_reply';
	public $activity_table = 'meepo_paoma_activity';
	public $user_table = 'meepo_paoma_user';
	public function fieldsFormDisplay($rid = 0) {
		//要嵌入规则编辑页的自定义内容，这里 $rid 为对应的规则编号，新增时为 0
		global $_W;
		if (!empty($rid)) {
			$reply = pdo_fetch("SELECT * FROM " . tablename($this->reply_table) . " WHERE rid = :rid", array(':rid' => $rid));
		} else {
			$reply = array(
				'loginpass'=>'admin',
				'slogan_list'=>'用力摇#再用力，再用力' ,
				'roundcolor'=>'#70B405',
				'awardsame'=>'1',
			  'leafContainer_show'=>1,
				'leafContainer_image1'=>'../addons/meepo_paoma/template/mobile/images/meigui1.png',
				'leafContainer_image2'=>'../addons/meepo_paoma/template/mobile/images/meigui2.png',
				'leafContainer_image3'=>'../addons/meepo_paoma/template/mobile/images/meigui3.png',
				'leafContainer_image4'=>'../addons/meepo_paoma/template/mobile/images/meigui4.png',
				'shake_cup'=>'../addons/meepo_paoma/template/mobile/images/shake_cup.png',
				'roundbg'=>'../addons/meepo_paoma/template/mobile/images/car.png',
				'appbg'=>'../addons/meepo_paoma/template/mobile/img/wheel.png',
				'app_shake_img'=>'../addons/meepo_paoma/template/mobile/img/hand.png',
				'bg'=>'../addons/meepo_paoma/template/mobile/images/webgb.jpg',
				'ma1'=>'../addons/meepo_paoma/template/mobile/images/ma.png',
				'ma2'=>'../addons/meepo_paoma/template/mobile/images/ma-.png',
				'tutu'=>'../addons/meepo_paoma/template/mobile/images/tutu.png',
				'logo_top'=>'../addons/meepo_paoma/template/mobile/images/logo-top.png',
				'logo_bottom'=>'../addons/meepo_paoma/template/mobile/images/logo-bottom.png',
				'top_words'=>'微信扫一扫，点击菜单“<span class="activity_key">跑马</span>“即可参与',
				'waitingbg'=>'../addons/meepo_paoma/template/mobile/images/webgb.jpg',
				'app_bg_color'=>'#e84144'
			);
		}
		$cert  = "images/cert/".$_W['uniacid']."/apiclient_cert.pem";
		$key = "images/cert/".$_W['uniacid']."/apiclient_key.pem";
		$ca = "images/cert/".$_W['uniacid']."/rootca.pem";
		if(file_exists(ATTACHMENT_ROOT . '/'.$cert)){
		     $_cert = 1;
		}
		if(file_exists(ATTACHMENT_ROOT . '/'.$key)){
		     $_key = 1;
		}
		if(file_exists(ATTACHMENT_ROOT . '/'.$ca)){
		     $_ca = 1;
		}
		load()->func('tpl');
		include $this->template('form');
	}

	public function fieldsFormValidate($rid = 0) {
		//规则编辑保存时，要进行的数据验证，返回空串表示验证无误，返回其他字符串将呈现为错误提示。这里 $rid 为对应的规则编号，新增时为 0
		return '';
	}

	public function fieldsFormSubmit($rid) {
		//规则验证无误保存入库时执行，这里应该进行自定义字段的保存。这里 $rid 为对应的规则编号
		global $_W, $_GPC;
		$reid = intval($_GPC['reply_id']);
		load()->func('file');
		if(!empty($_GPC['cert'])) {
				$picurl = "images/cert/".$_W['uniacid']."/apiclient_cert.pem";
				if(file_exists(ATTACHMENT_ROOT . '/'.$picurl)){
                   file_delete($picurl);
				}
				$upload = file_write($picurl,$_GPC['cert']);
            }
            if(!empty($_GPC['key'])) {
				$picurl = "images/cert/".$_W['uniacid']."/apiclient_key.pem";
				if(file_exists(ATTACHMENT_ROOT . '/'.$picurl)){
                   file_delete($picurl);
				}
				$upload = file_write($picurl,$_GPC['key']);	
            }
            if(!empty($_GPC['ca'])) {
				$picurl = "images/cert/".$_W['uniacid']."/rootca.pem";
				if(file_exists(ATTACHMENT_ROOT . '/'.$picurl)){
                   file_delete($picurl);
				}
				$upload = file_write($picurl,$_GPC['ca']);	
            }
		$data = array(
			'rid' => $rid,
			'weid'=> $_W['uniacid'],
			'cover' => $_GPC['cover'],
			'title' => $_GPC['title'],
			'description' => $_GPC['description'],
			'loginpass'=>$_GPC['loginpass'],
			'qr'=>$_GPC['qr'],
				'bg'=>$_GPC['bg'],
			'slogan_list'=>$_GPC['slogan_list'],
			'ready_time'=>intval($_GPC['ready_time']),
				'maxshake'=>intval($_GPC['maxshake']),
				'awardsame'=>intval($_GPC['awardsame']),
				'roundbg'=>$_GPC['roundbg'],
				'roundcolor'=>$_GPC['roundcolor'],
				'logo_top'=>$_GPC['logo_top'],
				'logo_bottom'=>$_GPC['logo_bottom'],
				'appbg'=>$_GPC['appbg'],
				'acceleration'=>intval($_GPC['acceleration']),
				'shake_cup'=>$_GPC['shake_cup'],
				'gameovermusic'=>$_GPC['gameovermusic'],
					'musicurl'=>$_GPC['musicurl'],
				'ma1'=>$_GPC['ma1'],
				'ma2'=>$_GPC['ma2'],
				'tutu'=>$_GPC['tutu'],
				'_desc'=>$_GPC['_desc'],
				'appid' => trim($_GPC['appid']),
			'secret' => trim($_GPC['secret']),
			'mchid' => trim($_GPC['mchid']),
			'signkey' => trim($_GPC['signkey']),
			'ip' => trim($_GPC['ip']),
			'waitingbg'=>$_GPC['waitingbg'],
			'leafContainer_show'=>intval($_GPC['leafContainer_show']),
      'leafContainer_image1'=>$_GPC['leafContainer_image1'],
				'leafContainer_image2'=>$_GPC['leafContainer_image2'],
				'leafContainer_image3'=>$_GPC['leafContainer_image3'],
				'leafContainer_image4'=>$_GPC['leafContainer_image4'],
			'top_words'=>$_GPC['top_words'],
			'app_bg_color'=>$_GPC['app_bg_color'],
				'app_shake_img'=>$_GPC['app_shake_img'],
			
		);
		if (empty($reid)) {
			pdo_insert($this->reply_table, $data);
		} else {
			pdo_update($this->reply_table, $data, array('id' => $reid));
		}
	}

	public function ruleDeleted($rid) {
		pdo_delete($this->reply_table, array('rid' => $rid));
		pdo_delete($this->activity_table, array('rid' => $rid));
		pdo_delete($this->user_table, array('rid' => $rid));
	}

	public function settingsDisplay($settings) {
		global $_GPC, $_W;
		if(checksubmit()) {
			$cfg = array();
      $cfg['socket_url'] = $_GPC['socket_url'];
			if($this->saveSettings($cfg)) {

				message('保存成功', 'refresh');

			}
		}	
    if(empty($settings)){
		        $settings['isshow'] = 1;  
		}	    
		load()->func('tpl');	
		include $this->template('setting');

	}

}
exports.db=
	{
    host: '127.0.0.1',
    user: 'root',
    password: 'jYKJkGWc',
    database: 'we7',
    port: 3306
    };  
exports.port= 1408;
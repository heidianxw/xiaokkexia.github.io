(function() {
  if ("undefined" == typeof app || !app) var app = {
    default: {
      client: null,
      token: null,
      openID: null,
      ua: null,
      id: null,
      progress: 0,
      startShake: false,
      shakeTime: 0,
      totalTime: 10,
      socket: null,
      audio: null,
	  audio2: null,
      msg:{
        notready: "请等待主持人在大屏幕开启摇一摇活动后再加入",
        join: "加入摇一摇游戏成功，等待主持人开始游戏",
        start: "游戏开始了，小伙伴们疯狂摇起来！",
        over: "游戏结束, ",
        noresult: "您没有参与本轮游戏"
      }
    },
    init: function() {
      app.setFullScreen(320);//全屏显示
      app.scan();//
      app.initSocket();//建立socket链接
      app.initAudio();//初始化音乐
      app.bindEvent();//绑定事件
      //app.reg();
    },
    initAudio: function(){
      app.default.audio = new Audio(); 
      app.default.audio.src = "../addons/meepo_paoma/template/mobile/img/shake.mp3";
	  app.default.audio2 = new Audio(); 
      app.default.audio2.src = "../addons/meepo_paoma/template/mobile/images/shake_cutdown.mp3";
    },
    initSocket: function(){
      var query = {
        rotate_id: app_user.rotate_id,
        openid: app_user.openid,
        nickname: app_user.nickname,
        avatar: app_user.avatar
      }
      socket = new io('ws://'+socket_url+'/', {query: query});
      socket.on('error', function(data) {
        //连接失败事件，比如token校验失败
        console.log("error");
        //console.log(data);
      });
      socket.on('not ready', function(data) {
        //大屏幕尚未开启摇一摇
        console.log("not ready");
        //$(".tips").html(app.default.msg.notready);
        alert(app.default.msg.notready);
        $(".btn-close").removeClass("hide");
      });
      socket.on('refresh', function(data) {
        //大屏幕尚未开启摇一摇
        window.location.reload();
      });

      socket.on('connect', function(data) {
		console.log(app_user.nickname+'链接了');
        socket.emit('init');//发送init事件 
      });
      socket.on('init', function(data) {//监听init返回
        //手机端监听start事件开始游戏
        if(data.running==1){//中途加入 或者断线重连
            $(".hand").addClass("shake");
            $(".progress").removeClass("hide");
            $(".tips").html(app.default.msg.start);
            app.default.startShake = true;
            app.default.totalTime = data.count || 10;
			if (typeof data.openid != "undefined"){
				if(data.openid==app_user.openid){
					app.default.shakeTime = data.score;
				}
			}
            app.progress();//手机端显示进度条 同步进度条
        } else{
            $(".tips").html(app.default.msg.join);
        }
      });
      socket.on('start', function(data) {
		$(".progress .val").css('-webkit-transform', 'translateX(-100%)');
        app.default.totalTime = data.count;
		app.default.shakeTime = 0;
		app.default.startShake = false;
        app.startShake();
      });
      socket.on('game over', function(data) {
		   app.stopShake();
		   $('#dia_title').html('温馨提示');
			$('#dia_content').html('本轮结束啦，等待下一轮开始');
			$('#dia_href').html('查看结果');
			$('#dia_href').attr("href",phb_url);
			$("#dialog2").show();
		
      });
      socket.on('game no start', function(data) {
        //手机端监听game over事件，结束本轮游戏
        console.log('game no start');
      });

    },
    
    bindEvent: function() {
      var myShakeEvent = new Shake({
        threshold: 10
      });
      myShakeEvent.start();
      window.addEventListener('shake', app.shakeEvent, false);
      $(".btn-close").on("click", function(){
        wx.closeWindow();
      })
    },
    timecount: function() {

    },
    progress: function() {//当前点数/总点数
      var progress = Math.round(app.default.shakeTime / app.default.totalTime * 100);
      if (progress <= 100) {
		
        $(".progress .val").css('-webkit-transform', 'translateX(-' + (100 - progress) + '%)');
      } else {
        app.onsuccess();
      }
	  if(progress==100){
		socket.emit('player_had_done');
	  }
    },
    onsuccess: function() {
      alert("游戏完成，请关注大屏幕显示比赛结果");
    },
    startShake: function() {
     
	  app.djstime();
    },
	djstime:function (){
				app.default.audio2.play();
				var interval=setInterval(function(){
					
					app.default.audio2.play();
					$(".tips").html('倒计时'+ready_time+'秒');
					ready_time--;
					
					if(ready_time<0){
						
						 $(".hand").addClass("shake");
						 $(".progress").removeClass("hide");
						$(".tips").html(app.default.msg.start);
						app.default.startShake = true;
						clearInterval(interval);	
					}
				},1000);	
	},
    stopShake: function() {
	 // $(".overlay").removeClass("show");
      $(".hand").removeClass("shake");
      $(".progress").addClass("hide");
      app.default.startShake = false;
      app.default.shakeTime = 0;
	   //app.resetShake();
    },
    resetShake: function() {
      $(".progress").addClass("hide");
      $(".progress .val").css('-webkit-transform', 'translateX(-100%)');
    },
    shakeEvent: function() {
      if (app.default.startShake) {
	  ///if(app.default.shakeTime < app.default.totalTime){
		app.default.shakeTime++;
	  //}
		socket.emit('shake');
        app.progress();
        app.default.audio.play();
      }
    },
    scan: function() {
      app.default.ua = function(ua, appVersion, platform) {
        return {
          // win系列
          win32: platform === "Win32",
          ie: /MSIE ([^;]+)/.test(ua),
          ieMobile: window.navigator.msPointerEnabled,
          ieVersion: Math.floor((/MSIE ([^;]+)/.exec(ua) || [0, "0"])[1]),

          // ios系列
          ios: (/iphone|ipad/gi).test(appVersion),
          iphone: (/iphone/gi).test(appVersion),
          ipad: (/ipad/gi).test(appVersion),
          iosVersion: parseFloat(('' + (/CPU.*OS ([0-9_]{1,5})|(CPU like).*AppleWebKit.*Mobile/i.exec(ua) || [0, ''])[1])
            .replace('undefined', '3_2').replace('_', '.').replace('_', '')) || false,
          safari: /Version\//gi.test(appVersion) && /Safari/gi.test(appVersion),
          uiWebView: /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(ua),

          // 安卓系列
          android: (/android/gi).test(appVersion),
          androidVersion: parseFloat("" + (/android ([0-9\.]*)/i.exec(ua) || [0, ''])[1]),

          // chrome
          chrome: /Chrome/gi.test(ua),
          chromeVersion: parseInt((/Chrome\/([0-9]*)/gi.exec(ua) || [0, 0])[1], 10),

          // 内核
          webkit: /AppleWebKit/.test(appVersion),

          // 其他浏览器
          uc: appVersion.indexOf("UCBrowser") !== -1,
          Browser: / Browser/gi.test(appVersion),
          MiuiBrowser: /MiuiBrowser/gi.test(appVersion),

          // 微信
          MicroMessenger: ua.toLowerCase().match(/MicroMessenger/i) == "micromessenger",

          // 其他
          canTouch: "ontouchstart" in document
        };
      }(navigator.userAgent, navigator.appVersion, navigator.platform);
    },
    getParam: function(name, url) {
      var r = new RegExp("(\\?|#|&)" + name + "=(.*?)(#|&|$)")
      var m = (url || location.href).match(r);
      return decodeURIComponent(m ? m[2] : '');
    },
    cookie: function(name, value, options) {
      if (typeof value != 'undefined') { // name and value given, set cookie
        options = options || {};
        if (value === null) {
          value = '';
          options.expires = -1;
        }
        var expires = '';
        if (options.expires && (typeof options.expires == 'number' || options.expires.toUTCString)) {
          var date;
          if (typeof options.expires == 'number') {
            date = new Date();
            date.setTime(date.getTime() + (options.expires * 1000));
          } else {
            date = options.expires;
          }
          expires = '; expires=' + date.toUTCString(); // use expires attribute, max-age is not supported by IE
        }
        var path = options.path ? '; path=' + options.path : '';
        var domain = options.domain ? '; domain=' + options.domain : '';
        var secure = options.secure ? '; secure' : '';
        document.cookie = [name, '=', encodeURIComponent(value), expires, path, domain, secure].join('');
      } else { // only name given, get cookie
        var cookieValue = null;
        if (document.cookie && document.cookie != '') {
          var cookies = document.cookie.split(';');
          for (var i = 0; i < cookies.length; i++) {
            var cookie = cookies[i].replace(/^\s*(.*?)\s*$/, "$1"); //this.trim(cookies[i]);
            // Does this cookie string begin with the name we want?
            if (cookie.substring(0, name.length + 1) == (name + '=')) {
              cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
              break;
            }
          }
        }
        return cookieValue;
      }
    },
    setFullScreen: function(width) {
      document.body.style.width = width + 'px';
      //为了防止取不到clientWidth，这里补充一个默认值
      var clientWidth = document.documentElement.clientWidth ? document.documentElement.clientWidth : 320;
      var scale = clientWidth / width;
      //缩放页面，这里一般是放大页面
      document.body.style['-webkit-transform'] = 'scale(' + scale + ',' + scale + ')';
      document.body.style['-webkit-transform-origin'] = '0px 0px';
      //缩回放大高度，避免出现一些兼容性问题
      var height = document.body.clientHeight / scale;
      document.body.style.height = height + 'px';
    }
  }
  app.init();

//使用方法 
　　
}());
var e = function(e) {
return function(t, n) {
	var r, i;
	if (typeof t == "object" && typeof n == "object" && t && n) return r = t[e], i = n[e], r === i ? 0 : r < i ? -1 : 1;
	throw "error"
}
};

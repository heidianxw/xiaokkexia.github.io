// RequireJS Router - A scalable, lazy loading, AMD router.
//
// Version: 0.8.0
// 
// The MIT License (MIT)
// Copyright (c) 2014 Erik Ringsmuth
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
// IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
// OR OTHER DEALINGS IN THE SOFTWARE.

/*!
 * Bowser - a browser detector
 * https://github.com/ded/bowser
 * MIT License | (c) Dustin Diaz 2014
 */

/*!
 * jQuery JavaScript Library v1.11.2
 * http://jquery.com/
 *
 * Includes Sizzle.js
 * http://sizzlejs.com/
 *
 * Copyright 2005, 2014 jQuery Foundation, Inc. and other contributors
 * Released under the MIT license
 * http://jquery.org/license
 *
 * Date: 2014-12-17T15:27Z
 */

/*!
 * Sizzle CSS Selector Engine v2.2.0-pre
 * http://sizzlejs.com/
 *
 * Copyright 2008, 2014 jQuery Foundation, Inc. and other contributors
 * Released under the MIT license
 * http://jquery.org/license
 *
 * Date: 2014-12-16
 */

/* ========================================================================
 * Bootstrap: modal.js v3.3.4
 * http://getbootstrap.com/javascript/#modals
 * ========================================================================
 * Copyright 2011-2015 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 * ======================================================================== */

/*! noUiSlider - 7.0.10 - 2014-12-27 14:50:46 */

/*
 * swiper 2.5.0
 * Mobile touch slider and framework with hardware accelerated transitions
 *
 * http://www.idangero.us/sliders/swiper/
 *
 * Copyright 2010-2014, Vladimir Kharlampidi
 * The iDangero.us
 * http://www.idangero.us/
 *
 * Licensed under GPL & MIT
 *
 * Released on: March 6, 2014
 */

/**
 * CommentCoreLibrary (//github.com/jabbany/CommentCoreLibrary)
 * @license MIT
 * @author Jim Chen
 */

/** 
 * Comment Filters Module Simplified (only supports modifiers & types)
 * @license MIT
 * @author Jim Chen
 */

/*!
 * Comment Core Library CommentManager
 * @license MIT
 * @author Jim Chen
 *
 * Copyright (c) 2014 Jim Chen
 */

/** 
 * AcFun Format Parser
 * @license MIT License
 * An alternative format comment parser
 */

/** 
 * Bilibili Format Parser
 * @license MIT License
 * Takes in an XMLDoc/LooseXMLDoc and parses that into a Generic Comment List
 **/

/*!
 * jQuery lightweight Selector boilerplate
 * Original author: @ajpiano
 * Further changes, comments: @addyosmani
 * Licensed under the MIT license
 */

(function() {
	function CommentFilter() {
		this.modifiers = [], this.runtime = null, this.allowTypes = {
			1: !0,
			4: !0,
			5: !0,
			6: !0,
			7: !0,
			8: !0,
			17: !0
		}, this.doModify = function(e) {
			for (var t = 0; t < this.modifiers.length; t++) e = this.modifiers[t](e);
			return e
		}, this.beforeSend = function(e) {
			return e
		}, this.doValidate = function(e) {
			return this.allowTypes[e.mode] ? !0 : !1
		}, this.addRule = function(e) {}, this.addModifier = function(e) {
			this.modifiers.push(e)
		}, this.runtimeFilter = function(e) {
			return this.runtime == null ? e : this.runtime(e)
		}, this.setRuntimeFilter = function(e) {
			this.runtime = e
		}
	}
	function AcfunParser(e) {
		var t = [];
		try {
			var n = JSON.parse(e)
		} catch (r) {
			return console.log("Error: Could not parse json list!"), []
		}
		for (var i = 0; i < n.length; i++) {
			var s = {},
				o = n[i].c.split(",");
			if (o.length > 0) {
				s.stime = parseFloat(o[0]) * 1e3, s.color = parseInt(o[1]), s.mode = parseInt(o[2]), s.size = parseInt(o[3]), s.hash = o[4], s.date = parseInt(o[5]), s.position = "absolute", s.mode != 7 ? (s.text = n[i].m.replace(/(\/n|\\n|\n|\r\n|\\r)/g, "\n"), s.text = s.text.replace(/\r/g, "\n"), s.text = s.text.replace(/\s/g, " ")) : s.text = n[i].m;
				if (s.mode == 7) {
					try {
						var u = JSON.parse(s.text)
					} catch (r) {
						console.log("[Err] Error parsing internal data for comment"), console.log("[Dbg] " + s.text);
						continue
					}
					s.position = "relative", s.text = u.n, s.text = s.text.replace(/\ /g, " "), u.a != null ? s.opacity = u.a : s.opacity = 1, u.p != null ? (s.x = u.p.x / 1e3, s.y = u.p.y / 1e3) : (s.x = 0, s.y = 0), s.shadow = u.b, s.dur = 4e3, u.l != null && (s.moveDelay = u.l * 1e3);
					if (u.z != null && u.z.length > 0) {
						s.movable = !0, s.motion = [];
						var a = 0,
							f = {
								x: s.x,
								y: s.y,
								alpha: s.opacity,
								color: s.color
							};
						for (var l = 0; l < u.z.length; l++) {
							var c = u.z[l].l != null ? u.z[l].l * 1e3 : 500;
							a += c;
							var h = {
								x: {
									from: f.x,
									to: u.z[l].x / 1e3,
									dur: c,
									delay: 0
								},
								y: {
									from: f.y,
									to: u.z[l].y / 1e3,
									dur: c,
									delay: 0
								}
							};
							f.x = h.x.to, f.y = h.y.to, u.z[l].t !== f.alpha && (h.alpha = {
								from: f.alpha,
								to: u.z[l].t,
								dur: c,
								delay: 0
							}, f.alpha = h.alpha.to), u.z[l].c != null && u.z[l].c !== f.color && (h.color = {
								from: f.color,
								to: u.z[l].c,
								dur: c,
								delay: 0
							}, f.color = h.color.to), s.motion.push(h)
						}
						s.dur = a + (s.moveDelay ? s.moveDelay : 0)
					}
					u.r != null && u.k != null && (s.rX = u.r, s.rY = u.k)
				}
				t.push(s)
			}
		}
		return t
	}
	function BilibiliParser(e, t, n) {
		function r(e) {
			return e.replace(/\t/, "\\t")
		}
		if (e !== null) var i = e.getElementsByTagName("d");
		else {
			if (!document || !document.createElement) return [];
			if (n) {
				if (!confirm("XML Parse Error. \n Allow tag soup parsing?\n[WARNING: This is unsafe.]")) return []
			} else t = t.replace(new RegExp("</([^d])", "g"), "</disabled $1"), t = t.replace(new RegExp("</(S{2,})", "g"), "</disabled $1"), t = t.replace(new RegExp("<([^d/]W*?)", "g"), "<disabled $1"), t = t.replace(new RegExp("<([^/ ]{2,}W*?)", "g"), "<disabled $1");
			var s = document.createElement("div");
			s.innerHTML = t;
			var i = s.getElementsByTagName("d")
		}
		var o = [];
		for (var u = 0; u < i.length; u++) if (i[u].getAttribute("p") != null) {
			var a = i[u].getAttribute("p").split(",");
			if (!i[u].childNodes[0]) continue;
			var t = i[u].childNodes[0].nodeValue,
				f = {};
			f.stime = Math.round(parseFloat(a[0]) * 1e3), f.size = parseInt(a[2]), f.color = parseInt(a[3]), f.mode = parseInt(a[1]), f.date = parseInt(a[4]), f.pool = parseInt(a[5]), f.position = "absolute", a[7] != null && (f.dbid = parseInt(a[7])), f.hash = a[6], f.border = !1;
			if (f.mode < 7) f.text = t.replace(/(\/n|\\n|\n|\r\n)/g, "\n");
			else if (f.mode == 7) try {
				adv = JSON.parse(r(t)), f.shadow = !0, f.x = parseFloat(adv[0]), f.y = parseFloat(adv[1]);
				if (Math.floor(f.x) < f.x || Math.floor(f.y) < f.y) f.position = "relative";
				f.text = adv[4].replace(/(\/n|\\n|\n|\r\n)/g, "\n"), f.rZ = 0, f.rY = 0, adv.length >= 7 && (f.rZ = parseInt(adv[5], 10), f.rY = parseInt(adv[6], 10)), f.motion = [], f.movable = !1;
				if (adv.length >= 11) {
					f.movable = !0;
					var l = 500,
						c = {
							x: {
								from: f.x,
								to: parseFloat(adv[7]),
								dur: l,
								delay: 0
							},
							y: {
								from: f.y,
								to: parseFloat(adv[8]),
								dur: l,
								delay: 0
							}
						};
					adv[9] !== "" && (l = parseInt(adv[9], 10), c.x.dur = l, c.y.dur = l), adv[10] !== "" && (c.x.delay = parseInt(adv[10], 10), c.y.delay = parseInt(adv[10], 10));
					if (adv.length > 11) {
						f.shadow = adv[11], f.shadow === "true" && (f.shadow = !0), f.shadow === "false" && (f.shadow = !1), adv[12] != null && (f.font = adv[12]);
						if (adv.length > 14) {
							f.position === "relative" && (console.log("Cannot mix relative and absolute positioning"), f.position = "absolute");
							var h = adv[14],
								p = {
									x: c.x.from,
									y: c.y.from
								},
								d = [],
								v = new RegExp("([a-zA-Z])\\s*(\\d+)[, ](\\d+)", "g"),
								m = h.split(/[a-zA-Z]/).length - 1,
								g = v.exec(h);
							while (g !== null) {
								switch (g[1]) {
								case "M":
									p.x = parseInt(g[2], 10), p.y = parseInt(g[3], 10);
									break;
								case "L":
									d.push({
										x: {
											from: p.x,
											to: parseInt(g[2], 10),
											dur: l / m,
											delay: 0
										},
										y: {
											from: p.y,
											to: parseInt(g[3], 10),
											dur: l / m,
											delay: 0
										}
									}), p.x = parseInt(g[2], 10), p.y = parseInt(g[3], 10)
								}
								g = v.exec(h)
							}
							c = null, f.motion = d
						}
					}
					c !== null && f.motion.push(c)
				}
				f.dur = 2500, adv[3] < 12 && (f.dur = adv[3] * 1e3);
				var s = adv[2].split("-");
				if (s != null && s.length > 1) {
					var y = parseFloat(s[0]),
						b = parseFloat(s[1]);
					f.opacity = y, y !== b && (f.alpha = {
						from: y,
						to: b
					})
				}
			} catch (w) {
				console.log("[Err] Error occurred in JSON parsing"), console.log("[Dbg] " + t)
			} else f.mode == 8 && (f.code = t);
			f.text != null && (f.text = f.text.replace(/\u25a0/g, "█")), o.push(f)
		}
		return o
	}
	var requirejs, require, define;
	(function(e) {
		function h(e, t) {
			return f.call(e, t)
		}
		function p(e, t) {
			var n, r, i, s, o, a, f, l, h, p, d, v = t && t.split("/"),
				m = u.map,
				g = m && m["*"] || {};
			if (e && e.charAt(0) === ".") if (t) {
				v = v.slice(0, v.length - 1), e = e.split("/"), o = e.length - 1, u.nodeIdCompat && c.test(e[o]) && (e[o] = e[o].replace(c, "")), e = v.concat(e);
				for (h = 0; h < e.length; h += 1) {
					d = e[h];
					if (d === ".") e.splice(h, 1), h -= 1;
					else if (d === "..") {
						if (h === 1 && (e[2] === ".." || e[0] === "..")) break;
						h > 0 && (e.splice(h - 1, 2), h -= 2)
					}
				}
				e = e.join("/")
			} else e.indexOf("./") === 0 && (e = e.substring(2));
			if ((v || g) && m) {
				n = e.split("/");
				for (h = n.length; h > 0; h -= 1) {
					r = n.slice(0, h).join("/");
					if (v) for (p = v.length; p > 0; p -= 1) {
						i = m[v.slice(0, p).join("/")];
						if (i) {
							i = i[r];
							if (i) {
								s = i, a = h;
								break
							}
						}
					}
					if (s) break;
					!f && g && g[r] && (f = g[r], l = h)
				}!s && f && (s = f, a = l), s && (n.splice(0, a, s), e = n.join("/"))
			}
			return e
		}
		function d(t, r) {
			return function() {
				var i = l.call(arguments, 0);
				return typeof i[0] != "string" && i.length === 1 && i.push(null), n.apply(e, i.concat([t, r]))
			}
		}
		function v(e) {
			return function(t) {
				return p(t, e)
			}
		}
		function m(e) {
			return function(t) {
				s[e] = t
			}
		}
		function g(n) {
			if (h(o, n)) {
				var r = o[n];
				delete o[n], a[n] = !0, t.apply(e, r)
			}
			if (!h(s, n) && !h(a, n)) throw new Error("No " + n);
			return s[n]
		}
		function y(e) {
			var t, n = e ? e.indexOf("!") : -1;
			return n > -1 && (t = e.substring(0, n), e = e.substring(n + 1, e.length)), [t, e]
		}
		function b(e) {
			return function() {
				return u && u.config && u.config[e] || {}
			}
		}
		var t, n, r, i, s = {},
			o = {},
			u = {},
			a = {},
			f = Object.prototype.hasOwnProperty,
			l = [].slice,
			c = /\.js$/;
		r = function(e, t) {
			var n, r = y(e),
				i = r[0];
			return e = r[1], i && (i = p(i, t), n = g(i)), i ? n && n.normalize ? e = n.normalize(e, v(t)) : e = p(e, t) : (e = p(e, t), r = y(e), i = r[0], e = r[1], i && (n = g(i))), {
				f: i ? i + "!" + e : e,
				n: e,
				pr: i,
				p: n
			}
		}, i = {
			require: function(e) {
				return d(e)
			},
			exports: function(e) {
				var t = s[e];
				return typeof t != "undefined" ? t : s[e] = {}
			},
			module: function(e) {
				return {
					id: e,
					uri: "",
					exports: s[e],
					config: b(e)
				}
			}
		}, t = function(t, n, u, f) {
			var l, c, p, v, y, b = [],
				w = typeof u,
				E;
			f = f || t;
			if (w === "undefined" || w === "function") {
				n = !n.length && u.length ? ["require", "exports", "module"] : n;
				for (y = 0; y < n.length; y += 1) {
					v = r(n[y], f), c = v.f;
					if (c === "require") b[y] = i.require(t);
					else if (c === "exports") b[y] = i.exports(t), E = !0;
					else if (c === "module") l = b[y] = i.module(t);
					else if (h(s, c) || h(o, c) || h(a, c)) b[y] = g(c);
					else {
						if (!v.p) throw new Error(t + " missing " + c);
						v.p.load(v.n, d(f, !0), m(c), {}), b[y] = s[c]
					}
				}
				p = u ? u.apply(s[t], b) : undefined;
				if (t) if (l && l.exports !== e && l.exports !== s[t]) s[t] = l.exports;
				else if (p !== e || !E) s[t] = p
			} else t && (s[t] = u)
		}, requirejs = require = n = function(s, o, a, f, l) {
			if (typeof s == "string") return i[s] ? i[s](o) : g(r(s, o).f);
			if (!s.splice) {
				u = s, u.deps && n(u.deps, u.callback);
				if (!o) return;
				o.splice ? (s = o, o = a, a = null) : s = e
			}
			return o = o ||
			function() {}, typeof a == "function" && (a = f, f = l), f ? t(e, s, o, a) : setTimeout(function() {
				t(e, s, o, a)
			}, 4), n
		}, n.config = function(e) {
			return n(e)
		}, requirejs._defined = s, define = function(e, t, n) {
			t.splice || (n = t, t = []), !h(s, e) && !h(o, e) && (o[e] = [e, t, n])
		}, define.amd = {
			jQuery: !0
		}
	})(), define("almond", function() {}), define("base/router", [], function() {
		"use strict";
		var e = {},
			t = {
				statechange: [],
				routeload: []
			},
			n = "",
			r = function() {
				n != window.location.href && (n = window.location.href, i.fire("statechange"))
			},
			i = {
				init: function(t) {
					return typeof t == "undefined" && (t = {}), window.addEventListener ? (window.addEventListener("popstate", r, !1), window.addEventListener("hashchange", r, !1)) : (window.attachEvent("popstate", r), window.attachEvent("onhashchange", r)), t.loadCurrentRouteOnStateChange !== !1 && i.on("statechange", function() {
						i.loadCurrentRoute()
					}), t.fireInitialStateChange !== !1 && i.fire("statechange"), i
				},
				routes: {},
				activeRoute: {},
				registerRoutes: function(t) {
					for (var n in t) t.hasOwnProperty(n) && (i.routes[n] = t[n]);
					return i
				},
				on: function(n, r) {
					return typeof t[n] == "undefined" && (t[n] = []), t[n].push(r), i
				},
				fire: function(n) {
					if (t[n]) {
						var r = Array.prototype.slice.call(arguments, 1);
						for (var s = 0; s < t[n].length; s++) t[n][s].apply(i, r)
					}
					return i
				},
				off: function(n, r) {
					if (t[n]) {
						var s = t[n].indexOf(r);
						s !== -1 && t[n].splice(s, 1)
					}
					return i
				},
				loadCurrentRoute: function() {
					for (var t in i.routes) if (i.routes.hasOwnProperty(t)) {
						var n = i.routes[t];
						if (i.testRoute(n)) {
							i.activeRoute.active = !1, n.active = !0, i.activeRoute = n, require([n.moduleId], function(e) {
								e.init(i.routeArguments(n, window.location.href)), n.active && i.fire("routeload", e, i.routeArguments(n, window.location.href))
							});
							break
						}
					}
					return i
				},
				urlPath: function(n) {
					if (typeof e[n] != "undefined") return e[n];
					var r = n.split("/"),
						i = "/" + r.splice(3, r.length - 3).join("/"),
						s = i.split(/[\?#]/)[0],
						o = i.indexOf("#");
					if (o !== -1) {
						var u = i.substring(o).split("?")[0];
						u.substring(0, 2) === "#/" || u.substring(0, 1) === "#" ? s = u.substring(1) : u.substring(0, 3) === "#!/" && (s = u.substring(2))
					}
					return e[n] = s, s
				},
				testRoute: function(t, n) {
					var r = i.urlPath(n || window.location.href);
					if (t.path === r || t.path === "*") return !0;
					if (t.path instanceof RegExp) return t.path.test(r);
					if (t.path.indexOf("*") === -1 && t.path.indexOf(":") === -1) return !1;
					var s = r.split("/"),
						o = t.path.split("/");
					if (s.length !== o.length) return !1;
					for (var u in o) if (o.hasOwnProperty(u)) {
						var a = o[u];
						if (a !== s[u] && a !== "*" && a.charAt(0) !== ":") return !1
					}
					return !0
				},
				routeArguments: function(t, n) {
					t || (t = i.activeRoute), n || (n = window.location.href);
					var r = {},
						s = i.urlPath(n),
						o = s.split("/"),
						u = [];
					t && t.path && !(t.path instanceof RegExp) && (u = t.path.split("/"));
					for (var a in u) if (u.hasOwnProperty(a)) {
						var f = u[a];
						f.charAt(0) === ":" && (r[f.substring(1)] = o[a])
					}
					var l = n.indexOf("?"),
						c = "";
					if (l !== -1) {
						c = n.substring(l);
						var h = c.indexOf("#");
						h !== -1 && (c = c.substring(0, h))
					}
					var p = n.indexOf("#/"),
						d = n.indexOf("#!/");
					if (p !== -1 || d !== -1) {
						var v = "";
						p !== -1 ? v = n.substring(p) : v = n.substring(d), l = v.indexOf("?"), l !== -1 && (c = v.substring(l))
					}
					var m = c.substring(1).split("&");
					m.length === 1 && m[0] === "" && (m = []);
					for (var g in m) if (m.hasOwnProperty(g)) {
						var y = m[g],
							b = y.split("=");
						r[b[0]] = b.splice(1, b.length - 1).join("=")
					}
					for (var w in r) {
						var E = r[w];
						E === "true" ? r[w] = !0 : E === "false" ? r[w] = !1 : !isNaN(E) && E !== "" && E.charAt(0) !== "0" ? r[w] = +E : r[w] = decodeURIComponent(E)
					}
					return r
				}
			};
		return i
	}), !
	function() {
		function e(e, t) {
			return (/string|function/.test(typeof t) ? u : o)(e, t)
		}
		function t(e, n) {
			return "string" != typeof e && (n = typeof e, "number" === n ? e += "" : e = "function" === n ? t(e.call(e)) : ""), e
		}
		function n(e) {
			return c[e]
		}
		function r(e) {
			return t(e).replace(/&(?![\w#]+;)|[<>"']/g, n)
		}
		function i(e, t) {
			if (h(e)) for (var n = 0, r = e.length; r > n; n++) t.call(e, e[n], n, e);
			else for (n in e) t.call(e, e[n], n)
		}
		function s(e, t) {
			var n = /(\/)[^/]+\1\.\.\1/,
				r = ("./" + e).replace(/[^/]+$/, ""),
				i = r + t;
			for (i = i.replace(/\/\.\//g, "/"); i.match(n);) i = i.replace(n, "/");
			return i
		}
		function o(t, n) {
			var r = e.get(t) || a({
				filename: t,
				name: "Render Error",
				message: "Template not found"
			});
			return n ? r(n) : r
		}
		function u(e, t) {
			if ("string" == typeof t) {
				var n = t;
				t = function() {
					return new l(n)
				}
			}
			var r = f[e] = function(n) {
					try {
						return new t(n, e) + ""
					} catch (r) {
						return a(r)()
					}
				};
			return r.prototype = t.prototype = p, r.toString = function() {
				return t + ""
			}, r
		}
		function a(e) {
			var t = "{Template Error}",
				n = e.stack || "";
			if (n) n = n.split("\n").slice(0, 2).join("\n");
			else for (var r in e) n += "<" + r + ">\n" + e[r] + "\n\n";
			return function() {
				return "object" == typeof console && console.error(t + "\n\n" + n), t
			}
		}
		var f = e.cache = {},
			l = this.String,
			c = {
				"<": "&#60;",
				">": "&#62;",
				'"': "&#34;",
				"'": "&#39;",
				"&": "&#38;"
			},
			h = Array.isArray ||
		function(e) {
			return "[object Array]" === {}.toString.call(e)
		}, p = e.utils = {
			$helpers: {},
			$include: function(e, t, n) {
				return e = s(n, e), o(e, t)
			},
			$string: t,
			$escape: r,
			$each: i
		}, d = e.helpers = p.$helpers;
		e.get = function(e) {
			return f[e.replace(/^\.\//, "")]
		}, e.helper = function(e, t) {
			d[e] = t
		}, "function" == typeof define ? define("template", [], function() {
			return e
		}) : "undefined" != typeof exports ? module.exports = e : this.template = e, e("component/default/brand/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.item_num,
				i = e.img_src,
				s = "";
			return s += '<div id="brand" class="view"> <div class="brand-header"> <div class="brand-header-title fl"> <a class="brand-header-left">签到墙</a> <a class="brand-header-right"> 共<span class="brand-header-num">', s += n(r), s += '</span>人签到 </a> </div> </div> <div class="brand-content"> <canvas id="brand-canvas"></canvas> <div id="brand-avatar"></div> </div> <div id="brand-style"></div> <div class="brand-qrcode-btn"></div> <div id="brand-qrcode" class="brand-qrcode hide"> <div class="brand-qrcode-wrapper"> <img src="', s += n(i), s += '" width="460" height="460"/> </div> </div> </div>', new l(s)
		}), e("component/default/game/guess/join", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.head,
				i = "";
			return i += '<li class="game-user"> <div class="head"> <img src="', i += n(r), i += '" alt=""> </div> </li> ', new l(i)
		}), e("component/default/game/guess/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.guessQrcode,
				i = e.guessTime,
				s = "";
			return s += '<div id="guess" class="view"> <div class="game-con"> <div class="game-prepare"> <div class="game-header clearfix"> <div class="game-header-title fl"> <a class="game-header-left">石头剪刀布比赛</a> </div> </div> <div class="game-userlist"> <div class="game-userlist-nouser clearfix"> <div class="game-userlist-emo"><img src="images/default/emo.png" /></div> <div class="game-userlist-title">扫描二维码，参与摇一摇比赛</div> </div> <div class="game-userlist-con"> <ul class="clearfix"> </ul> </div> </div> </div> <div class="game-sidebar"> <div class="game-sidebar-title">扫描二维码参与</div> <div class="game-sidebar-qrcode"> <div class="game-sidebar-qrcode-inner"> <img src="', s += n(r), s += '"> </div> </div> <div class="game-sidebar-btn-con"> <div class="game-sidebar-btn-info">游戏时间(分钟)</div> <div class="game-sidebar-config clearfix"> <span class="game-sidebar-config-btn minus">-</span><span id="guessTime">', s += n(i), s += '</span><span class="game-sidebar-config-btn add">+</span> </div> <div class="game-sidebar-btn start-btn">倒计时开始</div> </div> </div> <div class="game-process hide"> <ul class="clearfix" style="position:relative;width:60%;height:100%;overflow:hidden"> </ul> <div class="process-timer">60</div> </div> </div> <div class="count-overlay"> <div class="count-body"> <div class="count-wrapper right"> <div class="count-circle rightcircle"></div> </div> <div class="count-wrapper left"> <div class="count-circle leftcircle"></div> </div> <div class="number"> <div class="count count3"><img src="images/default/number/3.png"></div> <div class="count count2"><img src="images/default/number/2.png"></div> <div class="count count1"><img src="images/default/number/1.png"></div> </div> </div> </div> <div class="game-result-overlay"> </div> </div> <!-- <div id="guess" class="view"> <div class="prepare-con"> <div class="prepare-header center"> <div class="underline"> <span class="title">扫描二维码，参与石头剪刀布比赛</span> </div> </div> <div class="prepare-content-con clearfix"> <div class="topline"> <div class="prepare-qrcode-con center"> <div class="prepare-qrcode"> <img src="', s += n(r), s += '"> </div> <div class="prepare-btn-con"> <div class="start-btn">游戏开始</div> <div class="game-config">游戏时间(分钟)：<span class="config-btn minus">-</span><span id="guessTime">', s += n(i), s += '</span><span class="config-btn add">+</span></div> </div> </div> </div> </div> </div> <div class="game-con"> <div class="process-con"> <div class="process-rank fl"> <ul class="clearfix"> </ul> </div> <div class="process-timer">38</div> </div> <div class="result-con"> <div class="result-header"> <div class="underline"> <span class="title">恭喜以下选手取得好成绩！</span> <div class="back-btn-con"> <div class="btn btn-tran">返回</div> </div> </div> </div> <div class="result-content-con clearfix"> <div class="topline" id="game_result"> </div> </div> </div> </div> </div> -->', new l(s)
		}), e("component/default/game/guess/rank", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.openID,
				i = e.top,
				s = e.index,
				o = e.head,
				u = e.name,
				a = e.score,
				f = "";
			return f += '<li class="item" id="process_item_', f += n(r), f += '" style="top:', f += n(i), f += 'px"> <div class="rank fl"> ', 3 > s ? (f += ' <span class="medal rank', f += n(s + 1), f += '"></span> ') : (f += ' <span class="num">', f += n(s + 1), f += "</span> "), f += ' </div> <div class="head fl"> <img src="', f += n(o), f += '" width="100" height="100" alt=""> </div> <div class="name"> ', f += n(u), f += ' </div> <div class="percent fr"> ', f += n(a), f += "分 </div> </li>", new l(f)
		}), e("component/default/game/guess/record", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = "";
			return s += '<div class="board"> <div class="visual"> ', n(r, function(e, t) {
				s += " ", 3 > t && (s += ' <div class="top top', s += i(t + 1), s += '"> <div class="head"> <img src="', s += i(e.head), s += '"> </div> <div class="ribbon"></div> <div class="name">', s += i(e.name), s += "</div> </div> "), s += " "
			}), s += ' <ul class="top10 clearfix"> ', n(r, function(e, t) {
				s += " ", t >= 3 && 10 > t && (s += ' <li class="fl"> <div class="head"> <img src="', s += i(e.head), s += '"> </div> <div class="name"> <div class="num">', s += i(t + 1), s += "</div> ", s += i(e.name), s += " <div> </li> "), s += " "
			}), s += ' </ul> <div class="board-footer"> <span class="show-list">查看全部排名</span> <span class="restart">重新开始</span> </div> </div> <div class="list hide"> <div class="list-body"> <table> <tr><th>排名</th><th>微信id</th></tr> ', n(r, function(e, t) {
				s += " <tr><td>", s += i(t + 1), s += "</td><td>", s += i(e.name), s += "</td></tr> "
			}), s += ' </table> </div> <div class="board-footer"> <span class="show-visual">查看Top10</span> <span class="restart">重新开始</span> </div> </div> </div>', new l(s)
		}), e("component/default/game/shake/join", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.head,
				i = "";
			return i += '<li class="game-user"> <div class="head"> <img src="', i += n(r), i += '" alt=""> </div> </li>', new l(i)
		}), e("component/default/game/shake/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.shakeQrcode,
				i = e.shakeTime,
				s = "";
			return s += '<div id="shake" class="view"> <div class="game-con"> <div class="game-prepare"> <div class="game-header clearfix"> <div class="game-header-title fl"> <a class="game-header-left">摇一摇夺奖</a> <a class="game-header-right"> 共<span class="game-header-num" id="join_num">0</span>人参与 </a> </div> </div> <div class="game-userlist"> <div class="game-userlist-nouser clearfix"> <div class="game-userlist-emo"><img src="images/default/emo.png" /></div> <div class="game-userlist-title">扫描二维码，参与摇一摇比赛</div> </div> <div class="game-userlist-con"> <ul class="clearfix"> </ul> </div> </div> </div> <div class="game-sidebar"> <div class="game-sidebar-title">扫描二维码参与</div> <div class="game-sidebar-qrcode"> <div class="game-sidebar-qrcode-inner"> <img src="', s += n(r), s += '"> </div> </div> <div class="game-sidebar-btn-con"> <div class="game-sidebar-btn-info">摇一摇次数设置</div> <div class="game-sidebar-config clearfix"> <span class="game-sidebar-config-btn minus">-</span><span id="shakeTime">', s += n(i), s += '</span><span class="game-sidebar-config-btn add">+</span> </div> <div class="game-sidebar-btn start-btn">倒计时开始</div> </div> </div> <div class="game-process hide"> <ul class="clearfix"> </ul> <div id="reset">重新开始</div> </div> </div> <div class="count-overlay"> <div class="count-body"> <div class="count-wrapper right"> <div class="count-circle rightcircle"></div> </div> <div class="count-wrapper left"> <div class="count-circle leftcircle"></div> </div> <div class="number"> <div class="count count3"><img src="images/default/number/3.png"></div> <div class="count count2"><img src="images/default/number/2.png"></div> <div class="count count1"><img src="images/default/number/1.png"></div> </div> </div> </div> <div class="game-result-overlay"> </div> </div> <!-- <div id="shake" class="view"> <div class="prepare-con"> <div class="prepare-header"> <div class="underline"> <span class="title left">扫描二维码，参与摇一摇比赛</span> <div class="fr"> <span class="title orange" id="join_num">0</span><span class="title">人参与</span> </div> </div> </div> <div class="prepare-content-con clearfix"> <div class="topline"> <div class="prepare-qrcode-con fl"> <div class="prepare-qrcode"> <img src="', s += n(r), s += '"> </div> <div class="prepare-btn-con"> <div class="start-btn">倒计时开始</div> <div class="game-config">摇一摇次数：<span class="config-btn minus">-</span><span id="shakeTime">', s += n(i), s += '</span><span class="config-btn add">+</span></div> </div> </div> </div> <div class="prepare-user-con fl"> <ul class="clearfix"> </ul> </div> </div> </div> <div class="game-con"> <div class="count-con"> <div class="count count3"></div> <div class="count count2"></div> <div class="count count1"></div> <div class="count count0"></div> </div> <div class="process-con"> <ul class="clearfix"> </ul> </div> <div class="result-con"> <div class="result-header"> <div class="underline"> <span class="title">恭喜以下选手取得好成绩！</span> <div class="back-btn-con"> <div class="btn btn-tran">返回</div> </div> </div> </div> <div class="result-content-con clearfix"> <div class="topline" id="game_result"> </div> </div> </div> </div> </div> -->', new l(s)
		}), e("component/default/game/shake/rank", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.openid,
				i = e.top,
				s = e.index,
				o = e.head,
				u = e.name,
				a = e.percent,
				f = "";
			return f += '<li class="item" id="process_item_', f += n(r), f += '" style="top:', f += n(i), f += 'px"> <div class="rank fl"> ', 3 > s ? (f += ' <span class="medal rank', f += n(s + 1), f += '"></span> ') : (f += ' <span class="num">', f += n(s + 1), f += "</span> "), f += ' </div> <div class="head fl"> <img src="', f += n(o), f += '" width="100" height="100" alt=""> </div> <div class="name"> ', f += n(u), f += ' </div> <div class="progress"> <img class="run" src="images/default/run.gif" style="right:100%"> </img> <div class="progress-wrapper"> <span class="val" style="-webkit-transform: translateX(-100%);"> </span> </div> </div> <div class="percent fr"> ', f += n(a), f += " </div> </li>", new l(f)
		}), e("component/default/game/shake/record", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = "";
			return s += '<div class="board"> <div class="visual"> ', n(r, function(e, t) {
				s += " ", 3 > t && (s += ' <div class="top top', s += i(t + 1), s += '"> <div class="head"> <img src="', s += i(e.head), s += '"> </div> <div class="ribbon"></div> <div class="name">', s += i(e.name), s += "</div> </div> "), s += " "
			}), s += ' <ul class="top10 clearfix"> ', n(r, function(e, t) {
				s += " ", t >= 3 && 10 > t && (s += ' <li class="fl"> <div class="head"> <img src="', s += i(e.head), s += '"> </div> <div class="name"> <div class="num">', s += i(t + 1), s += "</div> ", s += i(e.name), s += " <div> </li> "), s += " "
			}), s += ' </ul> <div class="board-footer"> <span class="show-list">查看全部排名</span> <span class="restart">重新开始</span> </div> </div> <div class="list hide"> <div class="list-body"> <table> <tr><th>排名</th><th>微信id</th></tr> ', n(r, function(e, t) {
				s += " <tr><td>", s += i(t + 1), s += "</td><td>", s += i(e.name), s += "</td></tr> "
			}), s += ' </table> </div> <div class="board-footer"> <span class="show-visual">查看Top10</span> <span class="restart">重新开始</span> </div> </div> </div>', new l(s)
		}), e("component/default/header/main", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, e.logourl),
				r = t.$escape,
				i = e.name,
				s = "";
			return n && (s += ' <div class="logo fl"><img src="', s += r(n), s += '" /></div> '), s += ' <div class="title fl"> <h1>', s += r(i), s += "</h1> </div> ", new l(s)
		}), e("component/default/image/detail", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.index,
				i = e.anonymous,
				s = t.$string,
				o = e.name,
				u = e.content,
				a = "";
			return a += '<div class="image clearfix" data-index="', a += n(r), a += '"> <div class="head clearfix"> ', 0 == i && (a += ' <div class="left fl">', a += s(o), a += "</div> "), a += ' <div class="right fr">', a += n(r + 1), a += '</div> </div> <div class="body"> <div class="pic"> <img src="', a += n(u), a += '" id="FullImg_', a += n(r), a += '"> </div> </div> </div>', new l(a)
		}), e("component/default/image/layout", '<div id="image" class="view"> <div class="image-con swiper-container" id="container_image"> <div class="message-loading-con"> <p>正在加载上墙消息...</p> <div class="message-loading-progress"> <div class="message-loading-progress-bar" style="width: 0%">0%</div> </div> </div> <div class="swiper-wrapper"> </div> </div> </div> '), e("component/default/layout/error", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.message,
				i = "";
			return i += ' <div class="container background_img" id="background_img"> </div>  <div class="container browser_tips hide" id="browser_tips"> <div class="row clearfix" > <div class="browser_logo fl"> <img src="images/default/logo_black.png" /> </div> <div class="browser_download"> <p>您的浏览器对大屏幕上墙效果支持不佳，或者使用的浏览器版本过低，建议更换新版chrome浏览器获得更好的上墙体验</p> <a href="http://xiazai.sogou.com/detail/34/8/6262355089742005676.html">点击去下载chrome浏览器 <img src="images/default/chrome.png"></a> </div> </div> </div>  <div class="container stage"> <div class="row header clearfix" id="header"> </div> <div class="row main clearfix"> <div class="viewport"> <div class="error"> ', i += n(r), i += ' </div> </div> <div class="blur"> <div> </div> </div> </div> </div> ', new l(i)
		}), e("component/default/layout/main", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, e.bgurl),
				r = t.$escape,
				i = "";
			return i += ' <div class="container background_img" id="background_img" ', "" != n && (i += 'style="background-image:url(', i += r(n), i += ')"'), i += '> </div>  <div class="container browser_tips hide" id="browser_tips"> <div class="row clearfix" > <div class="browser_logo fl"> <img src="images/default/logo_black.png" /> </div> <div class="browser_download"> <p>您的浏览器对大屏幕上墙效果支持不佳，或者使用的浏览器版本过低，建议更换新版chrome浏览器获得更好的上墙体验</p> <a href="http://xiazai.sogou.com/detail/34/8/6262355089742005676.html">点击去下载chrome浏览器 <img src="images/default/chrome.png"></a> </div> </div> </div>  <div class="container stage"> <div class="row header clearfix" id="header"> </div> <div class="row main clearfix"> <div class="viewport"> </div> <div class="blur"> <div ', "" != n && (i += ' style="background-image:url(', i += r(n), i += ')"'), i += '> </div> </div> </div> </div>  <div class="container hover" id="ctrlbar"> <div class="clearfix" id="slogen"> </div> <div class="clearfix" id="toolkit"> </div> </div> <div class="gallery-con invisible"> <div id="comment" class="abp"> <div id="comment-stage" class="container"></div> </div> </div>  <a id="ribbon" href="http://xianchang.qq.com/manage/index.html" target="_blank" class="hide"> <img style="position: absolute; top: 0; right: 0; border: 0; width:100px; z-index:10000" src="images/default/peel.png" title="马上创建您专属的微现场"> </a>', new l(i)
		}), e("component/default/lottery/awards", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = "";
			return n(r, function(e) {
				s += ' <li class="options" data-target="', s += i(e.id), s += '" data-option="', s += i(e.name), s += '">', s += i(e.name), s += "</li> "
			}), s += " ", new l(s)
		}), e("component/default/lottery/layout", '<div id="lottery" class="view"> <div class="draw-box"> <div class="draw-header"> <div class="draw-title">现场抽奖</div> </div> <div class="slot-box"> <div class="slot-box-wrapper clearfix"> <div class="emo"><img src="images/default/emo.png" /></div> <div class="title">求中奖，快到碗里来</div> </div> </div> </div> <div class="controll-box"> <div class="select-wrapper" id="award-selector"> <a class="select-btn"><span>请选择奖品类别</span> <i class="select-btn-arrow icon icon-arrow"></i></a> <ul class="select-options hide"> </ul> </div>  <div class="select-wrapper" id="quantity-selector"> <div class="lottery-num clearfix"> <span class="lottery-num-btn minus">-</span> <input id="lotteryNum" value="1" /> <span class="lottery-num-btn add">+</span> </div> </div> <div class="award-img-wrapper"> </div> <div class="lottery-btn"> 正在加载奖池... </div> <div class="lottery-history"> 查看中奖记录 </div> </div> </div> '), e("component/default/lottery/list", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = (e.winner, e.j, t.$string),
				o = "";
			return o += '<div id="history-swiper-con" class="history-box"> <div class="swiper-wrapper"> ', n(r, function(e) {
				o += ' <div class="swiper-slide"> <div class="history-row clearfix"> <div class="history-award fl"> <img width="250" height="250" src="', o += i(e.image), o += '"> <p>', o += i(e.award), o += '</p> </div> <div class="history-winner fl"> <ul class="history-winner-list clearfix"> ', n(e.winner, function(e) {
					o += ' <li class="history-winner-item fl clearfix"> <div class="history-winner-avatar fl"> ', e.head ? (o += ' <img src="', o += i(e.head), o += '" width="100" height="100" alt=""> ') : o += ' <img src="images/default/avatar.png" width="100" height="100" alt=""> ', o += ' </div> <div class="history-winner-name fl">', o += s(e.name), o += "</div> </li> "
				}), o += " </ul> </div> </div> </div> "
			}), o += ' </div> <div class="winners-prev"><i class="icon icon-arrow-left"></i></div> <div class="winners-next"><i class="icon icon-arrow-right"></i></div> </div> <!-- <div class="history-overlay"> <div class="history-list"> <div class="history-header"> <span>获奖名单</span> </div> <div id="history-swiper-con"> <div class="swiper-wrapper"> ', n(r, function(e) {
				o += ' <div class="swiper-slide"> <div class="history-row clearfix"> <div class="history-award fl"> <img width="250" height="250" src="', o += i(e.imageurl), o += '"> <p>', o += i(e.award), o += '</p> </div> <div class="history-winner fl"> <ul class="history-winner-list clearfix"> ', n(e.winner, function(e) {
					o += ' <li class="history-winner-item fl clearfix"> <div class="history-winner-avatar fl"> ', e.head ? (o += ' <img src="', o += i(e.head), o += '" width="100" height="100" alt=""> ') : o += ' <img src="images/default/avatar.png" width="100" height="100" alt=""> ', o += ' </div> <div class="history-winner-name fl">', o += s(e.nick), o += "</div> </li> "
				}), o += " </ul> </div> </div> </div> "
			}), o += ' </div> </div> <div class="icon icon-arrow-left arrow-left"></div> <div class="icon icon-arrow-right arrow-right"></div> </div> </div> -->', new l(o)
		}), e("component/default/lottery/pools", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = t.$string,
				o = "";
			return n(r, function(e) {
				o += ' <li class="options" data-target="', o += i(e.id), o += '" data-option="', o += i(e.name), o += '">', o += s(e.name), o += "</li> "
			}), o += " ", new l(o)
		}), e("component/default/lottery/quantity", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = "";
			return n(r, function(e, t) {
				s += ' <li class="options" data-target="', s += i(t + 1), s += '" data-option="', s += i(t + 1), s += '">', s += i(t + 1), s += "</li> "
			}), s += " ", new l(s)
		}), e("component/default/lottery/single", '<div class="slot-box-single"> <ul> <li class="item">1</li> <li class="item">2</li> <li class="item">3</li> <li class="item">4</li> <li class="item">5</li> <li class="item">6</li> <li class="item">7</li> <li class="item">8</li> </ul> </div> '), e("component/default/lottery/slot", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, e.inner),
				r = t.$escape,
				i = e.item,
				s = t.$string,
				o = "";
			return n ? (o += ' <div class="slot-avatar"> <img src="', o += r(i.head), o += '" class="lotteryImg" width="150" height="150" alt=""> </div> <div class="slot-shadow"></div> <div class="slot-name">', o += s(i.name), o += "</div> ") : (o += ' <div class="slot-box-item"> <div class="slot-avatar"> <img src="', o += r(i.head), o += '" class="lotteryImg" width="150" height="150" alt=""> </div> <div class="slot-shadow"></div> <div class="slot-name">', o += s(i.name), o += "</div> </div> "), o += " ", new l(o)
		}), e("component/default/message/detail", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.index,
				i = e.height,
				s = e.head,
				o = e.anonymous,
				u = t.$string,
				a = e.name,
				f = e.fontsize,
				c = e.type,
				h = e.content,
				p = "";
			return p += '<div class="detail clearfix" data-index="', p += n(r), p += '" style="height:', p += n(i), p += 'px"> <div class="left fl"> <div class="avatar"> <img id="userhead_', p += n(r), p += '" src="', p += n(s), p += '" alt=""> </div> </div> <div class="right"> ', 0 == o ? (p += ' <div class="name">', p += u(a), p += '</div> <div class="message" style="font-size:', p += n(f), p += "px; line-height:", p += n(f + 10), p += 'px"> ', 0 == c ? (p += " ", p += u(h), p += " ") : (p += ' <img src="', p += n(h), p += '" > '), p += " </div> ") : (p += ' <div class="message h100" style="font-size:', p += n(f), p += "px; line-height:", p += n(f + 10), p += 'px"> ', 0 == c ? (p += " ", p += u(h), p += " ") : (p += ' <img src="', p += n(h), p += '" > '), p += " </div> "), p += ' </div> <div class="corner"></div> <div class="index">', p += n(r + 1), p += '</div> <div class="close"><i class="icon icon-close"></i></div> </div> ', new l(p)
		}), e("component/default/message/item", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.index,
				i = e.height,
				s = e.head,
				o = e.anonymous,
				u = t.$string,
				a = e.name,
				f = e.fontsize,
				c = e.type,
				h = e.content,
				p = "";
			return p += '<div class="item clearfix" data-index="', p += n(r), p += '" style="height:', p += n(i), p += 'px"> <div class="left fl"> <div class="avatar"> <img id="userhead_', p += n(r), p += '" src="', p += n(s), p += '" alt=""> </div> </div> <div class="right"> ', 0 == o ? (p += ' <div class="name">', p += u(a), p += '</div> <div class="message" style="font-size:', p += n(f), p += "px; line-height:", p += n(f + 10), p += 'px"> ', 0 == c ? (p += " ", p += u(h), p += " ") : (p += ' <img src="', p += n(h), p += '" > '), p += " </div> ") : (p += ' <div class="message h100" style="font-size:', p += n(f), p += "px; line-height:", p += n(f + 10), p += 'px"> ', 0 == c ? (p += " ", p += u(h), p += " ") : (p += ' <img src="', p += n(h), p += '" > '), p += " </div> "), p += ' </div> <div class="corner"></div> <div class="index">', p += n(r + 1), p += "</div> </div> ", new l(p)
		}), e("component/default/message/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.wxqrcode,
				i = e.wxname,
				s = "";
			return s += '<div id="message" class="view clearfix"> <div class="sidebar fl" id="sidebar"> <div class="sb-wrapper"> <div class="c-wrapper" id="mask_btn"> <img src="', s += n(r), s += '" /> </div> <p class="comment account"><span>', s += n(i), s += '</span></p> <p class="comment"> ', s += i ? " 关注微信号 " : " 扫描二维码 ", s += ' </p> <p class="comment">参与互动上墙</p> </div> </div> <div id="mask" class="mask hide"> <div class="mask-wrapper"> <img src="', s += n(r), s += '" width="460" height="460"/> </div> </div> <div id="message_wrapper" class="fl"> <div class="message-loading-con"> <p>正在加载上墙消息...</p> <div class="message-loading-progress"> <div class="message-loading-progress-bar" style="width: 0%">0%</div> </div> </div> <div class="message-con swiper-container" id="container_list"> <div class="swiper-wrapper"> </div> </div> <div class="message-con swiper-container hide" id="container_detail"> <div class="swiper-wrapper"> </div> </div> </div> </div> ', new l(s)
		}), e("component/default/message/sidebar", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.wxqrcode,
				i = e.wxname,
				s = t.$string,
				o = "";
			return o += '<div class="sb-wrapper"> <div class="c-wrapper" id="mask_btn"> <img src="', o += n(r), o += '" /> </div> <p class="comment"> ', o += i ? " 关注微信号 " : " 扫描二维码 ", o += ' </p> <p class="comment account"><span>', o += s(i), o += '</span></p> <p class="comment">参与互动上墙</p> </div>', new l(o)
		}), e("component/default/modal/alert", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, e.title),
				r = t.$escape,
				i = e.message,
				s = "";
			return s += '<div id="alert" class="modal fade"> <div class="modal-dialog modal-sm"> <div class="modal-content"> <div class="modal-header"> <h4 class="modal-title">', s += n ? r(n) : "提示", s += '<h4> </div> <div class="modal-body" style="min-height:200px"> ', s += r(i), s += ' </div> <div class="modal-footer"> <a class="btn btn-primary" data-dismiss="modal">确定</a> </div> </div> </div> </div> ', new l(s)
		}), e("component/default/modal/game", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.campaign_id,
				i = "";
			return i += '<div id="game" class="modal fade"> <div class="modal-dialog"> <div class="modal-content"> <div class="modal-header"> <h4 class="modal-title">游戏</h4> </div> <div class="modal-body"> <div class="game-wrapper clearfix"> <ul> <li class="game"> <div class="pic"> <img src="images/default/game/shake.jpg" / > <div class="button"> <span>摇一摇比赛</span> <a class="btn btn-primary remodal-cancel modal-close" app-jump="#', i += n(r), i += '/shake">开始游戏</a> </div> </div> </li> <li class="game"> <div class="pic"> <img src="images/default/game/guess.jpg" / > <div class="button"> <span>剪刀石头布</span> <a class="btn btn-primary remodal-cancel modal-close" app-jump="#', i += n(r), i += '/guess">开始游戏</a> </div> </div> </li> <li class="game" > <div class="pic"> <img src="images/default/game/default.jpg" / > </div> </li> </ul> </div> </div> <div class="modal-footer"> <a class="btn btn-default" data-dismiss="modal">返回</a> </div> </div> </div> </div> ', new l(i)
		}), e("component/default/modal/setting", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, e.theme),
				r = t.$escape,
				i = e.bgurl,
				s = e.interval,
				o = e.anonymous,
				u = "";
			return u += '<div id="setting" class="modal fade"> <div class="modal-dialog"> <div class="modal-content"> <div class="modal-header"> <h4 class="modal-title">设置</h4> </div> <div class="modal-body"> <div class="tab-wrapper"> <ul class="clearfix"> <li class="tab active"><a href="javascript:;">设置</a></li> </ul> </div> <div id="tab-swiper"> <!-- <div class="slide active"> <ul> <li class="theme ', "default" == n && (u += "active"), u += '" data-theme="default"> <div class="pic"> <img src="images/default/demo.jpg" / > <div class="name">商务会议</div> </div> <div class="check"></div> </li> <li class="theme ', "festival" == n && (u += "active"), u += '" data-theme="festival"> <div class="pic"> <img src="images/festival/demo.jpg" / > <div class="name">节日盛宴</div> </div> <div class="check"></div> </li> <li class="theme ', "wedding" == n && (u += "active"), u += '" data-theme="wedding"> <div class="pic"> <img src="images/wedding/demo.jpg" / > <div class="name">婚庆典礼</div> </div> <div class="check"></div> </li> <li class="theme ', "ds6" == n && (u += "active"), u += '" data-theme="ds6"> <div class="pic"> <img src="images/ds6/thumb.jpg" / > <div class="name">商业展会</div> </div> <div class="check"></div> </li> </ul> <input type="hidden" id="theme-value" value="', u += r(n), u += '"/> </div> <div class="slide"> <div class="upload-wrapper clearfix"> <div class="upload-img-box"> <img src="', u += r(i), u += '" /> </div> <div class="upload-img-select"> <div class="upload-btn btn btn-default"> <span>点击上传图片</span> <input id="upload-img-fileinput" type="file" title="点击更换图片" value="', u += r(i), u += '" /> </div> <div class="clear-btn btn btn-default"> <span>使用默认背景</span> </div> <p>*建议上传图片尺寸1920*1080，大小3M以内的图片</p> </div> <input type="hidden" id="bgurl-value" value="', u += r(i), u += '"/> </div> </div> --> <div class="slide active"> <div class="item"> <div class="inner-header">账号设置</div> <div class="inner-content"> <a class="btn btn-default" id="logout">更换账号</a> </div> </div> <!-- <div class="item"> <div class="inner-header">消息墙控制</div> <div class="inner-content"> <div class="form-group clearfix"> <label for="messageScrollTime" class="fl">滚动时间</label> <div id="messageScrollTimeBar" class="fl scrollbar"> </div> <div class="scrollval fl"></div> </div> <div class="form-group clearfix"> <label for="messageInterval" class="fl">循环播放</label> <div class="fl"> <label for="#" class="ui-switch"> ', u += s ? ' <input type="checkbox" id="messageInterval" checked="true" /> ' : ' <input type="checkbox" id="messageInterval" /> ', u += ' </label> </div> <div class="fl desc"> 消息从最后一条自动滚至第一条循环播放 </div> </div> <div class="form-group clearfix"> <label for="messageAnonymous" class="fl">匿名消息</label> <div class="fl"> <label for="#" class="ui-switch"> ', u += o ? ' <input type="checkbox" id="messageAnonymous" checked="true" /> ' : ' <input type="checkbox" id="messageAnonymous" /> ', u += ' </label> </div> <div class="fl desc"> 开启匿名消息以后将使用随机头像并匿名 </div> </div> </div> </div> --> </div> </div> </div> <div class="modal-footer"> <a class="btn btn-default" data-dismiss="modal">返回</a>  </div> </div> </div> </div> ', new l(u)
		}), e("component/default/modal/winners", '<div id="history" class="modal fade"> <div class="modal-dialog" style="width:80%;"> <div class="modal-content"> <div class="modal-header"> <h4 class="modal-title">获奖名单</h4> </div> <div class="modal-body"> <div class="modal-loading"> <i class="icon icon-loading"></i> 数据加载中... </div> </div> <div class="modal-footer"> <a class="btn btn-default" data-dismiss="modal">返回</a> </div> </div> </div> </div>'), e("component/default/signin/item", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.head,
				i = t.$string,
				s = e.name,
				o = "";
			return o += '<div class="signin-item"> <div class="signin-item-img"><img src="', o += n(r), o += '" /></div> <span class="signin-item-text">', o += i(s), o += "</span> </div>", new l(o)
		}), e("component/default/signin/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.item_num,
				i = e.img_src,
				s = "";
			return s += '<div id="signin" class="view"> <div class="signin-con"> <div class="signin-header clearfix"> <div class="signin-header-title fl"> <a class="signin-header-left">签到墙</a> <a class="signin-header-right"> 共<span class="signin-header-num">', s += n(r), s += '</span>人签到 </a> </div> </div> <div class="signin-content"></div> </div> <div class="signin-qrcode-btn"></div> <div id="signin-qrcode" class="signin-qrcode hide"> <div class="signin-qrcode-wrapper"> <img src="', s += n(i), s += '" width="460" height="460"/> </div> </div> </div>', new l(s)
		}), e("component/default/slogen/main", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.slogans,
				i = (e.item, e.$index, t.$escape),
				s = "";
			return s += '<div class="slogen-bg"> <div class="slogen-wrapper" id="slogen-swiper-con"> <div class="swiper-wrapper"> ', n(r, function(e) {
				s += ' <div class="swiper-slide"> <div class="slogen-row clearfix"> <p>', s += i(e), s += "</p> </div> </div> "
			}), s += " </div> </div> </div>", new l(s)
		}), e("component/default/toolkit/main", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.campaign_id,
				i = "";
			return i += '<div class="toolkit-bg"> <div class="toolkit-wrapper row"> <div class="nav-bar fl"> <ul> <li app-jump="#', i += n(r), i += '/signin" class="signin link tooltip tooltip-effect-2"> <i class="icon icon-signin"></i> <div class="tooltip-content"><span>签到</span></div> </li> <li app-jump="#', i += n(r), i += '/message" class="wall link tooltip tooltip-effect-2"> <i class="icon icon-message"></i> <div class="tooltip-content"><span>消息上墙</span></div> </li> <li app-jump="#', i += n(r), i += '/image" class="wall link tooltip tooltip-effect-2"> <i class="icon icon-image"></i> <div class="tooltip-content"><span>纯图模式</span></div> </li> <li app-bullet="enable" id="shoot" class="tooltip tooltip-effect-2"> <i class="icon icon-bullet"></i> <div class="tooltip-content"><span>弹幕开关</span></div> </li> <li app-jump="#', i += n(r), i += '/lottery" class="lottery link tooltip tooltip-effect-2"> <i class="icon icon-lottery"></i> <div class="tooltip-content"><span>抽奖</span></div> </li> <li app-jump="#', i += n(r), i += '/vote" class="vote link tooltip tooltip-effect-2"> <i class="icon icon-vote"></i> <div class="tooltip-content"><span>投票</span></div> </li> <li app-jump="#', i += n(r), i += '/shake" class="game link tooltip tooltip-effect-2"> <i class="icon icon-game"></i> <div class="tooltip-content"><span>摇一摇</span></div> </li> <li id="fullscreen" class="tooltip tooltip-effect-2"> <i class="icon icon-full-screen fullScreen"></i> <div class="tooltip-content"><span>全屏</span></div> </li> <li id="setting-btn" class="tooltip tooltip-effect-2"> <i class="icon icon-setting"></i> <div class="tooltip-content"><span>设置</span></div> </li> </ul> </div> <div class="action-bar fr hide"> <ul> <li message-action="backward" class="tooltip tooltip-effect-2"> <i class="icon icon-backward"></i> <div class="tooltip-content"><span>第一条</span></div> </li> <li message-action="step-backward" class="tooltip tooltip-effect-2"> <i class="icon icon-step-backward"></i> <div class="tooltip-content"><span>向上一条</span></div> </li> <li message-action="play" class="tooltip tooltip-effect-2"> <i class="icon icon-pause"></i> <div class="tooltip-content"><span>开始/暂停</span></div> </li> <li message-action="step-forward" class="tooltip tooltip-effect-2"> <i class="icon icon-step-forward"></i> <div class="tooltip-content"><span>向下一条</span></div> </li> <li message-action="forward" class="tooltip tooltip-effect-2"> <i class="icon icon-forward"></i> <div class="tooltip-content"><span>最后一条</span></div> </li> </ul> </div> </div> </div>', new l(i)
		}), e("component/default/vote/column", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.item,
				i = "";
			return i += '<div class="vote-column" id="vote-column-', i += n(r.item_id), i += '"> <div class="vote-column-con"> <div class="vote-column-count" style="color:', i += n(r.color), i += "; bottom:", i += n(r.height + 15), i += 'px;">', i += n(r.count), i += "票 ( ", i += n(r.percent), i += '% )</div> <div class="vote-column-bar" style="background-color:', i += n(r.color), i += "; height: ", i += n(r.height), i += 'px;"></div> </div> <div class="vote-column-title">', i += n(r.name), i += "</div> </div>", new l(i)
		}), e("component/default/vote/count", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.item,
				i = "";
			return i += n(r.count), i += "票 ( ", i += n(r.percent), i += "% )", new l(i)
		}), e("component/default/vote/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.item, e.index, t.$escape),
				s = t.$string,
				o = e.qrcode,
				u = "";
			return u += '<div id="vote" class="view"> <div class="vote-con" id="vote_list"> <div class="swiper-wrapper"> ', n(r, function(e) {
				u += ' <div class="swiper-slide"> <div class="vote" id="vote-', u += i(e.vote_id), u += '" data-index="', u += i(e.vote_id), u += '"> <div class="vote-header clearfix"> <div class="vote-header-title fl"> <a class="vote-header-left">', u += s(e.name), u += '</a> <a class="vote-header-right"> 共<span class="vote-header-num vote-title-num">0</span>人参与 </a> </div> </div> <div class="vote-content vote-content"> <div class="vote-scrollbar-move"> </div> </div> </div> </div> '
			}), u += ' </div> </div> <div class="vote-prev"><i class="icon icon-arrow-left"></i></div> <div class="vote-next"><i class="icon icon-arrow-right"></i></div> <div class="vote-qrcode-btn"></div> <div id="vote-qrcode" class="vote-qrcode hide"> <div class="vote-qrcode-wrapper"> <img width="460" height="460" src="', u += i(o), u += '"/> </div> </div> <div class="vote-order"> <input type="checkbox" class="order-switch" name="order-switch"> <label for="order-switch">排序</label> </div> </div>', new l(u)
		}), e("component/ds6/brand/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.item_num,
				i = e.img_src,
				s = "";
			return s += '<div id="brand" class="view"> <div class="brand-header"> <div class="brand-header-title fl"> <a class="brand-header-left">签到墙</a> <a class="brand-header-right"> 共<span class="brand-header-num">', s += n(r), s += '</span>人签到 </a> </div> </div> <div class="brand-content"> <canvas id="brand-canvas"></canvas> <div id="brand-avatar"></div> </div> <div id="brand-style"></div> <div class="brand-qrcode-btn"></div> <div id="brand-qrcode" class="brand-qrcode hide"> <div class="brand-qrcode-wrapper"> <img src="', s += n(i), s += '" width="460" height="460"/> </div> </div> </div>', new l(s)
		}), e("component/ds6/game/guess/join", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.head,
				i = "";
			return i += '<li class="game-user"> <div class="head"> <img src="', i += n(r), i += '" alt=""> </div> </li> ', new l(i)
		}), e("component/ds6/game/guess/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.guessQrcode,
				i = e.guessTime,
				s = "";
			return s += '<div id="guess" class="view"> <div class="game-con"> <div class="game-prepare"> <div class="game-header clearfix"> <div class="game-header-title fl"> <a class="game-header-left">石头剪刀布比赛</a> </div> </div> <div class="game-userlist"> <div class="game-userlist-nouser clearfix"> <div class="game-userlist-emo"><img src="images/default/emo.png" /></div> <div class="game-userlist-title">扫描二维码，参与摇一摇比赛</div> </div> <div class="game-userlist-con"> <ul class="clearfix"> </ul> </div> </div> </div> <div class="game-sidebar"> <div class="game-sidebar-title">扫描二维码参与</div> <div class="game-sidebar-qrcode"> <div class="game-sidebar-qrcode-inner"> <img src="', s += n(r), s += '"> </div> </div> <div class="game-sidebar-btn-con"> <div class="game-sidebar-btn-info">游戏时间(分钟)</div> <div class="game-sidebar-config clearfix"> <span class="game-sidebar-config-btn minus">-</span><span id="guessTime">', s += n(i), s += '</span><span class="game-sidebar-config-btn add">+</span> </div> <div class="game-sidebar-btn start-btn">倒计时开始</div> </div> </div> <div class="game-process hide"> <ul class="clearfix" style="position:relative;width:60%;height:100%;overflow:hidden"> </ul> <div class="process-timer">60</div> </div> </div> <div class="count-overlay"> <div class="count-body"> <div class="count-wrapper right"> <div class="count-circle rightcircle"></div> </div> <div class="count-wrapper left"> <div class="count-circle leftcircle"></div> </div> <div class="number"> <div class="count count3"><img src="images/default/number/3.png"></div> <div class="count count2"><img src="images/default/number/2.png"></div> <div class="count count1"><img src="images/default/number/1.png"></div> </div> </div> </div> <div class="game-result-overlay"> </div> </div> <!-- <div id="guess" class="view"> <div class="prepare-con"> <div class="prepare-header center"> <div class="underline"> <span class="title">扫描二维码，参与石头剪刀布比赛</span> </div> </div> <div class="prepare-content-con clearfix"> <div class="topline"> <div class="prepare-qrcode-con center"> <div class="prepare-qrcode"> <img src="', s += n(r), s += '"> </div> <div class="prepare-btn-con"> <div class="start-btn">游戏开始</div> <div class="game-config">游戏时间(分钟)：<span class="config-btn minus">-</span><span id="guessTime">', s += n(i), s += '</span><span class="config-btn add">+</span></div> </div> </div> </div> </div> </div> <div class="game-con"> <div class="process-con"> <div class="process-rank fl"> <ul class="clearfix"> </ul> </div> <div class="process-timer">38</div> </div> <div class="result-con"> <div class="result-header"> <div class="underline"> <span class="title">恭喜以下选手取得好成绩！</span> <div class="back-btn-con"> <div class="btn btn-tran">返回</div> </div> </div> </div> <div class="result-content-con clearfix"> <div class="topline" id="game_result"> </div> </div> </div> </div> </div> -->', new l(s)
		}), e("component/ds6/game/guess/rank", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.openID,
				i = e.top,
				s = e.index,
				o = e.head,
				u = e.name,
				a = e.score,
				f = "";
			return f += '<li class="item" id="process_item_', f += n(r), f += '" style="top:', f += n(i), f += 'px"> <div class="rank fl"> ', 3 > s ? (f += ' <span class="medal rank', f += n(s + 1), f += '"></span> ') : (f += ' <span class="num">', f += n(s + 1), f += "</span> "), f += ' </div> <div class="head fl"> <img src="', f += n(o), f += '" width="100" height="100" alt=""> </div> <div class="name"> ', f += n(u), f += ' </div> <div class="percent fr"> ', f += n(a), f += "分 </div> </li>", new l(f)
		}), e("component/ds6/game/guess/record", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = "";
			return s += '<div class="board"> <div class="visual"> ', n(r, function(e, t) {
				s += " ", 3 > t && (s += ' <div class="top top', s += i(t + 1), s += '"> <div class="head"> <img src="', s += i(e.head), s += '"> </div> <div class="ribbon"></div> <div class="name">', s += i(e.name), s += "</div> </div> "), s += " "
			}), s += ' <ul class="top10 clearfix"> ', n(r, function(e, t) {
				s += " ", t >= 3 && 10 > t && (s += ' <li class="fl"> <div class="head"> <img src="', s += i(e.head), s += '"> </div> <div class="name"> <div class="num">', s += i(t + 1), s += "</div> ", s += i(e.name), s += " <div> </li> "), s += " "
			}), s += ' </ul> <div class="board-footer"> <span class="show-list">查看全部排名</span> <span class="restart">重新开始</span> </div> </div> <div class="list hide"> <div class="list-body"> <table> <tr><th>排名</th><th>微信id</th></tr> ', n(r, function(e, t) {
				s += " <tr><td>", s += i(t + 1), s += "</td><td>", s += i(e.name), s += "</td></tr> "
			}), s += ' </table> </div> <div class="board-footer"> <span class="show-visual">查看Top10</span> <span class="restart">重新开始</span> </div> </div> </div>', new l(s)
		}), e("component/ds6/game/shake/join", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.head,
				i = "";
			return i += '<li class="game-user"> <div class="head"> <img src="', i += n(r), i += '" alt=""> </div> </li>', new l(i)
		}), e("component/ds6/game/shake/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.shakeQrcode,
				i = e.shakeTime,
				s = "";
			return s += '<div id="shake" class="view"> <div class="game-con"> <div class="game-prepare"> <div class="game-header clearfix"> <div class="game-header-title fl"> <a class="game-header-left">摇一摇夺奖</a> <a class="game-header-right"> 共<span class="game-header-num" id="join_num">0</span>人参与 </a> </div> </div> <div class="game-userlist"> <div class="game-userlist-nouser clearfix"> <div class="game-userlist-emo"><img src="images/default/emo.png" /></div> <div class="game-userlist-title">扫描二维码，参与摇一摇比赛</div> </div> <div class="game-userlist-con"> <ul class="clearfix"> </ul> </div> </div> </div> <div class="game-sidebar"> <div class="game-sidebar-title">扫描二维码参与</div> <div class="game-sidebar-qrcode"> <div class="game-sidebar-qrcode-inner"> <img src="', s += n(r), s += '"> </div> </div> <div class="game-sidebar-btn-con"> <div class="game-sidebar-btn-info">摇一摇次数设置</div> <div class="game-sidebar-config clearfix"> <span class="game-sidebar-config-btn minus">-</span><span id="shakeTime">', s += n(i), s += '</span><span class="game-sidebar-config-btn add">+</span> </div> <div class="game-sidebar-btn start-btn">倒计时开始</div> </div> </div> <div class="game-process hide"> <ul class="clearfix"> </ul> <div id="reset">重新开始</div> </div> </div> <div class="count-overlay"> <div class="count-body"> <div class="count-wrapper right"> <div class="count-circle rightcircle"></div> </div> <div class="count-wrapper left"> <div class="count-circle leftcircle"></div> </div> <div class="number"> <div class="count count3"><img src="images/default/number/3.png"></div> <div class="count count2"><img src="images/default/number/2.png"></div> <div class="count count1"><img src="images/default/number/1.png"></div> </div> </div> </div> <div class="game-result-overlay"> </div> </div> <!-- <div id="shake" class="view"> <div class="prepare-con"> <div class="prepare-header"> <div class="underline"> <span class="title left">扫描二维码，参与摇一摇比赛</span> <div class="fr"> <span class="title orange" id="join_num">0</span><span class="title">人参与</span> </div> </div> </div> <div class="prepare-content-con clearfix"> <div class="topline"> <div class="prepare-qrcode-con fl"> <div class="prepare-qrcode"> <img src="', s += n(r), s += '"> </div> <div class="prepare-btn-con"> <div class="start-btn">倒计时开始</div> <div class="game-config">摇一摇次数：<span class="config-btn minus">-</span><span id="shakeTime">', s += n(i), s += '</span><span class="config-btn add">+</span></div> </div> </div> </div> <div class="prepare-user-con fl"> <ul class="clearfix"> </ul> </div> </div> </div> <div class="game-con"> <div class="count-con"> <div class="count count3"></div> <div class="count count2"></div> <div class="count count1"></div> <div class="count count0"></div> </div> <div class="process-con"> <ul class="clearfix"> </ul> </div> <div class="result-con"> <div class="result-header"> <div class="underline"> <span class="title">恭喜以下选手取得好成绩！</span> <div class="back-btn-con"> <div class="btn btn-tran">返回</div> </div> </div> </div> <div class="result-content-con clearfix"> <div class="topline" id="game_result"> </div> </div> </div> </div> </div> -->', new l(s)
		}), e("component/ds6/game/shake/rank", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.openid,
				i = e.top,
				s = e.index,
				o = e.head,
				u = e.name,
				a = e.percent,
				f = "";
			return f += '<li class="item" id="process_item_', f += n(r), f += '" style="top:', f += n(i), f += 'px"> <div class="rank fl"> ', 3 > s ? (f += ' <span class="medal rank', f += n(s + 1), f += '"></span> ') : (f += ' <span class="num">', f += n(s + 1), f += "</span> "), f += ' </div> <div class="head fl"> <img src="', f += n(o), f += '" width="100" height="100" alt=""> </div> <div class="name"> ', f += n(u), f += ' </div> <div class="progress"> <img class="run" src="images/default/run.gif" style="right:100%"> </img> <div class="progress-wrapper"> <span class="val" style="-webkit-transform: translateX(-100%);"> </span> </div> </div> <div class="percent fr"> ', f += n(a), f += " </div> </li>", new l(f)
		}), e("component/ds6/game/shake/record", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = "";
			return s += '<div class="board"> <div class="visual"> ', n(r, function(e, t) {
				s += " ", 3 > t && (s += ' <div class="top top', s += i(t + 1), s += '"> <div class="head"> <img src="', s += i(e.head), s += '"> </div> <div class="ribbon"></div> <div class="name">', s += i(e.name), s += "</div> </div> "), s += " "
			}), s += ' <ul class="top10 clearfix"> ', n(r, function(e, t) {
				s += " ", t >= 3 && 10 > t && (s += ' <li class="fl"> <div class="head"> <img src="', s += i(e.head), s += '"> </div> <div class="name"> <div class="num">', s += i(t + 1), s += "</div> ", s += i(e.name), s += " <div> </li> "), s += " "
			}), s += ' </ul> <div class="board-footer"> <span class="show-list">查看全部排名</span> <span class="restart">重新开始</span> </div> </div> <div class="list hide"> <div class="list-body"> <table> <tr><th>排名</th><th>微信id</th></tr> ', n(r, function(e, t) {
				s += " <tr><td>", s += i(t + 1), s += "</td><td>", s += i(e.name), s += "</td></tr> "
			}), s += ' </table> </div> <div class="board-footer"> <span class="show-visual">查看Top10</span> <span class="restart">重新开始</span> </div> </div> </div>', new l(s)
		}), e("component/ds6/header/main", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, e.logourl),
				r = t.$escape,
				i = e.name,
				s = "";
			return n && (s += ' <div class="logo fl"><img src="', s += r(n), s += '" /></div> '), s += ' <div class="title fl"> <h1>', s += r(i), s += "</h1> </div> ", new l(s)
		}), e("component/ds6/image/detail", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.index,
				i = e.anonymous,
				s = t.$string,
				o = e.name,
				u = e.content,
				a = "";
			return a += '<div class="image clearfix" data-index="', a += n(r), a += '"> <div class="head clearfix"> ', 0 == i && (a += ' <div class="left fl">', a += s(o), a += "</div> "), a += ' <div class="right fr">', a += n(r + 1), a += '</div> </div> <div class="body"> <div class="pic"> <img src="', a += n(u), a += '" id="FullImg_', a += n(r), a += '"> </div> </div> </div>', new l(a)
		}), e("component/ds6/image/layout", '<div id="image" class="view"> <div class="image-con swiper-container" id="container_image"> <div class="message-loading-con"> <p>正在加载上墙消息...</p> <div class="message-loading-progress"> <div class="message-loading-progress-bar" style="width: 0%">0%</div> </div> </div> <div class="swiper-wrapper"> </div> </div> </div> '), e("component/ds6/layout/error", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.message,
				i = "";
			return i += ' <div class="container background_img" id="background_img"> </div>  <div class="container browser_tips hide" id="browser_tips"> <div class="row clearfix" > <div class="browser_logo fl"> <img src="images/default/logo_black.png" /> </div> <div class="browser_download"> <p>您的浏览器对大屏幕上墙效果支持不佳，或者使用的浏览器版本过低，建议更换新版chrome浏览器获得更好的上墙体验</p> <a href="http://xiazai.sogou.com/detail/34/8/6262355089742005676.html">点击去下载chrome浏览器 <img src="images/default/chrome.png"></a> </div> </div> </div>  <div class="container stage"> <div class="row header clearfix" id="header"> </div> <div class="row main clearfix"> <div class="viewport"> <div class="error"> ', i += n(r), i += ' </div> </div> <div class="blur"> <div> </div> </div> </div> </div> ', new l(i)
		}), e("component/ds6/layout/main", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, e.bgurl),
				r = t.$escape,
				i = "";
			return i += ' <div class="container background_img" id="background_img" ', "" != n && (i += 'style="background-image:url(', i += r(n), i += ')"'), i += '> </div>  <div class="container browser_tips hide" id="browser_tips"> <div class="row clearfix" > <div class="browser_logo fl"> <img src="images/default/logo_black.png" /> </div> <div class="browser_download"> <p>您的浏览器对大屏幕上墙效果支持不佳，或者使用的浏览器版本过低，建议更换新版chrome浏览器获得更好的上墙体验</p> <a href="http://xiazai.sogou.com/detail/34/8/6262355089742005676.html">点击去下载chrome浏览器 <img src="images/default/chrome.png"></a> </div> </div> </div>  <div class="container stage"> <div class="row header clearfix" id="header"> </div> <div class="row main clearfix"> <div class="viewport"> </div> <div class="blur"> <div ', "" != n && (i += ' style="background-image:url(', i += r(n), i += ')"'), i += '> </div> </div> </div> </div>  <div class="container hover" id="ctrlbar"> <div class="clearfix" id="slogen"> </div> <div class="clearfix" id="toolkit"> </div> </div> <div class="gallery-con invisible"> <div id="comment" class="abp"> <div id="comment-stage" class="container"></div> </div> </div>  <a id="ribbon" href="http://xianchang.qq.com/manage/index.html" target="_blank" class="hide"> <img style="position: absolute; top: 0; right: 0; border: 0; width:100px; z-index:10000" src="images/default/peel.png" title="马上创建您专属的微现场"> </a>', new l(i)
		}), e("component/ds6/lottery/awards", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = "";
			return n(r, function(e) {
				s += ' <li class="options" data-target="', s += i(e.id), s += '" data-option="', s += i(e.name), s += '">', s += i(e.name), s += "</li> "
			}), s += " ", new l(s)
		}), e("component/ds6/lottery/layout", '<div id="lottery" class="view"> <div class="draw-box"> <div class="draw-header"> <div class="draw-title">现场抽奖</div> </div> <div class="slot-box"> <div class="slot-box-wrapper clearfix"> <div class="emo"><img src="images/default/emo.png" /></div> <div class="title">求中奖，快到碗里来</div> </div> </div> </div> <div class="controll-box"> <div class="select-wrapper" id="award-selector"> <a class="select-btn"><span>请选择奖品类别</span> <i class="select-btn-arrow icon icon-arrow"></i></a> <ul class="select-options hide"> </ul> </div>  <div class="select-wrapper" id="quantity-selector"> <div class="lottery-num clearfix"> <span class="lottery-num-btn minus">-</span> <input id="lotteryNum" value="1" /> <span class="lottery-num-btn add">+</span> </div> </div> <div class="award-img-wrapper"> </div> <div class="lottery-btn"> 正在加载奖池... </div> <div class="lottery-history"> 查看中奖记录 </div> </div> </div> '), e("component/ds6/lottery/list", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = (e.winner, e.j, t.$string),
				o = "";
			return o += '<div id="history-swiper-con" class="history-box"> <div class="swiper-wrapper"> ', n(r, function(e) {
				o += ' <div class="swiper-slide"> <div class="history-row clearfix"> <div class="history-award fl"> <img width="250" height="250" src="', o += i(e.image), o += '"> <p>', o += i(e.award), o += '</p> </div> <div class="history-winner fl"> <ul class="history-winner-list clearfix"> ', n(e.winner, function(e) {
					o += ' <li class="history-winner-item fl clearfix"> <div class="history-winner-avatar fl"> ', e.head ? (o += ' <img src="', o += i(e.head), o += '" width="100" height="100" alt=""> ') : o += ' <img src="images/default/avatar.png" width="100" height="100" alt=""> ', o += ' </div> <div class="history-winner-name fl">', o += s(e.name), o += "</div> </li> "
				}), o += " </ul> </div> </div> </div> "
			}), o += ' </div> <div class="winners-prev"><i class="icon icon-arrow-left"></i></div> <div class="winners-next"><i class="icon icon-arrow-right"></i></div> </div> <!-- <div class="history-overlay"> <div class="history-list"> <div class="history-header"> <span>获奖名单</span> </div> <div id="history-swiper-con"> <div class="swiper-wrapper"> ', n(r, function(e) {
				o += ' <div class="swiper-slide"> <div class="history-row clearfix"> <div class="history-award fl"> <img width="250" height="250" src="', o += i(e.imageurl), o += '"> <p>', o += i(e.award), o += '</p> </div> <div class="history-winner fl"> <ul class="history-winner-list clearfix"> ', n(e.winner, function(e) {
					o += ' <li class="history-winner-item fl clearfix"> <div class="history-winner-avatar fl"> ', e.head ? (o += ' <img src="', o += i(e.head), o += '" width="100" height="100" alt=""> ') : o += ' <img src="images/default/avatar.png" width="100" height="100" alt=""> ', o += ' </div> <div class="history-winner-name fl">', o += s(e.nick), o += "</div> </li> "
				}), o += " </ul> </div> </div> </div> "
			}), o += ' </div> </div> <div class="icon icon-arrow-left arrow-left"></div> <div class="icon icon-arrow-right arrow-right"></div> </div> </div> -->', new l(o)
		}), e("component/ds6/lottery/pools", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = t.$string,
				o = "";
			return n(r, function(e) {
				o += ' <li class="options" data-target="', o += i(e.id), o += '" data-option="', o += i(e.name), o += '">', o += s(e.name), o += "</li> "
			}), o += " ", new l(o)
		}), e("component/ds6/lottery/quantity", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = "";
			return n(r, function(e, t) {
				s += ' <li class="options" data-target="', s += i(t + 1), s += '" data-option="', s += i(t + 1), s += '">', s += i(t + 1), s += "</li> "
			}), s += " ", new l(s)
		}), e("component/ds6/lottery/single", '<div class="slot-box-single"> <ul> <li class="item">1</li> <li class="item">2</li> <li class="item">3</li> <li class="item">4</li> <li class="item">5</li> <li class="item">6</li> <li class="item">7</li> <li class="item">8</li> </ul> </div> '), e("component/ds6/lottery/slot", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, e.inner),
				r = t.$escape,
				i = e.item,
				s = t.$string,
				o = "";
			return n ? (o += ' <div class="slot-avatar"> <img src="', o += r(i.head), o += '" class="lotteryImg" width="150" height="150" alt=""> </div> <div class="slot-shadow"></div> <div class="slot-name">', o += s(i.name), o += "</div> ") : (o += ' <div class="slot-box-item"> <div class="slot-avatar"> <img src="', o += r(i.head), o += '" class="lotteryImg" width="150" height="150" alt=""> </div> <div class="slot-shadow"></div> <div class="slot-name">', o += s(i.name), o += "</div> </div> "), o += " ", new l(o)
		}), e("component/ds6/message/detail", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.index,
				i = e.height,
				s = e.head,
				o = e.anonymous,
				u = t.$string,
				a = e.name,
				f = e.fontsize,
				c = e.type,
				h = e.content,
				p = "";
			return p += '<div class="detail clearfix" data-index="', p += n(r), p += '" style="height:', p += n(i), p += 'px"> <div class="left fl"> <div class="avatar"> <img id="userhead_', p += n(r), p += '" src="', p += n(s), p += '" alt=""> </div> </div> <div class="right"> ', 0 == o ? (p += ' <div class="name">', p += u(a), p += '</div> <div class="message" style="font-size:', p += n(f), p += "px; line-height:", p += n(f + 10), p += 'px"> ', 0 == c ? (p += " ", p += u(h), p += " ") : (p += ' <img src="', p += n(h), p += '" > '), p += " </div> ") : (p += ' <div class="message h100" style="font-size:', p += n(f), p += "px; line-height:", p += n(f + 10), p += 'px"> ', 0 == c ? (p += " ", p += u(h), p += " ") : (p += ' <img src="', p += n(h), p += '" > '), p += " </div> "), p += ' </div> <div class="corner"></div> <div class="index">', p += n(r + 1), p += '</div> <div class="close"><i class="icon icon-close"></i></div> </div> ', new l(p)
		}), e("component/ds6/message/item", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.index,
				i = e.height,
				s = e.head,
				o = e.anonymous,
				u = t.$string,
				a = e.name,
				f = e.fontsize,
				c = e.type,
				h = e.content,
				p = "";
			return p += '<div class="item clearfix" data-index="', p += n(r), p += '" style="height:', p += n(i), p += 'px"> <div class="left fl"> <div class="avatar"> <img id="userhead_', p += n(r), p += '" src="', p += n(s), p += '" alt=""> </div> </div> <div class="right"> ', 0 == o ? (p += ' <div class="name">', p += u(a), p += '</div> <div class="message" style="font-size:', p += n(f), p += "px; line-height:", p += n(f + 10), p += 'px"> ', 0 == c ? (p += " ", p += u(h), p += " ") : (p += ' <img src="', p += n(h), p += '" > '), p += " </div> ") : (p += ' <div class="message h100" style="font-size:', p += n(f), p += "px; line-height:", p += n(f + 10), p += 'px"> ', 0 == c ? (p += " ", p += u(h), p += " ") : (p += ' <img src="', p += n(h), p += '" > '), p += " </div> "), p += ' </div> <div class="corner"></div> <div class="index">', p += n(r + 1), p += "</div> </div> ", new l(p)
		}), e("component/ds6/message/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.wxqrcode,
				i = e.wxname,
				s = "";
			return s += '<div id="message" class="view clearfix"> <div class="sidebar fl" id="sidebar"> <div class="sb-wrapper"> <div class="c-wrapper" id="mask_btn"> <img src="', s += n(r), s += '" /> </div> <p class="comment account"><span>', s += n(i), s += '</span></p> <p class="comment"> ', s += i ? " 关注微信号 " : " 扫描二维码 ", s += ' </p> <p class="comment">参与互动上墙</p> </div> </div> <div id="mask" class="mask hide"> <div class="mask-wrapper"> <img src="', s += n(r), s += '" width="460" height="460"/> </div> </div> <div id="message_wrapper" class="fl"> <div class="message-loading-con"> <p>正在加载上墙消息...</p> <div class="message-loading-progress"> <div class="message-loading-progress-bar" style="width: 0%">0%</div> </div> </div> <div class="message-con swiper-container" id="container_list"> <div class="swiper-wrapper"> </div> </div> <div class="message-con swiper-container hide" id="container_detail"> <div class="swiper-wrapper"> </div> </div> </div> </div> ', new l(s)
		}), e("component/ds6/message/sidebar", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.wxqrcode,
				i = e.wxname,
				s = t.$string,
				o = "";
			return o += '<div class="sb-wrapper"> <div class="c-wrapper" id="mask_btn"> <img src="', o += n(r), o += '" /> </div> <p class="comment"> ', o += i ? " 关注微信号 " : " 扫描二维码 ", o += ' </p> <p class="comment account"><span>', o += s(i), o += '</span></p> <p class="comment">参与互动上墙</p> </div>', new l(o)
		}), e("component/ds6/modal/alert", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, e.title),
				r = t.$escape,
				i = e.message,
				s = "";
			return s += '<div id="alert" class="modal fade"> <div class="modal-dialog modal-sm"> <div class="modal-content"> <div class="modal-header"> <h4 class="modal-title">', s += n ? r(n) : "提示", s += '<h4> </div> <div class="modal-body" style="min-height:200px"> ', s += r(i), s += ' </div> <div class="modal-footer"> <a class="btn btn-primary" data-dismiss="modal">确定</a> </div> </div> </div> </div> ', new l(s)
		}), e("component/ds6/modal/game", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.campaign_id,
				i = "";
			return i += '<div id="game" class="modal fade"> <div class="modal-dialog"> <div class="modal-content"> <div class="modal-header"> <h4 class="modal-title">游戏</h4> </div> <div class="modal-body"> <div class="game-wrapper clearfix"> <ul> <li class="game"> <div class="pic"> <img src="images/default/game/shake.jpg" / > <div class="button"> <span>摇一摇比赛</span> <a class="btn btn-primary remodal-cancel modal-close" app-jump="#', i += n(r), i += '/shake">开始游戏</a> </div> </div> </li> <li class="game"> <div class="pic"> <img src="images/default/game/guess.jpg" / > <div class="button"> <span>剪刀石头布</span> <a class="btn btn-primary remodal-cancel modal-close" app-jump="#', i += n(r), i += '/guess">开始游戏</a> </div> </div> </li> <li class="game" > <div class="pic"> <img src="images/default/game/default.jpg" / > </div> </li> </ul> </div> </div> <div class="modal-footer"> <a class="btn btn-default" data-dismiss="modal">返回</a> </div> </div> </div> </div> ', new l(i)
		}), e("component/ds6/modal/setting", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, e.theme),
				r = t.$escape,
				i = e.bgurl,
				s = e.interval,
				o = e.anonymous,
				u = "";
			return u += '<div id="setting" class="modal fade"> <div class="modal-dialog"> <div class="modal-content"> <div class="modal-header"> <h4 class="modal-title">设置</h4> </div> <div class="modal-body"> <div class="tab-wrapper"> <ul class="clearfix"> <li class="tab active"><a href="javascript:;">设置</a></li> </ul> </div> <div id="tab-swiper"> <!-- <div class="slide active"> <ul> <li class="theme ', "default" == n && (u += "active"), u += '" data-theme="default"> <div class="pic"> <img src="images/default/demo.jpg" / > <div class="name">商务会议</div> </div> <div class="check"></div> </li> <li class="theme ', "festival" == n && (u += "active"), u += '" data-theme="festival"> <div class="pic"> <img src="images/festival/demo.jpg" / > <div class="name">节日盛宴</div> </div> <div class="check"></div> </li> <li class="theme ', "wedding" == n && (u += "active"), u += '" data-theme="wedding"> <div class="pic"> <img src="images/wedding/demo.jpg" / > <div class="name">婚庆典礼</div> </div> <div class="check"></div> </li> <li class="theme ', "ds6" == n && (u += "active"), u += '" data-theme="ds6"> <div class="pic"> <img src="images/ds6/thumb.jpg" / > <div class="name">商业展会</div> </div> <div class="check"></div> </li> </ul> <input type="hidden" id="theme-value" value="', u += r(n), u += '"/> </div> <div class="slide"> <div class="upload-wrapper clearfix"> <div class="upload-img-box"> <img src="', u += r(i), u += '" /> </div> <div class="upload-img-select"> <div class="upload-btn btn btn-default"> <span>点击上传图片</span> <input id="upload-img-fileinput" type="file" title="点击更换图片" value="', u += r(i), u += '" /> </div> <div class="clear-btn btn btn-default"> <span>使用默认背景</span> </div> <p>*建议上传图片尺寸1920*1080，大小3M以内的图片</p> </div> <input type="hidden" id="bgurl-value" value="', u += r(i), u += '"/> </div> </div> --> <div class="slide active"> <div class="item"> <div class="inner-header">账号设置</div> <div class="inner-content"> <a class="btn btn-default" id="logout">更换账号</a> </div> </div> <!-- <div class="item"> <div class="inner-header">消息墙控制</div> <div class="inner-content"> <div class="form-group clearfix"> <label for="messageScrollTime" class="fl">滚动时间</label> <div id="messageScrollTimeBar" class="fl scrollbar"> </div> <div class="scrollval fl"></div> </div> <div class="form-group clearfix"> <label for="messageInterval" class="fl">循环播放</label> <div class="fl"> <label for="#" class="ui-switch"> ', u += s ? ' <input type="checkbox" id="messageInterval" checked="true" /> ' : ' <input type="checkbox" id="messageInterval" /> ', u += ' </label> </div> <div class="fl desc"> 消息从最后一条自动滚至第一条循环播放 </div> </div> <div class="form-group clearfix"> <label for="messageAnonymous" class="fl">匿名消息</label> <div class="fl"> <label for="#" class="ui-switch"> ', u += o ? ' <input type="checkbox" id="messageAnonymous" checked="true" /> ' : ' <input type="checkbox" id="messageAnonymous" /> ', u += ' </label> </div> <div class="fl desc"> 开启匿名消息以后将使用随机头像并匿名 </div> </div> </div> </div> --> </div> </div> </div> <div class="modal-footer"> <a class="btn btn-default" data-dismiss="modal">返回</a>  </div> </div> </div> </div> ', new l(u)
		}), e("component/ds6/modal/winners", '<div id="history" class="modal fade"> <div class="modal-dialog" style="width:80%;"> <div class="modal-content"> <div class="modal-header"> <h4 class="modal-title">获奖名单</h4> </div> <div class="modal-body"> <div class="modal-loading"> <i class="icon icon-loading"></i> 数据加载中... </div> </div> <div class="modal-footer"> <a class="btn btn-default" data-dismiss="modal">返回</a> </div> </div> </div> </div>'), e("component/ds6/signin/item", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.head,
				i = t.$string,
				s = e.name,
				o = "";
			return o += '<div class="signin-item"> <div class="signin-item-img"><img src="', o += n(r), o += '" /></div> <span class="signin-item-text">', o += i(s), o += "</span> </div>", new l(o)
		}), e("component/ds6/signin/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.item_num,
				i = e.img_src,
				s = "";
			return s += '<div id="signin" class="view"> <div class="signin-con"> <div class="signin-header clearfix"> <div class="signin-header-title fl"> <a class="signin-header-left">签到墙</a> <a class="signin-header-right"> 共<span class="signin-header-num">', s += n(r), s += '</span>人签到 </a> </div> </div> <div class="signin-content"></div> </div> <div class="signin-qrcode-btn"></div> <div id="signin-qrcode" class="signin-qrcode hide"> <div class="signin-qrcode-wrapper"> <img src="', s += n(i), s += '" width="460" height="460"/> </div> </div> </div>', new l(s)
		}), e("component/ds6/slogen/main", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.slogans,
				i = (e.item, e.$index, t.$escape),
				s = "";
			return s += '<div class="slogen-bg"> <div class="slogen-wrapper" id="slogen-swiper-con"> <div class="swiper-wrapper"> ', n(r, function(e) {
				s += ' <div class="swiper-slide"> <div class="slogen-row clearfix"> <p>', s += i(e), s += "</p> </div> </div> "
			}), s += " </div> </div> </div>", new l(s)
		}), e("component/ds6/toolkit/main", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.campaign_id,
				i = "";
			return i += '<div class="toolkit-bg"> <div class="toolkit-wrapper row"> <div class="nav-bar fl"> <ul> <li app-jump="#', i += n(r), i += '/signin" class="signin link tooltip tooltip-effect-2"> <i class="icon icon-signin"></i> <div class="tooltip-content"><span>签到</span></div> </li> <li app-jump="#', i += n(r), i += '/message" class="wall link tooltip tooltip-effect-2"> <i class="icon icon-message"></i> <div class="tooltip-content"><span>消息上墙</span></div> </li> <li app-jump="#', i += n(r), i += '/image" class="wall link tooltip tooltip-effect-2"> <i class="icon icon-image"></i> <div class="tooltip-content"><span>纯图模式</span></div> </li> <li app-bullet="enable" id="shoot" class="tooltip tooltip-effect-2"> <i class="icon icon-bullet"></i> <div class="tooltip-content"><span>弹幕开关</span></div> </li> <li app-jump="#', i += n(r), i += '/lottery" class="lottery link tooltip tooltip-effect-2"> <i class="icon icon-lottery"></i> <div class="tooltip-content"><span>抽奖</span></div> </li> <li app-jump="#', i += n(r), i += '/vote" class="vote link tooltip tooltip-effect-2"> <i class="icon icon-vote"></i> <div class="tooltip-content"><span>投票</span></div> </li> <li app-jump="#', i += n(r), i += '/shake" class="game link tooltip tooltip-effect-2"> <i class="icon icon-game"></i> <div class="tooltip-content"><span>摇一摇</span></div> </li> <li id="fullscreen" class="tooltip tooltip-effect-2"> <i class="icon icon-full-screen fullScreen"></i> <div class="tooltip-content"><span>全屏</span></div> </li> <li id="setting-btn" class="tooltip tooltip-effect-2"> <i class="icon icon-setting"></i> <div class="tooltip-content"><span>设置</span></div> </li> </ul> </div> <div class="action-bar fr hide"> <ul> <li message-action="backward" class="tooltip tooltip-effect-2"> <i class="icon icon-backward"></i> <div class="tooltip-content"><span>第一条</span></div> </li> <li message-action="step-backward" class="tooltip tooltip-effect-2"> <i class="icon icon-step-backward"></i> <div class="tooltip-content"><span>向上一条</span></div> </li> <li message-action="play" class="tooltip tooltip-effect-2"> <i class="icon icon-pause"></i> <div class="tooltip-content"><span>开始/暂停</span></div> </li> <li message-action="step-forward" class="tooltip tooltip-effect-2"> <i class="icon icon-step-forward"></i> <div class="tooltip-content"><span>向下一条</span></div> </li> <li message-action="forward" class="tooltip tooltip-effect-2"> <i class="icon icon-forward"></i> <div class="tooltip-content"><span>最后一条</span></div> </li> </ul> </div> </div> </div>', new l(i)
		}), e("component/ds6/vote/column", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.item,
				i = "";
			return i += '<div class="vote-column" id="vote-column-', i += n(r.item_id), i += '"> <div class="vote-column-con"> <div class="vote-column-count" style="color:', i += n(r.color), i += "; bottom:", i += n(r.height + 15), i += 'px;">', i += n(r.count), i += "票 ( ", i += n(r.percent), i += '% )</div> <div class="vote-column-bar" style="background-color:', i += n(r.color), i += "; height: ", i += n(r.height), i += 'px;"></div> </div> <div class="vote-column-title">', i += n(r.name), i += "</div> </div>", new l(i)
		}), e("component/ds6/vote/count", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.item,
				i = "";
			return i += n(r.count), i += "票 ( ", i += n(r.percent), i += "% )", new l(i)
		}), e("component/ds6/vote/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.item, e.index, t.$escape),
				s = t.$string,
				o = e.qrcode,
				u = "";
			return u += '<div id="vote" class="view"> <div class="vote-con" id="vote_list"> <div class="swiper-wrapper"> ', n(r, function(e) {
				u += ' <div class="swiper-slide"> <div class="vote" id="vote-', u += i(e.vote_id), u += '" data-index="', u += i(e.vote_id), u += '"> <div class="vote-header clearfix"> <div class="vote-header-title fl"> <a class="vote-header-left">', u += s(e.name), u += '</a> <a class="vote-header-right"> 共<span class="vote-header-num vote-title-num">0</span>人参与 </a> </div> </div> <div class="vote-content vote-content"> <div class="vote-scrollbar-move"> </div> </div> </div> </div> '
			}), u += ' </div> </div> <div class="vote-prev"><i class="icon icon-arrow-left"></i></div> <div class="vote-next"><i class="icon icon-arrow-right"></i></div> <div class="vote-qrcode-btn"></div> <div id="vote-qrcode" class="vote-qrcode hide"> <div class="vote-qrcode-wrapper"> <img width="460" height="460" src="', u += i(o), u += '"/> </div> </div> <div class="vote-order"> <input type="checkbox" class="order-switch" name="order-switch"> <label for="order-switch">排序</label> </div> </div>', new l(u)
		}), e("component/festival/brand/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.item_num,
				i = e.img_src,
				s = "";
			return s += '<div id="brand" class="view"> <div class="brand-header"> <div class="brand-header-title fl"> <a class="brand-header-left">签到墙</a> <a class="brand-header-right"> 共<span class="brand-header-num">', s += n(r), s += '</span>人签到 </a> </div> </div> <div class="brand-content"> <canvas id="brand-canvas"></canvas> <div id="brand-avatar"></div> </div> <div id="brand-style"></div> <div class="brand-qrcode-btn"></div> <div id="brand-qrcode" class="brand-qrcode hide"> <div class="brand-qrcode-wrapper"> <img src="', s += n(i), s += '" width="460" height="460"/> </div> </div> </div>', new l(s)
		}), e("component/festival/game/guess/join", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.head,
				i = "";
			return i += '<li class="game-user"> <div class="head"> <img src="', i += n(r), i += '" alt=""> </div> </li> ', new l(i)
		}), e("component/festival/game/guess/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.guessQrcode,
				i = e.guessTime,
				s = "";
			return s += '<div id="guess" class="view"> <div class="game-con"> <div class="game-prepare"> <div class="game-header clearfix"> <div class="game-header-title fl"> <a class="game-header-left">石头剪刀布比赛</a> </div> </div> <div class="game-userlist"> <div class="game-userlist-nouser clearfix"> <div class="game-userlist-emo"><img src="images/default/emo.png" /></div> <div class="game-userlist-title">扫描二维码，参与摇一摇比赛</div> </div> <div class="game-userlist-con"> <ul class="clearfix"> </ul> </div> </div> </div> <div class="game-sidebar"> <div class="game-sidebar-title">扫描二维码参与</div> <div class="game-sidebar-qrcode"> <div class="game-sidebar-qrcode-inner"> <img src="', s += n(r), s += '"> </div> </div> <div class="game-sidebar-btn-con"> <div class="game-sidebar-btn-info">游戏时间(分钟)</div> <div class="game-sidebar-config clearfix"> <span class="game-sidebar-config-btn minus">-</span><span id="guessTime">', s += n(i), s += '</span><span class="game-sidebar-config-btn add">+</span> </div> <div class="game-sidebar-btn start-btn">倒计时开始</div> </div> </div> <div class="game-process hide"> <ul class="clearfix" style="position:relative;width:60%;height:100%;overflow:hidden"> </ul> <div class="process-timer">60</div> </div> </div> <div class="count-overlay"> <div class="count-body"> <div class="count-wrapper right"> <div class="count-circle rightcircle"></div> </div> <div class="count-wrapper left"> <div class="count-circle leftcircle"></div> </div> <div class="number"> <div class="count count3"><img src="images/default/number/3.png"></div> <div class="count count2"><img src="images/default/number/2.png"></div> <div class="count count1"><img src="images/default/number/1.png"></div> </div> </div> </div> <div class="game-result-overlay"> </div> </div> <!-- <div id="guess" class="view"> <div class="prepare-con"> <div class="prepare-header center"> <div class="underline"> <span class="title">扫描二维码，参与石头剪刀布比赛</span> </div> </div> <div class="prepare-content-con clearfix"> <div class="topline"> <div class="prepare-qrcode-con center"> <div class="prepare-qrcode"> <img src="', s += n(r), s += '"> </div> <div class="prepare-btn-con"> <div class="start-btn">游戏开始</div> <div class="game-config">游戏时间(分钟)：<span class="config-btn minus">-</span><span id="guessTime">', s += n(i), s += '</span><span class="config-btn add">+</span></div> </div> </div> </div> </div> </div> <div class="game-con"> <div class="process-con"> <div class="process-rank fl"> <ul class="clearfix"> </ul> </div> <div class="process-timer">38</div> </div> <div class="result-con"> <div class="result-header"> <div class="underline"> <span class="title">恭喜以下选手取得好成绩！</span> <div class="back-btn-con"> <div class="btn btn-tran">返回</div> </div> </div> </div> <div class="result-content-con clearfix"> <div class="topline" id="game_result"> </div> </div> </div> </div> </div> -->', new l(s)
		}), e("component/festival/game/guess/rank", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.openID,
				i = e.top,
				s = e.index,
				o = e.head,
				u = e.name,
				a = e.score,
				f = "";
			return f += '<li class="item" id="process_item_', f += n(r), f += '" style="top:', f += n(i), f += 'px"> <div class="rank fl"> ', 3 > s ? (f += ' <span class="medal rank', f += n(s + 1), f += '"></span> ') : (f += ' <span class="num">', f += n(s + 1), f += "</span> "), f += ' </div> <div class="head fl"> <img src="', f += n(o), f += '" width="100" height="100" alt=""> </div> <div class="name"> ', f += n(u), f += ' </div> <div class="percent fr"> ', f += n(a), f += "分 </div> </li>", new l(f)
		}), e("component/festival/game/guess/record", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = "";
			return s += '<div class="board"> <div class="visual"> ', n(r, function(e, t) {
				s += " ", 3 > t && (s += ' <div class="top top', s += i(t + 1), s += '"> <div class="head"> <img src="', s += i(e.head), s += '"> </div> <div class="ribbon"></div> <div class="name">', s += i(e.name), s += "</div> </div> "), s += " "
			}), s += ' <ul class="top10 clearfix"> ', n(r, function(e, t) {
				s += " ", t >= 3 && 10 > t && (s += ' <li class="fl"> <div class="head"> <img src="', s += i(e.head), s += '"> </div> <div class="name"> <div class="num">', s += i(t + 1), s += "</div> ", s += i(e.name), s += " <div> </li> "), s += " "
			}), s += ' </ul> <div class="board-footer"> <span class="show-list">查看全部排名</span> <span class="restart">重新开始</span> </div> </div> <div class="list hide"> <div class="list-body"> <table> <tr><th>排名</th><th>微信id</th></tr> ', n(r, function(e, t) {
				s += " <tr><td>", s += i(t + 1), s += "</td><td>", s += i(e.name), s += "</td></tr> "
			}), s += ' </table> </div> <div class="board-footer"> <span class="show-visual">查看Top10</span> <span class="restart">重新开始</span> </div> </div> </div>', new l(s)
		}), e("component/festival/game/shake/join", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.head,
				i = "";
			return i += '<li class="game-user"> <div class="head"> <img src="', i += n(r), i += '" alt=""> </div> </li>', new l(i)
		}), e("component/festival/game/shake/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.shakeQrcode,
				i = e.shakeTime,
				s = "";
			return s += '<div id="shake" class="view"> <div class="game-con"> <div class="game-prepare"> <div class="game-header clearfix"> <div class="game-header-title fl"> <a class="game-header-left">摇一摇夺奖</a> <a class="game-header-right"> 共<span class="game-header-num" id="join_num">0</span>人参与 </a> </div> </div> <div class="game-userlist"> <div class="game-userlist-nouser clearfix"> <div class="game-userlist-emo"><img src="images/default/emo.png" /></div> <div class="game-userlist-title">扫描二维码，参与摇一摇比赛</div> </div> <div class="game-userlist-con"> <ul class="clearfix"> </ul> </div> </div> </div> <div class="game-sidebar"> <div class="game-sidebar-title">扫描二维码参与</div> <div class="game-sidebar-qrcode"> <div class="game-sidebar-qrcode-inner"> <img src="', s += n(r), s += '"> </div> </div> <div class="game-sidebar-btn-con"> <div class="game-sidebar-btn-info">摇一摇次数设置</div> <div class="game-sidebar-config clearfix"> <span class="game-sidebar-config-btn minus">-</span><span id="shakeTime">', s += n(i), s += '</span><span class="game-sidebar-config-btn add">+</span> </div> <div class="game-sidebar-btn start-btn">倒计时开始</div> </div> </div> <div class="game-process hide"> <ul class="clearfix"> </ul> <div id="reset">重新开始</div> </div> </div> <div class="count-overlay"> <div class="count-body"> <div class="count-wrapper right"> <div class="count-circle rightcircle"></div> </div> <div class="count-wrapper left"> <div class="count-circle leftcircle"></div> </div> <div class="number"> <div class="count count3"><img src="images/default/number/3.png"></div> <div class="count count2"><img src="images/default/number/2.png"></div> <div class="count count1"><img src="images/default/number/1.png"></div> </div> </div> </div> <div class="game-result-overlay"> </div> </div> <!-- <div id="shake" class="view"> <div class="prepare-con"> <div class="prepare-header"> <div class="underline"> <span class="title left">扫描二维码，参与摇一摇比赛</span> <div class="fr"> <span class="title orange" id="join_num">0</span><span class="title">人参与</span> </div> </div> </div> <div class="prepare-content-con clearfix"> <div class="topline"> <div class="prepare-qrcode-con fl"> <div class="prepare-qrcode"> <img src="', s += n(r), s += '"> </div> <div class="prepare-btn-con"> <div class="start-btn">倒计时开始</div> <div class="game-config">摇一摇次数：<span class="config-btn minus">-</span><span id="shakeTime">', s += n(i), s += '</span><span class="config-btn add">+</span></div> </div> </div> </div> <div class="prepare-user-con fl"> <ul class="clearfix"> </ul> </div> </div> </div> <div class="game-con"> <div class="count-con"> <div class="count count3"></div> <div class="count count2"></div> <div class="count count1"></div> <div class="count count0"></div> </div> <div class="process-con"> <ul class="clearfix"> </ul> </div> <div class="result-con"> <div class="result-header"> <div class="underline"> <span class="title">恭喜以下选手取得好成绩！</span> <div class="back-btn-con"> <div class="btn btn-tran">返回</div> </div> </div> </div> <div class="result-content-con clearfix"> <div class="topline" id="game_result"> </div> </div> </div> </div> </div> -->', new l(s)
		}), e("component/festival/game/shake/rank", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.openid,
				i = e.top,
				s = e.index,
				o = e.head,
				u = e.name,
				a = e.percent,
				f = "";
			return f += '<li class="item" id="process_item_', f += n(r), f += '" style="top:', f += n(i), f += 'px"> <div class="rank fl"> ', 3 > s ? (f += ' <span class="medal rank', f += n(s + 1), f += '"></span> ') : (f += ' <span class="num">', f += n(s + 1), f += "</span> "), f += ' </div> <div class="head fl"> <img src="', f += n(o), f += '" width="100" height="100" alt=""> </div> <div class="name"> ', f += n(u), f += ' </div> <div class="progress"> <img class="run" src="images/default/run.gif" style="right:100%"> </img> <div class="progress-wrapper"> <span class="val" style="-webkit-transform: translateX(-100%);"> </span> </div> </div> <div class="percent fr"> ', f += n(a), f += " </div> </li>", new l(f)
		}), e("component/festival/game/shake/record", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = "";
			return s += '<div class="board"> <div class="visual"> ', n(r, function(e, t) {
				s += " ", 3 > t && (s += ' <div class="top top', s += i(t + 1), s += '"> <div class="head"> <img src="', s += i(e.head), s += '"> </div> <div class="ribbon"></div> <div class="name">', s += i(e.name), s += "</div> </div> "), s += " "
			}), s += ' <ul class="top10 clearfix"> ', n(r, function(e, t) {
				s += " ", t >= 3 && 10 > t && (s += ' <li class="fl"> <div class="head"> <img src="', s += i(e.head), s += '"> </div> <div class="name"> <div class="num">', s += i(t + 1), s += "</div> ", s += i(e.name), s += " <div> </li> "), s += " "
			}), s += ' </ul> <div class="board-footer"> <span class="show-list">查看全部排名</span> <span class="restart">重新开始</span> </div> </div> <div class="list hide"> <div class="list-body"> <table> <tr><th>排名</th><th>微信id</th></tr> ', n(r, function(e, t) {
				s += " <tr><td>", s += i(t + 1), s += "</td><td>", s += i(e.name), s += "</td></tr> "
			}), s += ' </table> </div> <div class="board-footer"> <span class="show-visual">查看Top10</span> <span class="restart">重新开始</span> </div> </div> </div>', new l(s)
		}), e("component/festival/header/main", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, e.logourl),
				r = t.$escape,
				i = e.name,
				s = "";
			return n && (s += ' <div class="logo fl"><img src="', s += r(n), s += '" /></div> '), s += ' <div class="title fl"> <h1>', s += r(i), s += "</h1> </div> ", new l(s)
		}), e("component/festival/image/detail", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.index,
				i = e.anonymous,
				s = t.$string,
				o = e.name,
				u = e.content,
				a = "";
			return a += '<div class="image clearfix" data-index="', a += n(r), a += '"> <div class="head clearfix"> ', 0 == i && (a += ' <div class="left fl">', a += s(o), a += "</div> "), a += ' <div class="right fr">', a += n(r + 1), a += '</div> </div> <div class="body"> <div class="pic"> <img src="', a += n(u), a += '" id="FullImg_', a += n(r), a += '"> </div> </div> </div>', new l(a)
		}), e("component/festival/image/layout", '<div id="image" class="view"> <div class="image-con swiper-container" id="container_image"> <div class="message-loading-con"> <p>正在加载上墙消息...</p> <div class="message-loading-progress"> <div class="message-loading-progress-bar" style="width: 0%">0%</div> </div> </div> <div class="swiper-wrapper"> </div> </div> </div> '), e("component/festival/layout/error", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.message,
				i = "";
			return i += ' <div class="container background_img" id="background_img"> </div>  <div class="container browser_tips hide" id="browser_tips"> <div class="row clearfix" > <div class="browser_logo fl"> <img src="images/default/logo_black.png" /> </div> <div class="browser_download"> <p>您的浏览器对大屏幕上墙效果支持不佳，或者使用的浏览器版本过低，建议更换新版chrome浏览器获得更好的上墙体验</p> <a href="http://xiazai.sogou.com/detail/34/8/6262355089742005676.html">点击去下载chrome浏览器 <img src="images/default/chrome.png"></a> </div> </div> </div>  <div class="container stage"> <div class="row header clearfix" id="header"> </div> <div class="row main clearfix"> <div class="viewport"> <div class="error"> ', i += n(r), i += ' </div> </div> <div class="blur"> <div> </div> </div> </div> </div> ', new l(i)
		}), e("component/festival/layout/main", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, e.bgurl),
				r = t.$escape,
				i = "";
			return i += ' <div class="container background_img" id="background_img" ', "" != n && (i += 'style="background-image:url(', i += r(n), i += ')"'), i += '> </div>  <div class="container browser_tips hide" id="browser_tips"> <div class="row clearfix" > <div class="browser_logo fl"> <img src="images/default/logo_black.png" /> </div> <div class="browser_download"> <p>您的浏览器对大屏幕上墙效果支持不佳，或者使用的浏览器版本过低，建议更换新版chrome浏览器获得更好的上墙体验</p> <a href="http://xiazai.sogou.com/detail/34/8/6262355089742005676.html">点击去下载chrome浏览器 <img src="images/default/chrome.png"></a> </div> </div> </div>  <div class="container stage"> <div class="row header clearfix" id="header"> </div> <div class="row main clearfix"> <div class="viewport"> </div> <div class="blur"> <div ', "" != n && (i += ' style="background-image:url(', i += r(n), i += ')"'), i += '> </div> </div> </div> </div>  <div class="container hover" id="ctrlbar"> <div class="clearfix" id="slogen"> </div> <div class="clearfix" id="toolkit"> </div> </div> <div class="gallery-con invisible"> <div id="comment" class="abp"> <div id="comment-stage" class="container"></div> </div> </div>  <a id="ribbon" href="http://xianchang.qq.com/manage/index.html" target="_blank" class="hide"> <img style="position: absolute; top: 0; right: 0; border: 0; width:100px; z-index:10000" src="images/default/peel.png" title="马上创建您专属的微现场"> </a>', new l(i)
		}), e("component/festival/lottery/awards", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = "";
			return n(r, function(e) {
				s += ' <li class="options" data-target="', s += i(e.id), s += '" data-option="', s += i(e.name), s += '">', s += i(e.name), s += "</li> "
			}), s += " ", new l(s)
		}), e("component/festival/lottery/layout", '<div id="lottery" class="view"> <div class="draw-box"> <div class="draw-header"> <div class="draw-title">现场抽奖</div> </div> <div class="slot-box"> <div class="slot-box-wrapper clearfix"> <div class="emo"><img src="images/default/emo.png" /></div> <div class="title">求中奖，快到碗里来</div> </div> </div> </div> <div class="controll-box"> <div class="select-wrapper" id="award-selector"> <a class="select-btn"><span>请选择奖品类别</span> <i class="select-btn-arrow icon icon-arrow"></i></a> <ul class="select-options hide"> </ul> </div>  <div class="select-wrapper" id="quantity-selector"> <div class="lottery-num clearfix"> <span class="lottery-num-btn minus">-</span> <input id="lotteryNum" value="1" /> <span class="lottery-num-btn add">+</span> </div> </div> <div class="award-img-wrapper"> </div> <div class="lottery-btn"> 正在加载奖池... </div> <div class="lottery-history"> 查看中奖记录 </div> </div> </div> '), e("component/festival/lottery/list", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = (e.winner, e.j, t.$string),
				o = "";
			return o += '<div id="history-swiper-con" class="history-box"> <div class="swiper-wrapper"> ', n(r, function(e) {
				o += ' <div class="swiper-slide"> <div class="history-row clearfix"> <div class="history-award fl"> <img width="250" height="250" src="', o += i(e.image), o += '"> <p>', o += i(e.award), o += '</p> </div> <div class="history-winner fl"> <ul class="history-winner-list clearfix"> ', n(e.winner, function(e) {
					o += ' <li class="history-winner-item fl clearfix"> <div class="history-winner-avatar fl"> ', e.head ? (o += ' <img src="', o += i(e.head), o += '" width="100" height="100" alt=""> ') : o += ' <img src="images/default/avatar.png" width="100" height="100" alt=""> ', o += ' </div> <div class="history-winner-name fl">', o += s(e.name), o += "</div> </li> "
				}), o += " </ul> </div> </div> </div> "
			}), o += ' </div> <div class="winners-prev"><i class="icon icon-arrow-left"></i></div> <div class="winners-next"><i class="icon icon-arrow-right"></i></div> </div> <!-- <div class="history-overlay"> <div class="history-list"> <div class="history-header"> <span>获奖名单</span> </div> <div id="history-swiper-con"> <div class="swiper-wrapper"> ', n(r, function(e) {
				o += ' <div class="swiper-slide"> <div class="history-row clearfix"> <div class="history-award fl"> <img width="250" height="250" src="', o += i(e.imageurl), o += '"> <p>', o += i(e.award), o += '</p> </div> <div class="history-winner fl"> <ul class="history-winner-list clearfix"> ', n(e.winner, function(e) {
					o += ' <li class="history-winner-item fl clearfix"> <div class="history-winner-avatar fl"> ', e.head ? (o += ' <img src="', o += i(e.head), o += '" width="100" height="100" alt=""> ') : o += ' <img src="images/default/avatar.png" width="100" height="100" alt=""> ', o += ' </div> <div class="history-winner-name fl">', o += s(e.nick), o += "</div> </li> "
				}), o += " </ul> </div> </div> </div> "
			}), o += ' </div> </div> <div class="icon icon-arrow-left arrow-left"></div> <div class="icon icon-arrow-right arrow-right"></div> </div> </div> -->', new l(o)
		}), e("component/festival/lottery/pools", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = t.$string,
				o = "";
			return n(r, function(e) {
				o += ' <li class="options" data-target="', o += i(e.id), o += '" data-option="', o += i(e.name), o += '">', o += s(e.name), o += "</li> "
			}), o += " ", new l(o)
		}), e("component/festival/lottery/quantity", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = "";
			return n(r, function(e, t) {
				s += ' <li class="options" data-target="', s += i(t + 1), s += '" data-option="', s += i(t + 1), s += '">', s += i(t + 1), s += "</li> "
			}), s += " ", new l(s)
		}), e("component/festival/lottery/single", '<div class="slot-box-single"> <ul> <li class="item">1</li> <li class="item">2</li> <li class="item">3</li> <li class="item">4</li> <li class="item">5</li> <li class="item">6</li> <li class="item">7</li> <li class="item">8</li> </ul> </div> '), e("component/festival/lottery/slot", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, e.inner),
				r = t.$escape,
				i = e.item,
				s = t.$string,
				o = "";
			return n ? (o += ' <div class="slot-avatar"> <img src="', o += r(i.head), o += '" class="lotteryImg" width="150" height="150" alt=""> </div> <div class="slot-shadow"></div> <div class="slot-name">', o += s(i.name), o += "</div> ") : (o += ' <div class="slot-box-item"> <div class="slot-avatar"> <img src="', o += r(i.head), o += '" class="lotteryImg" width="150" height="150" alt=""> </div> <div class="slot-shadow"></div> <div class="slot-name">', o += s(i.name), o += "</div> </div> "), o += " ", new l(o)
		}), e("component/festival/message/detail", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.index,
				i = e.height,
				s = e.head,
				o = e.anonymous,
				u = t.$string,
				a = e.name,
				f = e.fontsize,
				c = e.type,
				h = e.content,
				p = "";
			return p += '<div class="detail clearfix" data-index="', p += n(r), p += '" style="height:', p += n(i), p += 'px"> <div class="left fl"> <div class="avatar"> <img id="userhead_', p += n(r), p += '" src="', p += n(s), p += '" alt=""> </div> </div> <div class="right"> ', 0 == o ? (p += ' <div class="name">', p += u(a), p += '</div> <div class="message" style="font-size:', p += n(f), p += "px; line-height:", p += n(f + 10), p += 'px"> ', 0 == c ? (p += " ", p += u(h), p += " ") : (p += ' <img src="', p += n(h), p += '" > '), p += " </div> ") : (p += ' <div class="message h100" style="font-size:', p += n(f), p += "px; line-height:", p += n(f + 10), p += 'px"> ', 0 == c ? (p += " ", p += u(h), p += " ") : (p += ' <img src="', p += n(h), p += '" > '), p += " </div> "), p += ' </div> <div class="corner"></div> <div class="index">', p += n(r + 1), p += '</div> <div class="close"><i class="icon icon-close"></i></div> </div> ', new l(p)
		}), e("component/festival/message/item", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.index,
				i = e.height,
				s = e.head,
				o = e.anonymous,
				u = t.$string,
				a = e.name,
				f = e.fontsize,
				c = e.type,
				h = e.content,
				p = "";
			return p += '<div class="item clearfix" data-index="', p += n(r), p += '" style="height:', p += n(i), p += 'px"> <div class="left fl"> <div class="avatar"> <img id="userhead_', p += n(r), p += '" src="', p += n(s), p += '" alt=""> </div> </div> <div class="right"> ', 0 == o ? (p += ' <div class="name">', p += u(a), p += '</div> <div class="message" style="font-size:', p += n(f), p += "px; line-height:", p += n(f + 10), p += 'px"> ', 0 == c ? (p += " ", p += u(h), p += " ") : (p += ' <img src="', p += n(h), p += '" > '), p += " </div> ") : (p += ' <div class="message h100" style="font-size:', p += n(f), p += "px; line-height:", p += n(f + 10), p += 'px"> ', 0 == c ? (p += " ", p += u(h), p += " ") : (p += ' <img src="', p += n(h), p += '" > '), p += " </div> "), p += ' </div> <div class="corner"></div> <div class="index">', p += n(r + 1), p += "</div> </div> ", new l(p)
		}), e("component/festival/message/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.wxqrcode,
				i = e.wxname,
				s = "";
			return s += '<div id="message" class="view clearfix"> <div class="sidebar fl" id="sidebar"> <div class="sb-wrapper"> <div class="c-wrapper" id="mask_btn"> <img src="', s += n(r), s += '" /> </div> <p class="comment account"><span>', s += n(i), s += '</span></p> <p class="comment"> ', s += i ? " 关注微信号 " : " 扫描二维码 ", s += ' </p> <p class="comment">参与互动上墙</p> </div> </div> <div id="mask" class="mask hide"> <div class="mask-wrapper"> <img src="', s += n(r), s += '" width="460" height="460"/> </div> </div> <div id="message_wrapper" class="fl"> <div class="message-loading-con"> <p>正在加载上墙消息...</p> <div class="message-loading-progress"> <div class="message-loading-progress-bar" style="width: 0%">0%</div> </div> </div> <div class="message-con swiper-container" id="container_list"> <div class="swiper-wrapper"> </div> </div> <div class="message-con swiper-container hide" id="container_detail"> <div class="swiper-wrapper"> </div> </div> </div> </div> ', new l(s)
		}), e("component/festival/message/sidebar", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.wxqrcode,
				i = e.wxname,
				s = t.$string,
				o = "";
			return o += '<div class="sb-wrapper"> <div class="c-wrapper" id="mask_btn"> <img src="', o += n(r), o += '" /> </div> <p class="comment"> ', o += i ? " 关注微信号 " : " 扫描二维码 ", o += ' </p> <p class="comment account"><span>', o += s(i), o += '</span></p> <p class="comment">参与互动上墙</p> </div>', new l(o)
		}), e("component/festival/modal/alert", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, e.title),
				r = t.$escape,
				i = e.message,
				s = "";
			return s += '<div id="alert" class="modal fade"> <div class="modal-dialog modal-sm"> <div class="modal-content"> <div class="modal-header"> <h4 class="modal-title">', s += n ? r(n) : "提示", s += '<h4> </div> <div class="modal-body" style="min-height:200px"> ', s += r(i), s += ' </div> <div class="modal-footer"> <a class="btn btn-primary" data-dismiss="modal">确定</a> </div> </div> </div> </div> ', new l(s)
		}), e("component/festival/modal/game", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.campaign_id,
				i = "";
			return i += '<div id="game" class="modal fade"> <div class="modal-dialog"> <div class="modal-content"> <div class="modal-header"> <h4 class="modal-title">游戏</h4> </div> <div class="modal-body"> <div class="game-wrapper clearfix"> <ul> <li class="game"> <div class="pic"> <img src="images/default/game/shake.jpg" / > <div class="button"> <span>摇一摇比赛</span> <a class="btn btn-primary remodal-cancel modal-close" app-jump="#', i += n(r), i += '/shake">开始游戏</a> </div> </div> </li> <li class="game"> <div class="pic"> <img src="images/default/game/guess.jpg" / > <div class="button"> <span>剪刀石头布</span> <a class="btn btn-primary remodal-cancel modal-close" app-jump="#', i += n(r), i += '/guess">开始游戏</a> </div> </div> </li> <li class="game" > <div class="pic"> <img src="images/default/game/default.jpg" / > </div> </li> </ul> </div> </div> <div class="modal-footer"> <a class="btn btn-default" data-dismiss="modal">返回</a> </div> </div> </div> </div> ', new l(i)
		}), e("component/festival/modal/setting", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, e.theme),
				r = t.$escape,
				i = e.bgurl,
				s = e.interval,
				o = e.anonymous,
				u = "";
			return u += '<div id="setting" class="modal fade"> <div class="modal-dialog"> <div class="modal-content"> <div class="modal-header"> <h4 class="modal-title">设置</h4> </div> <div class="modal-body"> <div class="tab-wrapper"> <ul class="clearfix"> <li class="tab active"><a href="javascript:;">设置</a></li> </ul> </div> <div id="tab-swiper"> <!-- <div class="slide active"> <ul> <li class="theme ', "default" == n && (u += "active"), u += '" data-theme="default"> <div class="pic"> <img src="images/default/demo.jpg" / > <div class="name">商务会议</div> </div> <div class="check"></div> </li> <li class="theme ', "festival" == n && (u += "active"), u += '" data-theme="festival"> <div class="pic"> <img src="images/festival/demo.jpg" / > <div class="name">节日盛宴</div> </div> <div class="check"></div> </li> <li class="theme ', "wedding" == n && (u += "active"), u += '" data-theme="wedding"> <div class="pic"> <img src="images/wedding/demo.jpg" / > <div class="name">婚庆典礼</div> </div> <div class="check"></div> </li> <li class="theme ', "ds6" == n && (u += "active"), u += '" data-theme="ds6"> <div class="pic"> <img src="images/ds6/thumb.jpg" / > <div class="name">商业展会</div> </div> <div class="check"></div> </li> </ul> <input type="hidden" id="theme-value" value="', u += r(n), u += '"/> </div> <div class="slide"> <div class="upload-wrapper clearfix"> <div class="upload-img-box"> <img src="', u += r(i), u += '" /> </div> <div class="upload-img-select"> <div class="upload-btn btn btn-default"> <span>点击上传图片</span> <input id="upload-img-fileinput" type="file" title="点击更换图片" value="', u += r(i), u += '" /> </div> <div class="clear-btn btn btn-default"> <span>使用默认背景</span> </div> <p>*建议上传图片尺寸1920*1080，大小3M以内的图片</p> </div> <input type="hidden" id="bgurl-value" value="', u += r(i), u += '"/> </div> </div> --> <div class="slide active"> <div class="item"> <div class="inner-header">账号设置</div> <div class="inner-content"> <a class="btn btn-default" id="logout">更换账号</a> </div> </div> <!-- <div class="item"> <div class="inner-header">消息墙控制</div> <div class="inner-content"> <div class="form-group clearfix"> <label for="messageScrollTime" class="fl">滚动时间</label> <div id="messageScrollTimeBar" class="fl scrollbar"> </div> <div class="scrollval fl"></div> </div> <div class="form-group clearfix"> <label for="messageInterval" class="fl">循环播放</label> <div class="fl"> <label for="#" class="ui-switch"> ', u += s ? ' <input type="checkbox" id="messageInterval" checked="true" /> ' : ' <input type="checkbox" id="messageInterval" /> ', u += ' </label> </div> <div class="fl desc"> 消息从最后一条自动滚至第一条循环播放 </div> </div> <div class="form-group clearfix"> <label for="messageAnonymous" class="fl">匿名消息</label> <div class="fl"> <label for="#" class="ui-switch"> ', u += o ? ' <input type="checkbox" id="messageAnonymous" checked="true" /> ' : ' <input type="checkbox" id="messageAnonymous" /> ', u += ' </label> </div> <div class="fl desc"> 开启匿名消息以后将使用随机头像并匿名 </div> </div> </div> </div> --> </div> </div> </div> <div class="modal-footer"> <a class="btn btn-default" data-dismiss="modal">返回</a>  </div> </div> </div> </div> ', new l(u)
		}), e("component/festival/modal/winners", '<div id="history" class="modal fade"> <div class="modal-dialog" style="width:80%;"> <div class="modal-content"> <div class="modal-header"> <h4 class="modal-title">获奖名单</h4> </div> <div class="modal-body"> <div class="modal-loading"> <i class="icon icon-loading"></i> 数据加载中... </div> </div> <div class="modal-footer"> <a class="btn btn-default" data-dismiss="modal">返回</a> </div> </div> </div> </div>'), e("component/festival/signin/item", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.head,
				i = t.$string,
				s = e.name,
				o = "";
			return o += '<div class="signin-item"> <div class="signin-item-img"><img src="', o += n(r), o += '" /></div> <span class="signin-item-text">', o += i(s), o += "</span> </div>", new l(o)
		}), e("component/festival/signin/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.item_num,
				i = e.img_src,
				s = "";
			return s += '<div id="signin" class="view"> <div class="signin-con"> <div class="signin-header clearfix"> <div class="signin-header-title fl"> <a class="signin-header-left">签到墙</a> <a class="signin-header-right"> 共<span class="signin-header-num">', s += n(r), s += '</span>人签到 </a> </div> </div> <div class="signin-content"></div> </div> <div class="signin-qrcode-btn"></div> <div id="signin-qrcode" class="signin-qrcode hide"> <div class="signin-qrcode-wrapper"> <img src="', s += n(i), s += '" width="460" height="460"/> </div> </div> </div>', new l(s)
		}), e("component/festival/slogen/main", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.slogans,
				i = (e.item, e.$index, t.$escape),
				s = "";
			return s += '<div class="slogen-bg"> <div class="slogen-wrapper" id="slogen-swiper-con"> <div class="swiper-wrapper"> ', n(r, function(e) {
				s += ' <div class="swiper-slide"> <div class="slogen-row clearfix"> <p>', s += i(e), s += "</p> </div> </div> "
			}), s += " </div> </div> </div>", new l(s)
		}), e("component/festival/toolkit/main", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.campaign_id,
				i = "";
			return i += '<div class="toolkit-bg"> <div class="toolkit-wrapper row"> <div class="nav-bar fl"> <ul> <li app-jump="#', i += n(r), i += '/signin" class="signin link tooltip tooltip-effect-2"> <i class="icon icon-signin"></i> <div class="tooltip-content"><span>签到</span></div> </li> <li app-jump="#', i += n(r), i += '/message" class="wall link tooltip tooltip-effect-2"> <i class="icon icon-message"></i> <div class="tooltip-content"><span>消息上墙</span></div> </li> <li app-jump="#', i += n(r), i += '/image" class="wall link tooltip tooltip-effect-2"> <i class="icon icon-image"></i> <div class="tooltip-content"><span>纯图模式</span></div> </li> <li app-bullet="enable" id="shoot" class="tooltip tooltip-effect-2"> <i class="icon icon-bullet"></i> <div class="tooltip-content"><span>弹幕开关</span></div> </li> <li app-jump="#', i += n(r), i += '/lottery" class="lottery link tooltip tooltip-effect-2"> <i class="icon icon-lottery"></i> <div class="tooltip-content"><span>抽奖</span></div> </li> <li app-jump="#', i += n(r), i += '/vote" class="vote link tooltip tooltip-effect-2"> <i class="icon icon-vote"></i> <div class="tooltip-content"><span>投票</span></div> </li> <li app-jump="#', i += n(r), i += '/shake" class="game link tooltip tooltip-effect-2"> <i class="icon icon-game"></i> <div class="tooltip-content"><span>摇一摇</span></div> </li> <li id="fullscreen" class="tooltip tooltip-effect-2"> <i class="icon icon-full-screen fullScreen"></i> <div class="tooltip-content"><span>全屏</span></div> </li> <li id="setting-btn" class="tooltip tooltip-effect-2"> <i class="icon icon-setting"></i> <div class="tooltip-content"><span>设置</span></div> </li> </ul> </div> <div class="action-bar fr hide"> <ul> <li message-action="backward" class="tooltip tooltip-effect-2"> <i class="icon icon-backward"></i> <div class="tooltip-content"><span>第一条</span></div> </li> <li message-action="step-backward" class="tooltip tooltip-effect-2"> <i class="icon icon-step-backward"></i> <div class="tooltip-content"><span>向上一条</span></div> </li> <li message-action="play" class="tooltip tooltip-effect-2"> <i class="icon icon-pause"></i> <div class="tooltip-content"><span>开始/暂停</span></div> </li> <li message-action="step-forward" class="tooltip tooltip-effect-2"> <i class="icon icon-step-forward"></i> <div class="tooltip-content"><span>向下一条</span></div> </li> <li message-action="forward" class="tooltip tooltip-effect-2"> <i class="icon icon-forward"></i> <div class="tooltip-content"><span>最后一条</span></div> </li> </ul> </div> </div> </div>', new l(i)
		}), e("component/festival/vote/column", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.item,
				i = "";
			return i += '<div class="vote-column" id="vote-column-', i += n(r.item_id), i += '"> <div class="vote-column-con"> <div class="vote-column-count" style="color:', i += n(r.color), i += "; bottom:", i += n(r.height + 15), i += 'px;">', i += n(r.count), i += "票 ( ", i += n(r.percent), i += '% )</div> <div class="vote-column-bar" style="background-color:', i += n(r.color), i += "; height: ", i += n(r.height), i += 'px;"></div> </div> <div class="vote-column-title">', i += n(r.name), i += "</div> </div>", new l(i)
		}), e("component/festival/vote/count", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.item,
				i = "";
			return i += n(r.count), i += "票 ( ", i += n(r.percent), i += "% )", new l(i)
		}), e("component/festival/vote/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.item, e.index, t.$escape),
				s = t.$string,
				o = e.qrcode,
				u = "";
			return u += '<div id="vote" class="view"> <div class="vote-con" id="vote_list"> <div class="swiper-wrapper"> ', n(r, function(e) {
				u += ' <div class="swiper-slide"> <div class="vote" id="vote-', u += i(e.vote_id), u += '" data-index="', u += i(e.vote_id), u += '"> <div class="vote-header clearfix"> <div class="vote-header-title fl"> <a class="vote-header-left">', u += s(e.name), u += '</a> <a class="vote-header-right"> 共<span class="vote-header-num vote-title-num">0</span>人参与 </a> </div> </div> <div class="vote-content vote-content"> <div class="vote-scrollbar-move"> </div> </div> </div> </div> '
			}), u += ' </div> </div> <div class="vote-prev"><i class="icon icon-arrow-left"></i></div> <div class="vote-next"><i class="icon icon-arrow-right"></i></div> <div class="vote-qrcode-btn"></div> <div id="vote-qrcode" class="vote-qrcode hide"> <div class="vote-qrcode-wrapper"> <img width="460" height="460" src="', u += i(o), u += '"/> </div> </div> <div class="vote-order"> <input type="checkbox" class="order-switch" name="order-switch"> <label for="order-switch">排序</label> </div> </div>', new l(u)
		}), e("component/meeting/brand/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.item_num,
				i = "";
			return i += '<div id="brand" class="view"> <div class="brand-header"> <div class="brand-header-title fl"> <a class="brand-header-left">签到墙</a> <a class="brand-header-right"> 共<span class="brand-header-num">', i += n(r), i += '</span>人签到 </a> </div> </div> <div class="brand-content"> <canvas id="brand-canvas"></canvas> <div id="brand-avatar"></div> </div> <div id="brand-style"></div> </div>', new l(i)
		}), e("component/meeting/game/guess/join", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.head,
				i = "";
			return i += '<li class="game-user"> <div class="head"> <img src="', i += n(r), i += '" alt=""> </div> </li> ', new l(i)
		}), e("component/meeting/game/guess/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.guessQrcode,
				i = e.guessTime,
				s = "";
			return s += '<div id="guess" class="view"> <div class="game-con"> <div class="game-prepare"> <div class="game-header clearfix"> <div class="game-header-title fl"> <a class="game-header-left">石头剪刀布比赛</a> </div> </div> <div class="game-userlist"> <div class="game-userlist-nouser clearfix"> <div class="game-userlist-emo"><img src="images/default/emo.png" /></div> <div class="game-userlist-title">扫描二维码，参与摇一摇比赛</div> </div> <div class="game-userlist-con"> <ul class="clearfix"> </ul> </div> </div> </div> <div class="game-sidebar"> <div class="game-sidebar-title">扫描二维码参与</div> <div class="game-sidebar-qrcode"> <div class="game-sidebar-qrcode-inner"> <img src="', s += n(r), s += '"> </div> </div> <div class="game-sidebar-btn-con"> <div class="game-sidebar-btn-info">游戏时间(分钟)</div> <div class="game-sidebar-config clearfix"> <span class="game-sidebar-config-btn minus">-</span><span id="guessTime">', s += n(i), s += '</span><span class="game-sidebar-config-btn add">+</span> </div> <div class="game-sidebar-btn start-btn">倒计时开始</div> </div> </div> <div class="game-process hide"> <ul class="clearfix" style="position:relative;width:60%;height:100%;overflow:hidden"> </ul> <div class="process-timer">60</div> </div> </div> <div class="count-overlay"> <div class="count-body"> <div class="count-wrapper right"> <div class="count-circle rightcircle"></div> </div> <div class="count-wrapper left"> <div class="count-circle leftcircle"></div> </div> <div class="number"> <div class="count count3"><img src="images/default/number/3.png"></div> <div class="count count2"><img src="images/default/number/2.png"></div> <div class="count count1"><img src="images/default/number/1.png"></div> </div> </div> </div> <div class="game-result-overlay"> </div> </div> <!-- <div id="guess" class="view"> <div class="prepare-con"> <div class="prepare-header center"> <div class="underline"> <span class="title">扫描二维码，参与石头剪刀布比赛</span> </div> </div> <div class="prepare-content-con clearfix"> <div class="topline"> <div class="prepare-qrcode-con center"> <div class="prepare-qrcode"> <img src="', s += n(r), s += '"> </div> <div class="prepare-btn-con"> <div class="start-btn">游戏开始</div> <div class="game-config">游戏时间(分钟)：<span class="config-btn minus">-</span><span id="guessTime">', s += n(i), s += '</span><span class="config-btn add">+</span></div> </div> </div> </div> </div> </div> <div class="game-con"> <div class="process-con"> <div class="process-rank fl"> <ul class="clearfix"> </ul> </div> <div class="process-timer">38</div> </div> <div class="result-con"> <div class="result-header"> <div class="underline"> <span class="title">恭喜以下选手取得好成绩！</span> <div class="back-btn-con"> <div class="btn btn-tran">返回</div> </div> </div> </div> <div class="result-content-con clearfix"> <div class="topline" id="game_result"> </div> </div> </div> </div> </div> -->', new l(s)
		}), e("component/meeting/game/guess/rank", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.openID,
				i = e.top,
				s = e.index,
				o = e.head,
				u = e.name,
				a = e.score,
				f = "";
			return f += '<li class="item" id="process_item_', f += n(r), f += '" style="top:', f += n(i), f += 'px"> <div class="rank fl"> ', 3 > s ? (f += ' <span class="medal rank', f += n(s + 1), f += '"></span> ') : (f += ' <span class="num">', f += n(s + 1), f += "</span> "), f += ' </div> <div class="head fl"> <img src="', f += n(o), f += '" width="100" height="100" alt=""> </div> <div class="name"> ', f += n(u), f += ' </div> <div class="percent fr"> ', f += n(a), f += "分 </div> </li>", new l(f)
		}), e("component/meeting/game/guess/record", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = "";
			return s += '<div class="board"> <div class="visual"> ', n(r, function(e, t) {
				s += " ", 3 > t && (s += ' <div class="top top', s += i(t + 1), s += '"> <div class="head"> <img src="', s += i(e.head), s += '"> </div> <div class="ribbon"></div> <div class="name">', s += i(e.name), s += "</div> </div> "), s += " "
			}), s += ' <ul class="top10 clearfix"> ', n(r, function(e, t) {
				s += " ", t >= 3 && 10 > t && (s += ' <li class="fl"> <div class="head"> <img src="', s += i(e.head), s += '"> </div> <div class="name"> <div class="num">', s += i(t + 1), s += "</div> ", s += i(e.name), s += " <div> </li> "), s += " "
			}), s += ' </ul> <div class="board-footer"> <span class="show-list">查看全部排名</span> <span class="restart">重新开始</span> </div> </div> <div class="list hide"> <div class="list-body"> <table> <tr><th>排名</th><th>微信id</th></tr> ', n(r, function(e, t) {
				s += " <tr><td>", s += i(t + 1), s += "</td><td>", s += i(e.name), s += "</td></tr> "
			}), s += ' </table> </div> <div class="board-footer"> <span class="show-visual">查看Top10</span> <span class="restart">重新开始</span> </div> </div> </div>', new l(s)
		}), e("component/meeting/game/shake/join", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.head,
				i = "";
			return i += '<li class="game-user"> <div class="head"> <img src="', i += n(r), i += '" alt=""> </div> </li>', new l(i)
		}), e("component/meeting/game/shake/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.shakeQrcode,
				i = e.shakeTime,
				s = "";
			return s += '<div id="shake" class="view"> <div class="game-con"> <div class="game-prepare"> <div class="game-header clearfix"> <div class="game-header-title fl"> <a class="game-header-left">摇一摇夺奖</a> <a class="game-header-right"> 共<span class="game-header-num" id="join_num">0</span>人参与 </a> </div> </div> <div class="game-userlist"> <div class="game-userlist-nouser clearfix"> <div class="game-userlist-emo"><img src="images/default/emo.png" /></div> <div class="game-userlist-title">扫描二维码，参与摇一摇比赛</div> </div> <div class="game-userlist-con"> <ul class="clearfix"> </ul> </div> </div> </div> <div class="game-sidebar"> <div class="game-sidebar-title">扫描二维码参与</div> <div class="game-sidebar-qrcode"> <div class="game-sidebar-qrcode-inner"> <img src="', s += n(r), s += '"> </div> </div> <div class="game-sidebar-btn-con"> <div class="game-sidebar-btn-info">摇一摇次数设置</div> <div class="game-sidebar-config clearfix"> <span class="game-sidebar-config-btn minus">-</span><span id="shakeTime">', s += n(i), s += '</span><span class="game-sidebar-config-btn add">+</span> </div> <div class="game-sidebar-btn start-btn">倒计时开始</div> </div> </div> <div class="game-process hide"> <ul class="clearfix"> </ul> <div id="reset">重新开始</div> </div> </div> <div class="count-overlay"> <div class="count-body"> <div class="count-wrapper right"> <div class="count-circle rightcircle"></div> </div> <div class="count-wrapper left"> <div class="count-circle leftcircle"></div> </div> <div class="number"> <div class="count count3"><img src="images/default/number/3.png"></div> <div class="count count2"><img src="images/default/number/2.png"></div> <div class="count count1"><img src="images/default/number/1.png"></div> </div> </div> </div> <div class="game-result-overlay"> </div> </div> <!-- <div id="shake" class="view"> <div class="prepare-con"> <div class="prepare-header"> <div class="underline"> <span class="title left">扫描二维码，参与摇一摇比赛</span> <div class="fr"> <span class="title orange" id="join_num">0</span><span class="title">人参与</span> </div> </div> </div> <div class="prepare-content-con clearfix"> <div class="topline"> <div class="prepare-qrcode-con fl"> <div class="prepare-qrcode"> <img src="', s += n(r), s += '"> </div> <div class="prepare-btn-con"> <div class="start-btn">倒计时开始</div> <div class="game-config">摇一摇次数：<span class="config-btn minus">-</span><span id="shakeTime">', s += n(i), s += '</span><span class="config-btn add">+</span></div> </div> </div> </div> <div class="prepare-user-con fl"> <ul class="clearfix"> </ul> </div> </div> </div> <div class="game-con"> <div class="count-con"> <div class="count count3"></div> <div class="count count2"></div> <div class="count count1"></div> <div class="count count0"></div> </div> <div class="process-con"> <ul class="clearfix"> </ul> </div> <div class="result-con"> <div class="result-header"> <div class="underline"> <span class="title">恭喜以下选手取得好成绩！</span> <div class="back-btn-con"> <div class="btn btn-tran">返回</div> </div> </div> </div> <div class="result-content-con clearfix"> <div class="topline" id="game_result"> </div> </div> </div> </div> </div> -->', new l(s)
		}), e("component/meeting/game/shake/rank", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.openid,
				i = e.top,
				s = e.index,
				o = e.head,
				u = e.name,
				a = e.percent,
				f = "";
			return f += '<li class="item" id="process_item_', f += n(r), f += '" style="top:', f += n(i), f += 'px"> <div class="rank fl"> ', 3 > s ? (f += ' <span class="medal rank', f += n(s + 1), f += '"></span> ') : (f += ' <span class="num">', f += n(s + 1), f += "</span> "), f += ' </div> <div class="head fl"> <img src="', f += n(o), f += '" width="100" height="100" alt=""> </div> <div class="name"> ', f += n(u), f += ' </div> <div class="progress"> <img class="run" src="images/default/run.gif" style="right:100%"> </img> <div class="progress-wrapper"> <span class="val" style="-webkit-transform: translateX(-100%);"> </span> </div> </div> <div class="percent fr"> ', f += n(a), f += " </div> </li>", new l(f)
		}), e("component/meeting/game/shake/record", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = "";
			return s += '<div class="board"> <div class="visual"> ', n(r, function(e, t) {
				s += " ", 3 > t && (s += ' <div class="top top', s += i(t + 1), s += '"> <div class="head"> <img src="', s += i(e.head), s += '"> </div> <div class="ribbon"></div> <div class="name">', s += i(e.name), s += "</div> </div> "), s += " "
			}), s += ' <ul class="top10 clearfix"> ', n(r, function(e, t) {
				s += " ", t >= 3 && 10 > t && (s += ' <li class="fl"> <div class="head"> <img src="', s += i(e.head), s += '"> </div> <div class="name"> <div class="num">', s += i(t + 1), s += "</div> ", s += i(e.name), s += " <div> </li> "), s += " "
			}), s += ' </ul> <div class="board-footer"> <span class="show-list">查看全部排名</span> <span class="restart">重新开始</span> </div> </div> <div class="list hide"> <div class="list-body"> <table> <tr><th>排名</th><th>微信id</th></tr> ', n(r, function(e, t) {
				s += " <tr><td>", s += i(t + 1), s += "</td><td>", s += i(e.name), s += "</td></tr> "
			}), s += ' </table> </div> <div class="board-footer"> <span class="show-visual">查看Top10</span> <span class="restart">重新开始</span> </div> </div> </div>', new l(s)
		}), e("component/meeting/header/main", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.name,
				i = "";
			return i += '<div class="clearfix"> <div class="title fl"> <h1>', i += n(r), i += "</h1> </div> </div>", new l(i)
		}), e("component/meeting/image/detail", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.index,
				i = e.anonymous,
				s = t.$string,
				o = e.name,
				u = e.content,
				a = "";
			return a += '<div class="image clearfix" data-index="', a += n(r), a += '"> <div class="head clearfix"> ', 0 == i && (a += ' <div class="left fl">', a += s(o), a += "</div> "), a += ' <div class="right fr">', a += n(r + 1), a += '</div> </div> <div class="body"> <div class="pic"> <img src="', a += n(u), a += '" id="FullImg_', a += n(r), a += '"> </div> </div> </div>', new l(a)
		}), e("component/meeting/image/layout", '<div id="image" class="view"> <div class="image-con swiper-container" id="container_image"> <div class="message-loading-con"> <p>正在加载上墙消息...</p> <div class="message-loading-progress"> <div class="message-loading-progress-bar" style="width: 0%">0%</div> </div> </div> <div class="swiper-wrapper"> </div> </div> </div> '), e("component/meeting/layout/error", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.message,
				i = "";
			return i += ' <div class="container background_img" id="background_img"> </div>  <div class="container browser_tips hide" id="browser_tips"> <div class="row clearfix" > <div class="browser_logo fl"> <img src="images/default/logo_black.png" /> </div> <div class="browser_download"> <p>您的浏览器对大屏幕上墙效果支持不佳，或者使用的浏览器版本过低，建议更换新版chrome浏览器获得更好的上墙体验</p> <a href="http://xiazai.sogou.com/detail/34/8/6262355089742005676.html">点击去下载chrome浏览器 <img src="images/default/chrome.png"></a> </div> </div> </div>  <div class="container stage"> <div class="row header clearfix" id="header"> </div> <div class="row main clearfix"> <div class="viewport"> <div class="error"> ', i += n(r), i += ' </div> </div> <div class="blur"> <div> </div> </div> </div> </div> ', new l(i)
		}), e("component/meeting/layout/main", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, e.bgurl),
				r = t.$escape,
				i = "";
			return i += ' <div class="container background_img" id="background_img" ', "" != n && (i += 'style="background-image:url(', i += r(n), i += ')"'), i += '> </div>  <div class="container browser_tips hide" id="browser_tips"> <div class="row clearfix" > <div class="browser_logo fl"> <img src="images/default/logo_black.png" /> </div> <div class="browser_download"> <p>您的浏览器对大屏幕上墙效果支持不佳，或者使用的浏览器版本过低，建议更换新版chrome浏览器获得更好的上墙体验</p> <a href="http://xiazai.sogou.com/detail/34/8/6262355089742005676.html">点击去下载chrome浏览器 <img src="images/default/chrome.png"></a> </div> </div> </div>  <div class="container stage"> <div class="row header clearfix" id="header"> </div> <div class="row main clearfix"> <div class="viewport"> </div> </div> </div>  <div class="container hover" id="ctrlbar"> <div class="clearfix" id="slogen"> </div> <div class="clearfix" id="toolkit"> </div> </div> <div class="gallery-con invisible"> <div id="comment" class="abp"> <div id="comment-stage" class="container"></div> </div> </div>  <a id="ribbon" href="http://xianchang.qq.com/manage/index.html" target="_blank" class="hide"> <img style="position: absolute; top: 0; right: 0; border: 0; width:100px; z-index:10000" src="images/default/peel.png" title="马上创建您专属的微现场"> </a>', new l(i)
		}), e("component/meeting/lottery/awards", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = "";
			return n(r, function(e) {
				s += ' <li class="options" data-target="', s += i(e.id), s += '" data-option="', s += i(e.name), s += '">', s += i(e.name), s += "</li> "
			}), s += " ", new l(s)
		}), e("component/meeting/lottery/layout", '<div id="lottery" class="view"> <div class="draw-box"> <div class="draw-header"> <div class="draw-title">现场抽奖</div> </div> <div class="slot-box"> <div class="slot-box-wrapper clearfix"> <div class="emo"><img src="images/default/emo.png" /></div> <div class="title">求中奖，快到碗里来</div> </div> </div> </div> <div class="controll-box"> <div class="select-wrapper" id="award-selector"> <a class="select-btn"><span>请选择奖品类别</span> <i class="select-btn-arrow icon icon-arrow"></i></a> <ul class="select-options hide"> </ul> </div>  <div class="select-wrapper" id="quantity-selector"> <div class="lottery-num clearfix"> <span class="lottery-num-btn minus">-</span> <input id="lotteryNum" value="1" /> <span class="lottery-num-btn add">+</span> </div> </div> <div class="award-img-wrapper"> </div> <div class="lottery-btn"> 正在加载奖池... </div> <div class="lottery-history"> 查看中奖记录 </div> </div> </div> '), e("component/meeting/lottery/list", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = (e.winner, e.j, t.$string),
				o = "";
			return o += '<div id="history-swiper-con" class="history-box"> <div class="swiper-wrapper"> ', n(r, function(e) {
				o += ' <div class="swiper-slide"> <div class="history-row clearfix"> <div class="history-award fl"> <img width="250" height="250" src="', o += i(e.image), o += '"> <p>', o += i(e.award), o += '</p> </div> <div class="history-winner fl"> <ul class="history-winner-list clearfix"> ', n(e.winner, function(e) {
					o += ' <li class="history-winner-item fl clearfix"> <div class="history-winner-avatar fl"> ', e.head ? (o += ' <img src="', o += i(e.head), o += '" width="100" height="100" alt=""> ') : o += ' <img src="images/default/avatar.png" width="100" height="100" alt=""> ', o += ' </div> <div class="history-winner-name fl">', o += s(e.name), o += "</div> </li> "
				}), o += " </ul> </div> </div> </div> "
			}), o += ' </div> <div class="winners-prev"><i class="icon icon-arrow-left"></i></div> <div class="winners-next"><i class="icon icon-arrow-right"></i></div> </div> <!-- <div class="history-overlay"> <div class="history-list"> <div class="history-header"> <span>获奖名单</span> </div> <div id="history-swiper-con"> <div class="swiper-wrapper"> ', n(r, function(e) {
				o += ' <div class="swiper-slide"> <div class="history-row clearfix"> <div class="history-award fl"> <img width="250" height="250" src="', o += i(e.imageurl), o += '"> <p>', o += i(e.award), o += '</p> </div> <div class="history-winner fl"> <ul class="history-winner-list clearfix"> ', n(e.winner, function(e) {
					o += ' <li class="history-winner-item fl clearfix"> <div class="history-winner-avatar fl"> ', e.head ? (o += ' <img src="', o += i(e.head), o += '" width="100" height="100" alt=""> ') : o += ' <img src="images/default/avatar.png" width="100" height="100" alt=""> ', o += ' </div> <div class="history-winner-name fl">', o += s(e.nick), o += "</div> </li> "
				}), o += " </ul> </div> </div> </div> "
			}), o += ' </div> </div> <div class="icon icon-arrow-left arrow-left"></div> <div class="icon icon-arrow-right arrow-right"></div> </div> </div> -->', new l(o)
		}), e("component/meeting/lottery/pools", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = t.$string,
				o = "";
			return n(r, function(e) {
				o += ' <li class="options" data-target="', o += i(e.id), o += '" data-option="', o += i(e.name), o += '">', o += s(e.name), o += "</li> "
			}), o += " ", new l(o)
		}), e("component/meeting/lottery/quantity", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = "";
			return n(r, function(e, t) {
				s += ' <li class="options" data-target="', s += i(t + 1), s += '" data-option="', s += i(t + 1), s += '">', s += i(t + 1), s += "</li> "
			}), s += " ", new l(s)
		}), e("component/meeting/lottery/single", '<div class="slot-box-single"> <ul> <li class="item">1</li> <li class="item">2</li> <li class="item">3</li> <li class="item">4</li> <li class="item">5</li> <li class="item">6</li> <li class="item">7</li> <li class="item">8</li> </ul> </div> '), e("component/meeting/lottery/slot", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, e.inner),
				r = t.$escape,
				i = e.item,
				s = t.$string,
				o = "";
			return n ? (o += ' <div class="slot-avatar"> <img src="', o += r(i.head), o += '" class="lotteryImg" width="150" height="150" alt=""> </div> <div class="slot-shadow"></div> <div class="slot-name">', o += s(i.name), o += "</div> ") : (o += ' <div class="slot-box-item"> <div class="slot-avatar"> <img src="', o += r(i.head), o += '" class="lotteryImg" width="150" height="150" alt=""> </div> <div class="slot-shadow"></div> <div class="slot-name">', o += s(i.name), o += "</div> </div> "), o += " ", new l(o)
		}), e("component/meeting/message/detail", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.index,
				i = e.height,
				s = e.head,
				o = e.anonymous,
				u = t.$string,
				a = e.name,
				f = e.fontsize,
				c = e.type,
				h = e.content,
				p = "";
			return p += '<div class="detail clearfix" data-index="', p += n(r), p += '" style="height:', p += n(i), p += 'px"> <div class="left fl"> <div class="avatar"> <img id="userhead_', p += n(r), p += '" src="', p += n(s), p += '" alt=""> </div> </div> <div class="right"> ', 0 == o ? (p += ' <div class="name">', p += u(a), p += '</div> <div class="message" style="font-size:', p += n(f), p += "px; line-height:", p += n(f + 10), p += 'px"> ', 0 == c ? (p += " ", p += u(h), p += " ") : (p += ' <img src="', p += n(h), p += '" > '), p += " </div> ") : (p += ' <div class="message h100" style="font-size:', p += n(f), p += "px; line-height:", p += n(f + 10), p += 'px"> ', 0 == c ? (p += " ", p += u(h), p += " ") : (p += ' <img src="', p += n(h), p += '" > '), p += " </div> "), p += ' </div> <div class="corner"></div> <div class="index">', p += n(r + 1), p += '</div> <div class="close"><i class="icon icon-close"></i></div> </div> ', new l(p)
		}), e("component/meeting/message/item", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.index,
				i = e.height,
				s = e.head,
				o = e.anonymous,
				u = t.$string,
				a = e.name,
				f = e.fontsize,
				c = e.type,
				h = e.content,
				p = "";
			return p += '<div class="item clearfix" data-index="', p += n(r), p += '" style="height:', p += n(i), p += 'px"> <div class="left fl"> <div class="avatar"> <img id="userhead_', p += n(r), p += '" src="', p += n(s), p += '" alt=""> </div> </div> <div class="right"> ', 0 == o ? (p += ' <div class="name">', p += u(a), p += '</div> <div class="message" style="font-size:', p += n(f), p += "px; line-height:", p += n(f + 10), p += 'px"> ', 0 == c ? (p += " ", p += u(h), p += " ") : (p += ' <img src="', p += n(h), p += '" > '), p += " </div> ") : (p += ' <div class="message h100" style="font-size:', p += n(f), p += "px; line-height:", p += n(f + 10), p += 'px"> ', 0 == c ? (p += " ", p += u(h), p += " ") : (p += ' <img src="', p += n(h), p += '" > '), p += " </div> "), p += ' </div> <div class="corner"></div> <div class="index">', p += n(r + 1), p += "</div> </div> ", new l(p)
		}), e("component/meeting/message/layout", '<div id="message" class="view clearfix"> <div id="message_wrapper" class="fl"> <div class="message-loading-con"> <p>正在加载上墙消息...</p> <div class="message-loading-progress"> <div class="message-loading-progress-bar" style="width: 0%">0%</div> </div> </div> <div class="message-con swiper-container" id="container_list"> <div class="swiper-wrapper"> </div> </div> <div class="message-con swiper-container hide" id="container_detail"> <div class="swiper-wrapper"> </div> </div> </div> </div> '), e("component/meeting/message/sidebar", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.wxqrcode,
				i = e.wxname,
				s = t.$string,
				o = "";
			return o += '<div class="sb-wrapper"> <div class="c-wrapper" id="mask_btn"> <img src="', o += n(r), o += '" /> </div> <p class="comment"> ', o += i ? " 关注微信号 " : " 扫描二维码 ", o += ' </p> <p class="comment account"><span>', o += s(i), o += '</span></p> <p class="comment">参与互动上墙</p> </div>', new l(o)
		}), e("component/meeting/modal/alert", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, e.title),
				r = t.$escape,
				i = e.message,
				s = "";
			return s += '<div id="alert" class="modal fade"> <div class="modal-dialog modal-sm"> <div class="modal-content"> <div class="modal-header"> <h4 class="modal-title">', s += n ? r(n) : "提示", s += '<h4> </div> <div class="modal-body" style="min-height:200px"> ', s += r(i), s += ' </div> <div class="modal-footer"> <a class="btn btn-primary" data-dismiss="modal">确定</a> </div> </div> </div> </div> ', new l(s)
		}), e("component/meeting/modal/game", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.campaign_id,
				i = "";
			return i += '<div id="game" class="modal fade"> <div class="modal-dialog"> <div class="modal-content"> <div class="modal-header"> <h4 class="modal-title">游戏</h4> </div> <div class="modal-body"> <div class="game-wrapper clearfix"> <ul> <li class="game"> <div class="pic"> <img src="images/default/game/shake.jpg" / > <div class="button"> <span>摇一摇比赛</span> <a class="btn btn-primary remodal-cancel modal-close" app-jump="#', i += n(r), i += '/shake">开始游戏</a> </div> </div> </li> <li class="game"> <div class="pic"> <img src="images/default/game/guess.jpg" / > <div class="button"> <span>剪刀石头布</span> <a class="btn btn-primary remodal-cancel modal-close" app-jump="#', i += n(r), i += '/guess">开始游戏</a> </div> </div> </li> <li class="game" > <div class="pic"> <img src="images/default/game/default.jpg" / > </div> </li> </ul> </div> </div> <div class="modal-footer"> <a class="btn btn-default" data-dismiss="modal">返回</a> </div> </div> </div> </div> ', new l(i)
		}), e("component/meeting/modal/setting", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, e.theme),
				r = t.$escape,
				i = e.bgurl,
				s = e.interval,
				o = e.anonymous,
				u = "";
			return u += '<div id="setting" class="modal fade"> <div class="modal-dialog"> <div class="modal-content"> <div class="modal-header"> <h4 class="modal-title">设置</h4> </div> <div class="modal-body"> <div class="tab-wrapper"> <ul class="clearfix"> <li class="tab active"><a href="javascript:;">设置</a></li> </ul> </div> <div id="tab-swiper"> <!-- <div class="slide active"> <ul> <li class="theme ', "default" == n && (u += "active"), u += '" data-theme="default"> <div class="pic"> <img src="images/default/demo.jpg" / > <div class="name">商务会议</div> </div> <div class="check"></div> </li> <li class="theme ', "festival" == n && (u += "active"), u += '" data-theme="festival"> <div class="pic"> <img src="images/festival/demo.jpg" / > <div class="name">节日盛宴</div> </div> <div class="check"></div> </li> <li class="theme ', "wedding" == n && (u += "active"), u += '" data-theme="wedding"> <div class="pic"> <img src="images/wedding/demo.jpg" / > <div class="name">婚庆典礼</div> </div> <div class="check"></div> </li> <li class="theme ', "ds6" == n && (u += "active"), u += '" data-theme="ds6"> <div class="pic"> <img src="images/ds6/thumb.jpg" / > <div class="name">商业展会</div> </div> <div class="check"></div> </li> </ul> <input type="hidden" id="theme-value" value="', u += r(n), u += '"/> </div> <div class="slide"> <div class="upload-wrapper clearfix"> <div class="upload-img-box"> <img src="', u += r(i), u += '" /> </div> <div class="upload-img-select"> <div class="upload-btn btn btn-default"> <span>点击上传图片</span> <input id="upload-img-fileinput" type="file" title="点击更换图片" value="', u += r(i), u += '" /> </div> <div class="clear-btn btn btn-default"> <span>使用默认背景</span> </div> <p>*建议上传图片尺寸1920*1080，大小3M以内的图片</p> </div> <input type="hidden" id="bgurl-value" value="', u += r(i), u += '"/> </div> </div> --> <div class="slide active"> <div class="item"> <div class="inner-header">账号设置</div> <div class="inner-content"> <a class="btn btn-default" id="logout">更换账号</a> </div> </div> <!-- <div class="item"> <div class="inner-header">消息墙控制</div> <div class="inner-content"> <div class="form-group clearfix"> <label for="messageScrollTime" class="fl">滚动时间</label> <div id="messageScrollTimeBar" class="fl scrollbar"> </div> <div class="scrollval fl"></div> </div> <div class="form-group clearfix"> <label for="messageInterval" class="fl">循环播放</label> <div class="fl"> <label for="#" class="ui-switch"> ', u += s ? ' <input type="checkbox" id="messageInterval" checked="true" /> ' : ' <input type="checkbox" id="messageInterval" /> ', u += ' </label> </div> <div class="fl desc"> 消息从最后一条自动滚至第一条循环播放 </div> </div> <div class="form-group clearfix"> <label for="messageAnonymous" class="fl">匿名消息</label> <div class="fl"> <label for="#" class="ui-switch"> ', u += o ? ' <input type="checkbox" id="messageAnonymous" checked="true" /> ' : ' <input type="checkbox" id="messageAnonymous" /> ', u += ' </label> </div> <div class="fl desc"> 开启匿名消息以后将使用随机头像并匿名 </div> </div> </div> </div> --> </div> </div> </div> <div class="modal-footer"> <a class="btn btn-default" data-dismiss="modal">返回</a>  </div> </div> </div> </div> ', new l(u)
		}), e("component/meeting/modal/winners", '<div id="history" class="modal fade"> <div class="modal-dialog" style="width:80%;"> <div class="modal-content"> <div class="modal-header"> <h4 class="modal-title">获奖名单</h4> </div> <div class="modal-body"> <div class="modal-loading"> <i class="icon icon-loading"></i> 数据加载中... </div> </div> <div class="modal-footer"> <a class="btn btn-default" data-dismiss="modal">返回</a> </div> </div> </div> </div>'), e("component/meeting/signin/item", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.head,
				i = t.$string,
				s = e.name,
				o = "";
			return o += '<div class="signin-item"> <div class="signin-item-img"><img src="', o += n(r), o += '" /></div> <span class="signin-item-text">', o += i(s), o += "</span> </div>", new l(o)
		}), e("component/meeting/signin/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.item_num,
				i = e.img_src,
				s = "";
			return s += '<div id="signin" class="view"> <div class="signin-con"> <div class="signin-header clearfix"> <div class="signin-header-title fl"> <a class="signin-header-left">签到墙</a> <a class="signin-header-right"> 共<span class="signin-header-num">', s += n(r), s += '</span>人签到 </a> </div> </div> <div class="signin-content"></div> </div> <div class="signin-qrcode-btn"></div> <div id="signin-qrcode" class="signin-qrcode hide"> <div class="signin-qrcode-wrapper"> <img src="', s += n(i), s += '" width="460" height="460"/> </div> </div> </div>', new l(s)
		}), e("component/meeting/slogen/main", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.slogans,
				i = (e.item, e.$index, t.$escape),
				s = "";
			return s += '<div class="slogen-bg"> <div class="slogen-wrapper" id="slogen-swiper-con"> <div class="swiper-wrapper"> ', n(r, function(e) {
				s += ' <div class="swiper-slide"> <div class="slogen-row clearfix"> <p>', s += i(e), s += "</p> </div> </div> "
			}), s += " </div> </div> </div>", new l(s)
		}), e("component/meeting/toolkit/main", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.campaign_id,
				i = "";
			return i += '<div class="toolkit-bg"> <div class="toolkit-wrapper row"> <div class="nav-bar fl"> <ul> <li app-jump="#', i += n(r), i += '/signin" class="signin link tooltip tooltip-effect-2"> <i class="icon icon-signin"></i> <div class="tooltip-content"><span>签到</span></div> </li> <li app-jump="#', i += n(r), i += '/message" class="wall link tooltip tooltip-effect-2"> <i class="icon icon-message"></i> <div class="tooltip-content"><span>消息上墙</span></div> </li> <li app-jump="#', i += n(r), i += '/image" class="wall link tooltip tooltip-effect-2"> <i class="icon icon-image"></i> <div class="tooltip-content"><span>纯图模式</span></div> </li> <li app-bullet="enable" id="shoot" class="tooltip tooltip-effect-2"> <i class="icon icon-bullet"></i> <div class="tooltip-content"><span>弹幕开关</span></div> </li> <li app-jump="#', i += n(r), i += '/lottery" class="lottery link tooltip tooltip-effect-2"> <i class="icon icon-lottery"></i> <div class="tooltip-content"><span>抽奖</span></div> </li> <li app-jump="#', i += n(r), i += '/vote" class="vote link tooltip tooltip-effect-2"> <i class="icon icon-vote"></i> <div class="tooltip-content"><span>投票</span></div> </li> <li app-jump="#', i += n(r), i += '/shake" class="game link tooltip tooltip-effect-2"> <i class="icon icon-game"></i> <div class="tooltip-content"><span>摇一摇</span></div> </li> <li id="fullscreen" class="tooltip tooltip-effect-2"> <i class="icon icon-full-screen fullScreen"></i> <div class="tooltip-content"><span>全屏</span></div> </li> <li id="setting-btn" class="tooltip tooltip-effect-2"> <i class="icon icon-setting"></i> <div class="tooltip-content"><span>设置</span></div> </li> </ul> </div> <div class="action-bar fr hide"> <ul> <li message-action="backward" class="tooltip tooltip-effect-2"> <i class="icon icon-backward"></i> <div class="tooltip-content"><span>第一条</span></div> </li> <li message-action="step-backward" class="tooltip tooltip-effect-2"> <i class="icon icon-step-backward"></i> <div class="tooltip-content"><span>向上一条</span></div> </li> <li message-action="play" class="tooltip tooltip-effect-2"> <i class="icon icon-pause"></i> <div class="tooltip-content"><span>开始/暂停</span></div> </li> <li message-action="step-forward" class="tooltip tooltip-effect-2"> <i class="icon icon-step-forward"></i> <div class="tooltip-content"><span>向下一条</span></div> </li> <li message-action="forward" class="tooltip tooltip-effect-2"> <i class="icon icon-forward"></i> <div class="tooltip-content"><span>最后一条</span></div> </li> </ul> </div> </div> </div>', new l(i)
		}), e("component/meeting/vote/column", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.item,
				i = "";
			return i += '<div class="vote-column" id="vote-column-', i += n(r.item_id), i += '"> <div class="vote-column-con"> <div class="vote-column-count" style="color:', i += n(r.color), i += "; bottom:", i += n(r.height + 15), i += 'px;">', i += n(r.percent), i += '%</div> <div class="vote-column-bar" style="background-color:', i += n(r.color), i += "; height: ", i += n(r.height), i += 'px;"></div> </div> <div class="vote-column-title">', i += n(r.name), i += "</div> </div>", new l(i)
		}), e("component/meeting/vote/count", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.item,
				i = "";
			return i += n(r.percent), i += "% ", new l(i)
		}), e("component/meeting/vote/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.item, e.index, t.$escape),
				s = t.$string,
				o = "";
			return o += '<div id="vote" class="view"> <div class="vote-con" id="vote_list"> <div class="swiper-wrapper"> ', n(r, function(e) {
				o += ' <div class="swiper-slide"> <div class="vote" id="vote-', o += i(e.vote_id), o += '" data-index="', o += i(e.vote_id), o += '"> <div class="vote-header clearfix"> <div class="vote-header-title fl"> <a class="vote-header-left">', o += s(e.name), o += '</a> </div> </div> <div class="vote-content vote-content"> <div class="vote-scrollbar-move"> </div> </div> </div> </div> '
			}), o += ' </div> </div> <div class="vote-prev"><i class="icon icon-arrow-left"></i></div> <div class="vote-next"><i class="icon icon-arrow-right"></i></div> <div class="vote-order"> <input type="checkbox" class="order-switch" name="order-switch"> <label for="order-switch">排序</label> </div> </div>', new l(o)
		}), e("component/wedding/brand/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.item_num,
				i = e.img_src,
				s = "";
			return s += '<div id="brand" class="view"> <div class="brand-header"> <div class="brand-header-title fl"> <a class="brand-header-left">签到墙</a> <a class="brand-header-right"> 共<span class="brand-header-num">', s += n(r), s += '</span>人签到 </a> </div> </div> <div class="brand-content"> <canvas id="brand-canvas"></canvas> <div id="brand-avatar"></div> </div> <div id="brand-style"></div> <div class="brand-qrcode-btn"></div> <div id="brand-qrcode" class="brand-qrcode hide"> <div class="brand-qrcode-wrapper"> <img src="', s += n(i), s += '" width="460" height="460"/> </div> </div> </div>', new l(s)
		}), e("component/wedding/game/guess/join", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.head,
				i = "";
			return i += '<li class="game-user"> <div class="head"> <img src="', i += n(r), i += '" alt=""> </div> </li> ', new l(i)
		}), e("component/wedding/game/guess/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.guessQrcode,
				i = e.guessTime,
				s = "";
			return s += '<div id="guess" class="view"> <div class="game-con"> <div class="game-prepare"> <div class="game-header clearfix"> <div class="game-header-title fl"> <a class="game-header-left">石头剪刀布比赛</a> </div> </div> <div class="game-userlist"> <div class="game-userlist-nouser clearfix"> <div class="game-userlist-emo"><img src="images/default/emo.png" /></div> <div class="game-userlist-title">扫描二维码，参与摇一摇比赛</div> </div> <div class="game-userlist-con"> <ul class="clearfix"> </ul> </div> </div> </div> <div class="game-sidebar"> <div class="game-sidebar-title">扫描二维码参与</div> <div class="game-sidebar-qrcode"> <div class="game-sidebar-qrcode-inner"> <img src="', s += n(r), s += '"> </div> </div> <div class="game-sidebar-btn-con"> <div class="game-sidebar-btn-info">游戏时间(分钟)</div> <div class="game-sidebar-config clearfix"> <span class="game-sidebar-config-btn minus">-</span><span id="guessTime">', s += n(i), s += '</span><span class="game-sidebar-config-btn add">+</span> </div> <div class="game-sidebar-btn start-btn">倒计时开始</div> </div> </div> <div class="game-process hide"> <ul class="clearfix" style="position:relative;width:60%;height:100%;overflow:hidden"> </ul> <div class="process-timer">60</div> </div> </div> <div class="count-overlay"> <div class="count-body"> <div class="count-wrapper right"> <div class="count-circle rightcircle"></div> </div> <div class="count-wrapper left"> <div class="count-circle leftcircle"></div> </div> <div class="number"> <div class="count count3"><img src="images/default/number/3.png"></div> <div class="count count2"><img src="images/default/number/2.png"></div> <div class="count count1"><img src="images/default/number/1.png"></div> </div> </div> </div> <div class="game-result-overlay"> </div> </div> <!-- <div id="guess" class="view"> <div class="prepare-con"> <div class="prepare-header center"> <div class="underline"> <span class="title">扫描二维码，参与石头剪刀布比赛</span> </div> </div> <div class="prepare-content-con clearfix"> <div class="topline"> <div class="prepare-qrcode-con center"> <div class="prepare-qrcode"> <img src="', s += n(r), s += '"> </div> <div class="prepare-btn-con"> <div class="start-btn">游戏开始</div> <div class="game-config">游戏时间(分钟)：<span class="config-btn minus">-</span><span id="guessTime">', s += n(i), s += '</span><span class="config-btn add">+</span></div> </div> </div> </div> </div> </div> <div class="game-con"> <div class="process-con"> <div class="process-rank fl"> <ul class="clearfix"> </ul> </div> <div class="process-timer">38</div> </div> <div class="result-con"> <div class="result-header"> <div class="underline"> <span class="title">恭喜以下选手取得好成绩！</span> <div class="back-btn-con"> <div class="btn btn-tran">返回</div> </div> </div> </div> <div class="result-content-con clearfix"> <div class="topline" id="game_result"> </div> </div> </div> </div> </div> -->', new l(s)
		}), e("component/wedding/game/guess/rank", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.openID,
				i = e.top,
				s = e.index,
				o = e.head,
				u = e.name,
				a = e.score,
				f = "";
			return f += '<li class="item" id="process_item_', f += n(r), f += '" style="top:', f += n(i), f += 'px"> <div class="rank fl"> ', 3 > s ? (f += ' <span class="medal rank', f += n(s + 1), f += '"></span> ') : (f += ' <span class="num">', f += n(s + 1), f += "</span> "), f += ' </div> <div class="head fl"> <img src="', f += n(o), f += '" width="100" height="100" alt=""> </div> <div class="name"> ', f += n(u), f += ' </div> <div class="percent fr"> ', f += n(a), f += "分 </div> </li>", new l(f)
		}), e("component/wedding/game/guess/record", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = "";
			return s += '<div class="board"> <div class="visual"> ', n(r, function(e, t) {
				s += " ", 3 > t && (s += ' <div class="top top', s += i(t + 1), s += '"> <div class="head"> <img src="', s += i(e.head), s += '"> </div> <div class="ribbon"></div> <div class="name">', s += i(e.name), s += "</div> </div> "), s += " "
			}), s += ' <ul class="top10 clearfix"> ', n(r, function(e, t) {
				s += " ", t >= 3 && 10 > t && (s += ' <li class="fl"> <div class="head"> <img src="', s += i(e.head), s += '"> </div> <div class="name"> <div class="num">', s += i(t + 1), s += "</div> ", s += i(e.name), s += " <div> </li> "), s += " "
			}), s += ' </ul> <div class="board-footer"> <span class="show-list">查看全部排名</span> <span class="restart">重新开始</span> </div> </div> <div class="list hide"> <div class="list-body"> <table> <tr><th>排名</th><th>微信id</th></tr> ', n(r, function(e, t) {
				s += " <tr><td>", s += i(t + 1), s += "</td><td>", s += i(e.name), s += "</td></tr> "
			}), s += ' </table> </div> <div class="board-footer"> <span class="show-visual">查看Top10</span> <span class="restart">重新开始</span> </div> </div> </div>', new l(s)
		}), e("component/wedding/game/shake/join", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.head,
				i = "";
			return i += '<li class="game-user"> <div class="head"> <img src="', i += n(r), i += '" alt=""> </div> </li>', new l(i)
		}), e("component/wedding/game/shake/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.shakeQrcode,
				i = e.shakeTime,
				s = "";
			return s += '<div id="shake" class="view"> <div class="game-con"> <div class="game-prepare"> <div class="game-header clearfix"> <div class="game-header-title fl"> <a class="game-header-left">摇一摇夺奖</a> <a class="game-header-right"> 共<span class="game-header-num" id="join_num">0</span>人参与 </a> </div> </div> <div class="game-userlist"> <div class="game-userlist-nouser clearfix"> <div class="game-userlist-emo"><img src="images/default/emo.png" /></div> <div class="game-userlist-title">扫描二维码，参与摇一摇比赛</div> </div> <div class="game-userlist-con"> <ul class="clearfix"> </ul> </div> </div> </div> <div class="game-sidebar"> <div class="game-sidebar-title">扫描二维码参与</div> <div class="game-sidebar-qrcode"> <div class="game-sidebar-qrcode-inner"> <img src="', s += n(r), s += '"> </div> </div> <div class="game-sidebar-btn-con"> <div class="game-sidebar-btn-info">摇一摇次数设置</div> <div class="game-sidebar-config clearfix"> <span class="game-sidebar-config-btn minus">-</span><span id="shakeTime">', s += n(i), s += '</span><span class="game-sidebar-config-btn add">+</span> </div> <div class="game-sidebar-btn start-btn">倒计时开始</div> </div> </div> <div class="game-process hide"> <ul class="clearfix"> </ul> <div id="reset">重新开始</div> </div> </div> <div class="count-overlay"> <div class="count-body"> <div class="count-wrapper right"> <div class="count-circle rightcircle"></div> </div> <div class="count-wrapper left"> <div class="count-circle leftcircle"></div> </div> <div class="number"> <div class="count count3"><img src="images/default/number/3.png"></div> <div class="count count2"><img src="images/default/number/2.png"></div> <div class="count count1"><img src="images/default/number/1.png"></div> </div> </div> </div> <div class="game-result-overlay"> </div> </div> <!-- <div id="shake" class="view"> <div class="prepare-con"> <div class="prepare-header"> <div class="underline"> <span class="title left">扫描二维码，参与摇一摇比赛</span> <div class="fr"> <span class="title orange" id="join_num">0</span><span class="title">人参与</span> </div> </div> </div> <div class="prepare-content-con clearfix"> <div class="topline"> <div class="prepare-qrcode-con fl"> <div class="prepare-qrcode"> <img src="', s += n(r), s += '"> </div> <div class="prepare-btn-con"> <div class="start-btn">倒计时开始</div> <div class="game-config">摇一摇次数：<span class="config-btn minus">-</span><span id="shakeTime">', s += n(i), s += '</span><span class="config-btn add">+</span></div> </div> </div> </div> <div class="prepare-user-con fl"> <ul class="clearfix"> </ul> </div> </div> </div> <div class="game-con"> <div class="count-con"> <div class="count count3"></div> <div class="count count2"></div> <div class="count count1"></div> <div class="count count0"></div> </div> <div class="process-con"> <ul class="clearfix"> </ul> </div> <div class="result-con"> <div class="result-header"> <div class="underline"> <span class="title">恭喜以下选手取得好成绩！</span> <div class="back-btn-con"> <div class="btn btn-tran">返回</div> </div> </div> </div> <div class="result-content-con clearfix"> <div class="topline" id="game_result"> </div> </div> </div> </div> </div> -->', new l(s)
		}), e("component/wedding/game/shake/rank", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.openid,
				i = e.top,
				s = e.index,
				o = e.head,
				u = e.name,
				a = e.percent,
				f = "";
			return f += '<li class="item" id="process_item_', f += n(r), f += '" style="top:', f += n(i), f += 'px"> <div class="rank fl"> ', 3 > s ? (f += ' <span class="medal rank', f += n(s + 1), f += '"></span> ') : (f += ' <span class="num">', f += n(s + 1), f += "</span> "), f += ' </div> <div class="head fl"> <img src="', f += n(o), f += '" width="100" height="100" alt=""> </div> <div class="name"> ', f += n(u), f += ' </div> <div class="progress"> <img class="run" src="images/default/run.gif" style="right:100%"> </img> <div class="progress-wrapper"> <span class="val" style="-webkit-transform: translateX(-100%);"> </span> </div> </div> <div class="percent fr"> ', f += n(a), f += " </div> </li>", new l(f)
		}), e("component/wedding/game/shake/record", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = "";
			return s += '<div class="board"> <div class="visual"> ', n(r, function(e, t) {
				s += " ", 3 > t && (s += ' <div class="top top', s += i(t + 1), s += '"> <div class="head"> <img src="', s += i(e.head), s += '"> </div> <div class="ribbon"></div> <div class="name">', s += i(e.name), s += "</div> </div> "), s += " "
			}), s += ' <ul class="top10 clearfix"> ', n(r, function(e, t) {
				s += " ", t >= 3 && 10 > t && (s += ' <li class="fl"> <div class="head"> <img src="', s += i(e.head), s += '"> </div> <div class="name"> <div class="num">', s += i(t + 1), s += "</div> ", s += i(e.name), s += " <div> </li> "), s += " "
			}), s += ' </ul> <div class="board-footer"> <span class="show-list">查看全部排名</span> <span class="restart">重新开始</span> </div> </div> <div class="list hide"> <div class="list-body"> <table> <tr><th>排名</th><th>微信id</th></tr> ', n(r, function(e, t) {
				s += " <tr><td>", s += i(t + 1), s += "</td><td>", s += i(e.name), s += "</td></tr> "
			}), s += ' </table> </div> <div class="board-footer"> <span class="show-visual">查看Top10</span> <span class="restart">重新开始</span> </div> </div> </div>', new l(s)
		}), e("component/wedding/header/main", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, e.logourl),
				r = t.$escape,
				i = e.name,
				s = "";
			return n && (s += ' <div class="logo fl"><img src="', s += r(n), s += '" /></div> '), s += ' <div class="title fl"> <h1>', s += r(i), s += "</h1> </div> ", new l(s)
		}), e("component/wedding/image/detail", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.index,
				i = e.anonymous,
				s = t.$string,
				o = e.name,
				u = e.content,
				a = "";
			return a += '<div class="image clearfix" data-index="', a += n(r), a += '"> <div class="head clearfix"> ', 0 == i && (a += ' <div class="left fl">', a += s(o), a += "</div> "), a += ' <div class="right fr">', a += n(r + 1), a += '</div> </div> <div class="body"> <div class="pic"> <img src="', a += n(u), a += '" id="FullImg_', a += n(r), a += '"> </div> </div> </div>', new l(a)
		}), e("component/wedding/image/layout", '<div id="image" class="view"> <div class="image-con swiper-container" id="container_image"> <div class="message-loading-con"> <p>正在加载上墙消息...</p> <div class="message-loading-progress"> <div class="message-loading-progress-bar" style="width: 0%">0%</div> </div> </div> <div class="swiper-wrapper"> </div> </div> </div> '), e("component/wedding/layout/error", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.message,
				i = "";
			return i += ' <div class="container background_img" id="background_img"> </div>  <div class="container browser_tips hide" id="browser_tips"> <div class="row clearfix" > <div class="browser_logo fl"> <img src="images/default/logo_black.png" /> </div> <div class="browser_download"> <p>您的浏览器对大屏幕上墙效果支持不佳，或者使用的浏览器版本过低，建议更换新版chrome浏览器获得更好的上墙体验</p> <a href="http://xiazai.sogou.com/detail/34/8/6262355089742005676.html">点击去下载chrome浏览器 <img src="images/default/chrome.png"></a> </div> </div> </div>  <div class="container stage"> <div class="row header clearfix" id="header"> </div> <div class="row main clearfix"> <div class="viewport"> <div class="error"> ', i += n(r), i += ' </div> </div> <div class="blur"> <div> </div> </div> </div> </div> ', new l(i)
		}), e("component/wedding/layout/main", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, e.bgurl),
				r = t.$escape,
				i = "";
			return i += ' <div class="container background_img" id="background_img" ', "" != n && (i += 'style="background-image:url(', i += r(n), i += ')"'), i += '> </div>  <div class="container browser_tips hide" id="browser_tips"> <div class="row clearfix" > <div class="browser_logo fl"> <img src="images/default/logo_black.png" /> </div> <div class="browser_download"> <p>您的浏览器对大屏幕上墙效果支持不佳，或者使用的浏览器版本过低，建议更换新版chrome浏览器获得更好的上墙体验</p> <a href="http://xiazai.sogou.com/detail/34/8/6262355089742005676.html">点击去下载chrome浏览器 <img src="images/default/chrome.png"></a> </div> </div> </div>  <div class="container stage"> <div class="row header clearfix" id="header"> </div> <div class="row main clearfix"> <div class="viewport"> </div> <div class="blur"> <div ', "" != n && (i += ' style="background-image:url(', i += r(n), i += ')"'), i += '> </div> </div> </div> </div>  <div class="container hover" id="ctrlbar"> <div class="clearfix" id="slogen"> </div> <div class="clearfix" id="toolkit"> </div> </div> <div class="gallery-con invisible"> <div id="comment" class="abp"> <div id="comment-stage" class="container"></div> </div> </div>  <a id="ribbon" href="http://xianchang.qq.com/manage/index.html" target="_blank" class="hide"> <img style="position: absolute; top: 0; right: 0; border: 0; width:100px; z-index:10000" src="images/default/peel.png" title="马上创建您专属的微现场"> </a>', new l(i)
		}), e("component/wedding/lottery/awards", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = "";
			return n(r, function(e) {
				s += ' <li class="options" data-target="', s += i(e.id), s += '" data-option="', s += i(e.name), s += '">', s += i(e.name), s += "</li> "
			}), s += " ", new l(s)
		}), e("component/wedding/lottery/layout", '<div id="lottery" class="view"> <div class="draw-box"> <div class="draw-header"> <div class="draw-title">现场抽奖</div> </div> <div class="slot-box"> <div class="slot-box-wrapper clearfix"> <div class="emo"><img src="images/default/emo.png" /></div> <div class="title">求中奖，快到碗里来</div> </div> </div> </div> <div class="controll-box"> <div class="select-wrapper" id="award-selector"> <a class="select-btn"><span>请选择奖品类别</span> <i class="select-btn-arrow icon icon-arrow"></i></a> <ul class="select-options hide"> </ul> </div>  <div class="select-wrapper" id="quantity-selector"> <div class="lottery-num clearfix"> <span class="lottery-num-btn minus">-</span> <input id="lotteryNum" value="1" /> <span class="lottery-num-btn add">+</span> </div> </div> <div class="award-img-wrapper"> </div> <div class="lottery-btn"> 正在加载奖池... </div> <div class="lottery-history"> 查看中奖记录 </div> </div> </div> '), e("component/wedding/lottery/list", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = (e.winner, e.j, t.$string),
				o = "";
			return o += '<div id="history-swiper-con" class="history-box"> <div class="swiper-wrapper"> ', n(r, function(e) {
				o += ' <div class="swiper-slide"> <div class="history-row clearfix"> <div class="history-award fl"> <img width="250" height="250" src="', o += i(e.image), o += '"> <p>', o += i(e.award), o += '</p> </div> <div class="history-winner fl"> <ul class="history-winner-list clearfix"> ', n(e.winner, function(e) {
					o += ' <li class="history-winner-item fl clearfix"> <div class="history-winner-avatar fl"> ', e.head ? (o += ' <img src="', o += i(e.head), o += '" width="100" height="100" alt=""> ') : o += ' <img src="images/default/avatar.png" width="100" height="100" alt=""> ', o += ' </div> <div class="history-winner-name fl">', o += s(e.name), o += "</div> </li> "
				}), o += " </ul> </div> </div> </div> "
			}), o += ' </div> <div class="winners-prev"><i class="icon icon-arrow-left"></i></div> <div class="winners-next"><i class="icon icon-arrow-right"></i></div> </div> <!-- <div class="history-overlay"> <div class="history-list"> <div class="history-header"> <span>获奖名单</span> </div> <div id="history-swiper-con"> <div class="swiper-wrapper"> ', n(r, function(e) {
				o += ' <div class="swiper-slide"> <div class="history-row clearfix"> <div class="history-award fl"> <img width="250" height="250" src="', o += i(e.imageurl), o += '"> <p>', o += i(e.award), o += '</p> </div> <div class="history-winner fl"> <ul class="history-winner-list clearfix"> ', n(e.winner, function(e) {
					o += ' <li class="history-winner-item fl clearfix"> <div class="history-winner-avatar fl"> ', e.head ? (o += ' <img src="', o += i(e.head), o += '" width="100" height="100" alt=""> ') : o += ' <img src="images/default/avatar.png" width="100" height="100" alt=""> ', o += ' </div> <div class="history-winner-name fl">', o += s(e.nick), o += "</div> </li> "
				}), o += " </ul> </div> </div> </div> "
			}), o += ' </div> </div> <div class="icon icon-arrow-left arrow-left"></div> <div class="icon icon-arrow-right arrow-right"></div> </div> </div> -->', new l(o)
		}), e("component/wedding/lottery/pools", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = t.$string,
				o = "";
			return n(r, function(e) {
				o += ' <li class="options" data-target="', o += i(e.id), o += '" data-option="', o += i(e.name), o += '">', o += s(e.name), o += "</li> "
			}), o += " ", new l(o)
		}), e("component/wedding/lottery/quantity", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.value, e.i, t.$escape),
				s = "";
			return n(r, function(e, t) {
				s += ' <li class="options" data-target="', s += i(t + 1), s += '" data-option="', s += i(t + 1), s += '">', s += i(t + 1), s += "</li> "
			}), s += " ", new l(s)
		}), e("component/wedding/lottery/single", '<div class="slot-box-single"> <ul> <li class="item">1</li> <li class="item">2</li> <li class="item">3</li> <li class="item">4</li> <li class="item">5</li> <li class="item">6</li> <li class="item">7</li> <li class="item">8</li> </ul> </div> '), e("component/wedding/lottery/slot", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, e.inner),
				r = t.$escape,
				i = e.item,
				s = t.$string,
				o = "";
			return n ? (o += ' <div class="slot-avatar"> <img src="', o += r(i.head), o += '" class="lotteryImg" width="150" height="150" alt=""> </div> <div class="slot-shadow"></div> <div class="slot-name">', o += s(i.name), o += "</div> ") : (o += ' <div class="slot-box-item"> <div class="slot-avatar"> <img src="', o += r(i.head), o += '" class="lotteryImg" width="150" height="150" alt=""> </div> <div class="slot-shadow"></div> <div class="slot-name">', o += s(i.name), o += "</div> </div> "), o += " ", new l(o)
		}), e("component/wedding/message/detail", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.index,
				i = e.height,
				s = e.head,
				o = e.anonymous,
				u = t.$string,
				a = e.name,
				f = e.fontsize,
				c = e.type,
				h = e.content,
				p = "";
			return p += '<div class="detail clearfix" data-index="', p += n(r), p += '" style="height:', p += n(i), p += 'px"> <div class="left fl"> <div class="avatar"> <img id="userhead_', p += n(r), p += '" src="', p += n(s), p += '" alt=""> </div> </div> <div class="right"> ', 0 == o ? (p += ' <div class="name">', p += u(a), p += '</div> <div class="message" style="font-size:', p += n(f), p += "px; line-height:", p += n(f + 10), p += 'px"> ', 0 == c ? (p += " ", p += u(h), p += " ") : (p += ' <img src="', p += n(h), p += '" > '), p += " </div> ") : (p += ' <div class="message h100" style="font-size:', p += n(f), p += "px; line-height:", p += n(f + 10), p += 'px"> ', 0 == c ? (p += " ", p += u(h), p += " ") : (p += ' <img src="', p += n(h), p += '" > '), p += " </div> "), p += ' </div> <div class="corner"></div> <div class="index">', p += n(r + 1), p += '</div> <div class="close"><i class="icon icon-close"></i></div> </div> ', new l(p)
		}), e("component/wedding/message/item", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.index,
				i = e.height,
				s = e.head,
				o = e.anonymous,
				u = t.$string,
				a = e.name,
				f = e.fontsize,
				c = e.type,
				h = e.content,
				p = "";
			return p += '<div class="item clearfix" data-index="', p += n(r), p += '" style="height:', p += n(i), p += 'px"> <div class="left fl"> <div class="avatar"> <img id="userhead_', p += n(r), p += '" src="', p += n(s), p += '" alt=""> </div> </div> <div class="right"> ', 0 == o ? (p += ' <div class="name">', p += u(a), p += '</div> <div class="message" style="font-size:', p += n(f), p += "px; line-height:", p += n(f + 10), p += 'px"> ', 0 == c ? (p += " ", p += u(h), p += " ") : (p += ' <img src="', p += n(h), p += '" > '), p += " </div> ") : (p += ' <div class="message h100" style="font-size:', p += n(f), p += "px; line-height:", p += n(f + 10), p += 'px"> ', 0 == c ? (p += " ", p += u(h), p += " ") : (p += ' <img src="', p += n(h), p += '" > '), p += " </div> "), p += ' </div> <div class="corner"></div> <div class="index">', p += n(r + 1), p += "</div> </div> ", new l(p)
		}), e("component/wedding/message/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.wxqrcode,
				i = e.wxname,
				s = "";
			return s += '<div id="message" class="view clearfix"> <div class="sidebar fl" id="sidebar"> <div class="sb-wrapper"> <div class="c-wrapper" id="mask_btn"> <img src="', s += n(r), s += '" /> </div> <p class="comment account"><span>', s += n(i), s += '</span></p> <p class="comment"> ', s += i ? " 关注微信号 " : " 扫描二维码 ", s += ' </p> <p class="comment">参与互动上墙</p> </div> </div> <div id="mask" class="mask hide"> <div class="mask-wrapper"> <img src="', s += n(r), s += '" width="460" height="460"/> </div> </div> <div id="message_wrapper" class="fl"> <div class="message-loading-con"> <p>正在加载上墙消息...</p> <div class="message-loading-progress"> <div class="message-loading-progress-bar" style="width: 0%">0%</div> </div> </div> <div class="message-con swiper-container" id="container_list"> <div class="swiper-wrapper"> </div> </div> <div class="message-con swiper-container hide" id="container_detail"> <div class="swiper-wrapper"> </div> </div> </div> </div> ', new l(s)
		}), e("component/wedding/message/sidebar", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.wxqrcode,
				i = e.wxname,
				s = t.$string,
				o = "";
			return o += '<div class="sb-wrapper"> <div class="c-wrapper" id="mask_btn"> <img src="', o += n(r), o += '" /> </div> <p class="comment"> ', o += i ? " 关注微信号 " : " 扫描二维码 ", o += ' </p> <p class="comment account"><span>', o += s(i), o += '</span></p> <p class="comment">参与互动上墙</p> </div>', new l(o)
		}), e("component/wedding/modal/alert", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, e.title),
				r = t.$escape,
				i = e.message,
				s = "";
			return s += '<div id="alert" class="modal fade"> <div class="modal-dialog modal-sm"> <div class="modal-content"> <div class="modal-header"> <h4 class="modal-title">', s += n ? r(n) : "提示", s += '<h4> </div> <div class="modal-body" style="min-height:200px"> ', s += r(i), s += ' </div> <div class="modal-footer"> <a class="btn btn-primary" data-dismiss="modal">确定</a> </div> </div> </div> </div> ', new l(s)
		}), e("component/wedding/modal/game", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.campaign_id,
				i = "";
			return i += '<div id="game" class="modal fade"> <div class="modal-dialog"> <div class="modal-content"> <div class="modal-header"> <h4 class="modal-title">游戏</h4> </div> <div class="modal-body"> <div class="game-wrapper clearfix"> <ul> <li class="game"> <div class="pic"> <img src="images/default/game/shake.jpg" / > <div class="button"> <span>摇一摇比赛</span> <a class="btn btn-primary remodal-cancel modal-close" app-jump="#', i += n(r), i += '/shake">开始游戏</a> </div> </div> </li> <li class="game"> <div class="pic"> <img src="images/default/game/guess.jpg" / > <div class="button"> <span>剪刀石头布</span> <a class="btn btn-primary remodal-cancel modal-close" app-jump="#', i += n(r), i += '/guess">开始游戏</a> </div> </div> </li> <li class="game" > <div class="pic"> <img src="images/default/game/default.jpg" / > </div> </li> </ul> </div> </div> <div class="modal-footer"> <a class="btn btn-default" data-dismiss="modal">返回</a> </div> </div> </div> </div> ', new l(i)
		}), e("component/wedding/modal/setting", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, e.theme),
				r = t.$escape,
				i = e.bgurl,
				s = e.interval,
				o = e.anonymous,
				u = "";
			return u += '<div id="setting" class="modal fade"> <div class="modal-dialog"> <div class="modal-content"> <div class="modal-header"> <h4 class="modal-title">设置</h4> </div> <div class="modal-body"> <div class="tab-wrapper"> <ul class="clearfix"> <li class="tab active"><a href="javascript:;">设置</a></li> </ul> </div> <div id="tab-swiper"> <!-- <div class="slide active"> <ul> <li class="theme ', "default" == n && (u += "active"), u += '" data-theme="default"> <div class="pic"> <img src="images/default/demo.jpg" / > <div class="name">商务会议</div> </div> <div class="check"></div> </li> <li class="theme ', "festival" == n && (u += "active"), u += '" data-theme="festival"> <div class="pic"> <img src="images/festival/demo.jpg" / > <div class="name">节日盛宴</div> </div> <div class="check"></div> </li> <li class="theme ', "wedding" == n && (u += "active"), u += '" data-theme="wedding"> <div class="pic"> <img src="images/wedding/demo.jpg" / > <div class="name">婚庆典礼</div> </div> <div class="check"></div> </li> <li class="theme ', "ds6" == n && (u += "active"), u += '" data-theme="ds6"> <div class="pic"> <img src="images/ds6/thumb.jpg" / > <div class="name">商业展会</div> </div> <div class="check"></div> </li> </ul> <input type="hidden" id="theme-value" value="', u += r(n), u += '"/> </div> <div class="slide"> <div class="upload-wrapper clearfix"> <div class="upload-img-box"> <img src="', u += r(i), u += '" /> </div> <div class="upload-img-select"> <div class="upload-btn btn btn-default"> <span>点击上传图片</span> <input id="upload-img-fileinput" type="file" title="点击更换图片" value="', u += r(i), u += '" /> </div> <div class="clear-btn btn btn-default"> <span>使用默认背景</span> </div> <p>*建议上传图片尺寸1920*1080，大小3M以内的图片</p> </div> <input type="hidden" id="bgurl-value" value="', u += r(i), u += '"/> </div> </div> --> <div class="slide active"> <div class="item"> <div class="inner-header">账号设置</div> <div class="inner-content"> <a class="btn btn-default" id="logout">更换账号</a> </div> </div> <!-- <div class="item"> <div class="inner-header">消息墙控制</div> <div class="inner-content"> <div class="form-group clearfix"> <label for="messageScrollTime" class="fl">滚动时间</label> <div id="messageScrollTimeBar" class="fl scrollbar"> </div> <div class="scrollval fl"></div> </div> <div class="form-group clearfix"> <label for="messageInterval" class="fl">循环播放</label> <div class="fl"> <label for="#" class="ui-switch"> ', u += s ? ' <input type="checkbox" id="messageInterval" checked="true" /> ' : ' <input type="checkbox" id="messageInterval" /> ', u += ' </label> </div> <div class="fl desc"> 消息从最后一条自动滚至第一条循环播放 </div> </div> <div class="form-group clearfix"> <label for="messageAnonymous" class="fl">匿名消息</label> <div class="fl"> <label for="#" class="ui-switch"> ', u += o ? ' <input type="checkbox" id="messageAnonymous" checked="true" /> ' : ' <input type="checkbox" id="messageAnonymous" /> ', u += ' </label> </div> <div class="fl desc"> 开启匿名消息以后将使用随机头像并匿名 </div> </div> </div> </div> --> </div> </div> </div> <div class="modal-footer"> <a class="btn btn-default" data-dismiss="modal">返回</a>  </div> </div> </div> </div> ', new l(u)
		}), e("component/wedding/modal/winners", '<div id="history" class="modal fade"> <div class="modal-dialog" style="width:80%;"> <div class="modal-content"> <div class="modal-header"> <h4 class="modal-title">获奖名单</h4> </div> <div class="modal-body"> <div class="modal-loading"> <i class="icon icon-loading"></i> 数据加载中... </div> </div> <div class="modal-footer"> <a class="btn btn-default" data-dismiss="modal">返回</a> </div> </div> </div> </div>'), e("component/wedding/signin/item", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.head,
				i = t.$string,
				s = e.name,
				o = "";
			return o += '<div class="signin-item"> <div class="signin-item-img"><img src="', o += n(r), o += '" /></div> <span class="signin-item-text">', o += i(s), o += "</span> </div>", new l(o)
		}), e("component/wedding/signin/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.item_num,
				i = e.img_src,
				s = "";
			return s += '<div id="signin" class="view"> <div class="signin-con"> <div class="signin-header clearfix"> <div class="signin-header-title fl"> <a class="signin-header-left">签到墙</a> <a class="signin-header-right"> 共<span class="signin-header-num">', s += n(r), s += '</span>人签到 </a> </div> </div> <div class="signin-content"></div> </div> <div class="signin-qrcode-btn"></div> <div id="signin-qrcode" class="signin-qrcode hide"> <div class="signin-qrcode-wrapper"> <img src="', s += n(i), s += '" width="460" height="460"/> </div> </div> </div>', new l(s)
		}), e("component/wedding/slogen/main", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.slogans,
				i = (e.item, e.$index, t.$escape),
				s = "";
			return s += '<div class="slogen-bg"> <div class="slogen-wrapper" id="slogen-swiper-con"> <div class="swiper-wrapper"> ', n(r, function(e) {
				s += ' <div class="swiper-slide"> <div class="slogen-row clearfix"> <p>', s += i(e), s += "</p> </div> </div> "
			}), s += " </div> </div> </div>", new l(s)
		}), e("component/wedding/toolkit/main", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.campaign_id,
				i = "";
			return i += '<div class="toolkit-bg"> <div class="toolkit-wrapper row"> <div class="nav-bar fl"> <ul> <li app-jump="#', i += n(r), i += '/signin" class="signin link tooltip tooltip-effect-2"> <i class="icon icon-signin"></i> <div class="tooltip-content"><span>签到</span></div> </li> <li app-jump="#', i += n(r), i += '/message" class="wall link tooltip tooltip-effect-2"> <i class="icon icon-message"></i> <div class="tooltip-content"><span>消息上墙</span></div> </li> <li app-jump="#', i += n(r), i += '/image" class="wall link tooltip tooltip-effect-2"> <i class="icon icon-image"></i> <div class="tooltip-content"><span>纯图模式</span></div> </li> <li app-bullet="enable" id="shoot" class="tooltip tooltip-effect-2"> <i class="icon icon-bullet"></i> <div class="tooltip-content"><span>弹幕开关</span></div> </li> <li app-jump="#', i += n(r), i += '/lottery" class="lottery link tooltip tooltip-effect-2"> <i class="icon icon-lottery"></i> <div class="tooltip-content"><span>抽奖</span></div> </li> <li app-jump="#', i += n(r), i += '/vote" class="vote link tooltip tooltip-effect-2"> <i class="icon icon-vote"></i> <div class="tooltip-content"><span>投票</span></div> </li> <li app-jump="#', i += n(r), i += '/shake" class="game link tooltip tooltip-effect-2"> <i class="icon icon-game"></i> <div class="tooltip-content"><span>摇一摇</span></div> </li> <li id="fullscreen" class="tooltip tooltip-effect-2"> <i class="icon icon-full-screen fullScreen"></i> <div class="tooltip-content"><span>全屏</span></div> </li> <li id="setting-btn" class="tooltip tooltip-effect-2"> <i class="icon icon-setting"></i> <div class="tooltip-content"><span>设置</span></div> </li> </ul> </div> <div class="action-bar fr hide"> <ul> <li message-action="backward" class="tooltip tooltip-effect-2"> <i class="icon icon-backward"></i> <div class="tooltip-content"><span>第一条</span></div> </li> <li message-action="step-backward" class="tooltip tooltip-effect-2"> <i class="icon icon-step-backward"></i> <div class="tooltip-content"><span>向上一条</span></div> </li> <li message-action="play" class="tooltip tooltip-effect-2"> <i class="icon icon-pause"></i> <div class="tooltip-content"><span>开始/暂停</span></div> </li> <li message-action="step-forward" class="tooltip tooltip-effect-2"> <i class="icon icon-step-forward"></i> <div class="tooltip-content"><span>向下一条</span></div> </li> <li message-action="forward" class="tooltip tooltip-effect-2"> <i class="icon icon-forward"></i> <div class="tooltip-content"><span>最后一条</span></div> </li> </ul> </div> </div> </div>', new l(i)
		}), e("component/wedding/vote/column", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.item,
				i = "";
			return i += '<div class="vote-column" id="vote-column-', i += n(r.item_id), i += '"> <div class="vote-column-con"> <div class="vote-column-count" style="color:', i += n(r.color), i += "; bottom:", i += n(r.height + 15), i += 'px;">', i += n(r.count), i += "票 ( ", i += n(r.percent), i += '% )</div> <div class="vote-column-bar" style="background-color:', i += n(r.color), i += "; height: ", i += n(r.height), i += 'px;"></div> </div> <div class="vote-column-title">', i += n(r.name), i += "</div> </div>", new l(i)
		}), e("component/wedding/vote/count", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$escape),
				r = e.item,
				i = "";
			return i += n(r.count), i += "票 ( ", i += n(r.percent), i += "% )", new l(i)
		}), e("component/wedding/vote/layout", function(e) {
			"use strict";
			var t = this,
				n = (t.$helpers, t.$each),
				r = e.list,
				i = (e.item, e.index, t.$escape),
				s = t.$string,
				o = e.qrcode,
				u = "";
			return u += '<div id="vote" class="view"> <div class="vote-con" id="vote_list"> <div class="swiper-wrapper"> ', n(r, function(e) {
				u += ' <div class="swiper-slide"> <div class="vote" id="vote-', u += i(e.vote_id), u += '" data-index="', u += i(e.vote_id), u += '"> <div class="vote-header clearfix"> <div class="vote-header-title fl"> <a class="vote-header-left">', u += s(e.name), u += '</a> <a class="vote-header-right"> 共<span class="vote-header-num vote-title-num">0</span>人参与 </a> </div> </div> <div class="vote-content vote-content"> <div class="vote-scrollbar-move"> </div> </div> </div> </div> '
			}), u += ' </div> </div> <div class="vote-prev"><i class="icon icon-arrow-left"></i></div> <div class="vote-next"><i class="icon icon-arrow-right"></i></div> <div class="vote-qrcode-btn"></div> <div id="vote-qrcode" class="vote-qrcode hide"> <div class="vote-qrcode-wrapper"> <img width="460" height="460" src="', u += i(o), u += '"/> </div> </div> <div class="vote-order"> <input type="checkbox" class="order-switch" name="order-switch"> <label for="order-switch">排序</label> </div> </div>', new l(u)
		})
	}(), define("base/directive", [], function() {
		function remove(e) {
			e && ($(e.context).unbind(e.type, e.behavior), delete DirectiveList[e.name])
		}
		function register(e) {
			var t = e.name;
			if (t) {
				if (DirectiveList[t]) return;
				e = $.extend({
					context: "body",
					type: "click",
					behavior: emptyFunction
				}, e);
				var n = DirectiveList[t] = (DirectiveList[t] && remove(DirectiveList[t]), e);
				$(n.context).on(n.type, "[" + t + "]", function(e) {
					e.directive = n, n.behavior.call(this, e)
				})
			}
		}
		var DirectiveList = {},
			emptyFunction = function() {},
			directive = {
				register: function(e) {
					if (e && Object.prototype.toString.call(e) === "[object Array]") for (var t = 0; t < e.length; t++) register(e[t]);
					else register(e);
					return this
				},
				get: function(e) {
					return DirectiveList[e]
				},
				remove: function(e) {
					return e && remove(DirectiveList[e]), this
				}
			};
		return directive.register([{
			name: "app-url",
			behavior: function(e) {
				var t = e.directive;
				location.href = $(this).attr(t.name), e.stopPropagation()
			}
		}, {
			name: "app-jump",
			behavior: function(e) {
				var t = e.directive;
				location.hash = $(this).attr(t.name), e.stopPropagation()
			}
		}, {
			name: "app-on",
			type: "click tap touchstart touchmove touchend swipeLeft swipeRight swipeUp swipeDown swipe singleTap doubleTap longTap",
			methods: {},
			behavior: function(e) {
				var me = $(this),
					directive = e.directive,
					events = me.attr(directive.name).split(",");
				events.forEach(function(i) {
					var method, type = [],
						index = i.indexOf(":");
					if (index != -1) {
						type = i.substr(0, index).split(" ");
						if (type.indexOf(e.type) != -1) {
							var ename = i.substr(index + 1);
							method = DirectiveList[directive.name].methods[ename] || eval(ename), $.isFunction(method) && method.call(me, e)
						}
					} else e.type == "click" && (method = DirectiveList[directive.name].methods[i] || eval(i), $.isFunction(method) && method.call(me, e))
				})
			}
		}]), directive
	}), define("base/controller", [], function() {
		function o(e) {
			var t = e.root,
				r = e.controller;
			return e.controller = n([function() {
				if (a.current) {
					var t = a.current;
					typeof t.unload == "function" && (n(a.unload).apply(t.root, [].slice.call(arguments, 0)), t.unload.apply(t.root, [].slice.call(arguments, 0))), a.hide(t.name)
				}
				a.show(e.name)
			},
			e.before, function() {
				var t = a.current = e;
				r.apply(this, [].slice.call(arguments, 0))
			},
			e.after]), e
		}
		function u(n) {
			var r = n.name;
			r == null && n.controller && (r = n.controller.name), r && !e[r] && (n = $.extend({
				name: r,
				root: $("#" + r),
				controller: t,
				before: t,
				after: t,
				unload: t
			}, n), e[r] = o(n))
		}
		var e = {},
			t = function() {},
			n;
		if (!n) {
			Array.prototype.some || (Array.prototype.some = function(e) {
				"use strict";
				if (this == null) throw new TypeError("Array.prototype.some called on null or undefined");
				if (typeof e != "function") throw new TypeError;
				var t = Object(this),
					n = t.length >>> 0,
					r = arguments.length >= 2 ? arguments[1] : void 0;
				for (var i = 0; i < n; i++) if (i in t && e.call(r, t[i], i, t)) return !0;
				return !1
			});
			var r = [],
				i = r.some,
				s = r.slice;
			n = function(e) {
				isNaN(e.length) && ($.isFunction(e) ? e = [fn] : e = []);
				var t = function() {
						var t = this,
							n = s.call(arguments, 0);
						i.call(e, function(e) {
							return $.isFunction(e) && e.apply(t, n) === !1
						})
					};
				return t[":list"] = e, t
			}
		}
		var a = {
			register: function(e) {
				return e.forEach ? e.forEach(function(e) {
					u(e)
				}) : u(e), this
			},
			get: function(t) {
				return typeof t == "string" ? e[t] : e
			},
			show: function(t) {
				var n = e[t].root;
				$(n).addClass("current"), $(n).hasClass("tran") && ($(n).addClass("in"), $(n).one("webkitAnimationEnd", function() {
					$(n).removeClass("in")
				}))
			},
			hide: function(t) {
				var n = e[t].root;
				$(n).hasClass("tran") ? ($(n).addClass("out"), $(n).one("webkitAnimationEnd", function() {
					$(n).removeClass("out"), $(n).removeClass("current")
				})) : $(n).removeClass("current")
			},
			before: [],
			after: [],
			unload: [],
			current: null
		};
		return a
	}), define("controller/error", ["require", "base/controller", "template"], function(e) {
		"use strict";
		var t = e("base/controller"),
			n = e("template"),
			r, i = new Object;
		return i.init = function(e) {
			t.register({
				name: "error",
				controller: function() {
					var t = {
						message: null
					};
					switch (e.error_id) {
					case 1:
						t.message = "对不起，您没有该微现场的访问权限";
						break;
					case 2:
						t.message = "获取现场消息出错了，请重新试一下"
					}
					r = n("component/default/layout/error", t), $("#wrapper").html(r), $(".loading_con").addClass("hide")
				}
			}), t.get("error").controller()
		}, i
	}), define("base/hosts", [], function() {
		var e = new Object;
		return e.hostname = "http://" + location.hostname, e.env = "prod", e.setUrls = function(t) {
			switch (t) {
			case "test":
				e.urls = {
					getInfo: "./js/mock/getInfo.json",
					getSignList: "./js/mock/getSignList.json",
					getWallMsg: "./js/mock/getWallMsg.json",
					getLotteryUserList: "./js/mock/getLotteryUserList.json",
					getSigninUserList: "./js/mock/getSigninUserList.json",
					getSigninGR: "./js/mock/getSigninGR.json",
					getBrandMatrix: "/live/signin/getmatrix",
					drawAward: "./js/mock/drawAward.json",
					getWinnerHistory: "./js/mock/getWinnerHistory.json",
					getAwardList: "./js/mock/getAwardList.json",
					getPoolList: "./js/mock/getPoolList.json",
					getUserAuth: "./js/mock/getUserAuth.json",
					saveSetting: "./js/mock/saveSetting.json",
					saveGameWinner: "./js/mock/SaveWinner.json"
				};
				break;
			case "prod":
				e.urls = {
					getInfo: e.hostname + "/live/campaign/getinfo",
					getSignList: e.hostname + "/live/signin/getlist",
					getWallMsg: e.hostname + "/live/wall/getmsg",
					getLotteryUserList: e.hostname + "/live/lottery/getuserlist",
					getSigninUserList: e.hostname + "/live/signin/userlist",
					getSigninGR: e.hostname + "/live/signin/listrules",
					getSigninType: e.hostname + "/live/signin/getscreentype",
					getBrandMatrix: "/live/signin/getmatrix",
					getVoteList: e.hostname + "/live/vote/getlist",
					getVoteDetail: e.hostname + "/live/vote/getdetail",
					drawAward: e.hostname + "/live/lottery/draw",
					getWinnerHistory: e.hostname + "/live/lottery/getwinnerlist",
					getAwardList: e.hostname + "/live/lottery/getawardlist",
					getPoolList: e.hostname + "/live/lottery/listpools",
					getUserAuth: e.hostname + "/live/user/getauth",
					saveSetting: e.hostname + "/live/campaign/savesetting",
					saveGameWinner: e.hostname + "/live/game/savewinner",
					setGuessingDuration: e.hostname + "/live/game/setguessingduration",
					getGuessingRank: e.hostname + "/live/game/getguessingcurrentrank",
					getGuessingStatus: e.hostname + "/live/game/getguessingstatus"
				};
				break;
			case "demo":
				e.urls = {
					getInfo: e.hostname + "/live/demo/campaign/getinfo",
					getSignList: e.hostname + "/live/demo/signin/getlist",
					getWallMsg: e.hostname + "/live/demo/wall/getmsg",
					getLotteryUserList: e.hostname + "/live/demo/lottery/getpool",
					getSigninUserList: e.hostname + "/live/demo/signin/userlist",
					getSigninGR: e.hostname + "/live/signin/listrules",
					getSigninType: e.hostname + "/live/signin/getscreentype",
					getBrandMatrix: "/live/signin/getmatrix",
					getVoteList: e.hostname + "/live/demo/vote/getlist",
					getVoteDetail: e.hostname + "/live/demo/vote/getdetail",
					drawAward: e.hostname + "/live/demo/lottery/draw",
					getWinnerHistory: e.hostname + "/live/demo/lottery/getwinnerlist",
					getAwardList: e.hostname + "/live/demo/lottery/getawardlist",
					getPoolList: e.hostname + "/live/demo/lottery/listpools",
					getUserAuth: e.hostname + "/live/demo/user/getauth",
					saveSetting: e.hostname + "/live/demo/campaign/savesetting",
					saveGameWinner: e.hostname + "/live/demo/game/savewinner",
					setGuessingduration: e.hostname + "/live/demo/game/setguessingduration",
					getGuessingRank: e.hostname + "/live/demo/game/getguessingcurrentrank",
					getGuessingStatus: e.hostname + "/live/demo/game/getguessingstatus"
				}
			}
		}, e.getUrls = function(t) {
			return e.urls[t]
		}, e.setUrls(e.env), e
	}), Array.prototype.filter || (Array.prototype.filter = function(e) {
		"use strict";
		if (this === void 0 || this === null) throw new TypeError;
		var t = Object(this),
			n = t.length >>> 0;
		if (typeof e != "function") throw new TypeError;
		var r = [],
			i = arguments[1];
		for (var s = 0; s < n; s++) if (s in t) {
			var o = t[s];
			e.call(i, o, s, t) && r.push(o)
		}
		return r
	}), Array.prototype.forEach || (Array.prototype.forEach = function(e, t) {
		for (var n = 0, r = this.length; n < r; ++n) e.call(t, this[n], n, this)
	}), Array.prototype.indexOf || (Array.prototype.indexOf = function(e) {
		var t = this.length >>> 0,
			n = Number(arguments[1]) || 0;
		n = n < 0 ? Math.ceil(n) : Math.floor(n), n < 0 && (n += t);
		for (; n < t; n++) if (n in this && this[n] === e) return n;
		return -1
	});
	var emojiFiles = ["1f604", "1f60a", "1f603", "263a", "1f609", "1f60d", "1f618", "1f61a", "1f633", "1f601", "1f60c", "1f61c", "1f61d", "1f612", "1f60f", "1f613", "1f614", "1f61e", "1f616", "1f625", "1f630", "1f628", "1f62b", "1f622", "1f62d", "1f602", "1f632", "1f631", "1f620", "1f621", "1f62a", "1f637", "1f47f", "1f47d", "2764", "1f494", "1f498", "2728", "1f31f", "2757", "2753", "1f4a4", "1f4a6", "1f3b5", "1f525", "1f4a9", "1f44d", "1f44e", "1f44a", "270c", "1f446", "1f447", "1f449", "1f448", "261d", "1f4aa", "1f48f", "1f491", "1f466", "1f467", "1f469", "1f468", "1f47c", "1f480", "1f48b", "2600", "2614", "2601", "26c4", "1f31b", "26a1", "1f30a", "1f431", "1f436", "1f42d", "1f439", "1f430", "1f43a", "1f438", "1f42f", "1f428", "1f43b", "1f43d", "1f42e", "1f417", "1f435", "1f434", "1f40d", "1f426", "1f414", "1f427", "1f41b", "1f419", "1f420", "1f433", "1f42c", "1f339", "1f33a", "1f334", "1f335", "1f49d", "1f383", "1f47b", "1f385", "1f384", "1f381", "1f514", "1f389", "1f388", "1f4bf", "1f4f7", "1f3a5", "1f4bb", "1f4fa", "260e", "1f513", "1f512", "1f511", "1f528", "1f4a1", "1f4eb", "1f6c0", "1f4b0", "1f4a3", "1f52b", "1f48a", "1f3c8", "1f3c0", "26bd", "26be", "26f3", "1f3c6", "1f47e", "1f3a4", "1f3b8", "1f459", "1f451", "1f302", "1f45c", "1f484", "1f48d", "1f48e", "2615", "1f37a", "1f37b", "1f378", "1f354", "1f35f", "1f35d", "1f363", "1f35c", "1f373", "1f366", "1f382", "1f34e", "2708", "1f680", "1f6b2", "1f684", "26a0", "1f3c1", "1f6b9", "1f6ba", "2b55", "274c", "a9", "ae", "2122"];
	(function(e) {
		function o(e) {
			var t = (window.relEmo || "") + "emoticons/" + e.src;
			return "<span style='background-image:url(" + t + ")' class='emojicon-m'></span>"
		}
		function u(e) {
			pattern = "", e.forEach(function(e, t, n) {
				e.dict.forEach(function(e) {
					hidden.indexOf(e) == -1 && (pattern += e + "|")
				})
			}), pattern != "" && (pattern = pattern.substr(0, pattern.length - 1))
		}
		function f(e) {
			var t, n = "";
			for (var r = 0; r < e.length; r++) t = e.charCodeAt(r), t <= 127 ? n += e.charAt(r) : t >= 128 && t <= 2047 ? (n += String.fromCharCode(t >> 6 & 31 | 192), n += String.fromCharCode(t & 63 | 128)) : (n += String.fromCharCode(t >> 12 | 224), n += String.fromCharCode(t >> 6 & 63 | 128), n += String.fromCharCode(t & 63 | 128));
			return n
		}
		function l(e) {
			var t, n = "",
				r = 0,
				i;
			for (var s = 0; s < e.length; s++) t = e.charCodeAt(s), r == 0 ? (t & 224) == 224 ? (r = 2, i = (t & 15) << 12) : (t & 192) == 192 ? (r = 1, i = (t & 31) << 6) : (t & 128) == 0 ? n += e.charAt(s) : r = 0 : r == 1 ? (r = 0, n += String.fromCharCode(i | t & 63)) : r == 2 ? (r = 3, i |= (t & 63) << 6) : r == 3 ? (r = 0, n += String.fromCharCode(i | t & 63)) : r = 0;
			return n
		}
		var t = e + "em",
			n = document.createElement("style"),
			r = document.getElementsByTagName("head")[0];
		n.type = "text/css";
		var i = ".emojicon-m {    min-height: " + t + " !important;    min-width: " + t + " !important;    max-height: " + t + " !important;    max-width: " + t + " !important;	vertical-align: middle !important;	float:none !important;	background-repeat: no-repeat;	background-position: center center;	background-size: contain;	display: inline-block;}";
		n.styleSheet ? n.styleSheet.cssText = i : n.appendChild(document.createTextNode(i)), r && r.appendChild(n);
		var s = {
			items: [{
				name: "COPYRIGHT SIGN",
				id: "copyright_sign",
				src: "a9.png",
				dict: ["©"]
			}, {
				name: "REGISTERED SIGN",
				id: "registered_sign",
				src: "ae.png",
				dict: ["®"]
			}, {
				name: "DOUBLE EXCLAMATION MARK",
				id: "double_exclamation_mark",
				src: "203c.png",
				dict: ["‼"]
			}, {
				name: "EXCLAMATION QUESTION MARK",
				id: "exclamation_question_mark",
				src: "2049.png",
				dict: ["⁉"]
			}, {
				name: "TRADE MARK SIGN",
				id: "trade_mark_sign",
				src: "2122.png",
				dict: ["™"]
			}, {
				name: "INFORMATION SOURCE",
				id: "information_source",
				src: "2139.png",
				dict: ["ℹ"]
			}, {
				name: "LEFT RIGHT ARROW",
				id: "left_right_arrow",
				src: "2194.png",
				dict: ["↔"]
			}, {
				name: "UP DOWN ARROW",
				id: "up_down_arrow",
				src: "2195.png",
				dict: ["↕"]
			}, {
				name: "NORTH WEST ARROW",
				id: "north_west_arrow",
				src: "2196.png",
				dict: ["↖", ""]
			}, {
				name: "NORTH EAST ARROW",
				id: "north_east_arrow",
				src: "2197.png",
				dict: ["↗", ""]
			}, {
				name: "SOUTH EAST ARROW",
				id: "south_east_arrow",
				src: "2198.png",
				dict: ["↘", ""]
			}, {
				name: "SOUTH WEST ARROW",
				id: "south_west_arrow",
				src: "2199.png",
				dict: ["↙", ""]
			}, {
				name: "LEFTWARDS ARROW WITH HOOK",
				id: "leftwards_arrow_with_hook",
				src: "21a9.png",
				dict: ["↩"]
			}, {
				name: "RIGHTWARDS ARROW WITH HOOK",
				id: "rightwards_arrow_with_hook",
				src: "21aa.png",
				dict: ["↪"]
			}, {
				name: "WATCH",
				id: "watch",
				src: "231a.png",
				dict: ["⌚"]
			}, {
				name: "HOURGLASS",
				id: "hourglass",
				src: "231b.png",
				dict: ["⌛"]
			}, {
				name: "BLACK RIGHT-POINTING DOUBLE TRIANGLE",
				id: "black_right-pointing_double_triangle",
				src: "23e9.png",
				dict: ["⏩", ""]
			}, {
				name: "BLACK LEFT-POINTING DOUBLE TRIANGLE",
				id: "black_left-pointing_double_triangle",
				src: "23ea.png",
				dict: ["⏪", ""]
			}, {
				name: "BLACK UP-POINTING DOUBLE TRIANGLE",
				id: "black_up-pointing_double_triangle",
				src: "23eb.png",
				dict: ["⏫"]
			}, {
				name: "BLACK DOWN-POINTING DOUBLE TRIANGLE",
				id: "black_down-pointing_double_triangle",
				src: "23ec.png",
				dict: ["⏬"]
			}, {
				name: "ALARM CLOCK",
				id: "alarm_clock",
				src: "23f0.png",
				dict: ["⏰"]
			}, {
				name: "HOURGLASS WITH FLOWING SAND",
				id: "hourglass_with_flowing_sand",
				src: "23f3.png",
				dict: ["⏳"]
			}, {
				name: "CIRCLED CAPITAL LETTER M",
				id: "circled_capital_letter_m",
				src: "24c2.png",
				dict: ["Ⓜ"]
			}, {
				name: "BLACK SMALL SQUARE",
				id: "black_small_square",
				src: "25aa.png",
				dict: ["▪"]
			}, {
				name: "WHITE SMALL SQUARE",
				id: "white_small_square",
				src: "25ab.png",
				dict: ["▫"]
			}, {
				name: "BLACK RIGHT-POINTING TRIANGLE",
				id: "black_right-pointing_triangle",
				src: "25b6.png",
				dict: ["▶", ""]
			}, {
				name: "BLACK LEFT-POINTING TRIANGLE",
				id: "black_left-pointing_triangle",
				src: "25c0.png",
				dict: ["◀", ""]
			}, {
				name: "WHITE MEDIUM SQUARE",
				id: "white_medium_square",
				src: "25fb.png",
				dict: ["◻"]
			}, {
				name: "BLACK MEDIUM SQUARE",
				id: "black_medium_square",
				src: "25fc.png",
				dict: ["◼"]
			}, {
				name: "WHITE MEDIUM SMALL SQUARE",
				id: "white_medium_small_square",
				src: "25fd.png",
				dict: ["◽"]
			}, {
				name: "BLACK MEDIUM SMALL SQUARE",
				id: "black_medium_small_square",
				src: "25fe.png",
				dict: ["◾"]
			}, {
				name: "BLACK SUN WITH RAYS",
				id: "black_sun_with_rays",
				src: "2600.png",
				dict: ["☀", ""]
			}, {
				name: "CLOUD",
				id: "cloud",
				src: "2601.png",
				dict: ["☁", ""]
			}, {
				name: "BLACK TELEPHONE",
				id: "black_telephone",
				src: "260e.png",
				dict: ["☎", ""]
			}, {
				name: "BALLOT BOX WITH X",
				id: "ballot_box_with_x",
				src: "2611.png",
				dict: ["☑"]
			}, {
				name: "UMBRELLA WITH RAIN DROPS",
				id: "umbrella_with_rain_drops",
				src: "2614.png",
				dict: ["☔", ""]
			}, {
				name: "HOT BEVERAGE",
				id: "hot_beverage",
				src: "2615.png",
				dict: ["☕", ""]
			}, {
				name: "WHITE UP POINTING INDEX",
				id: "white_up_pointing_index",
				src: "261d.png",
				dict: ["☝", ""]
			}, {
				name: "WHITE SMILING FACE",
				id: "white_smiling_face",
				src: "263a.png",
				dict: ["☺", ""]
			}, {
				name: "ARIES",
				id: "aries",
				src: "2648.png",
				dict: ["♈", ""]
			}, {
				name: "TAURUS",
				id: "taurus",
				src: "2649.png",
				dict: ["♉", ""]
			}, {
				name: "GEMINI",
				id: "gemini",
				src: "264a.png",
				dict: ["♊", ""]
			}, {
				name: "CANCER",
				id: "cancer",
				src: "264b.png",
				dict: ["♋", ""]
			}, {
				name: "LEO",
				id: "leo",
				src: "264c.png",
				dict: ["♌", ""]
			}, {
				name: "VIRGO",
				id: "virgo",
				src: "264d.png",
				dict: ["♍", ""]
			}, {
				name: "LIBRA",
				id: "libra",
				src: "264e.png",
				dict: ["♎", ""]
			}, {
				name: "SCORPIUS",
				id: "scorpius",
				src: "264f.png",
				dict: ["♏", ""]
			}, {
				name: "SAGITTARIUS",
				id: "sagittarius",
				src: "2650.png",
				dict: ["♐", ""]
			}, {
				name: "CAPRICORN",
				id: "capricorn",
				src: "2651.png",
				dict: ["♑", ""]
			}, {
				name: "AQUARIUS",
				id: "aquarius",
				src: "2652.png",
				dict: ["♒", ""]
			}, {
				name: "PISCES",
				id: "pisces",
				src: "2653.png",
				dict: ["♓", ""]
			}, {
				name: "BLACK SPADE SUIT",
				id: "black_spade_suit",
				src: "2660.png",
				dict: ["♠", ""]
			}, {
				name: "BLACK CLUB SUIT",
				id: "black_club_suit",
				src: "2663.png",
				dict: ["♣", ""]
			}, {
				name: "BLACK HEART SUIT",
				id: "black_heart_suit",
				src: "2665.png",
				dict: ["♥", ""]
			}, {
				name: "BLACK DIAMOND SUIT",
				id: "black_diamond_suit",
				src: "2666.png",
				dict: ["♦", ""]
			}, {
				name: "HOT SPRINGS",
				id: "hot_springs",
				src: "2668.png",
				dict: ["♨", ""]
			}, {
				name: "BLACK UNIVERSAL RECYCLING SYMBOL",
				id: "black_universal_recycling_symbol",
				src: "267b.png",
				dict: ["♻"]
			}, {
				name: "WHEELCHAIR SYMBOL",
				id: "wheelchair_symbol",
				src: "267f.png",
				dict: ["♿", ""]
			}, {
				name: "ANCHOR",
				id: "anchor",
				src: "2693.png",
				dict: ["⚓"]
			}, {
				name: "WARNING SIGN",
				id: "warning_sign",
				src: "26a0.png",
				dict: ["⚠", ""]
			}, {
				name: "HIGH VOLTAGE SIGN",
				id: "high_voltage_sign",
				src: "26a1.png",
				dict: ["⚡", ""]
			}, {
				name: "MEDIUM WHITE CIRCLE",
				id: "medium_white_circle",
				src: "26aa.png",
				dict: ["⚪"]
			}, {
				name: "MEDIUM BLACK CIRCLE",
				id: "medium_black_circle",
				src: "26ab.png",
				dict: ["⚫"]
			}, {
				name: "SOCCER BALL",
				id: "soccer_ball",
				src: "26bd.png",
				dict: ["⚽", ""]
			}, {
				name: "BASEBALL",
				id: "baseball",
				src: "26be.png",
				dict: ["⚾", ""]
			}, {
				name: "SNOWMAN WITHOUT SNOW",
				id: "snowman_without_snow",
				src: "26c4.png",
				dict: ["⛄", ""]
			}, {
				name: "SUN BEHIND CLOUD",
				id: "sun_behind_cloud",
				src: "26c5.png",
				dict: ["⛅"]
			}, {
				name: "OPHIUCHUS",
				id: "ophiuchus",
				src: "26ce.png",
				dict: ["⛎", ""]
			}, {
				name: "NO ENTRY",
				id: "no_entry",
				src: "26d4.png",
				dict: ["⛔"]
			}, {
				name: "CHURCH",
				id: "church",
				src: "26ea.png",
				dict: ["⛪", ""]
			}, {
				name: "FOUNTAIN",
				id: "fountain",
				src: "26f2.png",
				dict: ["⛲", ""]
			}, {
				name: "FLAG IN HOLE",
				id: "flag_in_hole",
				src: "26f3.png",
				dict: ["⛳", ""]
			}, {
				name: "SAILBOAT",
				id: "sailboat",
				src: "26f5.png",
				dict: ["⛵", ""]
			}, {
				name: "TENT",
				id: "tent",
				src: "26fa.png",
				dict: ["⛺", ""]
			}, {
				name: "FUEL PUMP",
				id: "fuel_pump",
				src: "26fd.png",
				dict: ["⛽", ""]
			}, {
				name: "BLACK SCISSORS",
				id: "black_scissors",
				src: "2702.png",
				dict: ["✂", ""]
			}, {
				name: "WHITE HEAVY CHECK MARK",
				id: "white_heavy_check_mark",
				src: "2705.png",
				dict: ["✅"]
			}, {
				name: "AIRPLANE",
				id: "airplane",
				src: "2708.png",
				dict: ["✈", ""]
			}, {
				name: "ENVELOPE",
				id: "envelope",
				src: "2709.png",
				dict: ["✉"]
			}, {
				name: "RAISED FIST",
				id: "raised_fist",
				src: "270a.png",
				dict: ["✊", ""]
			}, {
				name: "RAISED HAND",
				id: "raised_hand",
				src: "270b.png",
				dict: ["✋", ""]
			}, {
				name: "VICTORY HAND",
				id: "victory_hand",
				src: "270c.png",
				dict: ["✌", ""]
			}, {
				name: "PENCIL",
				id: "pencil",
				src: "270f.png",
				dict: ["✏"]
			}, {
				name: "BLACK NIB",
				id: "black_nib",
				src: "2712.png",
				dict: ["✒"]
			}, {
				name: "HEAVY CHECK MARK",
				id: "heavy_check_mark",
				src: "2714.png",
				dict: ["✔"]
			}, {
				name: "HEAVY MULTIPLICATION X",
				id: "heavy_multiplication_x",
				src: "2716.png",
				dict: ["✖"]
			}, {
				name: "SPARKLES",
				id: "sparkles",
				src: "2728.png",
				dict: ["✨", ""]
			}, {
				name: "EIGHT SPOKED ASTERISK",
				id: "eight_spoked_asterisk",
				src: "2733.png",
				dict: ["✳", ""]
			}, {
				name: "EIGHT POINTED BLACK STAR",
				id: "eight_pointed_black_star",
				src: "2734.png",
				dict: ["✴", ""]
			}, {
				name: "SNOWFLAKE",
				id: "snowflake",
				src: "2744.png",
				dict: ["❄"]
			}, {
				name: "SPARKLE",
				id: "sparkle",
				src: "2747.png",
				dict: ["❇"]
			}, {
				name: "CROSS MARK",
				id: "cross_mark",
				src: "274c.png",
				dict: ["❌", ""]
			}, {
				name: "NEGATIVE SQUARED CROSS MARK",
				id: "negative_squared_cross_mark",
				src: "274e.png",
				dict: ["❎"]
			}, {
				name: "BLACK QUESTION MARK ORNAMENT",
				id: "black_question_mark_ornament",
				src: "2753.png",
				dict: ["❓"]
			}, {
				name: "WHITE QUESTION MARK ORNAMENT",
				id: "white_question_mark_ornament",
				src: "2754.png",
				dict: ["❔", ""]
			}, {
				name: "WHITE EXCLAMATION MARK ORNAMENT",
				id: "white_exclamation_mark_ornament",
				src: "2755.png",
				dict: ["❕", ""]
			}, {
				name: "HEAVY EXCLAMATION MARK SYMBOL",
				id: "heavy_exclamation_mark_symbol",
				src: "2757.png",
				dict: ["❗"]
			}, {
				name: "HEAVY EXCLAMATION MARK ORNAMENT",
				id: "heavy_exclamation_mark_ornament",
				src: "2762.png",
				dict: ["❢"]
			}, {
				name: "HEAVY BLACK HEART",
				id: "heavy_black_heart",
				src: "2764.png",
				dict: ["❤", ""]
			}, {
				name: "HEAVY PLUS SIGN",
				id: "heavy_plus_sign",
				src: "2795.png",
				dict: ["➕"]
			}, {
				name: "HEAVY MINUS SIGN",
				id: "heavy_minus_sign",
				src: "2796.png",
				dict: ["➖"]
			}, {
				name: "HEAVY DIVISION SIGN",
				id: "heavy_division_sign",
				src: "2797.png",
				dict: ["➗"]
			}, {
				name: "BLACK RIGHTWARDS ARROW",
				id: "black_rightwards_arrow",
				src: "27a1.png",
				dict: ["➡", ""]
			}, {
				name: "CURLY LOOP",
				id: "curly_loop",
				src: "27b0.png",
				dict: ["➰"]
			}, {
				name: "DOUBLE CURLY LOOP",
				id: "double_curly_loop",
				src: "27bf.png",
				dict: ["➿", ""]
			}, {
				name: "ARROW POINTING RIGHTWARDS THEN CURVING UPWARDS",
				id: "arrow_pointing_rightwards_then_curving_upwards",
				src: "2934.png",
				dict: ["⤴"]
			}, {
				name: "ARROW POINTING RIGHTWARDS THEN DOWNWARDS",
				id: "arrow_pointing_rightwards_then_downwards",
				src: "2935.png",
				dict: ["⤵"]
			}, {
				name: "LEFTWARDS BLACK ARROW",
				id: "leftwards_black_arrow",
				src: "2b05.png",
				dict: ["⬅", ""]
			}, {
				name: "UPWARDS BLACK ARROW",
				id: "upwards_black_arrow",
				src: "2b06.png",
				dict: ["⬆", ""]
			}, {
				name: "DOWNWARDS BLACK ARROW",
				id: "downwards_black_arrow",
				src: "2b07.png",
				dict: ["⬇", ""]
			}, {
				name: "BLACK LARGE SQUARE",
				id: "black_large_square",
				src: "2b1b.png",
				dict: ["⬛"]
			}, {
				name: "WHITE LARGE SQUARE",
				id: "white_large_square",
				src: "2b1c.png",
				dict: ["⬜"]
			}, {
				name: "WHTE MEDIUM STAR",
				id: "whte_medium_star",
				src: "2b50.png",
				dict: ["⭐"]
			}, {
				name: "HEAVY LARGE CIRCLE",
				id: "heavy_large_circle",
				src: "2b55.png",
				dict: ["⭕", ""]
			}, {
				name: "WAVY DASH",
				id: "wavy_dash",
				src: "3030.png",
				dict: ["〰"]
			}, {
				name: "PART ALTERNATION MARK",
				id: "part_alternation_mark",
				src: "303d.png",
				dict: ["〽", ""]
			}, {
				name: "CIRCLED IDEOGRAPH CONGRATULATION",
				id: "circled_ideograph_congratulation",
				src: "3297.png",
				dict: ["㊗", ""]
			}, {
				name: "CIRCLED IDEOGRAPH SECRET",
				id: "circled_ideograph_secret",
				src: "3299.png",
				dict: ["㊙", ""]
			}, {
				name: "PRIVATE USE U+E50A",
				id: "private_use_u+e50a",
				src: "e50a.png",
				dict: [""]
			}, {
				name: "APPLE LOGO",
				id: "apple_logo",
				src: "f8ff.png",
				dict: [""]
			}, {
				name: "MAHJONG TILE RED DRAGON",
				id: "mahjong_tile_red_dragon",
				src: "1f004.png",
				dict: ["🀄", ""]
			}, {
				name: "PLAYING CARD BLACK JOKER",
				id: "playing_card_black_joker",
				src: "1f0cf.png",
				dict: ["🃏"]
			}, {
				name: "NEGATIVE SQUARED LATIN CAPITAL LETTER A",
				id: "negative_squared_latin_capital_letter_a",
				src: "1f170.png",
				dict: ["🅰", ""]
			}, {
				name: "NEGATIVE SQUARED LATIN CAPITAL LETTER B",
				id: "negative_squared_latin_capital_letter_b",
				src: "1f171.png",
				dict: ["🅱", ""]
			}, {
				name: "NEGATIVE SQUARED LATIN CAPITAL LETTER O",
				id: "negative_squared_latin_capital_letter_o",
				src: "1f17e.png",
				dict: ["🅾", ""]
			}, {
				name: "NEGATIVE SQUARED LATIN CAPITAL LETTER P",
				id: "negative_squared_latin_capital_letter_p",
				src: "1f17f.png",
				dict: ["🅿", ""]
			}, {
				name: "NEGATIVE SQUARED AB",
				id: "negative_squared_ab",
				src: "1f18e.png",
				dict: ["🆎", ""]
			}, {
				name: "SQUARED CL",
				id: "squared_cl",
				src: "1f191.png",
				dict: ["🆑"]
			}, {
				name: "SQUARED COOL",
				id: "squared_cool",
				src: "1f192.png",
				dict: ["🆒", ""]
			}, {
				name: "SQUARED FREE",
				id: "squared_free",
				src: "1f193.png",
				dict: ["🆓"]
			}, {
				name: "SQUARED ID",
				id: "squared_id",
				src: "1f194.png",
				dict: ["🆔", ""]
			}, {
				name: "SQUARED NEW",
				id: "squared_new",
				src: "1f195.png",
				dict: ["🆕", ""]
			}, {
				name: "SQUARED NG",
				id: "squared_ng",
				src: "1f196.png",
				dict: ["🆖"]
			}, {
				name: "SQUARED OK",
				id: "squared_ok",
				src: "1f197.png",
				dict: ["🆗", ""]
			}, {
				name: "SQUARED SOS",
				id: "squared_sos",
				src: "1f198.png",
				dict: ["🆘"]
			}, {
				name: "SQUARED UP WITH EXCLAMATION MARK",
				id: "squared_up_with_exclamation_mark",
				src: "1f199.png",
				dict: ["🆙", ""]
			}, {
				name: "SQUARED VS",
				id: "squared_vs",
				src: "1f19a.png",
				dict: ["🆚", ""]
			}, {
				name: "SQUARED KATAKANA KOKO",
				id: "squared_katakana_koko",
				src: "1f201.png",
				dict: ["🈁", ""]
			}, {
				name: "SQUARED KATAKANA SA",
				id: "squared_katakana_sa",
				src: "1f202.png",
				dict: ["🈂", ""]
			}, {
				name: "SQUARED CJK UNIFIED IDEOGRAPH-7121",
				id: "squared_cjk_unified_ideograph-7121",
				src: "1f21a.png",
				dict: ["🈚", ""]
			}, {
				name: "SQUARED CJK UNIFIED IDEOGRAPH-8D70",
				id: "squared_cjk_unified_ideograph-8d70",
				src: "1f22f.png",
				dict: ["🈯", ""]
			}, {
				name: "SQUARED CJK UNIFIED IDEOGRAPH-7981",
				id: "squared_cjk_unified_ideograph-7981",
				src: "1f232.png",
				dict: ["🈲"]
			}, {
				name: "SQUARED CJK UNIFIED IDEOGRAPH-7A7A",
				id: "squared_cjk_unified_ideograph-7a7a",
				src: "1f233.png",
				dict: ["🈳", ""]
			}, {
				name: "SQUARED CJK UNIFIED IDEOGRAPH-5408",
				id: "squared_cjk_unified_ideograph-5408",
				src: "1f234.png",
				dict: ["🈴"]
			}, {
				name: "SQUARED CJK UNIFIED IDEOGRAPH-6E80",
				id: "squared_cjk_unified_ideograph-6e80",
				src: "1f235.png",
				dict: ["🈵", ""]
			}, {
				name: "SQUARED CJK UNIFIED IDEOGRAPH-6709",
				id: "squared_cjk_unified_ideograph-6709",
				src: "1f236.png",
				dict: ["🈶", ""]
			}, {
				name: "SQUARED CJK UNIFIED IDEOGRAPH-6808",
				id: "squared_cjk_unified_ideograph-6808",
				src: "1f237.png",
				dict: ["🈷", ""]
			}, {
				name: "SQUARED CJK UNIFIED IDEOGRAPH-7533",
				id: "squared_cjk_unified_ideograph-7533",
				src: "1f238.png",
				dict: ["🈸", ""]
			}, {
				name: "SQUARED CJK UNIFIED IDEOGRAPH-5272",
				id: "squared_cjk_unified_ideograph-5272",
				src: "1f239.png",
				dict: ["🈹", ""]
			}, {
				name: "SQUARED CJK UNIFIED IDEOGRAPH-55B6",
				id: "squared_cjk_unified_ideograph-55b6",
				src: "1f23a.png",
				dict: ["🈺", ""]
			}, {
				name: "CIRCLED IDEOGRAPH ADVANTAGE",
				id: "circled_ideograph_advantage",
				src: "1f250.png",
				dict: ["🉐", ""]
			}, {
				name: "CIRCLED IDEOGRAPH ACCEPT",
				id: "circled_ideograph_accept",
				src: "1f251.png",
				dict: ["🉑"]
			}, {
				name: "CYCLONE",
				id: "cyclone",
				src: "1f300.png",
				dict: ["🌀", ""]
			}, {
				name: "FOGGY",
				id: "foggy",
				src: "1f301.png",
				dict: ["🌁"]
			}, {
				name: "CLOSED UMBRELLA",
				id: "closed_umbrella",
				src: "1f302.png",
				dict: ["🌂", ""]
			}, {
				name: "NIGHT WITH STARS",
				id: "night_with_stars",
				src: "1f303.png",
				dict: ["🌃", ""]
			}, {
				name: "SUNRISE OVER MOUNTAINS",
				id: "sunrise_over_mountains",
				src: "1f304.png",
				dict: ["🌄", ""]
			}, {
				name: "SUNRISE",
				id: "sunrise",
				src: "1f305.png",
				dict: ["🌅", ""]
			}, {
				name: "CITYSCAPE AT DUSK",
				id: "cityscape_at_dusk",
				src: "1f306.png",
				dict: ["🌆", ""]
			}, {
				name: "SUNSET OVER BUILDINGS",
				id: "sunset_over_buildings",
				src: "1f307.png",
				dict: ["🌇", ""]
			}, {
				name: "RAINBOW",
				id: "rainbow",
				src: "1f308.png",
				dict: ["🌈", ""]
			}, {
				name: "BRIDGE AT NIGHT",
				id: "bridge_at_night",
				src: "1f309.png",
				dict: ["🌉"]
			}, {
				name: "WATER WAVE",
				id: "water_wave",
				src: "1f30a.png",
				dict: ["🌊", ""]
			}, {
				name: "VOLCANO",
				id: "volcano",
				src: "1f30b.png",
				dict: ["🌋"]
			}, {
				name: "MILKY WAY",
				id: "milky_way",
				src: "1f30c.png",
				dict: ["🌌"]
			}, {
				name: "EARTH GLOBE EUROPE-AFRICA",
				id: "earth_globe_europe-africa",
				src: "1f30d.png",
				dict: ["🌍"]
			}, {
				name: "EARTH GLOBE AMERICAS",
				id: "earth_globe_americas",
				src: "1f30e.png",
				dict: ["🌎"]
			}, {
				name: "EARTH GLOBE ASIA-AUSTRALIA",
				id: "earth_globe_asia-australia",
				src: "1f30f.png",
				dict: ["🌏"]
			}, {
				name: "GLOBE WITH MERIDIANS",
				id: "globe_with_meridians",
				src: "1f310.png",
				dict: ["🌐"]
			}, {
				name: "NEW MOON SYMBOL",
				id: "new_moon_symbol",
				src: "1f311.png",
				dict: ["🌑"]
			}, {
				name: "WAXING CRESCENT MOON SYMBOL",
				id: "waxing_crescent_moon_symbol",
				src: "1f312.png",
				dict: ["🌒"]
			}, {
				name: "FIRST QUARTER MOON SYMBOL",
				id: "first_quarter_moon_symbol",
				src: "1f313.png",
				dict: ["🌓"]
			}, {
				name: "WAXING GIBBOUS MOON SYMBOL",
				id: "waxing_gibbous_moon_symbol",
				src: "1f314.png",
				dict: ["🌔"]
			}, {
				name: "FULL MOON SYMBOL",
				id: "full_moon_symbol",
				src: "1f315.png",
				dict: ["🌕"]
			}, {
				name: "WANING GIBBOUS MOON SYMBOL",
				id: "waning_gibbous_moon_symbol",
				src: "1f316.png",
				dict: ["🌖"]
			}, {
				name: "LAST QUARTER MOON SYMBOL",
				id: "last_quarter_moon_symbol",
				src: "1f317.png",
				dict: ["🌗"]
			}, {
				name: "WANING CRESCENT MOON SYMBOL",
				id: "waning_crescent_moon_symbol",
				src: "1f318.png",
				dict: ["🌘"]
			}, {
				name: "CRESCENT MOON",
				id: "crescent_moon",
				src: "1f319.png",
				dict: ["🌙", ""]
			}, {
				name: "NEW MOON WITH FACE",
				id: "new_moon_with_face",
				src: "1f31a.png",
				dict: ["🌚"]
			}, {
				name: "FIRST QUARTER MOON WITH FACE",
				id: "first_quarter_moon_with_face",
				src: "1f31b.png",
				dict: ["🌛"]
			}, {
				name: "LAST QUARTER MOON WITH FACE",
				id: "last_quarter_moon_with_face",
				src: "1f31c.png",
				dict: ["🌜"]
			}, {
				name: "FULL MOON WITH FACE",
				id: "full_moon_with_face",
				src: "1f31d.png",
				dict: ["🌝"]
			}, {
				name: "SUN WITH FACE",
				id: "sun_with_face",
				src: "1f31e.png",
				dict: ["🌞"]
			}, {
				name: "GLOWING STAR",
				id: "glowing_star",
				src: "1f31f.png",
				dict: ["🌟", ""]
			}, {
				name: "SHOOTING STAR",
				id: "shooting_star",
				src: "1f320.png",
				dict: ["🌠"]
			}, {
				name: "CHESTNUT",
				id: "chestnut",
				src: "1f330.png",
				dict: ["🌰"]
			}, {
				name: "SEEDLING",
				id: "seedling",
				src: "1f331.png",
				dict: ["🌱"]
			}, {
				name: "EVERGREEN TREE",
				id: "evergreen_tree",
				src: "1f332.png",
				dict: ["🌲"]
			}, {
				name: "DECIDUOUS TREE",
				id: "deciduous_tree",
				src: "1f333.png",
				dict: ["🌳"]
			}, {
				name: "PALM TREE",
				id: "palm_tree",
				src: "1f334.png",
				dict: ["🌴", ""]
			}, {
				name: "CACTUS",
				id: "cactus",
				src: "1f335.png",
				dict: ["🌵", ""]
			}, {
				name: "TULIP",
				id: "tulip",
				src: "1f337.png",
				dict: ["🌷", ""]
			}, {
				name: "CHERRY BLOSSOM",
				id: "cherry_blossom",
				src: "1f338.png",
				dict: ["🌸", ""]
			}, {
				name: "ROSE",
				id: "rose",
				src: "1f339.png",
				dict: ["🌹", ""]
			}, {
				name: "HIBISCUS",
				id: "hibiscus",
				src: "1f33a.png",
				dict: ["🌺", ""]
			}, {
				name: "SUNFLOWER",
				id: "sunflower",
				src: "1f33b.png",
				dict: ["🌻", ""]
			}, {
				name: "BLOSSOM",
				id: "blossom",
				src: "1f33c.png",
				dict: ["🌼"]
			}, {
				name: "EAR OF MAIZE",
				id: "ear_of_maize",
				src: "1f33d.png",
				dict: ["🌽"]
			}, {
				name: "EAR OF RICE",
				id: "ear_of_rice",
				src: "1f33e.png",
				dict: ["🌾", ""]
			}, {
				name: "HERB",
				id: "herb",
				src: "1f33f.png",
				dict: ["🌿"]
			}, {
				name: "FOUR LEAF CLOVER",
				id: "four_leaf_clover",
				src: "1f340.png",
				dict: ["🍀", ""]
			}, {
				name: "MAPLE LEAF",
				id: "maple_leaf",
				src: "1f341.png",
				dict: ["🍁", ""]
			}, {
				name: "FALLEN LEAF",
				id: "fallen_leaf",
				src: "1f342.png",
				dict: ["🍂", ""]
			}, {
				name: "LEAF FLUTTERING IN WIND",
				id: "leaf_fluttering_in_wind",
				src: "1f343.png",
				dict: ["🍃", ""]
			}, {
				name: "MUSHROOM",
				id: "mushroom",
				src: "1f344.png",
				dict: ["🍄"]
			}, {
				name: "TOMATO",
				id: "tomato",
				src: "1f345.png",
				dict: ["🍅", ""]
			}, {
				name: "AUBERGINE",
				id: "aubergine",
				src: "1f346.png",
				dict: ["🍆", ""]
			}, {
				name: "GRAPES",
				id: "grapes",
				src: "1f347.png",
				dict: ["🍇"]
			}, {
				name: "MELON",
				id: "melon",
				src: "1f348.png",
				dict: ["🍈"]
			}, {
				name: "WATERMELON",
				id: "watermelon",
				src: "1f349.png",
				dict: ["🍉", ""]
			}, {
				name: "TANGERINE",
				id: "tangerine",
				src: "1f34a.png",
				dict: ["🍊", ""]
			}, {
				name: "LEMON",
				id: "lemon",
				src: "1f34b.png",
				dict: ["🍋"]
			}, {
				name: "BANANA",
				id: "banana",
				src: "1f34c.png",
				dict: ["🍌"]
			}, {
				name: "PINEAPPLE",
				id: "pineapple",
				src: "1f34d.png",
				dict: ["🍍"]
			}, {
				name: "RED APPLE",
				id: "red_apple",
				src: "1f34e.png",
				dict: ["🍎", ""]
			}, {
				name: "GREEN APPLE",
				id: "green_apple",
				src: "1f34f.png",
				dict: ["🍏"]
			}, {
				name: "PEAR",
				id: "pear",
				src: "1f350.png",
				dict: ["🍐"]
			}, {
				name: "PEACH",
				id: "peach",
				src: "1f351.png",
				dict: ["🍑"]
			}, {
				name: "CHERRIES",
				id: "cherries",
				src: "1f352.png",
				dict: ["🍒"]
			}, {
				name: "STRAWBERRY",
				id: "strawberry",
				src: "1f353.png",
				dict: ["🍓", ""]
			}, {
				name: "HAMBURGER",
				id: "hamburger",
				src: "1f354.png",
				dict: ["🍔", ""]
			}, {
				name: "SLICE OF PIZZA",
				id: "slice_of_pizza",
				src: "1f355.png",
				dict: ["🍕"]
			}, {
				name: "MEAT ON BONE",
				id: "meat_on_bone",
				src: "1f356.png",
				dict: ["🍖"]
			}, {
				name: "POULTRY LEG",
				id: "poultry_leg",
				src: "1f357.png",
				dict: ["🍗"]
			}, {
				name: "RICE CRACKER",
				id: "rice_cracker",
				src: "1f358.png",
				dict: ["🍘", ""]
			}, {
				name: "RICE BALL",
				id: "rice_ball",
				src: "1f359.png",
				dict: ["🍙", ""]
			}, {
				name: "COOKED RICE",
				id: "cooked_rice",
				src: "1f35a.png",
				dict: ["🍚", ""]
			}, {
				name: "CURRY AND RICE",
				id: "curry_and_rice",
				src: "1f35b.png",
				dict: ["🍛", ""]
			}, {
				name: "STEAMING BOWL",
				id: "steaming_bowl",
				src: "1f35c.png",
				dict: ["🍜", ""]
			}, {
				name: "SPAGHETTI",
				id: "spaghetti",
				src: "1f35d.png",
				dict: ["🍝", ""]
			}, {
				name: "BREAD",
				id: "bread",
				src: "1f35e.png",
				dict: ["🍞", ""]
			}, {
				name: "FRENCH FRIES",
				id: "french_fries",
				src: "1f35f.png",
				dict: ["🍟", ""]
			}, {
				name: "ROASTED SWEET POTATO",
				id: "roasted_sweet_potato",
				src: "1f360.png",
				dict: ["🍠"]
			}, {
				name: "DANGO",
				id: "dango",
				src: "1f361.png",
				dict: ["🍡", ""]
			}, {
				name: "ODEN",
				id: "oden",
				src: "1f362.png",
				dict: ["🍢", ""]
			}, {
				name: "SUSHI",
				id: "sushi",
				src: "1f363.png",
				dict: ["🍣", ""]
			}, {
				name: "FRIED SHRIMP",
				id: "fried_shrimp",
				src: "1f364.png",
				dict: ["🍤"]
			}, {
				name: "FISH CAKE WITH SWIRL DESIGN",
				id: "fish_cake_with_swirl_design",
				src: "1f365.png",
				dict: ["🍥"]
			}, {
				name: "SOFT ICE CREAM",
				id: "soft_ice_cream",
				src: "1f366.png",
				dict: ["🍦", ""]
			}, {
				name: "SHAVED ICE",
				id: "shaved_ice",
				src: "1f367.png",
				dict: ["🍧", ""]
			}, {
				name: "ICE CREAM",
				id: "ice_cream",
				src: "1f368.png",
				dict: ["🍨"]
			}, {
				name: "DOUGHNUT",
				id: "doughnut",
				src: "1f369.png",
				dict: ["🍩"]
			}, {
				name: "COOKIE",
				id: "cookie",
				src: "1f36a.png",
				dict: ["🍪"]
			}, {
				name: "CHOCOLATE BAR",
				id: "chocolate_bar",
				src: "1f36b.png",
				dict: ["🍫"]
			}, {
				name: "CANDY",
				id: "candy",
				src: "1f36c.png",
				dict: ["🍬"]
			}, {
				name: "LOLLIPOP",
				id: "lollipop",
				src: "1f36d.png",
				dict: ["🍭"]
			}, {
				name: "CUSTARD",
				id: "custard",
				src: "1f36e.png",
				dict: ["🍮"]
			}, {
				name: "HONEY POT",
				id: "honey_pot",
				src: "1f36f.png",
				dict: ["🍯"]
			}, {
				name: "SHORTCAKE",
				id: "shortcake",
				src: "1f370.png",
				dict: ["🍰", ""]
			}, {
				name: "BENTO BOX",
				id: "bento_box",
				src: "1f371.png",
				dict: ["🍱", ""]
			}, {
				name: "POT OF FOOD",
				id: "pot_of_food",
				src: "1f372.png",
				dict: ["🍲", ""]
			}, {
				name: "COOKING",
				id: "cooking",
				src: "1f373.png",
				dict: ["🍳", ""]
			}, {
				name: "FORK AND KNIFE",
				id: "fork_and_knife",
				src: "1f374.png",
				dict: ["🍴", ""]
			}, {
				name: "TEACUP WITHOUT HANDLE",
				id: "teacup_without_handle",
				src: "1f375.png",
				dict: ["🍵", ""]
			}, {
				name: "SAKE BOTTLE AND CUP",
				id: "sake_bottle_and_cup",
				src: "1f376.png",
				dict: ["🍶", ""]
			}, {
				name: "WINE GLASS",
				id: "wine_glass",
				src: "1f377.png",
				dict: ["🍷"]
			}, {
				name: "COCKTAIL GLASS",
				id: "cocktail_glass",
				src: "1f378.png",
				dict: ["🍸", ""]
			}, {
				name: "TROPICAL DRINK",
				id: "tropical_drink",
				src: "1f379.png",
				dict: ["🍹"]
			}, {
				name: "BEER MUG",
				id: "beer_mug",
				src: "1f37a.png",
				dict: ["🍺", ""]
			}, {
				name: "CLINKING BEER MUGS",
				id: "clinking_beer_mugs",
				src: "1f37b.png",
				dict: ["🍻", ""]
			}, {
				name: "BABY BOTTLE",
				id: "baby_bottle",
				src: "1f37c.png",
				dict: ["🍼"]
			}, {
				name: "RIBBON",
				id: "ribbon",
				src: "1f380.png",
				dict: ["🎀", ""]
			}, {
				name: "WRAPPED PRESENT",
				id: "wrapped_present",
				src: "1f381.png",
				dict: ["🎁", ""]
			}, {
				name: "BIRTHDAY CAKE",
				id: "birthday_cake",
				src: "1f382.png",
				dict: ["🎂", ""]
			}, {
				name: "JACK-O-LANTERN",
				id: "jack-o-lantern",
				src: "1f383.png",
				dict: ["🎃", ""]
			}, {
				name: "CHRISTMAS TREE",
				id: "christmas_tree",
				src: "1f384.png",
				dict: ["🎄", ""]
			}, {
				name: "FATHER CHRISTMAS",
				id: "father_christmas",
				src: "1f385.png",
				dict: ["🎅", ""]
			}, {
				name: "FIREWORKS",
				id: "fireworks",
				src: "1f386.png",
				dict: ["🎆", ""]
			}, {
				name: "FIREWORK SPARKLER",
				id: "firework_sparkler",
				src: "1f387.png",
				dict: ["🎇", ""]
			}, {
				name: "BALLOON",
				id: "balloon",
				src: "1f388.png",
				dict: ["🎈", ""]
			}, {
				name: "PARTY POPPER",
				id: "party_popper",
				src: "1f389.png",
				dict: ["🎉", ""]
			}, {
				name: "CONFETTI BALL",
				id: "confetti_ball",
				src: "1f38a.png",
				dict: ["🎊"]
			}, {
				name: "TANABATA TREE",
				id: "tanabata_tree",
				src: "1f38b.png",
				dict: ["🎋"]
			}, {
				name: "CROSSED FLAGS",
				id: "crossed_flags",
				src: "1f38c.png",
				dict: ["🎌", ""]
			}, {
				name: "PINE DECORATION",
				id: "pine_decoration",
				src: "1f38d.png",
				dict: ["🎍", ""]
			}, {
				name: "JAPANESE DOLLS",
				id: "japanese_dolls",
				src: "1f38e.png",
				dict: ["🎎", ""]
			}, {
				name: "CARP STREAMER",
				id: "carp_streamer",
				src: "1f38f.png",
				dict: ["🎏", ""]
			}, {
				name: "WIND CHIME",
				id: "wind_chime",
				src: "1f390.png",
				dict: ["🎐", ""]
			}, {
				name: "MOON VIEWING CEREMONY",
				id: "moon_viewing_ceremony",
				src: "1f391.png",
				dict: ["🎑", ""]
			}, {
				name: "SCHOOL SATCHEL",
				id: "school_satchel",
				src: "1f392.png",
				dict: ["🎒", ""]
			}, {
				name: "GRADUATION CAP",
				id: "graduation_cap",
				src: "1f393.png",
				dict: ["🎓", ""]
			}, {
				name: "CAROUSEL HORSE",
				id: "carousel_horse",
				src: "1f3a0.png",
				dict: ["🎠"]
			}, {
				name: "FERRIS WHEEL",
				id: "ferris_wheel",
				src: "1f3a1.png",
				dict: ["🎡", ""]
			}, {
				name: "ROLLER COASTER",
				id: "roller_coaster",
				src: "1f3a2.png",
				dict: ["🎢", ""]
			}, {
				name: "FISHING POLE AND FISH",
				id: "fishing_pole_and_fish",
				src: "1f3a3.png",
				dict: ["🎣"]
			}, {
				name: "MICROPHONE",
				id: "microphone",
				src: "1f3a4.png",
				dict: ["🎤", ""]
			}, {
				name: "MOVIE CAMERA",
				id: "movie_camera",
				src: "1f3a5.png",
				dict: ["🎥", ""]
			}, {
				name: "CINEMA",
				id: "cinema",
				src: "1f3a6.png",
				dict: ["🎦", ""]
			}, {
				name: "HEADPHONE",
				id: "headphone",
				src: "1f3a7.png",
				dict: ["🎧", ""]
			}, {
				name: "ARTIST PALETTE",
				id: "artist_palette",
				src: "1f3a8.png",
				dict: ["🎨", ""]
			}, {
				name: "TOP HAT",
				id: "top_hat",
				src: "1f3a9.png",
				dict: ["🎩", ""]
			}, {
				name: "CIRCUS TENT",
				id: "circus_tent",
				src: "1f3aa.png",
				dict: ["🎪"]
			}, {
				name: "TICKET",
				id: "ticket",
				src: "1f3ab.png",
				dict: ["🎫", ""]
			}, {
				name: "CLAPPER BOARD",
				id: "clapper_board",
				src: "1f3ac.png",
				dict: ["🎬", ""]
			}, {
				name: "PERFORMING ARTS",
				id: "performing_arts",
				src: "1f3ad.png",
				dict: ["🎭"]
			}, {
				name: "VIDEO GAME",
				id: "video_game",
				src: "1f3ae.png",
				dict: ["🎮"]
			}, {
				name: "DIRECT HIT",
				id: "direct_hit",
				src: "1f3af.png",
				dict: ["🎯", ""]
			}, {
				name: "SLOT MACHINE",
				id: "slot_machine",
				src: "1f3b0.png",
				dict: ["🎰", ""]
			}, {
				name: "BILLIARDS",
				id: "billiards",
				src: "1f3b1.png",
				dict: ["🎱", ""]
			}, {
				name: "GAME DIE",
				id: "game_die",
				src: "1f3b2.png",
				dict: ["🎲"]
			}, {
				name: "BOWLING",
				id: "bowling",
				src: "1f3b3.png",
				dict: ["🎳"]
			}, {
				name: "FLOWER PLAYING CARDS",
				id: "flower_playing_cards",
				src: "1f3b4.png",
				dict: ["🎴"]
			}, {
				name: "MUSICAL NOTE",
				id: "musical_note",
				src: "1f3b5.png",
				dict: ["🎵", ""]
			}, {
				name: "MULTIPLE MUSIC NOTES",
				id: "multiple_music_notes",
				src: "1f3b6.png",
				dict: ["🎶", ""]
			}, {
				name: "SAXOPHONE",
				id: "saxophone",
				src: "1f3b7.png",
				dict: ["🎷", ""]
			}, {
				name: "GUITAR",
				id: "guitar",
				src: "1f3b8.png",
				dict: ["🎸", ""]
			}, {
				name: "MUSICAL KEYBOARD",
				id: "musical_keyboard",
				src: "1f3b9.png",
				dict: ["🎹"]
			}, {
				name: "TRUMPET",
				id: "trumpet",
				src: "1f3ba.png",
				dict: ["🎺", ""]
			}, {
				name: "VIOLIN",
				id: "violin",
				src: "1f3bb.png",
				dict: ["🎻"]
			}, {
				name: "MUSICAL SCORE",
				id: "musical_score",
				src: "1f3bc.png",
				dict: ["🎼"]
			}, {
				name: "RUNNING SHIRT WITH SASH",
				id: "running_shirt_with_sash",
				src: "1f3bd.png",
				dict: ["🎽"]
			}, {
				name: "TENNIS RACQUET AND BALL",
				id: "tennis_racquet_and_ball",
				src: "1f3be.png",
				dict: ["🎾", ""]
			}, {
				name: "SKI AND SKI BOOT",
				id: "ski_and_ski_boot",
				src: "1f3bf.png",
				dict: ["🎿", ""]
			}, {
				name: "BASKETBALL AND HOOP",
				id: "basketball_and_hoop",
				src: "1f3c0.png",
				dict: ["🏀", ""]
			}, {
				name: "CHEQUERED FLAG",
				id: "chequered_flag",
				src: "1f3c1.png",
				dict: ["🏁", ""]
			}, {
				name: "SNOWBOARDER",
				id: "snowboarder",
				src: "1f3c2.png",
				dict: ["🏂"]
			}, {
				name: "RUNNER",
				id: "runner",
				src: "1f3c3.png",
				dict: ["🏃", ""]
			}, {
				name: "SURFER",
				id: "surfer",
				src: "1f3c4.png",
				dict: ["🏄", ""]
			}, {
				name: "TROPHY",
				id: "trophy",
				src: "1f3c6.png",
				dict: ["🏆", ""]
			}, {
				name: "HORSE RACING",
				id: "horse_racing",
				src: "1f3c7.png",
				dict: ["🏇"]
			}, {
				name: "AMERICAN FOOTBALL",
				id: "american_football",
				src: "1f3c8.png",
				dict: ["🏈", ""]
			}, {
				name: "RUGBY FOOTBALL",
				id: "rugby_football",
				src: "1f3c9.png",
				dict: ["🏉"]
			}, {
				name: "SWIMMER",
				id: "swimmer",
				src: "1f3ca.png",
				dict: ["🏊", ""]
			}, {
				name: "HOUSE BUILDING",
				id: "house_building",
				src: "1f3e0.png",
				dict: ["🏠", ""]
			}, {
				name: "HOUSE WITH GARDEN",
				id: "house_with_garden",
				src: "1f3e1.png",
				dict: ["🏡"]
			}, {
				name: "OFFICE BUILDING",
				id: "office_building",
				src: "1f3e2.png",
				dict: ["🏢", ""]
			}, {
				name: "JAPANESE POST OFFICE",
				id: "japanese_post_office",
				src: "1f3e3.png",
				dict: ["🏣", ""]
			}, {
				name: "EUROPEAN POST OFFICE",
				id: "european_post_office",
				src: "1f3e4.png",
				dict: ["🏤"]
			}, {
				name: "HOSPITAL",
				id: "hospital",
				src: "1f3e5.png",
				dict: ["🏥", ""]
			}, {
				name: "BANK",
				id: "bank",
				src: "1f3e6.png",
				dict: ["🏦", ""]
			}, {
				name: "AUTOMATED TELLER MACHINE",
				id: "automated_teller_machine",
				src: "1f3e7.png",
				dict: ["🏧", ""]
			}, {
				name: "HOTEL",
				id: "hotel",
				src: "1f3e8.png",
				dict: ["🏨", ""]
			}, {
				name: "LOVE HOTEL",
				id: "love_hotel",
				src: "1f3e9.png",
				dict: ["🏩", ""]
			}, {
				name: "CONVENIENCE STORE",
				id: "convenience_store",
				src: "1f3ea.png",
				dict: ["🏪", ""]
			}, {
				name: "SCHOOL",
				id: "school",
				src: "1f3eb.png",
				dict: ["🏫", ""]
			}, {
				name: "DEPARTMENT STORE",
				id: "department_store",
				src: "1f3ec.png",
				dict: ["🏬", ""]
			}, {
				name: "FACTORY",
				id: "factory",
				src: "1f3ed.png",
				dict: ["🏭", ""]
			}, {
				name: "IZAKAYA LANTERN",
				id: "izakaya_lantern",
				src: "1f3ee.png",
				dict: ["🏮"]
			}, {
				name: "JAPANESE CASTLE",
				id: "japanese_castle",
				src: "1f3ef.png",
				dict: ["🏯", ""]
			}, {
				name: "EUROPEAN CASTLE",
				id: "european_castle",
				src: "1f3f0.png",
				dict: ["🏰", ""]
			}, {
				name: "RAT",
				id: "rat",
				src: "1f400.png",
				dict: ["🐀"]
			}, {
				name: "MOUSE",
				id: "mouse",
				src: "1f401.png",
				dict: ["🐁"]
			}, {
				name: "OX",
				id: "ox",
				src: "1f402.png",
				dict: ["🐂"]
			}, {
				name: "WATER BUFFALO",
				id: "water_buffalo",
				src: "1f403.png",
				dict: ["🐃"]
			}, {
				name: "COW",
				id: "cow",
				src: "1f404.png",
				dict: ["🐄"]
			}, {
				name: "TIGER",
				id: "tiger",
				src: "1f405.png",
				dict: ["🐅"]
			}, {
				name: "LEOPARD",
				id: "leopard",
				src: "1f406.png",
				dict: ["🐆"]
			}, {
				name: "RABBIT",
				id: "rabbit",
				src: "1f407.png",
				dict: ["🐇"]
			}, {
				name: "CAT",
				id: "cat",
				src: "1f408.png",
				dict: ["🐈"]
			}, {
				name: "DRAGON",
				id: "dragon",
				src: "1f409.png",
				dict: ["🐉"]
			}, {
				name: "CROCODILE",
				id: "crocodile",
				src: "1f40a.png",
				dict: ["🐊"]
			}, {
				name: "WHALE",
				id: "whale",
				src: "1f40b.png",
				dict: ["🐋"]
			}, {
				name: "SNAIL",
				id: "snail",
				src: "1f40c.png",
				dict: ["🐌"]
			}, {
				name: "SNAKE",
				id: "snake",
				src: "1f40d.png",
				dict: ["🐍", ""]
			}, {
				name: "HORSE",
				id: "horse",
				src: "1f40e.png",
				dict: ["🐎", ""]
			}, {
				name: "RAM",
				id: "ram",
				src: "1f40f.png",
				dict: ["🐏"]
			}, {
				name: "GOAT",
				id: "goat",
				src: "1f410.png",
				dict: ["🐐"]
			}, {
				name: "SHEEP",
				id: "sheep",
				src: "1f411.png",
				dict: ["🐑", ""]
			}, {
				name: "MONKEY",
				id: "monkey",
				src: "1f412.png",
				dict: ["🐒", ""]
			}, {
				name: "ROOSTER",
				id: "rooster",
				src: "1f413.png",
				dict: ["🐓"]
			}, {
				name: "CHICKEN",
				id: "chicken",
				src: "1f414.png",
				dict: ["🐔", ""]
			}, {
				name: "DOG",
				id: "dog",
				src: "1f415.png",
				dict: ["🐕"]
			}, {
				name: "PIG",
				id: "pig",
				src: "1f416.png",
				dict: ["🐖"]
			}, {
				name: "BOAR",
				id: "boar",
				src: "1f417.png",
				dict: ["🐗", ""]
			}, {
				name: "ELEPHANT",
				id: "elephant",
				src: "1f418.png",
				dict: ["🐘", ""]
			}, {
				name: "OCTOPUS",
				id: "octopus",
				src: "1f419.png",
				dict: ["🐙", ""]
			}, {
				name: "SPIRAL SHELL",
				id: "spiral_shell",
				src: "1f41a.png",
				dict: ["🐚", ""]
			}, {
				name: "BUG",
				id: "bug",
				src: "1f41b.png",
				dict: ["🐛", ""]
			}, {
				name: "ANT",
				id: "ant",
				src: "1f41c.png",
				dict: ["🐜"]
			}, {
				name: "HONEYBEE",
				id: "honeybee",
				src: "1f41d.png",
				dict: ["🐝"]
			}, {
				name: "LADY BEETLE",
				id: "lady_beetle",
				src: "1f41e.png",
				dict: ["🐞"]
			}, {
				name: "FISH",
				id: "fish",
				src: "1f41f.png",
				dict: ["🐟", ""]
			}, {
				name: "TROPICAL FISH",
				id: "tropical_fish",
				src: "1f420.png",
				dict: ["🐠", ""]
			}, {
				name: "BLOWFISH",
				id: "blowfish",
				src: "1f421.png",
				dict: ["🐡"]
			}, {
				name: "TURTLE",
				id: "turtle",
				src: "1f422.png",
				dict: ["🐢"]
			}, {
				name: "HATCHING CHICK",
				id: "hatching_chick",
				src: "1f423.png",
				dict: ["🐣"]
			}, {
				name: "BABY CHICK",
				id: "baby_chick",
				src: "1f424.png",
				dict: ["🐤", ""]
			}, {
				name: "FRONT-FACING BABY CHICK",
				id: "front-facing_baby_chick",
				src: "1f425.png",
				dict: ["🐥"]
			}, {
				name: "BIRD",
				id: "bird",
				src: "1f426.png",
				dict: ["🐦", ""]
			}, {
				name: "PENGUIN",
				id: "penguin",
				src: "1f427.png",
				dict: ["🐧", ""]
			}, {
				name: "KOALA",
				id: "koala",
				src: "1f428.png",
				dict: ["🐨", ""]
			}, {
				name: "POODLE",
				id: "poodle",
				src: "1f429.png",
				dict: ["🐩"]
			}, {
				name: "DROMEDARY CAMEL",
				id: "dromedary_camel",
				src: "1f42a.png",
				dict: ["🐪"]
			}, {
				name: "BACTRIAN CAMEL",
				id: "bactrian_camel",
				src: "1f42b.png",
				dict: ["🐫", ""]
			}, {
				name: "DOLPHIN",
				id: "dolphin",
				src: "1f42c.png",
				dict: ["🐬", ""]
			}, {
				name: "MOUSE FACE",
				id: "mouse_face",
				src: "1f42d.png",
				dict: ["🐭", ""]
			}, {
				name: "COW FACE",
				id: "cow_face",
				src: "1f42e.png",
				dict: ["🐮", ""]
			}, {
				name: "TIGER FACE",
				id: "tiger_face",
				src: "1f42f.png",
				dict: ["🐯", ""]
			}, {
				name: "RABBIT FACE",
				id: "rabbit_face",
				src: "1f430.png",
				dict: ["🐰", ""]
			}, {
				name: "CAT FACE",
				id: "cat_face",
				src: "1f431.png",
				dict: ["🐱", ""]
			}, {
				name: "DRAGON FACE",
				id: "dragon_face",
				src: "1f432.png",
				dict: ["🐲"]
			}, {
				name: "SPOUTING WHALE",
				id: "spouting_whale",
				src: "1f433.png",
				dict: ["🐳", ""]
			}, {
				name: "HORSE FACE",
				id: "horse_face",
				src: "1f434.png",
				dict: ["🐴", ""]
			}, {
				name: "MONKEY FACE",
				id: "monkey_face",
				src: "1f435.png",
				dict: ["🐵", ""]
			}, {
				name: "DOG FACE",
				id: "dog_face",
				src: "1f436.png",
				dict: ["🐶", ""]
			}, {
				name: "PIG FACE",
				id: "pig_face",
				src: "1f437.png",
				dict: ["🐷", ""]
			}, {
				name: "FROG FACE",
				id: "frog_face",
				src: "1f438.png",
				dict: ["🐸", ""]
			}, {
				name: "HAMSTER FACE",
				id: "hamster_face",
				src: "1f439.png",
				dict: ["🐹", ""]
			}, {
				name: "WOLF FACE",
				id: "wolf_face",
				src: "1f43a.png",
				dict: ["🐺", ""]
			}, {
				name: "BEAR FACE",
				id: "bear_face",
				src: "1f43b.png",
				dict: ["🐻", ""]
			}, {
				name: "PANDA FACE",
				id: "panda_face",
				src: "1f43c.png",
				dict: ["🐼"]
			}, {
				name: "PIG NOSE",
				id: "pig_nose",
				src: "1f43d.png",
				dict: ["🐽"]
			}, {
				name: "PAW PRINTS",
				id: "paw_prints",
				src: "1f43e.png",
				dict: ["🐾"]
			}, {
				name: "EYES",
				id: "eyes",
				src: "1f440.png",
				dict: ["👀", ""]
			}, {
				name: "EAR",
				id: "ear",
				src: "1f442.png",
				dict: ["👂", ""]
			}, {
				name: "NOSE",
				id: "nose",
				src: "1f443.png",
				dict: ["👃", ""]
			}, {
				name: "MOUTH",
				id: "mouth",
				src: "1f444.png",
				dict: ["👄", ""]
			}, {
				name: "TONGUE",
				id: "tongue",
				src: "1f445.png",
				dict: ["👅"]
			}, {
				name: "WHITE UP POINTING BACKHAND INDEX",
				id: "white_up_pointing_backhand_index",
				src: "1f446.png",
				dict: ["👆", ""]
			}, {
				name: "WHITE DOWN POINTING BACKHAND INDEX",
				id: "white_down_pointing_backhand_index",
				src: "1f447.png",
				dict: ["👇", ""]
			}, {
				name: "WHITE LEFT POINTING BACKHAND INDEX",
				id: "white_left_pointing_backhand_index",
				src: "1f448.png",
				dict: ["👈", ""]
			}, {
				name: "WHITE RIGHT POINTING BACKHAND INDEX",
				id: "white_right_pointing_backhand_index",
				src: "1f449.png",
				dict: ["👉", ""]
			}, {
				name: "FISTED HAND SIGN",
				id: "fisted_hand_sign",
				src: "1f44a.png",
				dict: ["👊", ""]
			}, {
				name: "WAVING HAND SIGN",
				id: "waving_hand_sign",
				src: "1f44b.png",
				dict: ["👋", ""]
			}, {
				name: "OK HAND SIGN",
				id: "ok_hand_sign",
				src: "1f44c.png",
				dict: ["👌", ""]
			}, {
				name: "THUMBS UP SIGN",
				id: "thumbs_up_sign",
				src: "1f44d.png",
				dict: ["👍", ""]
			}, {
				name: "THUMBS DOWN SIGN",
				id: "thumbs_down_sign",
				src: "1f44e.png",
				dict: ["👎", ""]
			}, {
				name: "CLAPPING HANDS SIGN",
				id: "clapping_hands_sign",
				src: "1f44f.png",
				dict: ["👏", ""]
			}, {
				name: "OPEN HANDS SIGN",
				id: "open_hands_sign",
				src: "1f450.png",
				dict: ["👐", ""]
			}, {
				name: "CROWN",
				id: "crown",
				src: "1f451.png",
				dict: ["👑", ""]
			}, {
				name: "WOMANS HAT",
				id: "womans_hat",
				src: "1f452.png",
				dict: ["👒", ""]
			}, {
				name: "EYEGLASSES",
				id: "eyeglasses",
				src: "1f453.png",
				dict: ["👓"]
			}, {
				name: "NECKTIE",
				id: "necktie",
				src: "1f454.png",
				dict: ["👔", ""]
			}, {
				name: "T-SHIRT",
				id: "t-shirt",
				src: "1f455.png",
				dict: ["👕", ""]
			}, {
				name: "JEANS",
				id: "jeans",
				src: "1f456.png",
				dict: ["👖"]
			}, {
				name: "DRESS",
				id: "dress",
				src: "1f457.png",
				dict: ["👗", ""]
			}, {
				name: "KIMONO",
				id: "kimono",
				src: "1f458.png",
				dict: ["👘", ""]
			}, {
				name: "BIKINI",
				id: "bikini",
				src: "1f459.png",
				dict: ["👙", ""]
			}, {
				name: "WOMANS CLOTHES",
				id: "womans_clothes",
				src: "1f45a.png",
				dict: ["👚"]
			}, {
				name: "PURSE",
				id: "purse",
				src: "1f45b.png",
				dict: ["👛"]
			}, {
				name: "HANDBAG",
				id: "handbag",
				src: "1f45c.png",
				dict: ["👜", ""]
			}, {
				name: "POUCH",
				id: "pouch",
				src: "1f45d.png",
				dict: ["👝"]
			}, {
				name: "MANS SHOE",
				id: "mans_shoe",
				src: "1f45e.png",
				dict: ["👞"]
			}, {
				name: "ATHLETIC SHOE",
				id: "athletic_shoe",
				src: "1f45f.png",
				dict: ["👟", ""]
			}, {
				name: "HIGH-HEELED SHOE",
				id: "high-heeled_shoe",
				src: "1f460.png",
				dict: ["👠", ""]
			}, {
				name: "WOMANS SANDAL",
				id: "womans_sandal",
				src: "1f461.png",
				dict: ["👡", ""]
			}, {
				name: "WOMANS BOOTS",
				id: "womans_boots",
				src: "1f462.png",
				dict: ["👢", ""]
			}, {
				name: "FOOTPRINTS",
				id: "footprints",
				src: "1f463.png",
				dict: ["👣", ""]
			}, {
				name: "BUST IN SILHOUETTE",
				id: "bust_in_silhouette",
				src: "1f464.png",
				dict: ["👤"]
			}, {
				name: "BUSTS IN SILHOUETTE",
				id: "busts_in_silhouette",
				src: "1f465.png",
				dict: ["👥"]
			}, {
				name: "BOY",
				id: "boy",
				src: "1f466.png",
				dict: ["👦", ""]
			}, {
				name: "GIRL",
				id: "girl",
				src: "1f467.png",
				dict: ["👧", ""]
			}, {
				name: "MAN",
				id: "man",
				src: "1f468.png",
				dict: ["👨", ""]
			}, {
				name: "WOMAN",
				id: "woman",
				src: "1f469.png",
				dict: ["👩", ""]
			}, {
				name: "FAMILY",
				id: "family",
				src: "1f46a.png",
				dict: ["👪"]
			}, {
				name: "MAN AND WOMAN HOLDING HANDS",
				id: "man_and_woman_holding_hands",
				src: "1f46b.png",
				dict: ["👫", ""]
			}, {
				name: "TWO MEN HOLDING HANDS",
				id: "two_men_holding_hands",
				src: "1f46c.png",
				dict: ["👬"]
			}, {
				name: "TWO WOMEN HOLDING HANDS",
				id: "two_women_holding_hands",
				src: "1f46d.png",
				dict: ["👭"]
			}, {
				name: "POLICE OFFICER",
				id: "police_officer",
				src: "1f46e.png",
				dict: ["👮", ""]
			}, {
				name: "WOMAN WITH BUNNY EARS",
				id: "woman_with_bunny_ears",
				src: "1f46f.png",
				dict: ["👯", ""]
			}, {
				name: "BRIDE WITH VEIL",
				id: "bride_with_veil",
				src: "1f470.png",
				dict: ["👰"]
			}, {
				name: "PERSON WITH BOLND HAIR",
				id: "person_with_bolnd_hair",
				src: "1f471.png",
				dict: ["👱", ""]
			}, {
				name: "MAN WITH GUA PI MAO",
				id: "man_with_gua_pi_mao",
				src: "1f472.png",
				dict: ["👲", ""]
			}, {
				name: "MAN WITH TURBAN",
				id: "man_with_turban",
				src: "1f473.png",
				dict: ["👳", ""]
			}, {
				name: "OLDER MAN",
				id: "older_man",
				src: "1f474.png",
				dict: ["👴", ""]
			}, {
				name: "OLDER WOMAN",
				id: "older_woman",
				src: "1f475.png",
				dict: ["👵", ""]
			}, {
				name: "BABY",
				id: "baby",
				src: "1f476.png",
				dict: ["👶", ""]
			}, {
				name: "CONSTRUCTION WORKER",
				id: "construction_worker",
				src: "1f477.png",
				dict: ["👷", ""]
			}, {
				name: "PRINCESS",
				id: "princess",
				src: "1f478.png",
				dict: ["👸", ""]
			}, {
				name: "JAPANESE OGRE",
				id: "japanese_ogre",
				src: "1f479.png",
				dict: ["👹"]
			}, {
				name: "JAPANESE GOBLIN",
				id: "japanese_goblin",
				src: "1f47a.png",
				dict: ["👺"]
			}, {
				name: "GHOST",
				id: "ghost",
				src: "1f47b.png",
				dict: ["👻", ""]
			}, {
				name: "BABY ANGEL",
				id: "baby_angel",
				src: "1f47c.png",
				dict: ["👼", ""]
			}, {
				name: "EXTRATERRESTRIAL ALIEN",
				id: "extraterrestrial_alien",
				src: "1f47d.png",
				dict: ["👽", ""]
			}, {
				name: "ALIEN MONSTER",
				id: "alien_monster",
				src: "1f47e.png",
				dict: ["👾", ""]
			}, {
				name: "IMP",
				id: "imp",
				src: "1f47f.png",
				dict: ["👿", ""]
			}, {
				name: "SKULL",
				id: "skull",
				src: "1f480.png",
				dict: ["💀", ""]
			}, {
				name: "INFORMATION DESK PERSON",
				id: "information_desk_person",
				src: "1f481.png",
				dict: ["💁", ""]
			}, {
				name: "GUARDSMAN",
				id: "guardsman",
				src: "1f482.png",
				dict: ["💂", ""]
			}, {
				name: "DANCER",
				id: "dancer",
				src: "1f483.png",
				dict: ["💃", ""]
			}, {
				name: "LIPSTICK",
				id: "lipstick",
				src: "1f484.png",
				dict: ["💄", ""]
			}, {
				name: "NAIL POLISH",
				id: "nail_polish",
				src: "1f485.png",
				dict: ["💅", ""]
			}, {
				name: "FACE MASSAGE",
				id: "face_massage",
				src: "1f486.png",
				dict: ["💆", ""]
			}, {
				name: "HAIRCUT",
				id: "haircut",
				src: "1f487.png",
				dict: ["💇", ""]
			}, {
				name: "BARBER POLE",
				id: "barber_pole",
				src: "1f488.png",
				dict: ["💈", ""]
			}, {
				name: "SYRINGE",
				id: "syringe",
				src: "1f489.png",
				dict: ["💉", ""]
			}, {
				name: "PILL",
				id: "pill",
				src: "1f48a.png",
				dict: ["💊", ""]
			}, {
				name: "KISS MARK",
				id: "kiss_mark",
				src: "1f48b.png",
				dict: ["💋", ""]
			}, {
				name: "LOVE LETTER",
				id: "love_letter",
				src: "1f48c.png",
				dict: ["💌"]
			}, {
				name: "RING",
				id: "ring",
				src: "1f48d.png",
				dict: ["💍", ""]
			}, {
				name: "GEM STONE",
				id: "gem_stone",
				src: "1f48e.png",
				dict: ["💎", ""]
			}, {
				name: "KISS",
				id: "kiss",
				src: "1f48f.png",
				dict: ["💏", ""]
			}, {
				name: "BOUQUET",
				id: "bouquet",
				src: "1f490.png",
				dict: ["💐", ""]
			}, {
				name: "COUPLE WITH HEART",
				id: "couple_with_heart",
				src: "1f491.png",
				dict: ["💑", ""]
			}, {
				name: "WEDDING",
				id: "wedding",
				src: "1f492.png",
				dict: ["💒", ""]
			}, {
				name: "BEATING HEART",
				id: "beating_heart",
				src: "1f493.png",
				dict: ["💓", ""]
			}, {
				name: "BROKEN HEART",
				id: "broken_heart",
				src: "1f494.png",
				dict: ["💔", ""]
			}, {
				name: "TWO HEARTS",
				id: "two_hearts",
				src: "1f495.png",
				dict: ["💕"]
			}, {
				name: "SPARKLING HEART",
				id: "sparkling_heart",
				src: "1f496.png",
				dict: ["💖"]
			}, {
				name: "GROWING HEART",
				id: "growing_heart",
				src: "1f497.png",
				dict: ["💗", ""]
			}, {
				name: "HEART WITH ARROW",
				id: "heart_with_arrow",
				src: "1f498.png",
				dict: ["💘", ""]
			}, {
				name: "BLUE HEART",
				id: "blue_heart",
				src: "1f499.png",
				dict: ["💙", ""]
			}, {
				name: "GREEN HEART",
				id: "green_heart",
				src: "1f49a.png",
				dict: ["💚", ""]
			}, {
				name: "YELLOW HEART",
				id: "yellow_heart",
				src: "1f49b.png",
				dict: ["💛", ""]
			}, {
				name: "PURPLE HEART",
				id: "purple_heart",
				src: "1f49c.png",
				dict: ["💜", ""]
			}, {
				name: "HEART WITH RIBBON",
				id: "heart_with_ribbon",
				src: "1f49d.png",
				dict: ["💝", ""]
			}, {
				name: "REVOLVING HEARTS",
				id: "revolving_hearts",
				src: "1f49e.png",
				dict: ["💞"]
			}, {
				name: "HEART DECORATION",
				id: "heart_decoration",
				src: "1f49f.png",
				dict: ["💟", ""]
			}, {
				name: "DIAMOND SHAPE WITH A DOT INSIDE",
				id: "diamond_shape_with_a_dot_inside",
				src: "1f4a0.png",
				dict: ["💠"]
			}, {
				name: "ELECTRIC LIGHT BULB",
				id: "electric_light_bulb",
				src: "1f4a1.png",
				dict: ["💡", ""]
			}, {
				name: "ANGER SYMBOL",
				id: "anger_symbol",
				src: "1f4a2.png",
				dict: ["💢", ""]
			}, {
				name: "BOMB",
				id: "bomb",
				src: "1f4a3.png",
				dict: ["💣", ""]
			}, {
				name: "SLEEPING SYMBOL",
				id: "sleeping_symbol",
				src: "1f4a4.png",
				dict: ["💤", ""]
			}, {
				name: "COLLISION SYMBOL",
				id: "collision_symbol",
				src: "1f4a5.png",
				dict: ["💥"]
			}, {
				name: "SPLASHING SWEAT SYMBOL",
				id: "splashing_sweat_symbol",
				src: "1f4a6.png",
				dict: ["💦", ""]
			}, {
				name: "DROPLET",
				id: "droplet",
				src: "1f4a7.png",
				dict: ["💧"]
			}, {
				name: "DASH SYMBOL",
				id: "dash_symbol",
				src: "1f4a8.png",
				dict: ["💨", ""]
			}, {
				name: "PILE OF POO",
				id: "pile_of_poo",
				src: "1f4a9.png",
				dict: ["💩", ""]
			}, {
				name: "FLEXED BICEPS",
				id: "flexed_biceps",
				src: "1f4aa.png",
				dict: ["💪", ""]
			}, {
				name: "DIZZY SYMBOL",
				id: "dizzy_symbol",
				src: "1f4ab.png",
				dict: ["💫"]
			}, {
				name: "SPEECH BALLOON",
				id: "speech_balloon",
				src: "1f4ac.png",
				dict: ["💬"]
			}, {
				name: "THOUGHT BALLOON",
				id: "thought_balloon",
				src: "1f4ad.png",
				dict: ["💭"]
			}, {
				name: "WHITE FLOWER",
				id: "white_flower",
				src: "1f4ae.png",
				dict: ["💮"]
			}, {
				name: "HUNDRED POINTS SYMBOL",
				id: "hundred_points_symbol",
				src: "1f4af.png",
				dict: ["💯"]
			}, {
				name: "MONEY BAG",
				id: "money_bag",
				src: "1f4b0.png",
				dict: ["💰", ""]
			}, {
				name: "CURRENCY EXCHANGE",
				id: "currency_exchange",
				src: "1f4b1.png",
				dict: ["💱", ""]
			}, {
				name: "HEAVY DOLLAR SIGN",
				id: "heavy_dollar_sign",
				src: "1f4b2.png",
				dict: ["💲"]
			}, {
				name: "CREDIT CARD",
				id: "credit_card",
				src: "1f4b3.png",
				dict: ["💳"]
			}, {
				name: "BANKNOTE WITH YEN SYMBOL",
				id: "banknote_with_yen_symbol",
				src: "1f4b4.png",
				dict: ["💴"]
			}, {
				name: "BANKNOTE WITH DOLLAR SIGN",
				id: "banknote_with_dollar_sign",
				src: "1f4b5.png",
				dict: ["💵"]
			}, {
				name: "BANKNOTE WITH EURO SIGN",
				id: "banknote_with_euro_sign",
				src: "1f4b6.png",
				dict: ["💶"]
			}, {
				name: "BANKNOTE WITH POUND SIGN",
				id: "banknote_with_pound_sign",
				src: "1f4b7.png",
				dict: ["💷"]
			}, {
				name: "MONEY WITH WINGS",
				id: "money_with_wings",
				src: "1f4b8.png",
				dict: ["💸"]
			}, {
				name: "CHART WITH UPWARDS TREND AND YEN SIGN",
				id: "chart_with_upwards_trend_and_yen_sign",
				src: "1f4b9.png",
				dict: ["💹", ""]
			}, {
				name: "SEAT",
				id: "seat",
				src: "1f4ba.png",
				dict: ["💺", ""]
			}, {
				name: "PERSONAL COMPUTER",
				id: "personal_computer",
				src: "1f4bb.png",
				dict: ["💻", ""]
			}, {
				name: "BRIEFCASE",
				id: "briefcase",
				src: "1f4bc.png",
				dict: ["💼", ""]
			}, {
				name: "MINIDISC",
				id: "minidisc",
				src: "1f4bd.png",
				dict: ["💽", ""]
			}, {
				name: "FLOPPY DISK",
				id: "floppy_disk",
				src: "1f4be.png",
				dict: ["💾"]
			}, {
				name: "OPTICAL DISC",
				id: "optical_disc",
				src: "1f4bf.png",
				dict: ["💿", ""]
			}, {
				name: "DVD",
				id: "dvd",
				src: "1f4c0.png",
				dict: ["📀", ""]
			}, {
				name: "FILE FOLDER",
				id: "file_folder",
				src: "1f4c1.png",
				dict: ["📁"]
			}, {
				name: "OPEN FILE FOLDER",
				id: "open_file_folder",
				src: "1f4c2.png",
				dict: ["📂"]
			}, {
				name: "PAGE WITH CURL",
				id: "page_with_curl",
				src: "1f4c3.png",
				dict: ["📃"]
			}, {
				name: "PAGE FACING UP",
				id: "page_facing_up",
				src: "1f4c4.png",
				dict: ["📄"]
			}, {
				name: "CALENDAR",
				id: "calendar",
				src: "1f4c5.png",
				dict: ["📅"]
			}, {
				name: "TEAR-OFF CALENDAR",
				id: "tear-off_calendar",
				src: "1f4c6.png",
				dict: ["📆"]
			}, {
				name: "CARD INDEX",
				id: "card_index",
				src: "1f4c7.png",
				dict: ["📇"]
			}, {
				name: "CHART WITH UPWARDS TREND",
				id: "chart_with_upwards_trend",
				src: "1f4c8.png",
				dict: ["📈"]
			}, {
				name: "CHART WITH DOWNWARDS TREND",
				id: "chart_with_downwards_trend",
				src: "1f4c9.png",
				dict: ["📉"]
			}, {
				name: "BAR CHART",
				id: "bar_chart",
				src: "1f4ca.png",
				dict: ["📊"]
			}, {
				name: "CLIPBOARD",
				id: "clipboard",
				src: "1f4cb.png",
				dict: ["📋"]
			}, {
				name: "PUSHPIN",
				id: "pushpin",
				src: "1f4cc.png",
				dict: ["📌"]
			}, {
				name: "ROUND PUSHPIN",
				id: "round_pushpin",
				src: "1f4cd.png",
				dict: ["📍"]
			}, {
				name: "PAPERCLIP",
				id: "paperclip",
				src: "1f4ce.png",
				dict: ["📎"]
			}, {
				name: "STRAIGHT RULER",
				id: "straight_ruler",
				src: "1f4cf.png",
				dict: ["📏"]
			}, {
				name: "TRIANGULAR RULER",
				id: "triangular_ruler",
				src: "1f4d0.png",
				dict: ["📐"]
			}, {
				name: "BOOKMARK TABS",
				id: "bookmark_tabs",
				src: "1f4d1.png",
				dict: ["📑"]
			}, {
				name: "LEDGER",
				id: "ledger",
				src: "1f4d2.png",
				dict: ["📒"]
			}, {
				name: "NOTEBOOK",
				id: "notebook",
				src: "1f4d3.png",
				dict: ["📓"]
			}, {
				name: "NOTEBOOK WITH DECORATIVE COVER",
				id: "notebook_with_decorative_cover",
				src: "1f4d4.png",
				dict: ["📔"]
			}, {
				name: "CLOSED BOOK",
				id: "closed_book",
				src: "1f4d5.png",
				dict: ["📕"]
			}, {
				name: "OPEN BOOK",
				id: "open_book",
				src: "1f4d6.png",
				dict: ["📖", ""]
			}, {
				name: "GREEN BOOK",
				id: "green_book",
				src: "1f4d7.png",
				dict: ["📗"]
			}, {
				name: "BLUE BOOK",
				id: "blue_book",
				src: "1f4d8.png",
				dict: ["📘"]
			}, {
				name: "ORANGE BOOK",
				id: "orange_book",
				src: "1f4d9.png",
				dict: ["📙"]
			}, {
				name: "BOOKS",
				id: "books",
				src: "1f4da.png",
				dict: ["📚"]
			}, {
				name: "NAME BADGE",
				id: "name_badge",
				src: "1f4db.png",
				dict: ["📛"]
			}, {
				name: "SCROLL",
				id: "scroll",
				src: "1f4dc.png",
				dict: ["📜"]
			}, {
				name: "MEMO",
				id: "memo",
				src: "1f4dd.png",
				dict: ["📝", ""]
			}, {
				name: "TELEPHONE RECEIVER",
				id: "telephone_receiver",
				src: "1f4de.png",
				dict: ["📞"]
			}, {
				name: "PAGER",
				id: "pager",
				src: "1f4df.png",
				dict: ["📟"]
			}, {
				name: "FAX MACHINE",
				id: "fax_machine",
				src: "1f4e0.png",
				dict: ["📠", ""]
			}, {
				name: "SATELLITE ANTENNA",
				id: "satellite_antenna",
				src: "1f4e1.png",
				dict: ["📡", ""]
			}, {
				name: "PUBLIC ADDRESS LOUDSPEAKER",
				id: "public_address_loudspeaker",
				src: "1f4e2.png",
				dict: ["📢", ""]
			}, {
				name: "CHEERING MEGAPHONE",
				id: "cheering_megaphone",
				src: "1f4e3.png",
				dict: ["📣", ""]
			}, {
				name: "OUTBOX TRAY",
				id: "outbox_tray",
				src: "1f4e4.png",
				dict: ["📤"]
			}, {
				name: "INBOX TRAY",
				id: "inbox_tray",
				src: "1f4e5.png",
				dict: ["📥"]
			}, {
				name: "PACKAGE",
				id: "package",
				src: "1f4e6.png",
				dict: ["📦"]
			}, {
				name: "E-MAIL SYMBOL",
				id: "e-mail_symbol",
				src: "1f4e7.png",
				dict: ["📧"]
			}, {
				name: "INCOMING ENVELOPE",
				id: "incoming_envelope",
				src: "1f4e8.png",
				dict: ["📨"]
			}, {
				name: "ENVELOPE WITH DOWNWARDS ARROW ABOVE",
				id: "envelope_with_downwards_arrow_above",
				src: "1f4e9.png",
				dict: ["📩", ""]
			}, {
				name: "CLOSED MAILBOX WITH LOWERED FLAG",
				id: "closed_mailbox_with_lowered_flag",
				src: "1f4ea.png",
				dict: ["📪"]
			}, {
				name: "CLOSED MAILBOX WITH RAISED FLAG",
				id: "closed_mailbox_with_raised_flag",
				src: "1f4eb.png",
				dict: ["📫", ""]
			}, {
				name: "OPEN MAILBOX WITH RAISED FLAG",
				id: "open_mailbox_with_raised_flag",
				src: "1f4ec.png",
				dict: ["📬"]
			}, {
				name: "OPEN MAILBOX WITH LOWERED FLAG",
				id: "open_mailbox_with_lowered_flag",
				src: "1f4ed.png",
				dict: ["📭"]
			}, {
				name: "POSTBOX",
				id: "postbox",
				src: "1f4ee.png",
				dict: ["📮", ""]
			}, {
				name: "POSTAL HORN",
				id: "postal_horn",
				src: "1f4ef.png",
				dict: ["📯"]
			}, {
				name: "NEWSPAPER",
				id: "newspaper",
				src: "1f4f0.png",
				dict: ["📰"]
			}, {
				name: "MOBILE PHONE",
				id: "mobile_phone",
				src: "1f4f1.png",
				dict: ["📱", ""]
			}, {
				name: "MOBILE PHONE WITH RIGHTWARDS ARROW",
				id: "mobile_phone_with_rightwards_arrow",
				src: "1f4f2.png",
				dict: ["📲", ""]
			}, {
				name: "VIBRATION MODE",
				id: "vibration_mode",
				src: "1f4f3.png",
				dict: ["📳", ""]
			}, {
				name: "MOBILE PHONE OFF",
				id: "mobile_phone_off",
				src: "1f4f4.png",
				dict: ["📴", ""]
			}, {
				name: "NO MOBILE PHONES",
				id: "no_mobile_phones",
				src: "1f4f5.png",
				dict: ["📵"]
			}, {
				name: "ANTENNA WITH BARS",
				id: "antenna_with_bars",
				src: "1f4f6.png",
				dict: ["📶", ""]
			}, {
				name: "CAMERA",
				id: "camera",
				src: "1f4f7.png",
				dict: ["📷", ""]
			}, {
				name: "VIDEO CAMERA",
				id: "video_camera",
				src: "1f4f9.png",
				dict: ["📹"]
			}, {
				name: "TELEVISION",
				id: "television",
				src: "1f4fa.png",
				dict: ["📺", ""]
			}, {
				name: "RADIO",
				id: "radio",
				src: "1f4fb.png",
				dict: ["📻", ""]
			}, {
				name: "VIDEOCASSETTE",
				id: "videocassette",
				src: "1f4fc.png",
				dict: ["📼", ""]
			}, {
				name: "TWISTED RIGHTWARDS ARROWS",
				id: "twisted_rightwards_arrows",
				src: "1f500.png",
				dict: ["🔀"]
			}, {
				name: "CLOCKWISE RIGHTWARDS AND LEFTWARDS OPEN CIRCLE ARROWS",
				id: "clockwise_rightwards_and_leftwards_open_circle_arrows",
				src: "1f501.png",
				dict: ["🔁"]
			}, {
				name: "CLOCKWISE RIGHTWARDS AND LEFTWARDS OPEN CIRCLE ARROWS WITH CIRCLED ONE OVERLAY",
				id: "clockwise_rightwards_and_leftwards_open_circle_arrows_with_circled_one_overlay",
				src: "1f502.png",
				dict: ["🔂"]
			}, {
				name: "CLOCKWISE DOWNWARDS AND UPWARDS OPEN CIRCLE ARROWS",
				id: "clockwise_downwards_and_upwards_open_circle_arrows",
				src: "1f503.png",
				dict: ["🔃"]
			}, {
				name: "ANTICLOCKWISE DOWNWARDS AND UPWARDS OPEN CIRCLE ARROWS",
				id: "anticlockwise_downwards_and_upwards_open_circle_arrows",
				src: "1f504.png",
				dict: ["🔄"]
			}, {
				name: "LOW BRIGHTNESS SYMBOLS",
				id: "low_brightness_symbols",
				src: "1f505.png",
				dict: ["🔅"]
			}, {
				name: "HIGH BRIGHTNESS SYMBOLS",
				id: "high_brightness_symbols",
				src: "1f506.png",
				dict: ["🔆"]
			}, {
				name: "SPEAKER WITH CANCELLATION STROKE",
				id: "speaker_with_cancellation_stroke",
				src: "1f507.png",
				dict: ["🔇"]
			}, {
				name: "SPEAKER",
				id: "speaker",
				src: "1f508.png",
				dict: ["🔈"]
			}, {
				name: "SPEAKER WITH ONE SOUND WAVE",
				id: "speaker_with_one_sound_wave",
				src: "1f509.png",
				dict: ["🔉"]
			}, {
				name: "SPEAKER WITH THREE SOUND WAVES",
				id: "speaker_with_three_sound_waves",
				src: "1f50a.png",
				dict: ["🔊", ""]
			}, {
				name: "BATTERY",
				id: "battery",
				src: "1f50b.png",
				dict: ["🔋"]
			}, {
				name: "ELECTRIC PLUG",
				id: "electric_plug",
				src: "1f50c.png",
				dict: ["🔌"]
			}, {
				name: "LEFT-POINTING MAGNIFYING GLASS",
				id: "left-pointing_magnifying_glass",
				src: "1f50d.png",
				dict: ["🔍", ""]
			}, {
				name: "RIGHT POINTING MAGNIFYING GLASS",
				id: "right_pointing_magnifying_glass",
				src: "1f50e.png",
				dict: ["🔎"]
			}, {
				name: "LOCK WITH INK PEN",
				id: "lock_with_ink_pen",
				src: "1f50f.png",
				dict: ["🔏"]
			}, {
				name: "CLOSED LOCK WITH KEY",
				id: "closed_lock_with_key",
				src: "1f510.png",
				dict: ["🔐"]
			}, {
				name: "KEY",
				id: "key",
				src: "1f511.png",
				dict: ["🔑", ""]
			}, {
				name: "LOCK",
				id: "lock",
				src: "1f512.png",
				dict: ["🔒", ""]
			}, {
				name: "OPEN LOCK",
				id: "open_lock",
				src: "1f513.png",
				dict: ["🔓", ""]
			}, {
				name: "BELL",
				id: "bell",
				src: "1f514.png",
				dict: ["🔔", ""]
			}, {
				name: "BELL WITH CANCELLATION STROKE",
				id: "bell_with_cancellation_stroke",
				src: "1f515.png",
				dict: ["🔕"]
			}, {
				name: "BOOKMARK",
				id: "bookmark",
				src: "1f516.png",
				dict: ["🔖"]
			}, {
				name: "LINK SYMBOL",
				id: "link_symbol",
				src: "1f517.png",
				dict: ["🔗"]
			}, {
				name: "RADIO BUTTON",
				id: "radio_button",
				src: "1f518.png",
				dict: ["🔘"]
			}, {
				name: "BACK WITH LEFTWARDS ARROW ABOVE",
				id: "back_with_leftwards_arrow_above",
				src: "1f519.png",
				dict: ["🔙"]
			}, {
				name: "END WITH LEFTWARDS ARROW ABOVE",
				id: "end_with_leftwards_arrow_above",
				src: "1f51a.png",
				dict: ["🔚"]
			}, {
				name: "ON WITH EXCLAMATION MARK WITH LEFT RIGHT ARROW ABOVE",
				id: "on_with_exclamation_mark_with_left_right_arrow_above",
				src: "1f51b.png",
				dict: ["🔛"]
			}, {
				name: "SOON WITH RIGHTWARDS ARROW ABOVE",
				id: "soon_with_rightwards_arrow_above",
				src: "1f51c.png",
				dict: ["🔜"]
			}, {
				name: "TOP WITH UPWARDS ARROW ABOVE",
				id: "top_with_upwards_arrow_above",
				src: "1f51d.png",
				dict: ["🔝", ""]
			}, {
				name: "NO ONE UNDER EIGHTEEN SYMBOL",
				id: "no_one_under_eighteen_symbol",
				src: "1f51e.png",
				dict: ["🔞", ""]
			}, {
				name: "KEYCAP TEN",
				id: "keycap_ten",
				src: "1f51f.png",
				dict: ["🔟"]
			}, {
				name: "INPUT SYMBOL FOR LATIN CAPITAL LETTERS",
				id: "input_symbol_for_latin_capital_letters",
				src: "1f520.png",
				dict: ["🔠"]
			}, {
				name: "INPUT SYMBOL FOR LATIN SMALL LETTERS",
				id: "input_symbol_for_latin_small_letters",
				src: "1f521.png",
				dict: ["🔡"]
			}, {
				name: "INPUT SYMBOL FOR NUMBERS",
				id: "input_symbol_for_numbers",
				src: "1f522.png",
				dict: ["🔢"]
			}, {
				name: "INPUT SYMBOL FOR SYMBOLS",
				id: "input_symbol_for_symbols",
				src: "1f523.png",
				dict: ["🔣"]
			}, {
				name: "INPUT SYMBOL FOR LATIN LETTERS",
				id: "input_symbol_for_latin_letters",
				src: "1f524.png",
				dict: ["🔤"]
			}, {
				name: "FIRE",
				id: "fire",
				src: "1f525.png",
				dict: ["🔥", ""]
			}, {
				name: "ELECTRIC TORCH",
				id: "electric_torch",
				src: "1f526.png",
				dict: ["🔦"]
			}, {
				name: "WRENCH",
				id: "wrench",
				src: "1f527.png",
				dict: ["🔧"]
			}, {
				name: "HAMMER",
				id: "hammer",
				src: "1f528.png",
				dict: ["🔨", ""]
			}, {
				name: "NUT AND BOLT",
				id: "nut_and_bolt",
				src: "1f529.png",
				dict: ["🔩"]
			}, {
				name: "HOCHO",
				id: "hocho",
				src: "1f52a.png",
				dict: ["🔪"]
			}, {
				name: "PISTOL",
				id: "pistol",
				src: "1f52b.png",
				dict: ["🔫", ""]
			}, {
				name: "MICROSCOPE",
				id: "microscope",
				src: "1f52c.png",
				dict: ["🔬"]
			}, {
				name: "TELESCOPE",
				id: "telescope",
				src: "1f52d.png",
				dict: ["🔭"]
			}, {
				name: "CRYSTAL BALL",
				id: "crystal_ball",
				src: "1f52e.png",
				dict: ["🔮"]
			}, {
				name: "SIX POINTED STAR WITH MIDDLE DOT",
				id: "six_pointed_star_with_middle_dot",
				src: "1f52f.png",
				dict: ["🔯", ""]
			}, {
				name: "JAPANESE SYMBOL FOR BEGINNER",
				id: "japanese_symbol_for_beginner",
				src: "1f530.png",
				dict: ["🔰", ""]
			}, {
				name: "TRIDENT EMBLEM",
				id: "trident_emblem",
				src: "1f531.png",
				dict: ["🔱", ""]
			}, {
				name: "BLACK SQUARE BUTTON",
				id: "black_square_button",
				src: "1f532.png",
				dict: ["🔲", ""]
			}, {
				name: "WHITE SQUARE BUTTON",
				id: "white_square_button",
				src: "1f533.png",
				dict: ["🔳", ""]
			}, {
				name: "LARGE RED CIRCLE",
				id: "large_red_circle",
				src: "1f534.png",
				dict: ["🔴", ""]
			}, {
				name: "LARGE BLUE CIRCLE",
				id: "large_blue_circle",
				src: "1f535.png",
				dict: ["🔵"]
			}, {
				name: "LARGE ORANGE DIAMOND",
				id: "large_orange_diamond",
				src: "1f536.png",
				dict: ["🔶"]
			}, {
				name: "LARGE BLUE DIAMOND",
				id: "large_blue_diamond",
				src: "1f537.png",
				dict: ["🔷"]
			}, {
				name: "SMALL ORANGE DIAMOND",
				id: "small_orange_diamond",
				src: "1f538.png",
				dict: ["🔸"]
			}, {
				name: "SMALL BLUE DIAMOND",
				id: "small_blue_diamond",
				src: "1f539.png",
				dict: ["🔹"]
			}, {
				name: "UP-POINTING RED TRIANGLE",
				id: "up-pointing_red_triangle",
				src: "1f53a.png",
				dict: ["🔺"]
			}, {
				name: "DOWN-POINTING RED TRIANGLE",
				id: "down-pointing_red_triangle",
				src: "1f53b.png",
				dict: ["🔻"]
			}, {
				name: "UP-POINTING SMALL RED TRIANGLE",
				id: "up-pointing_small_red_triangle",
				src: "1f53c.png",
				dict: ["🔼"]
			}, {
				name: "DOWN-POINTING SMALL RED TRIANGLE",
				id: "down-pointing_small_red_triangle",
				src: "1f53d.png",
				dict: ["🔽"]
			}, {
				name: "CLOCK FACE ONE OCLOCK",
				id: "clock_face_one_oclock",
				src: "1f550.png",
				dict: ["🕐", ""]
			}, {
				name: "CLOCK FACE TWO OCLOCK",
				id: "clock_face_two_oclock",
				src: "1f551.png",
				dict: ["🕑", ""]
			}, {
				name: "CLOCK FACE THREE OCLOCK",
				id: "clock_face_three_oclock",
				src: "1f552.png",
				dict: ["🕒", ""]
			}, {
				name: "CLOCK FACE FOUR OCLOCK",
				id: "clock_face_four_oclock",
				src: "1f553.png",
				dict: ["🕓", ""]
			}, {
				name: "CLOCK FACE FIVE OCLOCK",
				id: "clock_face_five_oclock",
				src: "1f554.png",
				dict: ["🕔", ""]
			}, {
				name: "CLOCK FACE SIX OCLOCK",
				id: "clock_face_six_oclock",
				src: "1f555.png",
				dict: ["🕕", ""]
			}, {
				name: "CLOCK FACE SEVEN OCLOCK",
				id: "clock_face_seven_oclock",
				src: "1f556.png",
				dict: ["🕖", ""]
			}, {
				name: "CLOCK FACE EIGHT OCLOCK",
				id: "clock_face_eight_oclock",
				src: "1f557.png",
				dict: ["🕗", ""]
			}, {
				name: "CLOCK FACE NINE OCLOCK",
				id: "clock_face_nine_oclock",
				src: "1f558.png",
				dict: ["🕘", ""]
			}, {
				name: "CLOCK FACE TEN OCLOCK",
				id: "clock_face_ten_oclock",
				src: "1f559.png",
				dict: ["🕙", ""]
			}, {
				name: "CLOCK FACE ELEVEN OCLOCK",
				id: "clock_face_eleven_oclock",
				src: "1f55a.png",
				dict: ["🕚", ""]
			}, {
				name: "CLOCK FACE TWELVE OCLOCK",
				id: "clock_face_twelve_oclock",
				src: "1f55b.png",
				dict: ["🕛", ""]
			}, {
				name: "CLOCK FACE ONE-THIRTY",
				id: "clock_face_one-thirty",
				src: "1f55c.png",
				dict: ["🕜"]
			}, {
				name: "CLOCK FACE TWO-THIRTY",
				id: "clock_face_two-thirty",
				src: "1f55d.png",
				dict: ["🕝"]
			}, {
				name: "CLOCK FACE THREE-THIRTY",
				id: "clock_face_three-thirty",
				src: "1f55e.png",
				dict: ["🕞"]
			}, {
				name: "CLOCK FACE FOUR-THIRTY",
				id: "clock_face_four-thirty",
				src: "1f55f.png",
				dict: ["🕟"]
			}, {
				name: "CLOCK FACE FIVE-THIRTY",
				id: "clock_face_five-thirty",
				src: "1f560.png",
				dict: ["🕠"]
			}, {
				name: "CLOCK FACE SIX-THIRTY",
				id: "clock_face_six-thirty",
				src: "1f561.png",
				dict: ["🕡"]
			}, {
				name: "CLOCK FACE SEVEN-THIRTY",
				id: "clock_face_seven-thirty",
				src: "1f562.png",
				dict: ["🕢"]
			}, {
				name: "CLOCK FACE EIGHT-THIRTY",
				id: "clock_face_eight-thirty",
				src: "1f563.png",
				dict: ["🕣"]
			}, {
				name: "CLOCK FACE NINE-THIRTY",
				id: "clock_face_nine-thirty",
				src: "1f564.png",
				dict: ["🕤"]
			}, {
				name: "CLOCK FACE TEN-THIRTY",
				id: "clock_face_ten-thirty",
				src: "1f565.png",
				dict: ["🕥"]
			}, {
				name: "CLOCK FACE ELEVEN-THIRTY",
				id: "clock_face_eleven-thirty",
				src: "1f566.png",
				dict: ["🕦"]
			}, {
				name: "CLOCK FACE TWELVE-THIRTY",
				id: "clock_face_twelve-thirty",
				src: "1f567.png",
				dict: ["🕧"]
			}, {
				name: "MOUNT FUJI",
				id: "mount_fuji",
				src: "1f5fb.png",
				dict: ["🗻", ""]
			}, {
				name: "TOKYO TOWER",
				id: "tokyo_tower",
				src: "1f5fc.png",
				dict: ["🗼", ""]
			}, {
				name: "STATUE OF LIBERTY",
				id: "statue_of_liberty",
				src: "1f5fd.png",
				dict: ["🗽", ""]
			}, {
				name: "SILHOUETTE OF JAPAN",
				id: "silhouette_of_japan",
				src: "1f5fe.png",
				dict: ["🗾"]
			}, {
				name: "MOYAI",
				id: "moyai",
				src: "1f5ff.png",
				dict: ["🗿"]
			}, {
				name: "GRINNING FACE",
				id: "grinning_face",
				src: "1f600.png",
				dict: ["😀"]
			}, {
				name: "GRINNING FACE WITH SMILING EYES",
				id: "grinning_face_with_smiling_eyes",
				src: "1f601.png",
				dict: ["😁", ""]
			}, {
				name: "FACE WITH TEARS OF JOY",
				id: "face_with_tears_of_joy",
				src: "1f602.png",
				dict: ["😂", ""]
			}, {
				name: "SMILING FACE WITH OPEN MOUTH",
				id: "smiling_face_with_open_mouth",
				src: "1f603.png",
				dict: ["😃", ""]
			}, {
				name: "SMILING FACE WITH OPEN MOUTH AND SMILING EYES",
				id: "smiling_face_with_open_mouth_and_smiling_eyes",
				src: "1f604.png",
				dict: ["😄", ""]
			}, {
				name: "SMILING FACE WITH OPEN MOUTH AND COLD SWEAT",
				id: "smiling_face_with_open_mouth_and_cold_sweat",
				src: "1f605.png",
				dict: ["😅"]
			}, {
				name: "SMILING FACE WITH OPEN MOUTH AND TIGHTLY-CLOSED EYES",
				id: "smiling_face_with_open_mouth_and_tightly-closed_eyes",
				src: "1f606.png",
				dict: ["😆"]
			}, {
				name: "SMILING FACE WITH HALO",
				id: "smiling_face_with_halo",
				src: "1f607.png",
				dict: ["😇"]
			}, {
				name: "SMILING FACE WITH HORNS",
				id: "smiling_face_with_horns",
				src: "1f608.png",
				dict: ["😈"]
			}, {
				name: "WINKING FACE",
				id: "winking_face",
				src: "1f609.png",
				dict: ["😉", ""]
			}, {
				name: "SMILING FACE WITH SMILING EYES",
				id: "smiling_face_with_smiling_eyes",
				src: "1f60a.png",
				dict: ["😊", ""]
			}, {
				name: "FACE SAVOURING DELICIOUS FOOD",
				id: "face_savouring_delicious_food",
				src: "1f60b.png",
				dict: ["😋"]
			}, {
				name: "RELIEVED FACE",
				id: "relieved_face",
				src: "1f60c.png",
				dict: ["😌", ""]
			}, {
				name: "SMILING FACE WITH HEART-SHAPED EYES",
				id: "smiling_face_with_heart-shaped_eyes",
				src: "1f60d.png",
				dict: ["😍", ""]
			}, {
				name: "SMILING FACE WITH SUNGLASSES",
				id: "smiling_face_with_sunglasses",
				src: "1f60e.png",
				dict: ["😎"]
			}, {
				name: "SMIRKING FACE",
				id: "smirking_face",
				src: "1f60f.png",
				dict: ["😏", ""]
			}, {
				name: "NEUTRAL FACE",
				id: "neutral_face",
				src: "1f610.png",
				dict: ["😐"]
			}, {
				name: "EXPRESSIONLESS FACE",
				id: "expressionless_face",
				src: "1f611.png",
				dict: ["😑"]
			}, {
				name: "UNAMUSED FACE",
				id: "unamused_face",
				src: "1f612.png",
				dict: ["😒", ""]
			}, {
				name: "FACE WITH COLD SWEAT",
				id: "face_with_cold_sweat",
				src: "1f613.png",
				dict: ["😓", ""]
			}, {
				name: "PENSIVE FACE",
				id: "pensive_face",
				src: "1f614.png",
				dict: ["😔", ""]
			}, {
				name: "CONFUSED FACE",
				id: "confused_face",
				src: "1f615.png",
				dict: ["😕"]
			}, {
				name: "CONFOUNDED FACE",
				id: "confounded_face",
				src: "1f616.png",
				dict: ["😖", ""]
			}, {
				name: "KISSING FACE",
				id: "kissing_face",
				src: "1f617.png",
				dict: ["😗"]
			}, {
				name: "FACE THROWING A KISS",
				id: "face_throwing_a_kiss",
				src: "1f618.png",
				dict: ["😘", ""]
			}, {
				name: "KISSING FACE WITH SMILING EYES",
				id: "kissing_face_with_smiling_eyes",
				src: "1f619.png",
				dict: ["😙"]
			}, {
				name: "KISSING FACE WITH CLOSED EYES",
				id: "kissing_face_with_closed_eyes",
				src: "1f61a.png",
				dict: ["😚", ""]
			}, {
				name: "FACE WITH STUCK-OUT TONGUE",
				id: "face_with_stuck-out_tongue",
				src: "1f61b.png",
				dict: ["😛"]
			}, {
				name: "FACE WITH STUCK-OUT TONGUE AND WINKING EYE",
				id: "face_with_stuck-out_tongue_and_winking_eye",
				src: "1f61c.png",
				dict: ["😜", ""]
			}, {
				name: "FACE WITH STUCK-OUT TONGUE AND TIGHTLY-CLOSED EYES",
				id: "face_with_stuck-out_tongue_and_tightly-closed_eyes",
				src: "1f61d.png",
				dict: ["😝", ""]
			}, {
				name: "DISAPPOINTED FACE",
				id: "disappointed_face",
				src: "1f61e.png",
				dict: ["😞", ""]
			}, {
				name: "WORRIED FACE",
				id: "worried_face",
				src: "1f61f.png",
				dict: ["😟"]
			}, {
				name: "ANGRY FACE",
				id: "angry_face",
				src: "1f620.png",
				dict: ["😠", ""]
			}, {
				name: "POUTING FACE",
				id: "pouting_face",
				src: "1f621.png",
				dict: ["😡", ""]
			}, {
				name: "CRYING FACE",
				id: "crying_face",
				src: "1f622.png",
				dict: ["😢", ""]
			}, {
				name: "PERSEVERING FACE",
				id: "persevering_face",
				src: "1f623.png",
				dict: ["😣", ""]
			}, {
				name: "FACE WITH LOOK OF TRIUMPH",
				id: "face_with_look_of_triumph",
				src: "1f624.png",
				dict: ["😤"]
			}, {
				name: "DISAPPOINTED BUT RELIEVED FACE",
				id: "disappointed_but_relieved_face",
				src: "1f625.png",
				dict: ["😥", ""]
			}, {
				name: "FROWNING FACE WITH OPEN MOUTH",
				id: "frowning_face_with_open_mouth",
				src: "1f626.png",
				dict: ["😦"]
			}, {
				name: "ANGUISHED FACE",
				id: "anguished_face",
				src: "1f627.png",
				dict: ["😧"]
			}, {
				name: "FEARFUL FACE",
				id: "fearful_face",
				src: "1f628.png",
				dict: ["😨", ""]
			}, {
				name: "WEARY FACE",
				id: "weary_face",
				src: "1f629.png",
				dict: ["😩"]
			}, {
				name: "SLEEPY FACE",
				id: "sleepy_face",
				src: "1f62a.png",
				dict: ["😪", ""]
			}, {
				name: "TIRED FACE",
				id: "tired_face",
				src: "1f62b.png",
				dict: ["😫"]
			}, {
				name: "GRIMACING FACE",
				id: "grimacing_face",
				src: "1f62c.png",
				dict: ["😬"]
			}, {
				name: "LOUDLY CRYING FACE",
				id: "loudly_crying_face",
				src: "1f62d.png",
				dict: ["😭", ""]
			}, {
				name: "FACE WITH OPEN MOUTH",
				id: "face_with_open_mouth",
				src: "1f62e.png",
				dict: ["😮"]
			}, {
				name: "HUSHED FACE",
				id: "hushed_face",
				src: "1f62f.png",
				dict: ["😯"]
			}, {
				name: "FACE WITH OPEN MOUTH AND COLD SWEAT",
				id: "face_with_open_mouth_and_cold_sweat",
				src: "1f630.png",
				dict: ["😰", ""]
			}, {
				name: "FACE SCREAMING IN FEAR",
				id: "face_screaming_in_fear",
				src: "1f631.png",
				dict: ["😱", ""]
			}, {
				name: "ASTONISHED FACE",
				id: "astonished_face",
				src: "1f632.png",
				dict: ["😲", ""]
			}, {
				name: "FLUSHED FACE",
				id: "flushed_face",
				src: "1f633.png",
				dict: ["😳", ""]
			}, {
				name: "SLEEPING FACE",
				id: "sleeping_face",
				src: "1f634.png",
				dict: ["😴"]
			}, {
				name: "DIZZY FACE",
				id: "dizzy_face",
				src: "1f635.png",
				dict: ["😵"]
			}, {
				name: "FACE WITHOUT MOUTH",
				id: "face_without_mouth",
				src: "1f636.png",
				dict: ["😶"]
			}, {
				name: "FACE WITH MEDICAL MASK",
				id: "face_with_medical_mask",
				src: "1f637.png",
				dict: ["😷", ""]
			}, {
				name: "GRINNING CAT FACE WITH SMILING EYES",
				id: "grinning_cat_face_with_smiling_eyes",
				src: "1f638.png",
				dict: ["😸"]
			}, {
				name: "CAT FACE WITH TEARS OF JOY",
				id: "cat_face_with_tears_of_joy",
				src: "1f639.png",
				dict: ["😹"]
			}, {
				name: "SMILING CAT FACE WITH OPEN MOUTH",
				id: "smiling_cat_face_with_open_mouth",
				src: "1f63a.png",
				dict: ["😺"]
			}, {
				name: "SMILING CAT FACE WITH HEART-SHAPED EYES",
				id: "smiling_cat_face_with_heart-shaped_eyes",
				src: "1f63b.png",
				dict: ["😻"]
			}, {
				name: "CAT FACE WITH WRY SMILE",
				id: "cat_face_with_wry_smile",
				src: "1f63c.png",
				dict: ["😼"]
			}, {
				name: "KISSING CAT FACE WITH CLOSED EYES",
				id: "kissing_cat_face_with_closed_eyes",
				src: "1f63d.png",
				dict: ["😽"]
			}, {
				name: "POUTING CAT FACE",
				id: "pouting_cat_face",
				src: "1f63e.png",
				dict: ["😾"]
			}, {
				name: "CRYING CAT FACE",
				id: "crying_cat_face",
				src: "1f63f.png",
				dict: ["😿"]
			}, {
				name: "WEARY CAT FACE",
				id: "weary_cat_face",
				src: "1f640.png",
				dict: ["🙀"]
			}, {
				name: "FACE WITH NO GOOD GESTURE",
				id: "face_with_no_good_gesture",
				src: "1f645.png",
				dict: ["🙅", ""]
			}, {
				name: "FACE WITH OK GESTURE",
				id: "face_with_ok_gesture",
				src: "1f646.png",
				dict: ["🙆", ""]
			}, {
				name: "PERSON BOWING DEEPLY",
				id: "person_bowing_deeply",
				src: "1f647.png",
				dict: ["🙇", ""]
			}, {
				name: "SEE-NO-EVIL MONKEY",
				id: "see-no-evil_monkey",
				src: "1f648.png",
				dict: ["🙈"]
			}, {
				name: "HEAR-NO-EVIL MONKEY",
				id: "hear-no-evil_monkey",
				src: "1f649.png",
				dict: ["🙉"]
			}, {
				name: "SPEAK-NO-EVIL MONKEY",
				id: "speak-no-evil_monkey",
				src: "1f64a.png",
				dict: ["🙊"]
			}, {
				name: "HAPPY PERSON RAISING ONE HAND",
				id: "happy_person_raising_one_hand",
				src: "1f64b.png",
				dict: ["🙋"]
			}, {
				name: "PERSON RAISING BOTH HANDS IN CELEBRATION",
				id: "person_raising_both_hands_in_celebration",
				src: "1f64c.png",
				dict: ["🙌", ""]
			}, {
				name: "PERSON FROWNING",
				id: "person_frowning",
				src: "1f64d.png",
				dict: ["🙍"]
			}, {
				name: "PERSON WITH POUTING FACE",
				id: "person_with_pouting_face",
				src: "1f64e.png",
				dict: ["🙎"]
			}, {
				name: "PERSON WITH FOLDED HANDS",
				id: "person_with_folded_hands",
				src: "1f64f.png",
				dict: ["🙏", ""]
			}, {
				name: "ROCKET",
				id: "rocket",
				src: "1f680.png",
				dict: ["🚀", ""]
			}, {
				name: "HELICOPTER",
				id: "helicopter",
				src: "1f681.png",
				dict: ["🚁"]
			}, {
				name: "STEAM LOCOMOTIVE",
				id: "steam_locomotive",
				src: "1f682.png",
				dict: ["🚂"]
			}, {
				name: "RAILWAY CAR",
				id: "railway_car",
				src: "1f683.png",
				dict: ["🚃", ""]
			}, {
				name: "HIGH-SPEED TRAIN",
				id: "high-speed_train",
				src: "1f684.png",
				dict: ["🚄", ""]
			}, {
				name: "HIGH-SPEED TRAIN WITH BULLET NOSE",
				id: "high-speed_train_with_bullet_nose",
				src: "1f685.png",
				dict: ["🚅", ""]
			}, {
				name: "TRAIN",
				id: "train",
				src: "1f686.png",
				dict: ["🚆"]
			}, {
				name: "METRO",
				id: "metro",
				src: "1f687.png",
				dict: ["🚇", ""]
			}, {
				name: "LIGHT RAIL",
				id: "light_rail",
				src: "1f688.png",
				dict: ["🚈"]
			}, {
				name: "STATION",
				id: "station",
				src: "1f689.png",
				dict: ["🚉", ""]
			}, {
				name: "TRAM",
				id: "tram",
				src: "1f68a.png",
				dict: ["🚊"]
			}, {
				name: "TRAM CAR",
				id: "tram_car",
				src: "1f68b.png",
				dict: ["🚋"]
			}, {
				name: "BUS",
				id: "bus",
				src: "1f68c.png",
				dict: ["🚌", ""]
			}, {
				name: "ONCOMING BUS",
				id: "oncoming_bus",
				src: "1f68d.png",
				dict: ["🚍"]
			}, {
				name: "TROLLEYBUS",
				id: "trolleybus",
				src: "1f68e.png",
				dict: ["🚎"]
			}, {
				name: "BUS STOP",
				id: "bus_stop",
				src: "1f68f.png",
				dict: ["🚏", ""]
			}, {
				name: "MINIBUS",
				id: "minibus",
				src: "1f690.png",
				dict: ["🚐"]
			}, {
				name: "AMBULANCE",
				id: "ambulance",
				src: "1f691.png",
				dict: ["🚑", ""]
			}, {
				name: "FIRE ENGINE",
				id: "fire_engine",
				src: "1f692.png",
				dict: ["🚒", ""]
			}, {
				name: "POLICE CAR",
				id: "police_car",
				src: "1f693.png",
				dict: ["🚓", ""]
			}, {
				name: "ONCOMING POLICE CAR",
				id: "oncoming_police_car",
				src: "1f694.png",
				dict: ["🚔"]
			}, {
				name: "TAXI",
				id: "taxi",
				src: "1f695.png",
				dict: ["🚕", ""]
			}, {
				name: "ONCOMING TAXI",
				id: "oncoming_taxi",
				src: "1f696.png",
				dict: ["🚖"]
			}, {
				name: "AUTOMOBILE",
				id: "automobile",
				src: "1f697.png",
				dict: ["🚗", ""]
			}, {
				name: "ONCOMING AUTOMOBILE",
				id: "oncoming_automobile",
				src: "1f698.png",
				dict: ["🚘"]
			}, {
				name: "RECREATIONAL VEHICLE",
				id: "recreational_vehicle",
				src: "1f699.png",
				dict: ["🚙", ""]
			}, {
				name: "DELIVERY TRUCK",
				id: "delivery_truck",
				src: "1f69a.png",
				dict: ["🚚", ""]
			}, {
				name: "ARTICULATED LORRY",
				id: "articulated_lorry",
				src: "1f69b.png",
				dict: ["🚛"]
			}, {
				name: "TRACTOR",
				id: "tractor",
				src: "1f69c.png",
				dict: ["🚜"]
			}, {
				name: "MONORAIL",
				id: "monorail",
				src: "1f69d.png",
				dict: ["🚝"]
			}, {
				name: "MOUNTAIN RAILWAY",
				id: "mountain_railway",
				src: "1f69e.png",
				dict: ["🚞"]
			}, {
				name: "SUSPENSION RAILWAY",
				id: "suspension_railway",
				src: "1f69f.png",
				dict: ["🚟"]
			}, {
				name: "MOUNTAIN CABLEWAY",
				id: "mountain_cableway",
				src: "1f6a0.png",
				dict: ["🚠"]
			}, {
				name: "AERIAL TRAMWAY",
				id: "aerial_tramway",
				src: "1f6a1.png",
				dict: ["🚡"]
			}, {
				name: "SHIP",
				id: "ship",
				src: "1f6a2.png",
				dict: ["🚢", ""]
			}, {
				name: "ROWBOAT",
				id: "rowboat",
				src: "1f6a3.png",
				dict: ["🚣"]
			}, {
				name: "SPEEDBOAT",
				id: "speedboat",
				src: "1f6a4.png",
				dict: ["🚤", ""]
			}, {
				name: "HORIZONTAL TRAFFIC LIGHT",
				id: "horizontal_traffic_light",
				src: "1f6a5.png",
				dict: ["🚥", ""]
			}, {
				name: "VERTICAL TRAFFIC LIGHT",
				id: "vertical_traffic_light",
				src: "1f6a6.png",
				dict: ["🚦"]
			}, {
				name: "CONSTRUCTION SIGN",
				id: "construction_sign",
				src: "1f6a7.png",
				dict: ["🚧", ""]
			}, {
				name: "POLICE CARS REVOLVING LIGHT",
				id: "police_cars_revolving_light",
				src: "1f6a8.png",
				dict: ["🚨"]
			}, {
				name: "TRIANGULAR FLAG ON POST",
				id: "triangular_flag_on_post",
				src: "1f6a9.png",
				dict: ["🚩"]
			}, {
				name: "DOOR",
				id: "door",
				src: "1f6aa.png",
				dict: ["🚪"]
			}, {
				name: "NO ENTRY SIGN",
				id: "no_entry_sign",
				src: "1f6ab.png",
				dict: ["🚫"]
			}, {
				name: "SMOKING SYMBOL",
				id: "smoking_symbol",
				src: "1f6ac.png",
				dict: ["🚬", ""]
			}, {
				name: "NO SMOKING SYMBOL",
				id: "no_smoking_symbol",
				src: "1f6ad.png",
				dict: ["🚭", ""]
			}, {
				name: "PUT LITTER IN ITS PLACE SYMBOL",
				id: "put_litter_in_its_place_symbol",
				src: "1f6ae.png",
				dict: ["🚮"]
			}, {
				name: "DO NOT LITTER SYMBOL",
				id: "do_not_litter_symbol",
				src: "1f6af.png",
				dict: ["🚯"]
			}, {
				name: "POTABLE WATER SYMBOL",
				id: "potable_water_symbol",
				src: "1f6b0.png",
				dict: ["🚰"]
			}, {
				name: "NON-POTABLE WATER SYMBOL",
				id: "non-potable_water_symbol",
				src: "1f6b1.png",
				dict: ["🚱"]
			}, {
				name: "BICYCLE",
				id: "bicycle",
				src: "1f6b2.png",
				dict: ["🚲", ""]
			}, {
				name: "NO BICYCLES",
				id: "no_bicycles",
				src: "1f6b3.png",
				dict: ["🚳"]
			}, {
				name: "BICYCLIST",
				id: "bicyclist",
				src: "1f6b4.png",
				dict: ["🚴"]
			}, {
				name: "MOUNTAIN BICYCLIST",
				id: "mountain_bicyclist",
				src: "1f6b5.png",
				dict: ["🚵"]
			}, {
				name: "PEDESTRIAN",
				id: "pedestrian",
				src: "1f6b6.png",
				dict: ["🚶", ""]
			}, {
				name: "NO PEDESTRIANS",
				id: "no_pedestrians",
				src: "1f6b7.png",
				dict: ["🚷"]
			}, {
				name: "CHILDREN CROSSING",
				id: "children_crossing",
				src: "1f6b8.png",
				dict: ["🚸"]
			}, {
				name: "MENS SYMBOL",
				id: "mens_symbol",
				src: "1f6b9.png",
				dict: ["🚹", ""]
			}, {
				name: "WOMENS SYMBOL",
				id: "womens_symbol",
				src: "1f6ba.png",
				dict: ["🚺", ""]
			}, {
				name: "RESTROOM",
				id: "restroom",
				src: "1f6bb.png",
				dict: ["🚻", ""]
			}, {
				name: "BABY SYMBOL",
				id: "baby_symbol",
				src: "1f6bc.png",
				dict: ["🚼", ""]
			}, {
				name: "TOILET",
				id: "toilet",
				src: "1f6bd.png",
				dict: ["🚽", ""]
			}, {
				name: "WATER CLOSET",
				id: "water_closet",
				src: "1f6be.png",
				dict: ["🚾", ""]
			}, {
				name: "SHOWER",
				id: "shower",
				src: "1f6bf.png",
				dict: ["🚿"]
			}, {
				name: "BATH",
				id: "bath",
				src: "1f6c0.png",
				dict: ["🛀", ""]
			}, {
				name: "BATHTUB",
				id: "bathtub",
				src: "1f6c1.png",
				dict: ["🛁"]
			}, {
				name: "PASSPORT CONTROL",
				id: "passport_control",
				src: "1f6c2.png",
				dict: ["🛂"]
			}, {
				name: "CUSTOMS",
				id: "customs",
				src: "1f6c3.png",
				dict: ["🛃"]
			}, {
				name: "BAGGAGE CLAIM",
				id: "baggage_claim",
				src: "1f6c4.png",
				dict: ["🛄"]
			}, {
				name: "LEFT LUGGAGE",
				id: "left_luggage",
				src: "1f6c5.png",
				dict: ["🛅"]
			}, {
				name: "HASH KEY",
				id: "hash_key",
				src: "23-20e3.png",
				dict: ["#⃣", ""]
			}, {
				name: "KEYCAP 0",
				id: "keycap_0",
				src: "30-20e3.png",
				dict: ["0⃣", ""]
			}, {
				name: "KEYCAP 1",
				id: "keycap_1",
				src: "31-20e3.png",
				dict: ["1⃣", ""]
			}, {
				name: "KEYCAP 2",
				id: "keycap_2",
				src: "32-20e3.png",
				dict: ["2⃣", ""]
			}, {
				name: "KEYCAP 3",
				id: "keycap_3",
				src: "33-20e3.png",
				dict: ["3⃣", ""]
			}, {
				name: "KEYCAP 4",
				id: "keycap_4",
				src: "34-20e3.png",
				dict: ["4⃣", ""]
			}, {
				name: "KEYCAP 5",
				id: "keycap_5",
				src: "35-20e3.png",
				dict: ["5⃣", ""]
			}, {
				name: "KEYCAP 6",
				id: "keycap_6",
				src: "36-20e3.png",
				dict: ["6⃣", ""]
			}, {
				name: "KEYCAP 7",
				id: "keycap_7",
				src: "37-20e3.png",
				dict: ["7⃣", ""]
			}, {
				name: "KEYCAP 8",
				id: "keycap_8",
				src: "38-20e3.png",
				dict: ["8⃣", ""]
			}, {
				name: "KEYCAP 9",
				id: "keycap_9",
				src: "39-20e3.png",
				dict: ["9⃣", ""]
			}, {
				name: "FLAG OF CHINA",
				id: "flag_of_china",
				src: "1f1e8-1f1f3.png",
				dict: ["🇨🇳", ""]
			}, {
				name: "FLAG OF GERMANY",
				id: "flag_of_germany",
				src: "1f1e9-1f1ea.png",
				dict: ["🇩🇪", ""]
			}, {
				name: "FLAG OF SPAIN",
				id: "flag_of_spain",
				src: "1f1ea-1f1f8.png",
				dict: ["🇪🇸", ""]
			}, {
				name: "FLAG OF FRANCE",
				id: "flag_of_france",
				src: "1f1eb-1f1f7.png",
				dict: ["🇫🇷", ""]
			}, {
				name: "FLAG OF ITALY",
				id: "flag_of_italy",
				src: "1f1ee-1f1f9.png",
				dict: ["🇮🇹", ""]
			}, {
				name: "FLAG OF JAPAN",
				id: "flag_of_japan",
				src: "1f1ef-1f1f5.png",
				dict: ["🇯🇵", ""]
			}, {
				name: "FLAG OF SOUTH KOREA",
				id: "flag_of_south_korea",
				src: "1f1f0-1f1f7.png",
				dict: ["🇰🇷", ""]
			}, {
				name: "FLAG OF RUSSIA",
				id: "flag_of_russia",
				src: "1f1f7-1f1fa.png",
				dict: ["🇷🇺", ""]
			}, {
				name: "FLAG OF THE UNITED STATES",
				id: "flag_of_the_united_states",
				src: "1f1fa-1f1f8.png",
				dict: ["🇺🇸", ""]
			}, {
				name: "FLAG OF THE UNITED KINGDOM",
				id: "flag_of_the_united_kingdom",
				src: "1f1ec-1f1e7.png",
				dict: ["🇬🇧", ""]
			}],
			blocks: [{
				name: "Basic Latin",
				start: "\0",
				end: ""
			}, {
				name: "Latin-1 Supplement",
				start: "",
				end: "ÿ"
			}, {
				name: "Latin Extended-A",
				start: "Ā",
				end: "ſ"
			}, {
				name: "Latin Extended-B",
				start: "ƀ",
				end: "ɏ"
			}, {
				name: "IPA Extensions",
				start: "ɐ",
				end: "ʯ"
			}, {
				name: "Spacing Modifier Letters",
				start: "ʰ",
				end: "˿"
			}, {
				name: "Combining Diacritical Marks",
				start: "̀",
				end: "ͯ"
			}, {
				name: "Greek and Coptic",
				start: "Ͱ",
				end: "Ͽ"
			}, {
				name: "Cyrillic",
				start: "Ѐ",
				end: "ӿ"
			}, {
				name: "Cyrillic Supplement",
				start: "Ԁ",
				end: "ԯ"
			}, {
				name: "Armenian",
				start: "԰",
				end: "֏"
			}, {
				name: "Hebrew",
				start: "֐",
				end: "׿"
			}, {
				name: "Arabic",
				start: "؀",
				end: "ۿ"
			}, {
				name: "Syriac",
				start: "܀",
				end: "ݏ"
			}, {
				name: "Arabic Supplement",
				start: "ݐ",
				end: "ݿ"
			}, {
				name: "Thaana",
				start: "ހ",
				end: "޿"
			}, {
				name: "NKo",
				start: "߀",
				end: "߿"
			}, {
				name: "Samaritan",
				start: "ࠀ",
				end: "࠿"
			}, {
				name: "Mandaic",
				start: "ࡀ",
				end: "࡟"
			}, {
				name: "Arabic Extended-A",
				start: "ࢠ",
				end: "ࣿ"
			}, {
				name: "Devanagari",
				start: "ऀ",
				end: "ॿ"
			}, {
				name: "Bengali",
				start: "ঀ",
				end: "৿"
			}, {
				name: "Gurmukhi",
				start: "਀",
				end: "੿"
			}, {
				name: "Gujarati",
				start: "઀",
				end: "૿"
			}, {
				name: "Oriya",
				start: "଀",
				end: "୿"
			}, {
				name: "Tamil",
				start: "஀",
				end: "௿"
			}, {
				name: "Telugu",
				start: "ఀ",
				end: "౿"
			}, {
				name: "Kannada",
				start: "ಀ",
				end: "೿"
			}, {
				name: "Malayalam",
				start: "ഀ",
				end: "ൿ"
			}, {
				name: "Sinhala",
				start: "඀",
				end: "෿"
			}, {
				name: "Thai",
				start: "฀",
				end: "๿"
			}, {
				name: "Lao",
				start: "຀",
				end: "໿"
			}, {
				name: "Tibetan",
				start: "ༀ",
				end: "࿿"
			}, {
				name: "Myanmar",
				start: "က",
				end: "႟"
			}, {
				name: "Georgian",
				start: "Ⴀ",
				end: "ჿ"
			}, {
				name: "Hangul Jamo",
				start: "ᄀ",
				end: "ᇿ"
			}, {
				name: "Ethiopic",
				start: "ሀ",
				end: "፿"
			}, {
				name: "Ethiopic Supplement",
				start: "ᎀ",
				end: "᎟"
			}, {
				name: "Cherokee",
				start: "Ꭰ",
				end: "᏿"
			}, {
				name: "Unified Canadian Aboriginal Syllabics",
				start: "᐀",
				end: "ᙿ"
			}, {
				name: "Ogham",
				start: " ",
				end: "᚟"
			}, {
				name: "Runic",
				start: "ᚠ",
				end: "᛿"
			}, {
				name: "Tagalog",
				start: "ᜀ",
				end: "ᜟ"
			}, {
				name: "Hanunoo",
				start: "ᜠ",
				end: "᜿"
			}, {
				name: "Buhid",
				start: "ᝀ",
				end: "᝟"
			}, {
				name: "Tagbanwa",
				start: "ᝠ",
				end: "᝿"
			}, {
				name: "Khmer",
				start: "ក",
				end: "៿"
			}, {
				name: "Mongolian",
				start: "᠀",
				end: "᢯"
			}, {
				name: "Unified Canadian Aboriginal Syllabics Extended",
				start: "ᢰ",
				end: "᣿"
			}, {
				name: "Limbu",
				start: "ᤀ",
				end: "᥏"
			}, {
				name: "Tai Le",
				start: "ᥐ",
				end: "᥿"
			}, {
				name: "New Tai Lue",
				start: "ᦀ",
				end: "᧟"
			}, {
				name: "Khmer Symbols",
				start: "᧠",
				end: "᧿"
			}, {
				name: "Buginese",
				start: "ᨀ",
				end: "᨟"
			}, {
				name: "Tai Tham",
				start: "ᨠ",
				end: "᪯"
			}, {
				name: "Balinese",
				start: "ᬀ",
				end: "᭿"
			}, {
				name: "Sundanese",
				start: "ᮀ",
				end: "ᮿ"
			}, {
				name: "Batak",
				start: "ᯀ",
				end: "᯿"
			}, {
				name: "Lepcha",
				start: "ᰀ",
				end: "ᱏ"
			}, {
				name: "Ol Chiki",
				start: "᱐",
				end: "᱿"
			}, {
				name: "Sundanese Supplement",
				start: "᳀",
				end: "᳏"
			}, {
				name: "Vedic Extensions",
				start: "᳐",
				end: "᳿"
			}, {
				name: "Phonetic Extensions",
				start: "ᴀ",
				end: "ᵿ"
			}, {
				name: "Phonetic Extensions Supplement",
				start: "ᶀ",
				end: "ᶿ"
			}, {
				name: "Combining Diacritical Marks Supplement",
				start: "᷀",
				end: "᷿"
			}, {
				name: "Latin Extended Additional",
				start: "Ḁ",
				end: "ỿ"
			}, {
				name: "Greek Extended",
				start: "ἀ",
				end: "῿"
			}, {
				name: "General Punctuation",
				start: " ",
				end: "⁯"
			}, {
				name: "Superscripts and Subscripts",
				start: "⁰",
				end: "₟"
			}, {
				name: "Currency Symbols",
				start: "₠",
				end: "⃏"
			}, {
				name: "Combining Diacritical Marks for Symbols",
				start: "⃐",
				end: "⃿"
			}, {
				name: "Letterlike Symbols",
				start: "℀",
				end: "⅏"
			}, {
				name: "Number Forms",
				start: "⅐",
				end: "↏"
			}, {
				name: "Arrows",
				start: "←",
				end: "⇿"
			}, {
				name: "Mathematical Operators",
				start: "∀",
				end: "⋿"
			}, {
				name: "Miscellaneous Technical",
				start: "⌀",
				end: "⏿"
			}, {
				name: "Control Pictures",
				start: "␀",
				end: "␿"
			}, {
				name: "Optical Character Recognition",
				start: "⑀",
				end: "⑟"
			}, {
				name: "Enclosed Alphanumerics",
				start: "①",
				end: "⓿"
			}, {
				name: "Box Drawing",
				start: "─",
				end: "╿"
			}, {
				name: "Block Elements",
				start: "▀",
				end: "▟"
			}, {
				name: "Geometric Shapes",
				start: "■",
				end: "◿"
			}, {
				name: "Miscellaneous Symbols",
				start: "☀",
				end: "⛿"
			}, {
				name: "Dingbats",
				start: "✀",
				end: "➿"
			}, {
				name: "Miscellaneous Mathematical Symbols-A",
				start: "⟀",
				end: "⟯"
			}, {
				name: "Supplemental Arrows-A",
				start: "⟰",
				end: "⟿"
			}, {
				name: "Braille Patterns",
				start: "⠀",
				end: "⣿"
			}, {
				name: "Supplemental Arrows-B",
				start: "⤀",
				end: "⥿"
			}, {
				name: "Miscellaneous Mathematical Symbols-B",
				start: "⦀",
				end: "⧿"
			}, {
				name: "Supplemental Mathematical Operators",
				start: "⨀",
				end: "⫿"
			}, {
				name: "Miscellaneous Symbols and Arrows",
				start: "⬀",
				end: "⯿"
			}, {
				name: "Glagolitic",
				start: "Ⰰ",
				end: "ⱟ"
			}, {
				name: "Latin Extended-C",
				start: "Ⱡ",
				end: "Ɀ"
			}, {
				name: "Coptic",
				start: "Ⲁ",
				end: "⳿"
			}, {
				name: "Georgian Supplement",
				start: "ⴀ",
				end: "⴯"
			}, {
				name: "Tifinagh",
				start: "ⴰ",
				end: "⵿"
			}, {
				name: "Ethiopic Extended",
				start: "ⶀ",
				end: "⷟"
			}, {
				name: "Cyrillic Extended-A",
				start: "ⷠ",
				end: "ⷿ"
			}, {
				name: "Supplemental Punctuation",
				start: "⸀",
				end: "⹿"
			}, {
				name: "CJK Radicals Supplement",
				start: "⺀",
				end: "⻿"
			}, {
				name: "Kangxi Radicals",
				start: "⼀",
				end: "⿟"
			}, {
				name: "Ideographic Description Characters",
				start: "⿰",
				end: "⿿"
			}, {
				name: "CJK Symbols and Punctuation",
				start: "　",
				end: "〿"
			}, {
				name: "Hiragana",
				start: "぀",
				end: "ゟ"
			}, {
				name: "Katakana",
				start: "゠",
				end: "ヿ"
			}, {
				name: "Bopomofo",
				start: "㄀",
				end: "ㄯ"
			}, {
				name: "Hangul Compatibility Jamo",
				start: "㄰",
				end: "㆏"
			}, {
				name: "Kanbun",
				start: "㆐",
				end: "㆟"
			}, {
				name: "Bopomofo Extended",
				start: "ㆠ",
				end: "ㆿ"
			}, {
				name: "CJK Strokes",
				start: "㇀",
				end: "㇯"
			}, {
				name: "Katakana Phonetic Extensions",
				start: "ㇰ",
				end: "ㇿ"
			}, {
				name: "Enclosed CJK Letters and Months",
				start: "㈀",
				end: "㋿"
			}, {
				name: "CJK Compatibility",
				start: "㌀",
				end: "㏿"
			}, {
				name: "CJK Unified Ideographs Extension A",
				start: "㐀",
				end: "䶿"
			}, {
				name: "Yijing Hexagram Symbols",
				start: "䷀",
				end: "䷿"
			}, {
				name: "CJK Unified Ideographs",
				start: "一",
				end: "鿿"
			}, {
				name: "Yi Syllables",
				start: "ꀀ",
				end: "꒏"
			}, {
				name: "Yi Radicals",
				start: "꒐",
				end: "꓏"
			}, {
				name: "Lisu",
				start: "ꓐ",
				end: "꓿"
			}, {
				name: "Vai",
				start: "ꔀ",
				end: "꘿"
			}, {
				name: "Cyrillic Extended-B",
				start: "Ꙁ",
				end: "ꚟ"
			}, {
				name: "Bamum",
				start: "ꚠ",
				end: "꛿"
			}, {
				name: "Modifier Tone Letters",
				start: "꜀",
				end: "ꜟ"
			}, {
				name: "Latin Extended-D",
				start: "꜠",
				end: "ꟿ"
			}, {
				name: "Syloti Nagri",
				start: "ꠀ",
				end: "꠯"
			}, {
				name: "Common Indic Number Forms",
				start: "꠰",
				end: "꠿"
			}, {
				name: "Phags-pa",
				start: "ꡀ",
				end: "꡿"
			}, {
				name: "Saurashtra",
				start: "ꢀ",
				end: "꣟"
			}, {
				name: "Devanagari Extended",
				start: "꣠",
				end: "ꣿ"
			}, {
				name: "Kayah Li",
				start: "꤀",
				end: "꤯"
			}, {
				name: "Rejang",
				start: "ꤰ",
				end: "꥟"
			}, {
				name: "Hangul Jamo Extended-A",
				start: "ꥠ",
				end: "꥿"
			}, {
				name: "Javanese",
				start: "ꦀ",
				end: "꧟"
			}, {
				name: "Cham",
				start: "ꨀ",
				end: "꩟"
			}, {
				name: "Myanmar Extended-A",
				start: "ꩠ",
				end: "ꩿ"
			}, {
				name: "Tai Viet",
				start: "ꪀ",
				end: "꫟"
			}, {
				name: "Meetei Mayek Extensions",
				start: "ꫠ",
				end: "꫿"
			}, {
				name: "Ethiopic Extended-A",
				start: "꬀",
				end: "꬯"
			}, {
				name: "Meetei Mayek",
				start: "ꯀ",
				end: "꯿"
			}, {
				name: "Hangul Syllables",
				start: "가",
				end: "힯"
			}, {
				name: "Hangul Jamo Extended-B",
				start: "ힰ",
				end: "퟿"
			}, {
				name: "High Surrogates",
				start: "��",
				end: "��"
			}, {
				name: "High Private Use Surrogates",
				start: "��",
				end: "��"
			}, {
				name: "Low Surrogates",
				start: "��",
				end: "��"
			}, {
				name: "Private Use Area",
				start: "",
				end: ""
			}, {
				name: "CJK Compatibility Ideographs",
				start: "豈",
				end: "﫿"
			}, {
				name: "Alphabetic Presentation Forms",
				start: "ﬀ",
				end: "ﭏ"
			}, {
				name: "Arabic Presentation Forms-A",
				start: "ﭐ",
				end: "﷿"
			}, {
				name: "Variation Selectors",
				start: "︀",
				end: "️"
			}, {
				name: "Vertical Forms",
				start: "︐",
				end: "︟"
			}, {
				name: "Combining Half Marks",
				start: "︠",
				end: "︯"
			}, {
				name: "CJK Compatibility Forms",
				start: "︰",
				end: "﹏"
			}, {
				name: "Small Form Variants",
				start: "﹐",
				end: "﹯"
			}, {
				name: "Arabic Presentation Forms-B",
				start: "ﹰ",
				end: "﻿"
			}, {
				name: "Halfwidth and Fullwidth Forms",
				start: "＀",
				end: "￯"
			}, {
				name: "Specials",
				start: "￰",
				end: "￿"
			}, {
				name: "Linear B Syllabary",
				start: "𐀀",
				end: "𐁿"
			}, {
				name: "Linear B Ideograms",
				start: "𐂀",
				end: "𐃿"
			}, {
				name: "Aegean Numbers",
				start: "𐄀",
				end: "𐄿"
			}, {
				name: "Ancient Greek Numbers",
				start: "𐅀",
				end: "𐆏"
			}, {
				name: "Ancient Symbols",
				start: "𐆐",
				end: "𐇏"
			}, {
				name: "Phaistos Disc",
				start: "𐇐",
				end: "𐇿"
			}, {
				name: "Lycian",
				start: "𐊀",
				end: "𐊟"
			}, {
				name: "Carian",
				start: "𐊠",
				end: "𐋟"
			}, {
				name: "Old Italic",
				start: "𐌀",
				end: "𐌯"
			}, {
				name: "Gothic",
				start: "𐌰",
				end: "𐍏"
			}, {
				name: "Ugaritic",
				start: "𐎀",
				end: "𐎟"
			}, {
				name: "Old Persian",
				start: "𐎠",
				end: "𐏟"
			}, {
				name: "Deseret",
				start: "𐐀",
				end: "𐑏"
			}, {
				name: "Shavian",
				start: "𐑐",
				end: "𐑿"
			}, {
				name: "Osmanya",
				start: "𐒀",
				end: "𐒯"
			}, {
				name: "Cypriot Syllabary",
				start: "𐠀",
				end: "𐠿"
			}, {
				name: "Imperial Aramaic",
				start: "𐡀",
				end: "𐡟"
			}, {
				name: "Phoenician",
				start: "𐤀",
				end: "𐤟"
			}, {
				name: "Lydian",
				start: "𐤠",
				end: "𐤿"
			}, {
				name: "Meroitic Hieroglyphs",
				start: "𐦀",
				end: "𐦟"
			}, {
				name: "Meroitic Cursive",
				start: "𐦠",
				end: "𐧿"
			}, {
				name: "Kharoshthi",
				start: "𐨀",
				end: "𐩟"
			}, {
				name: "Old South Arabian",
				start: "𐩠",
				end: "𐩿"
			}, {
				name: "Avestan",
				start: "𐬀",
				end: "𐬿"
			}, {
				name: "Inscriptional Parthian",
				start: "𐭀",
				end: "𐭟"
			}, {
				name: "Inscriptional Pahlavi",
				start: "𐭠",
				end: "𐭿"
			}, {
				name: "Old Turkic",
				start: "𐰀",
				end: "𐱏"
			}, {
				name: "Rumi Numeral Symbols",
				start: "𐹠",
				end: "𐹿"
			}, {
				name: "Brahmi",
				start: "𑀀",
				end: "𑁿"
			}, {
				name: "Kaithi",
				start: "𑂀",
				end: "𑃏"
			}, {
				name: "Sora Sompeng",
				start: "𑃐",
				end: "𑃿"
			}, {
				name: "Chakma",
				start: "𑄀",
				end: "𑅏"
			}, {
				name: "Sharada",
				start: "𑆀",
				end: "𑇟"
			}, {
				name: "Takri",
				start: "𑚀",
				end: "𑛏"
			}, {
				name: "Cuneiform",
				start: "𒀀",
				end: "𒏿"
			}, {
				name: "Cuneiform Numbers and Punctuation",
				start: "𒐀",
				end: "𒑿"
			}, {
				name: "Egyptian Hieroglyphs",
				start: "𓀀",
				end: "𓐯"
			}, {
				name: "Bamum Supplement",
				start: "𖠀",
				end: "𖨿"
			}, {
				name: "Miao",
				start: "𖼀",
				end: "𖾟"
			}, {
				name: "Kana Supplement",
				start: "𛀀",
				end: "𛃿"
			}, {
				name: "Byzantine Musical Symbols",
				start: "𝀀",
				end: "𝃿"
			}, {
				name: "Musical Symbols",
				start: "𝄀",
				end: "𝇿"
			}, {
				name: "Ancient Greek Musical Notation",
				start: "𝈀",
				end: "𝉏"
			}, {
				name: "Tai Xuan Jing Symbols",
				start: "𝌀",
				end: "𝍟"
			}, {
				name: "Counting Rod Numerals",
				start: "𝍠",
				end: "𝍿"
			}, {
				name: "Mathematical Alphanumeric Symbols",
				start: "𝐀",
				end: "𝟿"
			}, {
				name: "Arabic Mathematical Alphabetic Symbols",
				start: "𞸀",
				end: "𞻿"
			}, {
				name: "Mahjong Tiles",
				start: "🀀",
				end: "🀯"
			}, {
				name: "Domino Tiles",
				start: "🀰",
				end: "🂟"
			}, {
				name: "Playing Cards",
				start: "🂠",
				end: "🃿"
			}, {
				name: "Enclosed Alphanumeric Supplement",
				start: "🄀",
				end: "🇿"
			}, {
				name: "Enclosed Ideographic Supplement",
				start: "🈀",
				end: "🋿"
			}, {
				name: "Miscellaneous Symbols And Pictographs",
				start: "🌀",
				end: "🗿"
			}, {
				name: "Emoticons",
				start: "😀",
				end: "🙏"
			}, {
				name: "Transport And Map Symbols",
				start: "🚀",
				end: "🛿"
			}, {
				name: "Alchemical Symbols",
				start: "🜀",
				end: "🝿"
			}, {
				name: "CJK Unified Ideographs Extension B",
				start: "𠀀",
				end: "𪛟"
			}, {
				name: "CJK Unified Ideographs Extension C",
				start: "𪜀",
				end: "𫜿"
			}, {
				name: "CJK Unified Ideographs Extension D",
				start: "𫝀",
				end: "𫠟"
			}, {
				name: "CJK Compatibility Ideographs Supplement",
				start: "丽",
				end: "𯨟"
			}, {
				name: "Tags",
				start: "󠀀",
				end: "󠁿"
			}, {
				name: "Variation Selectors Supplement",
				start: "󠄀",
				end: "󠇯"
			}, {
				name: "Supplementary Private Use Area-A",
				start: "󰀀",
				end: "󿿿"
			}, {
				name: "Supplementary Private Use Area-B",
				start: "􀀀",
				end: "􏿿"
			}],
			groups: [{
				name: "People",
				items: []
			}, {
				name: "Nature",
				items: []
			}, {
				name: "Objects",
				items: []
			}, {
				name: "Places",
				items: []
			}, {
				name: "Symbols",
				items: []
			}],
			ioshidden: ["©", "®", "‼", "⁉", "™", "ℹ", "↔", "↕", "↖", "↗", "↘", "↙", "↩", "↪", "⌚", "⌛", "Ⓜ", "▪", "▫", "▶", "◀", "◻", "◼", "◽", "◾", "☀", "☁", "☎", "☑", "☝", "☺", "♈", "♉", "♊", "♋", "♌", "♍", "♎", "♏", "♐", "♑", "♒", "♓", "♠", "♣", "♥", "♦", "♨", "♻", "♿", "⚓", "⚠", "⚡", "⚪", "⚫", "✂", "✈", "✉", "✌", "✏", "✒", "✔", "✖", "✳", "✴", "❄", "❇", "❤", "➡", "〰", "〽", "㊗", "㊙"],
			machidden: [""]
		},
			a = s.items;
		hidden = [], valid = a.filter(function(e) {
			return e.src != ""
		}), u(valid), regexp = new RegExp(pattern, "g"), window.emojis = function(e) {
			return e = e.replace(regexp, function(e) {
				var t = valid.filter(function(t) {
					if (t.dict.indexOf(e) != -1) return t.src
				});
				if (t.length > 0) return o(t[0])
			}), emojiFiles.forEach(function(t) {
				var n = unescape("%u" + t);
				e.indexOf(n) > -1 && (e = e.split(n).join(o({
					src: t + ".png"
				})))
			}), e
		}
	})(window.emoScale || 1.2), function() {
		function d(u) {
			if (!u) return u;
			var u = p(u),
				a = ['<span style="background-image: url(' + (window.relEmo || "") + "emoticons/", '.png)" class="emojicon-m"></span>'];
			for (var f = 0, l = o.length; f < l; f++) u.indexOf(o[f]) > -1 && (u = u.split(o[f]).join(a[0] + emojiFiles[f] + a[1]));
			if (u.indexOf("/:") > -1) for (var f = 0, l = e.length; f < l; f++) u.indexOf(e[f]) > -1 && (u = u.split(e[f]).join(a[0] + "qq/" + (f + 1) + a[1]));
			if (u.indexOf("/") > -1) for (var f = 0, l = t.length; f < l; f++) u.indexOf(t[f]) > -1 && (u = u.split(t[f]).join(a[0] + "qq/" + (f + 1) + a[1]));
			if (u.indexOf("[") > -1 && u.indexOf("]") > -1) for (var f = 0, l = t.length; f < l; f++) n[f] && u.indexOf(n[f]) > -1 && (u = u.split(n[f]).join(a[0] + "qq/" + (f + 1) + a[1])), r[f] && u.indexOf(r[f]) > -1 && (u = u.split(r[f]).join(a[0] + "qq/" + (f + 1) + a[1])), i[f] && u.indexOf(i[f]) > -1 && (u = u.split(i[f]).join(a[0] + "qq/" + (f + 1) + a[1])), s[f] && u.indexOf(s[f]) > -1 && (u = u.split(s[f]).join(a[0] + "qq/" + (f + 1) + a[1]));
			return window.emojis && (u = window.emojis(u)), u
		}
		var e = ["/::)", "/::~", "/::B", "/::|", "/:8-)", "/::<", "/::$", "/::X", "/::Z", "/::'(", "/::-|", "/::@", "/::P", "/::D", "/::O", "/::(", "/::+", "/:--b", "/::Q", "/::T", "/:,@P", "/:,@-D", "/::d", "/:,@o", "/::g", "/:|-)", "/::!", "/::L", "/::>", "/::,@", "/:,@f", "/::-S", "/:?", "/:,@x", "/:,@@", "/::8", "/:,@!", "/:!!!", "/:xx", "/:bye", "/:wipe", "/:dig", "/:handclap", "/:&-(", "/:B-)", "/:<@", "/:@>", "/::-O", "/:>-|", "/:P-(", "/::'|", "/:X-)", "/::*", "/:@x", "/:8*", "/:pd", "/:<W>", "/:beer", "/:basketb", "/:oo", "/:coffee", "/:eat", "/:pig", "/:rose", "/:fade", "/:showlove", "/:heart", "/:break", "/:cake", "/:li", "/:bome", "/:kn", "/:footb", "/:ladybug", "/:shit", "/:moon", "/:sun", "/:gift", "/:hug", "/:strong", "/:weak", "/:share", "/:v", "/:@)", "/:jj", "/:@@", "/:bad", "/:lvu", "/:no", "/:ok", "/:love", "/:<L>", "/:jump", "/:shake", "/:<O>", "/:circle", "/:kotow", "/:turn", "/:skip", "/:oY", "/:#-0", "/:hiphot", "/:kiss", "/:<&", "/:&>"],
			t = ["/微笑", "/撇嘴", "/色", "/发呆", "/得意", "/流泪", "/害羞", "/闭嘴", "/睡", "/大哭", "/尴尬", "/发怒", "/调皮", "/呲牙", "/惊讶", "/难过", "/酷", "/冷汗", "/抓狂", "/吐", "/偷笑", "/可爱", "/白眼", "/傲慢", "/饥饿", "/困", "/惊恐", "/流汗", "/憨笑", "/大兵", "/奋斗", "/咒骂", "/疑问", "/嘘", "/晕", "/折磨", "/衰", "/骷髅", "/敲打", "/再见", "/擦汗", "/抠鼻", "/鼓掌", "/糗大了", "/坏笑", "/左哼哼", "/右哼哼", "/哈欠", "/鄙视", "/委屈", "/快哭了", "/阴险", "/亲亲", "/吓", "/可怜", "/菜刀", "/西瓜", "/啤酒", "/篮球", "/乒乓", "/咖啡", "/饭", "/猪头", "/玫瑰", "/凋谢", "/示爱", "/爱心", "/心碎", "/蛋糕", "/闪电", "/炸弹", "/刀", "/足球", "/瓢虫", "/便便", "/月亮", "/太阳", "/礼物", "/拥抱", "/强", "/弱", "/握手", "/胜利", "/抱拳", "/勾引", "/拳头", "/差劲", "/爱你", "/NO", "/OK", "/爱情", "/飞吻", "/跳跳", "/发抖", "/怄火", "/转圈", "/磕头", "/回头", "/跳绳", "/挥手", "/激动", "/街舞", "/献吻", "/左太极", "/右太极"],
			n = ["[微笑]", "[撇嘴]", "[色]", "[发呆]", "[得意]", "[流泪]", "[害羞]", "[闭嘴]", "[睡]", "[大哭]", "[尴尬]", "[发怒]", "[调皮]", "[呲牙]", "[惊讶]", "[难过]", "[酷]", "[冷汗]", "[抓狂]", "[吐]", "[偷笑]", "[愉快]", "[白眼]", "[傲慢]", "[饥饿]", "[困]", "[惊恐]", "[流汗]", "[憨笑]", "[悠闲]", "[奋斗]", "[咒骂]", "[疑问]", "[嘘]", "[晕]", "[疯了]", "[衰]", "[骷髅]", "[敲打]", "[再见]", "[擦汗]", "[抠鼻]", "[鼓掌]", "[糗大了]", "[坏笑]", "[左哼哼]", "[右哼哼]", "[哈欠]", "[鄙视]", "[委屈]", "[快哭了]", "[阴险]", "[亲亲]", "[吓]", "[可怜]", "[菜刀]", "[西瓜]", "[啤酒]", "[篮球]", "[乒乓]", "[咖啡]", "[饭]", "[猪头]", "[玫瑰]", "[凋谢]", "[嘴唇]", "[爱心]", "[心碎]", "[蛋糕]", "[闪电]", "[炸弹]", "[刀]", "[足球]", "[瓢虫]", "[便便]", "[月亮]", "[太阳]", "[礼物]", "[拥抱]", "[强]", "[弱]", "[握手]", "[胜利]", "[抱拳]", "[勾引]", "[拳头]", "[差劲]", "[爱你]", "[NO]", "[OK]", "[爱情]", "[飞吻]", "[跳跳]", "[发抖]", "[怄火]", "[转圈]", "[磕头]", "[回头]", "[跳绳]", "[投降]", "[激动]", "[乱舞]", "[献吻]", "[左太极]", "[右太极]"],
			r = ["[微笑]", "[撇嘴]", "[色]", "[發呆]", "[得意]", "[流淚]", "[害羞]", "[閉嘴]", "[睡]", "[大哭]", "[尷尬]", "[發怒]", "[調皮]", "[呲牙]", "[驚訝]", "[難過]", "[酷]", "[冷汗]", "[抓狂]", "[吐]", "[偷笑]", "[愉快]", "[白眼]", "[傲慢]", "[饑餓]", "[累]", "[驚恐]", "[流汗]", "[大笑]", "[悠閑]", "[奮鬥]", "[咒罵]", "[疑問]", "[噓]", "[暈]", "[瘋了]", "[衰]", "[骷髏頭]", "[敲打]", "[再見]", "[擦汗]", "[摳鼻]", "[鼓掌]", "[羞辱]", "[壞笑]", "[左哼哼]", "[右哼哼]", "[哈欠]", "[鄙視]", "[委屈]", "[快哭了]", "[陰險]", "[親親]", "[嚇]", "[可憐]", "[菜刀]", "[西瓜]", "[啤酒]", "[籃球]", "[乒乓]", "[咖啡]", "[飯]", "[豬頭]", "[玫瑰]", "[枯萎]", "[嘴唇]", "[愛心]", "[心碎]", "[蛋糕]", "[閃電]", "[炸彈]", "[刀]", "[足球]", "[甲蟲]", "[便便]", "[月亮]", "[太陽]", "[禮物]", "[擁抱]", "[強]", "[弱]", "[握手]", "[勝利]", "[抱拳]", "[勾引]", "[拳頭]", "[差勁]", "[愛你]", "[NO]", "[OK]", "[愛情]", "[飛吻]", "[跳跳]", "[發抖]", "[噴火]", "[轉圈]", "[磕頭]", "[回頭]", "[跳繩]", "[投降]", "[激動]", "[亂舞]", "[獻吻]", "[左太極]", "[右太極]"],
			i = ["[Smile]", "[Grimace]", "[Drool]", "[Scowl]", "[CoolGuy]", "[Sob]", "[Shy]", "[Silent]", "[Sleep]", "[Cry]", "[Awkward]", "[Angry]", "[Tongue]", "[Grin]", "[Surprise]", "[Frown]", "[Ruthless]", "[Blush]", "[Scream]", "[Puke]", "[Chuckle]", "[Joyful]", "[Slight]", "[Smug]", "[Hungry]", "[Drowsy]", "[Panic]", "[Sweat]", "[Laugh]", "[Commando]", "[Determined]", "[Scold]", "[Shocked]", "[Shhh]", "[Dizzy]", "[Tormented]", "[Toasted]", "[Skull]", "[Hammer]", "[Wave]", "[Speechless]", "[NosePick]", "[Clap]", "[Shame]", "[Trick]", "[Bah！L]", "[Bah！R]", "[Yawn]", "[Pooh-pooh]", "[Shrunken]", "[TearingUp]", "[Sly]", "[Kiss]", "[Wrath]", "[Whimper]", "[Cleaver]", "[Watermelon]", "[Beer]", "[Basketball]", "[PingPong]", "[Coffee]", "[Rice]", "[Pig]", "[Rose]", "[Wilt]", "[Lips]", "[Heart]", "[BrokenHeart]", "[Cake]", "[Lightning]", "[Bomb]", "[Dagger]", "[Soccer]", "[Ladybug]", "[Poop]", "[Moon]", "[Sun]", "[Gift]", "[Hug]", "[ThumbsUp]", "[ThumbsDown]", "[Shake]", "[Peace]", "[Fight]", "[Beckon]", "[Fist]", "[Pinky]", "[RockOn]", "[Nuh-uh]", "[OK]", "[InLove]", "[Blowkiss]", "[Waddle]", "[Tremble]", "[Aaagh!]", "[Twirl]", "[Kotow]", "[Dramatic]", "[JumpRope]", "[Surrender]", "[Hooray]", "[Meditate]", "[Smooch]", "[TaiChi L]", "[TaiChi R]"],
			s = ["[ยิ้ม]", "[หน้าบูด]", "[น้ำลายไหล]", "[หน้าบึ้ง]", "[สบาย]", "[ร้องไห้โฮ]", "[อาย]", "[ห้ามพูด]", "[หลับ]", "[ร้องไห้]", "[ลำบากใจ]", "[โกรธสุด]", "[ขยิบตา]", "[ยิ้มกว้าง]", "[ประหลาดใจ]", "[เสียใจ]", "[เจ๋ง]", "[เขินอาย]", "[กรีดร้อง]", "[อาเจียน]", "[หัวเราะหึๆ]", "[พอใจ]", "[สงสัย]", "[หยิ่ง]", "[หิว]", "[ง่วงนอน]", "[ตกใจกลัว]", "[เหงื่อตก]", "[หัวเราะ]", "[ทหาร]", "[มุ่งมั่น]", "[ด่าว่าา]", "[สับสน]", "[จุ๊ๆ]", "[เวียนหัว]", "[ท้อแท้]", "[ชั่วร้าย]", "[หัวกะโหลก]", "[ค้อนทุบ]", "[บายๆ]", "[เช็ดเหงื่อ]", "[แคะจมูก]", "[ตบมือ]", "[อับอาย]", "[กลโกง]", "[เชิดซ้าย]", "[เชิดขวา]", "[หาว]", "[ดูถูก]", "[ข้องใจ]", "[เกือบร้องไห้]", "[ขี้โกง]", "[จุ๊บ]", "[ห๊า]", "[น่าสงสาร]", "[มีด]", "[แตงโม]", "[เบียร์]", "[บาสเกตบอล]", "[ปิงปอง]", "[กาแฟ]", "[ข้าว]", "[หมู]", "[กุหลาบ]", "[ร่วงโรย]", "[ริมฝีปาก]", "[หัวใจ]", "[ใจสลาย]", "[เค้ก]", "[ฟ้าผ่า]", "[ระเบิด]", "[ดาบ]", "[ฟุตบอล]", "[เต่าทอง]", "[อุจจาระ]", "[พระจันทร์]", "[พระอาทิตย์]", "[ของขวัญ]", "[กอด]", "[ยอดเยี่ยม]", "[ยอดแย่]", "[จับมือ]", "[สู้ตาย]", "[คารวะ]", "[เข้ามา]", "[กำหมัด]", "[ดีกัน]", "[ฉันรักคุณ]", "[ไม่]", "[ตกลง]", "[รักกัน]", "[มีรัก]", "[กระโดด]", "[เขย่า]", "[อ้ากส์!]", "[หมุนตัว]", "[คำนับ]", "[เหลียวหลัง]", "[กระโดด]", "[ยอมแพ้]", "[ไชโย]", "[เย้เย้]", "[จูบ]", "[หญิงต่อสู้]", "[ชายต่อสู้]"],
			o = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""],
			u = {
				"&": "&#38;",
				"<": "&#60;",
				">": "&#62;",
				'"': "&#34;",
				"'": "&#39;"
			},
			a = /[<>\'\"&]/;
		for (var f = 0, l = e.length; f < l; f++) {
			var c = e[f];
			if (a.test(e[f])) {
				for (var h in u) c = c.split(h).join(u[h]);
				e[f] = c
			}
		}
		var p = function(e) {
				return e.replace(/&/g, "&#38;").replace(/</g, "&#60;").replace(/>/g, "&#62;").replace(/\"/g, "&#34;").replace(/\'/g, "&#39;").replace(/\r?\n/g, "<br />")
			};
		window.emopr = d, window.emocache = function() {
			if (window.localStorage) {
				if (window.localStorage["emo-preload"]) return !0;
				window.localStorage["emo-preload"] = 1
			}
			var e = document.createElement("iframe");
			e.src = (window.relEmo || "") + "emoticons/cache.html", e.onload = function() {
				e.onload = null, e = null
			}, e.style.display = "none", (document.documentElement || document.body).appendChild(e)
		}
	}(), define("emopr", function(e) {
		return function() {
			var t, n;
			return t || e.emopr
		}
	}(this)), define("base/md5", ["require"], function(e) {
		function t(e, t) {
			var n = (e & 65535) + (t & 65535),
				r = (e >> 16) + (t >> 16) + (n >> 16);
			return r << 16 | n & 65535
		}
		function n(e, t) {
			return e << t | e >>> 32 - t
		}
		function r(e, r, i, s, o, u) {
			return t(n(t(t(r, e), t(s, u)), o), i)
		}
		function i(e, t, n, i, s, o, u) {
			return r(t & n | ~t & i, e, t, s, o, u)
		}
		function s(e, t, n, i, s, o, u) {
			return r(t & i | n & ~i, e, t, s, o, u)
		}
		function o(e, t, n, i, s, o, u) {
			return r(t ^ n ^ i, e, t, s, o, u)
		}
		function u(e, t, n, i, s, o, u) {
			return r(n ^ (t | ~i), e, t, s, o, u)
		}
		function a(e, n) {
			e[n >> 5] |= 128 << n % 32, e[(n + 64 >>> 9 << 4) + 14] = n;
			var r, a, f, l, c, h = 1732584193,
				p = -271733879,
				d = -1732584194,
				v = 271733878;
			for (r = 0; r < e.length; r += 16) a = h, f = p, l = d, c = v, h = i(h, p, d, v, e[r], 7, -680876936), v = i(v, h, p, d, e[r + 1], 12, -389564586), d = i(d, v, h, p, e[r + 2], 17, 606105819), p = i(p, d, v, h, e[r + 3], 22, -1044525330), h = i(h, p, d, v, e[r + 4], 7, -176418897), v = i(v, h, p, d, e[r + 5], 12, 1200080426), d = i(d, v, h, p, e[r + 6], 17, -1473231341), p = i(p, d, v, h, e[r + 7], 22, -45705983), h = i(h, p, d, v, e[r + 8], 7, 1770035416), v = i(v, h, p, d, e[r + 9], 12, -1958414417), d = i(d, v, h, p, e[r + 10], 17, -42063), p = i(p, d, v, h, e[r + 11], 22, -1990404162), h = i(h, p, d, v, e[r + 12], 7, 1804603682), v = i(v, h, p, d, e[r + 13], 12, -40341101), d = i(d, v, h, p, e[r + 14], 17, -1502002290), p = i(p, d, v, h, e[r + 15], 22, 1236535329), h = s(h, p, d, v, e[r + 1], 5, -165796510), v = s(v, h, p, d, e[r + 6], 9, -1069501632), d = s(d, v, h, p, e[r + 11], 14, 643717713), p = s(p, d, v, h, e[r], 20, -373897302), h = s(h, p, d, v, e[r + 5], 5, -701558691), v = s(v, h, p, d, e[r + 10], 9, 38016083), d = s(d, v, h, p, e[r + 15], 14, -660478335), p = s(p, d, v, h, e[r + 4], 20, -405537848), h = s(h, p, d, v, e[r + 9], 5, 568446438), v = s(v, h, p, d, e[r + 14], 9, -1019803690), d = s(d, v, h, p, e[r + 3], 14, -187363961), p = s(p, d, v, h, e[r + 8], 20, 1163531501), h = s(h, p, d, v, e[r + 13], 5, -1444681467), v = s(v, h, p, d, e[r + 2], 9, -51403784), d = s(d, v, h, p, e[r + 7], 14, 1735328473), p = s(p, d, v, h, e[r + 12], 20, -1926607734), h = o(h, p, d, v, e[r + 5], 4, -378558), v = o(v, h, p, d, e[r + 8], 11, -2022574463), d = o(d, v, h, p, e[r + 11], 16, 1839030562), p = o(p, d, v, h, e[r + 14], 23, -35309556), h = o(h, p, d, v, e[r + 1], 4, -1530992060), v = o(v, h, p, d, e[r + 4], 11, 1272893353), d = o(d, v, h, p, e[r + 7], 16, -155497632), p = o(p, d, v, h, e[r + 10], 23, -1094730640), h = o(h, p, d, v, e[r + 13], 4, 681279174), v = o(v, h, p, d, e[r], 11, -358537222), d = o(d, v, h, p, e[r + 3], 16, -722521979), p = o(p, d, v, h, e[r + 6], 23, 76029189), h = o(h, p, d, v, e[r + 9], 4, -640364487), v = o(v, h, p, d, e[r + 12], 11, -421815835), d = o(d, v, h, p, e[r + 15], 16, 530742520), p = o(p, d, v, h, e[r + 2], 23, -995338651), h = u(h, p, d, v, e[r], 6, -198630844), v = u(v, h, p, d, e[r + 7], 10, 1126891415), d = u(d, v, h, p, e[r + 14], 15, -1416354905), p = u(p, d, v, h, e[r + 5], 21, -57434055), h = u(h, p, d, v, e[r + 12], 6, 1700485571), v = u(v, h, p, d, e[r + 3], 10, -1894986606), d = u(d, v, h, p, e[r + 10], 15, -1051523), p = u(p, d, v, h, e[r + 1], 21, -2054922799), h = u(h, p, d, v, e[r + 8], 6, 1873313359), v = u(v, h, p, d, e[r + 15], 10, -30611744), d = u(d, v, h, p, e[r + 6], 15, -1560198380), p = u(p, d, v, h, e[r + 13], 21, 1309151649), h = u(h, p, d, v, e[r + 4], 6, -145523070), v = u(v, h, p, d, e[r + 11], 10, -1120210379), d = u(d, v, h, p, e[r + 2], 15, 718787259), p = u(p, d, v, h, e[r + 9], 21, -343485551), h = t(h, a), p = t(p, f), d = t(d, l), v = t(v, c);
			return [h, p, d, v]
		}
		function f(e) {
			var t, n = "";
			for (t = 0; t < e.length * 32; t += 8) n += String.fromCharCode(e[t >> 5] >>> t % 32 & 255);
			return n
		}
		function l(e) {
			var t, n = [];
			n[(e.length >> 2) - 1] = undefined;
			for (t = 0; t < n.length; t += 1) n[t] = 0;
			for (t = 0; t < e.length * 8; t += 8) n[t >> 5] |= (e.charCodeAt(t / 8) & 255) << t % 32;
			return n
		}
		function c(e) {
			return f(a(l(e), e.length * 8))
		}
		function h(e, t) {
			var n, r = l(e),
				i = [],
				s = [],
				o;
			i[15] = s[15] = undefined, r.length > 16 && (r = a(r, e.length * 8));
			for (n = 0; n < 16; n += 1) i[n] = r[n] ^ 909522486, s[n] = r[n] ^ 1549556828;
			return o = a(i.concat(l(t)), 512 + t.length * 8), f(a(s.concat(o), 640))
		}
		function p(e) {
			var t = "0123456789abcdef",
				n = "",
				r, i;
			for (i = 0; i < e.length; i += 1) r = e.charCodeAt(i), n += t.charAt(r >>> 4 & 15) + t.charAt(r & 15);
			return n
		}
		function d(e) {
			return unescape(encodeURIComponent(e))
		}
		function v(e) {
			return c(d(e))
		}
		function m(e) {
			return p(v(e))
		}
		function g(e, t) {
			return h(d(e), d(t))
		}
		function y(e, t) {
			return p(g(e, t))
		}
		function b(e, t, n) {
			return t ? n ? g(t, e) : y(t, e) : n ? v(e) : m(e)
		}
		return b
	}), !
	function(e, t) {
		typeof module != "undefined" && module.exports ? module.exports.browser = t() : typeof define == "function" && define.amd ? define("vendor/browser", t) : this[e] = t()
	}("bowser", function() {
		function e(e) {
			function n(t) {
				var n = e.match(t);
				return n && n.length > 1 && n[1] || ""
			}
			var r = n(/(ipod|iphone|ipad)/i).toLowerCase(),
				i = /like android/i.test(e),
				s = !i && /android/i.test(e),
				o = n(/version\/(\d+(\.\d+)?)/i),
				u = /tablet/i.test(e),
				a = !u && /[^-]mobi/i.test(e),
				f;
			/opera|opr/i.test(e) ? f = {
				name: "Opera",
				opera: t,
				version: o || n(/(?:opera|opr)[\s\/](\d+(\.\d+)?)/i)
			} : /windows phone/i.test(e) ? f = {
				name: "Windows Phone",
				windowsphone: t,
				msie: t,
				version: n(/iemobile\/(\d+(\.\d+)?)/i)
			} : /msie|trident/i.test(e) ? f = {
				name: "Internet Explorer",
				msie: t,
				version: n(/(?:msie |rv:)(\d+(\.\d+)?)/i)
			} : /chrome|crios|crmo/i.test(e) ? f = {
				name: "Chrome",
				chrome: t,
				version: n(/(?:chrome|crios|crmo)\/(\d+(\.\d+)?)/i)
			} : r ? (f = {
				name: r == "iphone" ? "iPhone" : r == "ipad" ? "iPad" : "iPod"
			}, o && (f.version = o)) : /sailfish/i.test(e) ? f = {
				name: "Sailfish",
				sailfish: t,
				version: n(/sailfish\s?browser\/(\d+(\.\d+)?)/i)
			} : /seamonkey\//i.test(e) ? f = {
				name: "SeaMonkey",
				seamonkey: t,
				version: n(/seamonkey\/(\d+(\.\d+)?)/i)
			} : /firefox|iceweasel/i.test(e) ? (f = {
				name: "Firefox",
				firefox: t,
				version: n(/(?:firefox|iceweasel)[ \/](\d+(\.\d+)?)/i)
			}, /\((mobile|tablet);[^\)]*rv:[\d\.]+\)/i.test(e) && (f.firefoxos = t)) : /silk/i.test(e) ? f = {
				name: "Amazon Silk",
				silk: t,
				version: n(/silk\/(\d+(\.\d+)?)/i)
			} : s ? f = {
				name: "Android",
				version: o
			} : /phantom/i.test(e) ? f = {
				name: "PhantomJS",
				phantom: t,
				version: n(/phantomjs\/(\d+(\.\d+)?)/i)
			} : /blackberry|\bbb\d+/i.test(e) || /rim\stablet/i.test(e) ? f = {
				name: "BlackBerry",
				blackberry: t,
				version: o || n(/blackberry[\d]+\/(\d+(\.\d+)?)/i)
			} : /(web|hpw)os/i.test(e) ? (f = {
				name: "WebOS",
				webos: t,
				version: o || n(/w(?:eb)?osbrowser\/(\d+(\.\d+)?)/i)
			}, /touchpad\//i.test(e) && (f.touchpad = t)) : /bada/i.test(e) ? f = {
				name: "Bada",
				bada: t,
				version: n(/dolfin\/(\d+(\.\d+)?)/i)
			} : /tizen/i.test(e) ? f = {
				name: "Tizen",
				tizen: t,
				version: n(/(?:tizen\s?)?browser\/(\d+(\.\d+)?)/i) || o
			} : /safari/i.test(e) ? f = {
				name: "Safari",
				safari: t,
				version: o
			} : f = {}, /(apple)?webkit/i.test(e) ? (f.name = f.name || "Webkit", f.webkit = t, !f.version && o && (f.version = o)) : !f.opera && /gecko\//i.test(e) && (f.name = f.name || "Gecko", f.gecko = t, f.version = f.version || n(/gecko\/(\d+(\.\d+)?)/i)), s || f.silk ? f.android = t : r && (f[r] = t, f.ios = t);
			var l = "";
			r ? (l = n(/os (\d+([_\s]\d+)*) like mac os x/i), l = l.replace(/[_\s]/g, ".")) : s ? l = n(/android[ \/-](\d+(\.\d+)*)/i) : f.windowsphone ? l = n(/windows phone (?:os)?\s?(\d+(\.\d+)*)/i) : f.webos ? l = n(/(?:web|hpw)os\/(\d+(\.\d+)*)/i) : f.blackberry ? l = n(/rim\stablet\sos\s(\d+(\.\d+)*)/i) : f.bada ? l = n(/bada\/(\d+(\.\d+)*)/i) : f.tizen && (l = n(/tizen[\/\s](\d+(\.\d+)*)/i)), l && (f.osversion = l);
			var c = l.split(".")[0];
			if (u || r == "ipad" || s && (c == 3 || c == 4 && !a) || f.silk) f.tablet = t;
			else if (a || r == "iphone" || r == "ipod" || s || f.blackberry || f.webos || f.bada) f.mobile = t;
			return f.msie && f.version >= 10 || f.chrome && f.version >= 20 || f.firefox && f.version >= 20 || f.safari && f.version >= 6 || f.opera && f.version >= 10 || f.ios && f.osversion && f.osversion.split(".")[0] >= 6 || f.blackberry && f.version >= 10.1 ? f.a = t : f.msie && f.version < 10 || f.chrome && f.version < 20 || f.firefox && f.version < 20 || f.safari && f.version < 6 || f.opera && f.version < 10 || f.ios && f.osversion && f.osversion.split(".")[0] < 6 ? f.c = t : f.x = t, f
		}
		var t = !0,
			n = e(typeof navigator != "undefined" ? navigator.userAgent : "");
		return n._detect = e, n
	}), function(e, t) {
		typeof module == "object" && typeof module.exports == "object" ? module.exports = e.document ? t(e, !0) : function(e) {
			if (!e.document) throw new Error("jQuery requires a window with a document");
			return t(e)
		} : t(e)
	}(typeof window != "undefined" ? window : this, function(e, t) {
		function g(e) {
			var t = e.length,
				n = h.type(e);
			return n === "function" || h.isWindow(e) ? !1 : e.nodeType === 1 && t ? !0 : n === "array" || t === 0 || typeof t == "number" && t > 0 && t - 1 in e
		}
		function S(e, t, n) {
			if (h.isFunction(t)) return h.grep(e, function(e, r) {
				return !!t.call(e, r, e) !== n
			});
			if (t.nodeType) return h.grep(e, function(e) {
				return e === t !== n
			});
			if (typeof t == "string") {
				if (E.test(t)) return h.filter(t, e, n);
				t = h.filter(t, e)
			}
			return h.grep(e, function(e) {
				return h.inArray(e, t) >= 0 !== n
			})
		}
		function A(e, t) {
			do e = e[t];
			while (e && e.nodeType !== 1);
			return e
		}
		function _(e) {
			var t = M[e] = {};
			return h.each(e.match(O) || [], function(e, n) {
				t[n] = !0
			}), t
		}
		function P() {
			T.addEventListener ? (T.removeEventListener("DOMContentLoaded", H, !1), e.removeEventListener("load", H, !1)) : (T.detachEvent("onreadystatechange", H), e.detachEvent("onload", H))
		}
		function H() {
			if (T.addEventListener || event.type === "load" || T.readyState === "complete") P(), h.ready()
		}
		function q(e, t, n) {
			if (n === undefined && e.nodeType === 1) {
				var r = "data-" + t.replace(I, "-$1").toLowerCase();
				n = e.getAttribute(r);
				if (typeof n == "string") {
					try {
						n = n === "true" ? !0 : n === "false" ? !1 : n === "null" ? null : +n + "" === n ? +n : F.test(n) ? h.parseJSON(n) : n
					} catch (i) {}
					h.data(e, t, n)
				} else n = undefined
			}
			return n
		}
		function R(e) {
			var t;
			for (t in e) {
				if (t === "data" && h.isEmptyObject(e[t])) continue;
				if (t !== "toJSON") return !1
			}
			return !0
		}
		function U(e, t, r, i) {
			if (!h.acceptData(e)) return;
			var s, o, u = h.expando,
				a = e.nodeType,
				f = a ? h.cache : e,
				l = a ? e[u] : e[u] && u;
			if ((!l || !f[l] || !i && !f[l].data) && r === undefined && typeof t == "string") return;
			l || (a ? l = e[u] = n.pop() || h.guid++ : l = u), f[l] || (f[l] = a ? {} : {
				toJSON: h.noop
			});
			if (typeof t == "object" || typeof t == "function") i ? f[l] = h.extend(f[l], t) : f[l].data = h.extend(f[l].data, t);
			return o = f[l], i || (o.data || (o.data = {}), o = o.data), r !== undefined && (o[h.camelCase(t)] = r), typeof t == "string" ? (s = o[t], s == null && (s = o[h.camelCase(t)])) : s = o, s
		}
		function z(e, t, n) {
			if (!h.acceptData(e)) return;
			var r, i, s = e.nodeType,
				o = s ? h.cache : e,
				u = s ? e[h.expando] : h.expando;
			if (!o[u]) return;
			if (t) {
				r = n ? o[u] : o[u].data;
				if (r) {
					h.isArray(t) ? t = t.concat(h.map(t, h.camelCase)) : t in r ? t = [t] : (t = h.camelCase(t), t in r ? t = [t] : t = t.split(" ")), i = t.length;
					while (i--) delete r[t[i]];
					if (n ? !R(r) : !h.isEmptyObject(r)) return
				}
			}
			if (!n) {
				delete o[u].data;
				if (!R(o[u])) return
			}
			s ? h.cleanData([e], !0) : l.deleteExpando || o != o.window ? delete o[u] : o[u] = null
		}
		function et() {
			return !0
		}
		function tt() {
			return !1
		}
		function nt() {
			try {
				return T.activeElement
			} catch (e) {}
		}
		function rt(e) {
			var t = it.split("|"),
				n = e.createDocumentFragment();
			if (n.createElement) while (t.length) n.createElement(t.pop());
			return n
		}
		function wt(e, t) {
			var n, r, i = 0,
				s = typeof e.getElementsByTagName !== B ? e.getElementsByTagName(t || "*") : typeof e.querySelectorAll !== B ? e.querySelectorAll(t || "*") : undefined;
			if (!s) for (s = [], n = e.childNodes || e;
			(r = n[i]) != null; i++)!t || h.nodeName(r, t) ? s.push(r) : h.merge(s, wt(r, t));
			return t === undefined || t && h.nodeName(e, t) ? h.merge([e], s) : s
		}
		function Et(e) {
			J.test(e.type) && (e.defaultChecked = e.checked)
		}
		function St(e, t) {
			return h.nodeName(e, "table") && h.nodeName(t.nodeType !== 11 ? t : t.firstChild, "tr") ? e.getElementsByTagName("tbody")[0] || e.appendChild(e.ownerDocument.createElement("tbody")) : e
		}
		function xt(e) {
			return e.type = (h.find.attr(e, "type") !== null) + "/" + e.type, e
		}
		function Tt(e) {
			var t = vt.exec(e.type);
			return t ? e.type = t[1] : e.removeAttribute("type"), e
		}
		function Nt(e, t) {
			var n, r = 0;
			for (;
			(n = e[r]) != null; r++) h._data(n, "globalEval", !t || h._data(t[r], "globalEval"))
		}
		function Ct(e, t) {
			if (t.nodeType !== 1 || !h.hasData(e)) return;
			var n, r, i, s = h._data(e),
				o = h._data(t, s),
				u = s.events;
			if (u) {
				delete o.handle, o.events = {};
				for (n in u) for (r = 0, i = u[n].length; r < i; r++) h.event.add(t, n, u[n][r])
			}
			o.data && (o.data = h.extend({}, o.data))
		}
		function kt(e, t) {
			var n, r, i;
			if (t.nodeType !== 1) return;
			n = t.nodeName.toLowerCase();
			if (!l.noCloneEvent && t[h.expando]) {
				i = h._data(t);
				for (r in i.events) h.removeEvent(t, r, i.handle);
				t.removeAttribute(h.expando)
			}
			if (n === "script" && t.text !== e.text) xt(t).text = e.text, Tt(t);
			else if (n === "object") t.parentNode && (t.outerHTML = e.outerHTML), l.html5Clone && e.innerHTML && !h.trim(t.innerHTML) && (t.innerHTML = e.innerHTML);
			else if (n === "input" && J.test(e.type)) t.defaultChecked = t.checked = e.checked, t.value !== e.value && (t.value = e.value);
			else if (n === "option") t.defaultSelected = t.selected = e.defaultSelected;
			else if (n === "input" || n === "textarea") t.defaultValue = e.defaultValue
		}
		function Ot(t, n) {
			var r, i = h(n.createElement(t)).appendTo(n.body),
				s = e.getDefaultComputedStyle && (r = e.getDefaultComputedStyle(i[0])) ? r.display : h.css(i[0], "display");
			return i.detach(), s
		}
		function Mt(e) {
			var t = T,
				n = At[e];
			if (!n) {
				n = Ot(e, t);
				if (n === "none" || !n) Lt = (Lt || h("<iframe frameborder='0' width='0' height='0'/>")).appendTo(t.documentElement), t = (Lt[0].contentWindow || Lt[0].contentDocument).document, t.write(), t.close(), n = Ot(e, t), Lt.detach();
				At[e] = n
			}
			return n
		}
		function jt(e, t) {
			return {
				get: function() {
					var n = e();
					if (n == null) return;
					if (n) {
						delete this.get;
						return
					}
					return (this.get = t).apply(this, arguments)
				}
			}
		}
		function Vt(e, t) {
			if (t in e) return t;
			var n = t.charAt(0).toUpperCase() + t.slice(1),
				r = t,
				i = Xt.length;
			while (i--) {
				t = Xt[i] + n;
				if (t in e) return t
			}
			return r
		}
		function $t(e, t) {
			var n, r, i, s = [],
				o = 0,
				u = e.length;
			for (; o < u; o++) {
				r = e[o];
				if (!r.style) continue;
				s[o] = h._data(r, "olddisplay"), n = r.style.display, t ? (!s[o] && n === "none" && (r.style.display = ""), r.style.display === "" && V(r) && (s[o] = h._data(r, "olddisplay", Mt(r.nodeName)))) : (i = V(r), (n && n !== "none" || !i) && h._data(r, "olddisplay", i ? n : h.css(r, "display")))
			}
			for (o = 0; o < u; o++) {
				r = e[o];
				if (!r.style) continue;
				if (!t || r.style.display === "none" || r.style.display === "") r.style.display = t ? s[o] || "" : "none"
			}
			return e
		}
		function Jt(e, t, n) {
			var r = Rt.exec(t);
			return r ? Math.max(0, r[1] - (n || 0)) + (r[2] || "px") : t
		}
		function Kt(e, t, n, r, i) {
			var s = n === (r ? "border" : "content") ? 4 : t === "width" ? 1 : 0,
				o = 0;
			for (; s < 4; s += 2) n === "margin" && (o += h.css(e, n + X[s], !0, i)), r ? (n === "content" && (o -= h.css(e, "padding" + X[s], !0, i)), n !== "margin" && (o -= h.css(e, "border" + X[s] + "Width", !0, i))) : (o += h.css(e, "padding" + X[s], !0, i), n !== "padding" && (o += h.css(e, "border" + X[s] + "Width", !0, i)));
			return o
		}
		function Qt(e, t, n) {
			var r = !0,
				i = t === "width" ? e.offsetWidth : e.offsetHeight,
				s = Pt(e),
				o = l.boxSizing && h.css(e, "boxSizing", !1, s) === "border-box";
			if (i <= 0 || i == null) {
				i = Ht(e, t, s);
				if (i < 0 || i == null) i = e.style[t];
				if (Dt.test(i)) return i;
				r = o && (l.boxSizingReliable() || i === e.style[t]), i = parseFloat(i) || 0
			}
			return i + Kt(e, t, n || (o ? "border" : "content"), r, s) + "px"
		}
		function Gt(e, t, n, r, i) {
			return new Gt.prototype.init(e, t, n, r, i)
		}
		function on() {
			return setTimeout(function() {
				Yt = undefined
			}), Yt = h.now()
		}
		function un(e, t) {
			var n, r = {
				height: e
			},
				i = 0;
			t = t ? 1 : 0;
			for (; i < 4; i += 2 - t) n = X[i], r["margin" + n] = r["padding" + n] = e;
			return t && (r.opacity = r.width = e), r
		}
		function an(e, t, n) {
			var r, i = (sn[t] || []).concat(sn["*"]),
				s = 0,
				o = i.length;
			for (; s < o; s++) if (r = i[s].call(n, t, e)) return r
		}
		function fn(e, t, n) {
			var r, i, s, o, u, a, f, c, p = this,
				d = {},
				v = e.style,
				m = e.nodeType && V(e),
				g = h._data(e, "fxshow");
			n.queue || (u = h._queueHooks(e, "fx"), u.unqueued == null && (u.unqueued = 0, a = u.empty.fire, u.empty.fire = function() {
				u.unqueued || a()
			}), u.unqueued++, p.always(function() {
				p.always(function() {
					u.unqueued--, h.queue(e, "fx").length || u.empty.fire()
				})
			})), e.nodeType === 1 && ("height" in t || "width" in t) && (n.overflow = [v.overflow, v.overflowX, v.overflowY], f = h.css(e, "display"), c = f === "none" ? h._data(e, "olddisplay") || Mt(e.nodeName) : f, c === "inline" && h.css(e, "float") === "none" && (!l.inlineBlockNeedsLayout || Mt(e.nodeName) === "inline" ? v.display = "inline-block" : v.zoom = 1)), n.overflow && (v.overflow = "hidden", l.shrinkWrapBlocks() || p.always(function() {
				v.overflow = n.overflow[0], v.overflowX = n.overflow[1], v.overflowY = n.overflow[2]
			}));
			for (r in t) {
				i = t[r];
				if (en.exec(i)) {
					delete t[r], s = s || i === "toggle";
					if (i === (m ? "hide" : "show")) {
						if (i !== "show" || !g || g[r] === undefined) continue;
						m = !0
					}
					d[r] = g && g[r] || h.style(e, r)
				} else f = undefined
			}
			if (!h.isEmptyObject(d)) {
				g ? "hidden" in g && (m = g.hidden) : g = h._data(e, "fxshow", {}), s && (g.hidden = !m), m ? h(e).show() : p.done(function() {
					h(e).hide()
				}), p.done(function() {
					var t;
					h._removeData(e, "fxshow");
					for (t in d) h.style(e, t, d[t])
				});
				for (r in d) o = an(m ? g[r] : 0, r, p), r in g || (g[r] = o.start, m && (o.end = o.start, o.start = r === "width" || r === "height" ? 1 : 0))
			} else(f === "none" ? Mt(e.nodeName) : f) === "inline" && (v.display = f)
		}
		function ln(e, t) {
			var n, r, i, s, o;
			for (n in e) {
				r = h.camelCase(n), i = t[r], s = e[n], h.isArray(s) && (i = s[1], s = e[n] = s[0]), n !== r && (e[r] = s, delete e[n]), o = h.cssHooks[r];
				if (o && "expand" in o) {
					s = o.expand(s), delete e[r];
					for (n in s) n in e || (e[n] = s[n], t[n] = i)
				} else t[r] = i
			}
		}
		function cn(e, t, n) {
			var r, i, s = 0,
				o = rn.length,
				u = h.Deferred().always(function() {
					delete a.elem
				}),
				a = function() {
					if (i) return !1;
					var t = Yt || on(),
						n = Math.max(0, f.startTime + f.duration - t),
						r = n / f.duration || 0,
						s = 1 - r,
						o = 0,
						a = f.tweens.length;
					for (; o < a; o++) f.tweens[o].run(s);
					return u.notifyWith(e, [f, s, n]), s < 1 && a ? n : (u.resolveWith(e, [f]), !1)
				},
				f = u.promise({
					elem: e,
					props: h.extend({}, t),
					opts: h.extend(!0, {
						specialEasing: {}
					}, n),
					originalProperties: t,
					originalOptions: n,
					startTime: Yt || on(),
					duration: n.duration,
					tweens: [],
					createTween: function(t, n) {
						var r = h.Tween(e, f.opts, t, n, f.opts.specialEasing[t] || f.opts.easing);
						return f.tweens.push(r), r
					},
					stop: function(t) {
						var n = 0,
							r = t ? f.tweens.length : 0;
						if (i) return this;
						i = !0;
						for (; n < r; n++) f.tweens[n].run(1);
						return t ? u.resolveWith(e, [f, t]) : u.rejectWith(e, [f, t]), this
					}
				}),
				l = f.props;
			ln(l, f.opts.specialEasing);
			for (; s < o; s++) {
				r = rn[s].call(f, e, l, f.opts);
				if (r) return r
			}
			return h.map(l, an, f), h.isFunction(f.opts.start) && f.opts.start.call(e, f), h.fx.timer(h.extend(a, {
				elem: e,
				anim: f,
				queue: f.opts.queue
			})), f.progress(f.opts.progress).done(f.opts.done, f.opts.complete).fail(f.opts.fail).always(f.opts.always)
		}
		function Fn(e) {
			return function(t, n) {
				typeof t != "string" && (n = t, t = "*");
				var r, i = 0,
					s = t.toLowerCase().match(O) || [];
				if (h.isFunction(n)) while (r = s[i++]) r.charAt(0) === "+" ? (r = r.slice(1) || "*", (e[r] = e[r] || []).unshift(n)) : (e[r] = e[r] || []).push(n)
			}
		}
		function In(e, t, n, r) {
			function o(u) {
				var a;
				return i[u] = !0, h.each(e[u] || [], function(e, u) {
					var f = u(t, n, r);
					if (typeof f == "string" && !s && !i[f]) return t.dataTypes.unshift(f), o(f), !1;
					if (s) return !(a = f)
				}), a
			}
			var i = {},
				s = e === Hn;
			return o(t.dataTypes[0]) || !i["*"] && o("*")
		}
		function qn(e, t) {
			var n, r, i = h.ajaxSettings.flatOptions || {};
			for (r in t) t[r] !== undefined && ((i[r] ? e : n || (n = {}))[r] = t[r]);
			return n && h.extend(!0, e, n), e
		}
		function Rn(e, t, n) {
			var r, i, s, o, u = e.contents,
				a = e.dataTypes;
			while (a[0] === "*") a.shift(), i === undefined && (i = e.mimeType || t.getResponseHeader("Content-Type"));
			if (i) for (o in u) if (u[o] && u[o].test(i)) {
				a.unshift(o);
				break
			}
			if (a[0] in n) s = a[0];
			else {
				for (o in n) {
					if (!a[0] || e.converters[o + " " + a[0]]) {
						s = o;
						break
					}
					r || (r = o)
				}
				s = s || r
			}
			if (s) return s !== a[0] && a.unshift(s), n[s]
		}
		function Un(e, t, n, r) {
			var i, s, o, u, a, f = {},
				l = e.dataTypes.slice();
			if (l[1]) for (o in e.converters) f[o.toLowerCase()] = e.converters[o];
			s = l.shift();
			while (s) {
				e.responseFields[s] && (n[e.responseFields[s]] = t), !a && r && e.dataFilter && (t = e.dataFilter(t, e.dataType)), a = s, s = l.shift();
				if (s) if (s === "*") s = a;
				else if (a !== "*" && a !== s) {
					o = f[a + " " + s] || f["* " + s];
					if (!o) for (i in f) {
						u = i.split(" ");
						if (u[1] === s) {
							o = f[a + " " + u[0]] || f["* " + u[0]];
							if (o) {
								o === !0 ? o = f[i] : f[i] !== !0 && (s = u[0], l.unshift(u[1]));
								break
							}
						}
					}
					if (o !== !0) if (o && e["throws"]) t = o(t);
					else try {
						t = o(t)
					} catch (c) {
						return {
							state: "parsererror",
							error: o ? c : "No conversion from " + a + " to " + s
						}
					}
				}
			}
			return {
				state: "success",
				data: t
			}
		}
		function Jn(e, t, n, r) {
			var i;
			if (h.isArray(t)) h.each(t, function(t, i) {
				n || Wn.test(e) ? r(e, i) : Jn(e + "[" + (typeof i == "object" ? t : "") + "]", i, n, r)
			});
			else if (!n && h.type(t) === "object") for (i in t) Jn(e + "[" + i + "]", t[i], n, r);
			else r(e, t)
		}
		function Yn() {
			try {
				return new e.XMLHttpRequest
			} catch (t) {}
		}
		function Zn() {
			try {
				return new e.ActiveXObject("Microsoft.XMLHTTP")
			} catch (t) {}
		}
		function ir(e) {
			return h.isWindow(e) ? e : e.nodeType === 9 ? e.defaultView || e.parentWindow : !1
		}
		var n = [],
			r = n.slice,
			i = n.concat,
			s = n.push,
			o = n.indexOf,
			u = {},
			a = u.toString,
			f = u.hasOwnProperty,
			l = {},
			c = "1.11.2",
			h = function(e, t) {
				return new h.fn.init(e, t)
			},
			p = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,
			d = /^-ms-/,
			v = /-([\da-z])/gi,
			m = function(e, t) {
				return t.toUpperCase()
			};
		h.fn = h.prototype = {
			jquery: c,
			constructor: h,
			selector: "",
			length: 0,
			toArray: function() {
				return r.call(this)
			},
			get: function(e) {
				return e != null ? e < 0 ? this[e + this.length] : this[e] : r.call(this)
			},
			pushStack: function(e) {
				var t = h.merge(this.constructor(), e);
				return t.prevObject = this, t.context = this.context, t
			},
			each: function(e, t) {
				return h.each(this, e, t)
			},
			map: function(e) {
				return this.pushStack(h.map(this, function(t, n) {
					return e.call(t, n, t)
				}))
			},
			slice: function() {
				return this.pushStack(r.apply(this, arguments))
			},
			first: function() {
				return this.eq(0)
			},
			last: function() {
				return this.eq(-1)
			},
			eq: function(e) {
				var t = this.length,
					n = +e + (e < 0 ? t : 0);
				return this.pushStack(n >= 0 && n < t ? [this[n]] : [])
			},
			end: function() {
				return this.prevObject || this.constructor(null)
			},
			push: s,
			sort: n.sort,
			splice: n.splice
		}, h.extend = h.fn.extend = function() {
			var e, t, n, r, i, s, o = arguments[0] || {},
				u = 1,
				a = arguments.length,
				f = !1;
			typeof o == "boolean" && (f = o, o = arguments[u] || {}, u++), typeof o != "object" && !h.isFunction(o) && (o = {}), u === a && (o = this, u--);
			for (; u < a; u++) if ((i = arguments[u]) != null) for (r in i) {
				e = o[r], n = i[r];
				if (o === n) continue;
				f && n && (h.isPlainObject(n) || (t = h.isArray(n))) ? (t ? (t = !1, s = e && h.isArray(e) ? e : []) : s = e && h.isPlainObject(e) ? e : {}, o[r] = h.extend(f, s, n)) : n !== undefined && (o[r] = n)
			}
			return o
		}, h.extend({
			expando: "jQuery" + (c + Math.random()).replace(/\D/g, ""),
			isReady: !0,
			error: function(e) {
				throw new Error(e)
			},
			noop: function() {},
			isFunction: function(e) {
				return h.type(e) === "function"
			},
			isArray: Array.isArray ||
			function(e) {
				return h.type(e) === "array"
			},
			isWindow: function(e) {
				return e != null && e == e.window
			},
			isNumeric: function(e) {
				return !h.isArray(e) && e - parseFloat(e) + 1 >= 0
			},
			isEmptyObject: function(e) {
				var t;
				for (t in e) return !1;
				return !0
			},
			isPlainObject: function(e) {
				var t;
				if (!e || h.type(e) !== "object" || e.nodeType || h.isWindow(e)) return !1;
				try {
					if (e.constructor && !f.call(e, "constructor") && !f.call(e.constructor.prototype, "isPrototypeOf")) return !1
				} catch (n) {
					return !1
				}
				if (l.ownLast) for (t in e) return f.call(e, t);
				for (t in e);
				return t === undefined || f.call(e, t)
			},
			type: function(e) {
				return e == null ? e + "" : typeof e == "object" || typeof e == "function" ? u[a.call(e)] || "object" : typeof e
			},
			globalEval: function(t) {
				t && h.trim(t) && (e.execScript ||
				function(t) {
					e.eval.call(e, t)
				})(t)
			},
			camelCase: function(e) {
				return e.replace(d, "ms-").replace(v, m)
			},
			nodeName: function(e, t) {
				return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase()
			},
			each: function(e, t, n) {
				var r, i = 0,
					s = e.length,
					o = g(e);
				if (n) if (o) for (; i < s; i++) {
					r = t.apply(e[i], n);
					if (r === !1) break
				} else for (i in e) {
					r = t.apply(e[i], n);
					if (r === !1) break
				} else if (o) for (; i < s; i++) {
					r = t.call(e[i], i, e[i]);
					if (r === !1) break
				} else for (i in e) {
					r = t.call(e[i], i, e[i]);
					if (r === !1) break
				}
				return e
			},
			trim: function(e) {
				return e == null ? "" : (e + "").replace(p, "")
			},
			makeArray: function(e, t) {
				var n = t || [];
				return e != null && (g(Object(e)) ? h.merge(n, typeof e == "string" ? [e] : e) : s.call(n, e)), n
			},
			inArray: function(e, t, n) {
				var r;
				if (t) {
					if (o) return o.call(t, e, n);
					r = t.length, n = n ? n < 0 ? Math.max(0, r + n) : n : 0;
					for (; n < r; n++) if (n in t && t[n] === e) return n
				}
				return -1
			},
			merge: function(e, t) {
				var n = +t.length,
					r = 0,
					i = e.length;
				while (r < n) e[i++] = t[r++];
				if (n !== n) while (t[r] !== undefined) e[i++] = t[r++];
				return e.length = i, e
			},
			grep: function(e, t, n) {
				var r, i = [],
					s = 0,
					o = e.length,
					u = !n;
				for (; s < o; s++) r = !t(e[s], s), r !== u && i.push(e[s]);
				return i
			},
			map: function(e, t, n) {
				var r, s = 0,
					o = e.length,
					u = g(e),
					a = [];
				if (u) for (; s < o; s++) r = t(e[s], s, n), r != null && a.push(r);
				else for (s in e) r = t(e[s], s, n), r != null && a.push(r);
				return i.apply([], a)
			},
			guid: 1,
			proxy: function(e, t) {
				var n, i, s;
				return typeof t == "string" && (s = e[t], t = e, e = s), h.isFunction(e) ? (n = r.call(arguments, 2), i = function() {
					return e.apply(t || this, n.concat(r.call(arguments)))
				}, i.guid = e.guid = e.guid || h.guid++, i) : undefined
			},
			now: function() {
				return +(new Date)
			},
			support: l
		}), h.each("Boolean Number String Function Array Date RegExp Object Error".split(" "), function(e, t) {
			u["[object " + t + "]"] = t.toLowerCase()
		});
		var y = function(e) {
				function ot(e, t, r, i) {
					var s, u, f, l, c, d, g, y, S, x;
					(t ? t.ownerDocument || t : E) !== p && h(t), t = t || p, r = r || [], l = t.nodeType;
					if (typeof e != "string" || !e || l !== 1 && l !== 9 && l !== 11) return r;
					if (!i && v) {
						if (l !== 11 && (s = Z.exec(e))) if (f = s[1]) {
							if (l === 9) {
								u = t.getElementById(f);
								if (!u || !u.parentNode) return r;
								if (u.id === f) return r.push(u), r
							} else if (t.ownerDocument && (u = t.ownerDocument.getElementById(f)) && b(t, u) && u.id === f) return r.push(u), r
						} else {
							if (s[2]) return D.apply(r, t.getElementsByTagName(e)), r;
							if ((f = s[3]) && n.getElementsByClassName) return D.apply(r, t.getElementsByClassName(f)), r
						}
						if (n.qsa && (!m || !m.test(e))) {
							y = g = w, S = t, x = l !== 1 && e;
							if (l === 1 && t.nodeName.toLowerCase() !== "object") {
								d = o(e), (g = t.getAttribute("id")) ? y = g.replace(tt, "\\$&") : t.setAttribute("id", y), y = "[id='" + y + "'] ", c = d.length;
								while (c--) d[c] = y + gt(d[c]);
								S = et.test(e) && vt(t.parentNode) || t, x = d.join(",")
							}
							if (x) try {
								return D.apply(r, S.querySelectorAll(x)), r
							} catch (T) {} finally {
								g || t.removeAttribute("id")
							}
						}
					}
					return a(e.replace(z, "$1"), t, r, i)
				}
				function ut() {
					function t(n, i) {
						return e.push(n + " ") > r.cacheLength && delete t[e.shift()], t[n + " "] = i
					}
					var e = [];
					return t
				}
				function at(e) {
					return e[w] = !0, e
				}
				function ft(e) {
					var t = p.createElement("div");
					try {
						return !!e(t)
					} catch (n) {
						return !1
					} finally {
						t.parentNode && t.parentNode.removeChild(t), t = null
					}
				}
				function lt(e, t) {
					var n = e.split("|"),
						i = e.length;
					while (i--) r.attrHandle[n[i]] = t
				}
				function ct(e, t) {
					var n = t && e,
						r = n && e.nodeType === 1 && t.nodeType === 1 && (~t.sourceIndex || L) - (~e.sourceIndex || L);
					if (r) return r;
					if (n) while (n = n.nextSibling) if (n === t) return -1;
					return e ? 1 : -1
				}
				function ht(e) {
					return function(t) {
						var n = t.nodeName.toLowerCase();
						return n === "input" && t.type === e
					}
				}
				function pt(e) {
					return function(t) {
						var n = t.nodeName.toLowerCase();
						return (n === "input" || n === "button") && t.type === e
					}
				}
				function dt(e) {
					return at(function(t) {
						return t = +t, at(function(n, r) {
							var i, s = e([], n.length, t),
								o = s.length;
							while (o--) n[i = s[o]] && (n[i] = !(r[i] = n[i]))
						})
					})
				}
				function vt(e) {
					return e && typeof e.getElementsByTagName != "undefined" && e
				}
				function mt() {}
				function gt(e) {
					var t = 0,
						n = e.length,
						r = "";
					for (; t < n; t++) r += e[t].value;
					return r
				}
				function yt(e, t, n) {
					var r = t.dir,
						i = n && r === "parentNode",
						s = x++;
					return t.first ?
					function(t, n, s) {
						while (t = t[r]) if (t.nodeType === 1 || i) return e(t, n, s)
					} : function(t, n, o) {
						var u, a, f = [S, s];
						if (o) {
							while (t = t[r]) if (t.nodeType === 1 || i) if (e(t, n, o)) return !0
						} else while (t = t[r]) if (t.nodeType === 1 || i) {
							a = t[w] || (t[w] = {});
							if ((u = a[r]) && u[0] === S && u[1] === s) return f[2] = u[2];
							a[r] = f;
							if (f[2] = e(t, n, o)) return !0
						}
					}
				}
				function bt(e) {
					return e.length > 1 ?
					function(t, n, r) {
						var i = e.length;
						while (i--) if (!e[i](t, n, r)) return !1;
						return !0
					} : e[0]
				}
				function wt(e, t, n) {
					var r = 0,
						i = t.length;
					for (; r < i; r++) ot(e, t[r], n);
					return n
				}
				function Et(e, t, n, r, i) {
					var s, o = [],
						u = 0,
						a = e.length,
						f = t != null;
					for (; u < a; u++) if (s = e[u]) if (!n || n(s, r, i)) o.push(s), f && t.push(u);
					return o
				}
				function St(e, t, n, r, i, s) {
					return r && !r[w] && (r = St(r)), i && !i[w] && (i = St(i, s)), at(function(s, o, u, a) {
						var f, l, c, h = [],
							p = [],
							d = o.length,
							v = s || wt(t || "*", u.nodeType ? [u] : u, []),
							m = e && (s || !t) ? Et(v, h, e, u, a) : v,
							g = n ? i || (s ? e : d || r) ? [] : o : m;
						n && n(m, g, u, a);
						if (r) {
							f = Et(g, p), r(f, [], u, a), l = f.length;
							while (l--) if (c = f[l]) g[p[l]] = !(m[p[l]] = c)
						}
						if (s) {
							if (i || e) {
								if (i) {
									f = [], l = g.length;
									while (l--)(c = g[l]) && f.push(m[l] = c);
									i(null, g = [], f, a)
								}
								l = g.length;
								while (l--)(c = g[l]) && (f = i ? H(s, c) : h[l]) > -1 && (s[f] = !(o[f] = c))
							}
						} else g = Et(g === o ? g.splice(d, g.length) : g), i ? i(null, o, g, a) : D.apply(o, g)
					})
				}
				function xt(e) {
					var t, n, i, s = e.length,
						o = r.relative[e[0].type],
						u = o || r.relative[" "],
						a = o ? 1 : 0,
						l = yt(function(e) {
							return e === t
						}, u, !0),
						c = yt(function(e) {
							return H(t, e) > -1
						}, u, !0),
						h = [function(e, n, r) {
							var i = !o && (r || n !== f) || ((t = n).nodeType ? l(e, n, r) : c(e, n, r));
							return t = null, i
						}];
					for (; a < s; a++) if (n = r.relative[e[a].type]) h = [yt(bt(h), n)];
					else {
						n = r.filter[e[a].type].apply(null, e[a].matches);
						if (n[w]) {
							i = ++a;
							for (; i < s; i++) if (r.relative[e[i].type]) break;
							return St(a > 1 && bt(h), a > 1 && gt(e.slice(0, a - 1).concat({
								value: e[a - 2].type === " " ? "*" : ""
							})).replace(z, "$1"), n, a < i && xt(e.slice(a, i)), i < s && xt(e = e.slice(i)), i < s && gt(e))
						}
						h.push(n)
					}
					return bt(h)
				}
				function Tt(e, t) {
					var n = t.length > 0,
						i = e.length > 0,
						s = function(s, o, u, a, l) {
							var c, h, d, v = 0,
								m = "0",
								g = s && [],
								y = [],
								b = f,
								w = s || i && r.find.TAG("*", l),
								E = S += b == null ? 1 : Math.random() || .1,
								x = w.length;
							l && (f = o !== p && o);
							for (; m !== x && (c = w[m]) != null; m++) {
								if (i && c) {
									h = 0;
									while (d = e[h++]) if (d(c, o, u)) {
										a.push(c);
										break
									}
									l && (S = E)
								}
								n && ((c = !d && c) && v--, s && g.push(c))
							}
							v += m;
							if (n && m !== v) {
								h = 0;
								while (d = t[h++]) d(g, y, o, u);
								if (s) {
									if (v > 0) while (m--)!g[m] && !y[m] && (y[m] = M.call(a));
									y = Et(y)
								}
								D.apply(a, y), l && !s && y.length > 0 && v + t.length > 1 && ot.uniqueSort(a)
							}
							return l && (S = E, f = b), g
						};
					return n ? at(s) : s
				}
				var t, n, r, i, s, o, u, a, f, l, c, h, p, d, v, m, g, y, b, w = "sizzle" + 1 * new Date,
					E = e.document,
					S = 0,
					x = 0,
					T = ut(),
					N = ut(),
					C = ut(),
					k = function(e, t) {
						return e === t && (c = !0), 0
					},
					L = 1 << 31,
					A = {}.hasOwnProperty,
					O = [],
					M = O.pop,
					_ = O.push,
					D = O.push,
					P = O.slice,
					H = function(e, t) {
						var n = 0,
							r = e.length;
						for (; n < r; n++) if (e[n] === t) return n;
						return -1
					},
					B = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
					j = "[\\x20\\t\\r\\n\\f]",
					F = "(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",
					I = F.replace("w", "w#"),
					q = "\\[" + j + "*(" + F + ")(?:" + j + "*([*^$|!~]?=)" + j + "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + I + "))|)" + j + "*\\]",
					R = ":(" + F + ")(?:\\((" + "('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|" + "((?:\\\\.|[^\\\\()[\\]]|" + q + ")*)|" + ".*" + ")\\)|)",
					U = new RegExp(j + "+", "g"),
					z = new RegExp("^" + j + "+|((?:^|[^\\\\])(?:\\\\.)*)" + j + "+$", "g"),
					W = new RegExp("^" + j + "*," + j + "*"),
					X = new RegExp("^" + j + "*([>+~]|" + j + ")" + j + "*"),
					V = new RegExp("=" + j + "*([^\\]'\"]*?)" + j + "*\\]", "g"),
					$ = new RegExp(R),
					J = new RegExp("^" + I + "$"),
					K = {
						ID: new RegExp("^#(" + F + ")"),
						CLASS: new RegExp("^\\.(" + F + ")"),
						TAG: new RegExp("^(" + F.replace("w", "w*") + ")"),
						ATTR: new RegExp("^" + q),
						PSEUDO: new RegExp("^" + R),
						CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + j + "*(even|odd|(([+-]|)(\\d*)n|)" + j + "*(?:([+-]|)" + j + "*(\\d+)|))" + j + "*\\)|)", "i"),
						bool: new RegExp("^(?:" + B + ")$", "i"),
						needsContext: new RegExp("^" + j + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + j + "*((?:-\\d)?\\d*)" + j + "*\\)|)(?=[^-]|$)", "i")
					},
					Q = /^(?:input|select|textarea|button)$/i,
					G = /^h\d$/i,
					Y = /^[^{]+\{\s*\[native \w/,
					Z = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
					et = /[+~]/,
					tt = /'|\\/g,
					nt = new RegExp("\\\\([\\da-f]{1,6}" + j + "?|(" + j + ")|.)", "ig"),
					rt = function(e, t, n) {
						var r = "0x" + t - 65536;
						return r !== r || n ? t : r < 0 ? String.fromCharCode(r + 65536) : String.fromCharCode(r >> 10 | 55296, r & 1023 | 56320)
					},
					it = function() {
						h()
					};
				try {
					D.apply(O = P.call(E.childNodes), E.childNodes), O[E.childNodes.length].nodeType
				} catch (st) {
					D = {
						apply: O.length ?
						function(e, t) {
							_.apply(e, P.call(t))
						} : function(e, t) {
							var n = e.length,
								r = 0;
							while (e[n++] = t[r++]);
							e.length = n - 1
						}
					}
				}
				n = ot.support = {}, s = ot.isXML = function(e) {
					var t = e && (e.ownerDocument || e).documentElement;
					return t ? t.nodeName !== "HTML" : !1
				}, h = ot.setDocument = function(e) {
					var t, i, o = e ? e.ownerDocument || e : E;
					if (o === p || o.nodeType !== 9 || !o.documentElement) return p;
					p = o, d = o.documentElement, i = o.defaultView, i && i !== i.top && (i.addEventListener ? i.addEventListener("unload", it, !1) : i.attachEvent && i.attachEvent("onunload", it)), v = !s(o), n.attributes = ft(function(e) {
						return e.className = "i", !e.getAttribute("className")
					}), n.getElementsByTagName = ft(function(e) {
						return e.appendChild(o.createComment("")), !e.getElementsByTagName("*").length
					}), n.getElementsByClassName = Y.test(o.getElementsByClassName), n.getById = ft(function(e) {
						return d.appendChild(e).id = w, !o.getElementsByName || !o.getElementsByName(w).length
					}), n.getById ? (r.find.ID = function(e, t) {
						if (typeof t.getElementById != "undefined" && v) {
							var n = t.getElementById(e);
							return n && n.parentNode ? [n] : []
						}
					}, r.filter.ID = function(e) {
						var t = e.replace(nt, rt);
						return function(e) {
							return e.getAttribute("id") === t
						}
					}) : (delete r.find.ID, r.filter.ID = function(e) {
						var t = e.replace(nt, rt);
						return function(e) {
							var n = typeof e.getAttributeNode != "undefined" && e.getAttributeNode("id");
							return n && n.value === t
						}
					}), r.find.TAG = n.getElementsByTagName ?
					function(e, t) {
						if (typeof t.getElementsByTagName != "undefined") return t.getElementsByTagName(e);
						if (n.qsa) return t.querySelectorAll(e)
					} : function(e, t) {
						var n, r = [],
							i = 0,
							s = t.getElementsByTagName(e);
						if (e === "*") {
							while (n = s[i++]) n.nodeType === 1 && r.push(n);
							return r
						}
						return s
					}, r.find.CLASS = n.getElementsByClassName &&
					function(e, t) {
						if (v) return t.getElementsByClassName(e)
					}, g = [], m = [];
					if (n.qsa = Y.test(o.querySelectorAll)) ft(function(e) {
						d.appendChild(e).innerHTML = "<a id='" + w + "'></a>" + "<select id='" + w + "-\f]' msallowcapture=''>" + "<option selected=''></option></select>", e.querySelectorAll("[msallowcapture^='']").length && m.push("[*^$]=" + j + "*(?:''|\"\")"), e.querySelectorAll("[selected]").length || m.push("\\[" + j + "*(?:value|" + B + ")"), e.querySelectorAll("[id~=" + w + "-]").length || m.push("~="), e.querySelectorAll(":checked").length || m.push(":checked"), e.querySelectorAll("a#" + w + "+*").length || m.push(".#.+[+~]")
					}), ft(function(e) {
						var t = o.createElement("input");
						t.setAttribute("type", "hidden"), e.appendChild(t).setAttribute("name", "D"), e.querySelectorAll("[name=d]").length && m.push("name" + j + "*[*^$|!~]?="), e.querySelectorAll(":enabled").length || m.push(":enabled", ":disabled"), e.querySelectorAll("*,:x"), m.push(",.*:")
					});
					return (n.matchesSelector = Y.test(y = d.matches || d.webkitMatchesSelector || d.mozMatchesSelector || d.oMatchesSelector || d.msMatchesSelector)) && ft(function(e) {
						n.disconnectedMatch = y.call(e, "div"), y.call(e, "[s!='']:x"), g.push("!=", R)
					}), m = m.length && new RegExp(m.join("|")), g = g.length && new RegExp(g.join("|")), t = Y.test(d.compareDocumentPosition), b = t || Y.test(d.contains) ?
					function(e, t) {
						var n = e.nodeType === 9 ? e.documentElement : e,
							r = t && t.parentNode;
						return e === r || !! r && r.nodeType === 1 && !! (n.contains ? n.contains(r) : e.compareDocumentPosition && e.compareDocumentPosition(r) & 16)
					} : function(e, t) {
						if (t) while (t = t.parentNode) if (t === e) return !0;
						return !1
					}, k = t ?
					function(e, t) {
						if (e === t) return c = !0, 0;
						var r = !e.compareDocumentPosition - !t.compareDocumentPosition;
						return r ? r : (r = (e.ownerDocument || e) === (t.ownerDocument || t) ? e.compareDocumentPosition(t) : 1, r & 1 || !n.sortDetached && t.compareDocumentPosition(e) === r ? e === o || e.ownerDocument === E && b(E, e) ? -1 : t === o || t.ownerDocument === E && b(E, t) ? 1 : l ? H(l, e) - H(l, t) : 0 : r & 4 ? -1 : 1)
					} : function(e, t) {
						if (e === t) return c = !0, 0;
						var n, r = 0,
							i = e.parentNode,
							s = t.parentNode,
							u = [e],
							a = [t];
						if (!i || !s) return e === o ? -1 : t === o ? 1 : i ? -1 : s ? 1 : l ? H(l, e) - H(l, t) : 0;
						if (i === s) return ct(e, t);
						n = e;
						while (n = n.parentNode) u.unshift(n);
						n = t;
						while (n = n.parentNode) a.unshift(n);
						while (u[r] === a[r]) r++;
						return r ? ct(u[r], a[r]) : u[r] === E ? -1 : a[r] === E ? 1 : 0
					}, o
				}, ot.matches = function(e, t) {
					return ot(e, null, null, t)
				}, ot.matchesSelector = function(e, t) {
					(e.ownerDocument || e) !== p && h(e), t = t.replace(V, "='$1']");
					if (n.matchesSelector && v && (!g || !g.test(t)) && (!m || !m.test(t))) try {
						var r = y.call(e, t);
						if (r || n.disconnectedMatch || e.document && e.document.nodeType !== 11) return r
					} catch (i) {}
					return ot(t, p, null, [e]).length > 0
				}, ot.contains = function(e, t) {
					return (e.ownerDocument || e) !== p && h(e), b(e, t)
				}, ot.attr = function(e, t) {
					(e.ownerDocument || e) !== p && h(e);
					var i = r.attrHandle[t.toLowerCase()],
						s = i && A.call(r.attrHandle, t.toLowerCase()) ? i(e, t, !v) : undefined;
					return s !== undefined ? s : n.attributes || !v ? e.getAttribute(t) : (s = e.getAttributeNode(t)) && s.specified ? s.value : null
				}, ot.error = function(e) {
					throw new Error("Syntax error, unrecognized expression: " + e)
				}, ot.uniqueSort = function(e) {
					var t, r = [],
						i = 0,
						s = 0;
					c = !n.detectDuplicates, l = !n.sortStable && e.slice(0), e.sort(k);
					if (c) {
						while (t = e[s++]) t === e[s] && (i = r.push(s));
						while (i--) e.splice(r[i], 1)
					}
					return l = null, e
				}, i = ot.getText = function(e) {
					var t, n = "",
						r = 0,
						s = e.nodeType;
					if (!s) while (t = e[r++]) n += i(t);
					else if (s === 1 || s === 9 || s === 11) {
						if (typeof e.textContent == "string") return e.textContent;
						for (e = e.firstChild; e; e = e.nextSibling) n += i(e)
					} else if (s === 3 || s === 4) return e.nodeValue;
					return n
				}, r = ot.selectors = {
					cacheLength: 50,
					createPseudo: at,
					match: K,
					attrHandle: {},
					find: {},
					relative: {
						">": {
							dir: "parentNode",
							first: !0
						},
						" ": {
							dir: "parentNode"
						},
						"+": {
							dir: "previousSibling",
							first: !0
						},
						"~": {
							dir: "previousSibling"
						}
					},
					preFilter: {
						ATTR: function(e) {
							return e[1] = e[1].replace(nt, rt), e[3] = (e[3] || e[4] || e[5] || "").replace(nt, rt), e[2] === "~=" && (e[3] = " " + e[3] + " "), e.slice(0, 4)
						},
						CHILD: function(e) {
							return e[1] = e[1].toLowerCase(), e[1].slice(0, 3) === "nth" ? (e[3] || ot.error(e[0]), e[4] = +(e[4] ? e[5] + (e[6] || 1) : 2 * (e[3] === "even" || e[3] === "odd")), e[5] = +(e[7] + e[8] || e[3] === "odd")) : e[3] && ot.error(e[0]), e
						},
						PSEUDO: function(e) {
							var t, n = !e[6] && e[2];
							return K.CHILD.test(e[0]) ? null : (e[3] ? e[2] = e[4] || e[5] || "" : n && $.test(n) && (t = o(n, !0)) && (t = n.indexOf(")", n.length - t) - n.length) && (e[0] = e[0].slice(0, t), e[2] = n.slice(0, t)), e.slice(0, 3))
						}
					},
					filter: {
						TAG: function(e) {
							var t = e.replace(nt, rt).toLowerCase();
							return e === "*" ?
							function() {
								return !0
							} : function(e) {
								return e.nodeName && e.nodeName.toLowerCase() === t
							}
						},
						CLASS: function(e) {
							var t = T[e + " "];
							return t || (t = new RegExp("(^|" + j + ")" + e + "(" + j + "|$)")) && T(e, function(e) {
								return t.test(typeof e.className == "string" && e.className || typeof e.getAttribute != "undefined" && e.getAttribute("class") || "")
							})
						},
						ATTR: function(e, t, n) {
							return function(r) {
								var i = ot.attr(r, e);
								return i == null ? t === "!=" : t ? (i += "", t === "=" ? i === n : t === "!=" ? i !== n : t === "^=" ? n && i.indexOf(n) === 0 : t === "*=" ? n && i.indexOf(n) > -1 : t === "$=" ? n && i.slice(-n.length) === n : t === "~=" ? (" " + i.replace(U, " ") + " ").indexOf(n) > -1 : t === "|=" ? i === n || i.slice(0, n.length + 1) === n + "-" : !1) : !0
							}
						},
						CHILD: function(e, t, n, r, i) {
							var s = e.slice(0, 3) !== "nth",
								o = e.slice(-4) !== "last",
								u = t === "of-type";
							return r === 1 && i === 0 ?
							function(e) {
								return !!e.parentNode
							} : function(t, n, a) {
								var f, l, c, h, p, d, v = s !== o ? "nextSibling" : "previousSibling",
									m = t.parentNode,
									g = u && t.nodeName.toLowerCase(),
									y = !a && !u;
								if (m) {
									if (s) {
										while (v) {
											c = t;
											while (c = c[v]) if (u ? c.nodeName.toLowerCase() === g : c.nodeType === 1) return !1;
											d = v = e === "only" && !d && "nextSibling"
										}
										return !0
									}
									d = [o ? m.firstChild : m.lastChild];
									if (o && y) {
										l = m[w] || (m[w] = {}), f = l[e] || [], p = f[0] === S && f[1], h = f[0] === S && f[2], c = p && m.childNodes[p];
										while (c = ++p && c && c[v] || (h = p = 0) || d.pop()) if (c.nodeType === 1 && ++h && c === t) {
											l[e] = [S, p, h];
											break
										}
									} else if (y && (f = (t[w] || (t[w] = {}))[e]) && f[0] === S) h = f[1];
									else while (c = ++p && c && c[v] || (h = p = 0) || d.pop()) if ((u ? c.nodeName.toLowerCase() === g : c.nodeType === 1) && ++h) {
										y && ((c[w] || (c[w] = {}))[e] = [S, h]);
										if (c === t) break
									}
									return h -= i, h === r || h % r === 0 && h / r >= 0
								}
							}
						},
						PSEUDO: function(e, t) {
							var n, i = r.pseudos[e] || r.setFilters[e.toLowerCase()] || ot.error("unsupported pseudo: " + e);
							return i[w] ? i(t) : i.length > 1 ? (n = [e, e, "", t], r.setFilters.hasOwnProperty(e.toLowerCase()) ? at(function(e, n) {
								var r, s = i(e, t),
									o = s.length;
								while (o--) r = H(e, s[o]), e[r] = !(n[r] = s[o])
							}) : function(e) {
								return i(e, 0, n)
							}) : i
						}
					},
					pseudos: {
						not: at(function(e) {
							var t = [],
								n = [],
								r = u(e.replace(z, "$1"));
							return r[w] ? at(function(e, t, n, i) {
								var s, o = r(e, null, i, []),
									u = e.length;
								while (u--) if (s = o[u]) e[u] = !(t[u] = s)
							}) : function(e, i, s) {
								return t[0] = e, r(t, null, s, n), t[0] = null, !n.pop()
							}
						}),
						has: at(function(e) {
							return function(t) {
								return ot(e, t).length > 0
							}
						}),
						contains: at(function(e) {
							return e = e.replace(nt, rt), function(t) {
								return (t.textContent || t.innerText || i(t)).indexOf(e) > -1
							}
						}),
						lang: at(function(e) {
							return J.test(e || "") || ot.error("unsupported lang: " + e), e = e.replace(nt, rt).toLowerCase(), function(t) {
								var n;
								do
								if (n = v ? t.lang : t.getAttribute("xml:lang") || t.getAttribute("lang")) return n = n.toLowerCase(), n === e || n.indexOf(e + "-") === 0;
								while ((t = t.parentNode) && t.nodeType === 1);
								return !1
							}
						}),
						target: function(t) {
							var n = e.location && e.location.hash;
							return n && n.slice(1) === t.id
						},
						root: function(e) {
							return e === d
						},
						focus: function(e) {
							return e === p.activeElement && (!p.hasFocus || p.hasFocus()) && !! (e.type || e.href || ~e.tabIndex)
						},
						enabled: function(e) {
							return e.disabled === !1
						},
						disabled: function(e) {
							return e.disabled === !0
						},
						checked: function(e) {
							var t = e.nodeName.toLowerCase();
							return t === "input" && !! e.checked || t === "option" && !! e.selected
						},
						selected: function(e) {
							return e.parentNode && e.parentNode.selectedIndex, e.selected === !0
						},
						empty: function(e) {
							for (e = e.firstChild; e; e = e.nextSibling) if (e.nodeType < 6) return !1;
							return !0
						},
						parent: function(e) {
							return !r.pseudos.empty(e)
						},
						header: function(e) {
							return G.test(e.nodeName)
						},
						input: function(e) {
							return Q.test(e.nodeName)
						},
						button: function(e) {
							var t = e.nodeName.toLowerCase();
							return t === "input" && e.type === "button" || t === "button"
						},
						text: function(e) {
							var t;
							return e.nodeName.toLowerCase() === "input" && e.type === "text" && ((t = e.getAttribute("type")) == null || t.toLowerCase() === "text")
						},
						first: dt(function() {
							return [0]
						}),
						last: dt(function(e, t) {
							return [t - 1]
						}),
						eq: dt(function(e, t, n) {
							return [n < 0 ? n + t : n]
						}),
						even: dt(function(e, t) {
							var n = 0;
							for (; n < t; n += 2) e.push(n);
							return e
						}),
						odd: dt(function(e, t) {
							var n = 1;
							for (; n < t; n += 2) e.push(n);
							return e
						}),
						lt: dt(function(e, t, n) {
							var r = n < 0 ? n + t : n;
							for (; --r >= 0;) e.push(r);
							return e
						}),
						gt: dt(function(e, t, n) {
							var r = n < 0 ? n + t : n;
							for (; ++r < t;) e.push(r);
							return e
						})
					}
				}, r.pseudos.nth = r.pseudos.eq;
				for (t in {
					radio: !0,
					checkbox: !0,
					file: !0,
					password: !0,
					image: !0
				}) r.pseudos[t] = ht(t);
				for (t in {
					submit: !0,
					reset: !0
				}) r.pseudos[t] = pt(t);
				return mt.prototype = r.filters = r.pseudos, r.setFilters = new mt, o = ot.tokenize = function(e, t) {
					var n, i, s, o, u, a, f, l = N[e + " "];
					if (l) return t ? 0 : l.slice(0);
					u = e, a = [], f = r.preFilter;
					while (u) {
						if (!n || (i = W.exec(u))) i && (u = u.slice(i[0].length) || u), a.push(s = []);
						n = !1;
						if (i = X.exec(u)) n = i.shift(), s.push({
							value: n,
							type: i[0].replace(z, " ")
						}), u = u.slice(n.length);
						for (o in r.filter)(i = K[o].exec(u)) && (!f[o] || (i = f[o](i))) && (n = i.shift(), s.push({
							value: n,
							type: o,
							matches: i
						}), u = u.slice(n.length));
						if (!n) break
					}
					return t ? u.length : u ? ot.error(e) : N(e, a).slice(0)
				}, u = ot.compile = function(e, t) {
					var n, r = [],
						i = [],
						s = C[e + " "];
					if (!s) {
						t || (t = o(e)), n = t.length;
						while (n--) s = xt(t[n]), s[w] ? r.push(s) : i.push(s);
						s = C(e, Tt(i, r)), s.selector = e
					}
					return s
				}, a = ot.select = function(e, t, i, s) {
					var a, f, l, c, h, p = typeof e == "function" && e,
						d = !s && o(e = p.selector || e);
					i = i || [];
					if (d.length === 1) {
						f = d[0] = d[0].slice(0);
						if (f.length > 2 && (l = f[0]).type === "ID" && n.getById && t.nodeType === 9 && v && r.relative[f[1].type]) {
							t = (r.find.ID(l.matches[0].replace(nt, rt), t) || [])[0];
							if (!t) return i;
							p && (t = t.parentNode), e = e.slice(f.shift().value.length)
						}
						a = K.needsContext.test(e) ? 0 : f.length;
						while (a--) {
							l = f[a];
							if (r.relative[c = l.type]) break;
							if (h = r.find[c]) if (s = h(l.matches[0].replace(nt, rt), et.test(f[0].type) && vt(t.parentNode) || t)) {
								f.splice(a, 1), e = s.length && gt(f);
								if (!e) return D.apply(i, s), i;
								break
							}
						}
					}
					return (p || u(e, d))(s, t, !v, i, et.test(e) && vt(t.parentNode) || t), i
				}, n.sortStable = w.split("").sort(k).join("") === w, n.detectDuplicates = !! c, h(), n.sortDetached = ft(function(e) {
					return e.compareDocumentPosition(p.createElement("div")) & 1
				}), ft(function(e) {
					return e.innerHTML = "<a href='#'></a>", e.firstChild.getAttribute("href") === "#"
				}) || lt("type|href|height|width", function(e, t, n) {
					if (!n) return e.getAttribute(t, t.toLowerCase() === "type" ? 1 : 2)
				}), (!n.attributes || !ft(function(e) {
					return e.innerHTML = "<input/>", e.firstChild.setAttribute("value", ""), e.firstChild.getAttribute("value") === ""
				})) && lt("value", function(e, t, n) {
					if (!n && e.nodeName.toLowerCase() === "input") return e.defaultValue
				}), ft(function(e) {
					return e.getAttribute("disabled") == null
				}) || lt(B, function(e, t, n) {
					var r;
					if (!n) return e[t] === !0 ? t.toLowerCase() : (r = e.getAttributeNode(t)) && r.specified ? r.value : null
				}), ot
			}(e);
		h.find = y, h.expr = y.selectors, h.expr[":"] = h.expr.pseudos, h.unique = y.uniqueSort, h.text = y.getText, h.isXMLDoc = y.isXML, h.contains = y.contains;
		var b = h.expr.match.needsContext,
			w = /^<(\w+)\s*\/?>(?:<\/\1>|)$/,
			E = /^.[^:#\[\.,]*$/;
		h.filter = function(e, t, n) {
			var r = t[0];
			return n && (e = ":not(" + e + ")"), t.length === 1 && r.nodeType === 1 ? h.find.matchesSelector(r, e) ? [r] : [] : h.find.matches(e, h.grep(t, function(e) {
				return e.nodeType === 1
			}))
		}, h.fn.extend({
			find: function(e) {
				var t, n = [],
					r = this,
					i = r.length;
				if (typeof e != "string") return this.pushStack(h(e).filter(function() {
					for (t = 0; t < i; t++) if (h.contains(r[t], this)) return !0
				}));
				for (t = 0; t < i; t++) h.find(e, r[t], n);
				return n = this.pushStack(i > 1 ? h.unique(n) : n), n.selector = this.selector ? this.selector + " " + e : e, n
			},
			filter: function(e) {
				return this.pushStack(S(this, e || [], !1))
			},
			not: function(e) {
				return this.pushStack(S(this, e || [], !0))
			},
			is: function(e) {
				return !!S(this, typeof e == "string" && b.test(e) ? h(e) : e || [], !1).length
			}
		});
		var x, T = e.document,
			N = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/,
			C = h.fn.init = function(e, t) {
				var n, r;
				if (!e) return this;
				if (typeof e == "string") {
					e.charAt(0) === "<" && e.charAt(e.length - 1) === ">" && e.length >= 3 ? n = [null, e, null] : n = N.exec(e);
					if (n && (n[1] || !t)) {
						if (n[1]) {
							t = t instanceof h ? t[0] : t, h.merge(this, h.parseHTML(n[1], t && t.nodeType ? t.ownerDocument || t : T, !0));
							if (w.test(n[1]) && h.isPlainObject(t)) for (n in t) h.isFunction(this[n]) ? this[n](t[n]) : this.attr(n, t[n]);
							return this
						}
						r = T.getElementById(n[2]);
						if (r && r.parentNode) {
							if (r.id !== n[2]) return x.find(e);
							this.length = 1, this[0] = r
						}
						return this.context = T, this.selector = e, this
					}
					return !t || t.jquery ? (t || x).find(e) : this.constructor(t).find(e)
				}
				return e.nodeType ? (this.context = this[0] = e, this.length = 1, this) : h.isFunction(e) ? typeof x.ready != "undefined" ? x.ready(e) : e(h) : (e.selector !== undefined && (this.selector = e.selector, this.context = e.context), h.makeArray(e, this))
			};
		C.prototype = h.fn, x = h(T);
		var k = /^(?:parents|prev(?:Until|All))/,
			L = {
				children: !0,
				contents: !0,
				next: !0,
				prev: !0
			};
		h.extend({
			dir: function(e, t, n) {
				var r = [],
					i = e[t];
				while (i && i.nodeType !== 9 && (n === undefined || i.nodeType !== 1 || !h(i).is(n))) i.nodeType === 1 && r.push(i), i = i[t];
				return r
			},
			sibling: function(e, t) {
				var n = [];
				for (; e; e = e.nextSibling) e.nodeType === 1 && e !== t && n.push(e);
				return n
			}
		}), h.fn.extend({
			has: function(e) {
				var t, n = h(e, this),
					r = n.length;
				return this.filter(function() {
					for (t = 0; t < r; t++) if (h.contains(this, n[t])) return !0
				})
			},
			closest: function(e, t) {
				var n, r = 0,
					i = this.length,
					s = [],
					o = b.test(e) || typeof e != "string" ? h(e, t || this.context) : 0;
				for (; r < i; r++) for (n = this[r]; n && n !== t; n = n.parentNode) if (n.nodeType < 11 && (o ? o.index(n) > -1 : n.nodeType === 1 && h.find.matchesSelector(n, e))) {
					s.push(n);
					break
				}
				return this.pushStack(s.length > 1 ? h.unique(s) : s)
			},
			index: function(e) {
				return e ? typeof e == "string" ? h.inArray(this[0], h(e)) : h.inArray(e.jquery ? e[0] : e, this) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1
			},
			add: function(e, t) {
				return this.pushStack(h.unique(h.merge(this.get(), h(e, t))))
			},
			addBack: function(e) {
				return this.add(e == null ? this.prevObject : this.prevObject.filter(e))
			}
		}), h.each({
			parent: function(e) {
				var t = e.parentNode;
				return t && t.nodeType !== 11 ? t : null
			},
			parents: function(e) {
				return h.dir(e, "parentNode")
			},
			parentsUntil: function(e, t, n) {
				return h.dir(e, "parentNode", n)
			},
			next: function(e) {
				return A(e, "nextSibling")
			},
			prev: function(e) {
				return A(e, "previousSibling")
			},
			nextAll: function(e) {
				return h.dir(e, "nextSibling")
			},
			prevAll: function(e) {
				return h.dir(e, "previousSibling")
			},
			nextUntil: function(e, t, n) {
				return h.dir(e, "nextSibling", n)
			},
			prevUntil: function(e, t, n) {
				return h.dir(e, "previousSibling", n)
			},
			siblings: function(e) {
				return h.sibling((e.parentNode || {}).firstChild, e)
			},
			children: function(e) {
				return h.sibling(e.firstChild)
			},
			contents: function(e) {
				return h.nodeName(e, "iframe") ? e.contentDocument || e.contentWindow.document : h.merge([], e.childNodes)
			}
		}, function(e, t) {
			h.fn[e] = function(n, r) {
				var i = h.map(this, t, n);
				return e.slice(-5) !== "Until" && (r = n), r && typeof r == "string" && (i = h.filter(r, i)), this.length > 1 && (L[e] || (i = h.unique(i)), k.test(e) && (i = i.reverse())), this.pushStack(i)
			}
		});
		var O = /\S+/g,
			M = {};
		h.Callbacks = function(e) {
			e = typeof e == "string" ? M[e] || _(e) : h.extend({}, e);
			var t, n, r, i, s, o, u = [],
				a = !e.once && [],
				f = function(c) {
					n = e.memory && c, r = !0, s = o || 0, o = 0, i = u.length, t = !0;
					for (; u && s < i; s++) if (u[s].apply(c[0], c[1]) === !1 && e.stopOnFalse) {
						n = !1;
						break
					}
					t = !1, u && (a ? a.length && f(a.shift()) : n ? u = [] : l.disable())
				},
				l = {
					add: function() {
						if (u) {
							var r = u.length;
							(function s(t) {
								h.each(t, function(t, n) {
									var r = h.type(n);
									r === "function" ? (!e.unique || !l.has(n)) && u.push(n) : n && n.length && r !== "string" && s(n)
								})
							})(arguments), t ? i = u.length : n && (o = r, f(n))
						}
						return this
					},
					remove: function() {
						return u && h.each(arguments, function(e, n) {
							var r;
							while ((r = h.inArray(n, u, r)) > -1) u.splice(r, 1), t && (r <= i && i--, r <= s && s--)
						}), this
					},
					has: function(e) {
						return e ? h.inArray(e, u) > -1 : !! u && !! u.length
					},
					empty: function() {
						return u = [], i = 0, this
					},
					disable: function() {
						return u = a = n = undefined, this
					},
					disabled: function() {
						return !u
					},
					lock: function() {
						return a = undefined, n || l.disable(), this
					},
					locked: function() {
						return !a
					},
					fireWith: function(e, n) {
						return u && (!r || a) && (n = n || [], n = [e, n.slice ? n.slice() : n], t ? a.push(n) : f(n)), this
					},
					fire: function() {
						return l.fireWith(this, arguments), this
					},
					fired: function() {
						return !!r
					}
				};
			return l
		}, h.extend({
			Deferred: function(e) {
				var t = [
					["resolve", "done", h.Callbacks("once memory"), "resolved"],
					["reject", "fail", h.Callbacks("once memory"), "rejected"],
					["notify", "progress", h.Callbacks("memory")]
				],
					n = "pending",
					r = {
						state: function() {
							return n
						},
						always: function() {
							return i.done(arguments).fail(arguments), this
						},
						then: function() {
							var e = arguments;
							return h.Deferred(function(n) {
								h.each(t, function(t, s) {
									var o = h.isFunction(e[t]) && e[t];
									i[s[1]](function() {
										var e = o && o.apply(this, arguments);
										e && h.isFunction(e.promise) ? e.promise().done(n.resolve).fail(n.reject).progress(n.notify) : n[s[0] + "With"](this === r ? n.promise() : this, o ? [e] : arguments)
									})
								}), e = null
							}).promise()
						},
						promise: function(e) {
							return e != null ? h.extend(e, r) : r
						}
					},
					i = {};
				return r.pipe = r.then, h.each(t, function(e, s) {
					var o = s[2],
						u = s[3];
					r[s[1]] = o.add, u && o.add(function() {
						n = u
					}, t[e ^ 1][2].disable, t[2][2].lock), i[s[0]] = function() {
						return i[s[0] + "With"](this === i ? r : this, arguments), this
					}, i[s[0] + "With"] = o.fireWith
				}), r.promise(i), e && e.call(i, i), i
			},
			when: function(e) {
				var t = 0,
					n = r.call(arguments),
					i = n.length,
					s = i !== 1 || e && h.isFunction(e.promise) ? i : 0,
					o = s === 1 ? e : h.Deferred(),
					u = function(e, t, n) {
						return function(i) {
							t[e] = this, n[e] = arguments.length > 1 ? r.call(arguments) : i, n === a ? o.notifyWith(t, n) : --s || o.resolveWith(t, n)
						}
					},
					a, f, l;
				if (i > 1) {
					a = new Array(i), f = new Array(i), l = new Array(i);
					for (; t < i; t++) n[t] && h.isFunction(n[t].promise) ? n[t].promise().done(u(t, l, n)).fail(o.reject).progress(u(t, f, a)) : --s
				}
				return s || o.resolveWith(l, n), o.promise()
			}
		});
		var D;
		h.fn.ready = function(e) {
			return h.ready.promise().done(e), this
		}, h.extend({
			isReady: !1,
			readyWait: 1,
			holdReady: function(e) {
				e ? h.readyWait++ : h.ready(!0)
			},
			ready: function(e) {
				if (e === !0 ? --h.readyWait : h.isReady) return;
				if (!T.body) return setTimeout(h.ready);
				h.isReady = !0;
				if (e !== !0 && --h.readyWait > 0) return;
				D.resolveWith(T, [h]), h.fn.triggerHandler && (h(T).triggerHandler("ready"), h(T).off("ready"))
			}
		}), h.ready.promise = function(t) {
			if (!D) {
				D = h.Deferred();
				if (T.readyState === "complete") setTimeout(h.ready);
				else if (T.addEventListener) T.addEventListener("DOMContentLoaded", H, !1), e.addEventListener("load", H, !1);
				else {
					T.attachEvent("onreadystatechange", H), e.attachEvent("onload", H);
					var n = !1;
					try {
						n = e.frameElement == null && T.documentElement
					} catch (r) {}
					n && n.doScroll &&
					function i() {
						if (!h.isReady) {
							try {
								n.doScroll("left")
							} catch (e) {
								return setTimeout(i, 50)
							}
							P(), h.ready()
						}
					}()
				}
			}
			return D.promise(t)
		};
		var B = typeof undefined,
			j;
		for (j in h(l)) break;
		l.ownLast = j !== "0", l.inlineBlockNeedsLayout = !1, h(function() {
			var e, t, n, r;
			n = T.getElementsByTagName("body")[0];
			if (!n || !n.style) return;
			t = T.createElement("div"), r = T.createElement("div"), r.style.cssText = "position:absolute;border:0;width:0;height:0;top:0;left:-9999px", n.appendChild(r).appendChild(t), typeof t.style.zoom !== B && (t.style.cssText = "display:inline;margin:0;border:0;padding:1px;width:1px;zoom:1", l.inlineBlockNeedsLayout = e = t.offsetWidth === 3, e && (n.style.zoom = 1)), n.removeChild(r)
		}), function() {
			var e = T.createElement("div");
			if (l.deleteExpando == null) {
				l.deleteExpando = !0;
				try {
					delete e.test
				} catch (t) {
					l.deleteExpando = !1
				}
			}
			e = null
		}(), h.acceptData = function(e) {
			var t = h.noData[(e.nodeName + " ").toLowerCase()],
				n = +e.nodeType || 1;
			return n !== 1 && n !== 9 ? !1 : !t || t !== !0 && e.getAttribute("classid") === t
		};
		var F = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
			I = /([A-Z])/g;
		h.extend({
			cache: {},
			noData: {
				"applet ": !0,
				"embed ": !0,
				"object ": "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
			},
			hasData: function(e) {
				return e = e.nodeType ? h.cache[e[h.expando]] : e[h.expando], !! e && !R(e)
			},
			data: function(e, t, n) {
				return U(e, t, n)
			},
			removeData: function(e, t) {
				return z(e, t)
			},
			_data: function(e, t, n) {
				return U(e, t, n, !0)
			},
			_removeData: function(e, t) {
				return z(e, t, !0)
			}
		}), h.fn.extend({
			data: function(e, t) {
				var n, r, i, s = this[0],
					o = s && s.attributes;
				if (e === undefined) {
					if (this.length) {
						i = h.data(s);
						if (s.nodeType === 1 && !h._data(s, "parsedAttrs")) {
							n = o.length;
							while (n--) o[n] && (r = o[n].name, r.indexOf("data-") === 0 && (r = h.camelCase(r.slice(5)), q(s, r, i[r])));
							h._data(s, "parsedAttrs", !0)
						}
					}
					return i
				}
				return typeof e == "object" ? this.each(function() {
					h.data(this, e)
				}) : arguments.length > 1 ? this.each(function() {
					h.data(this, e, t)
				}) : s ? q(s, e, h.data(s, e)) : undefined
			},
			removeData: function(e) {
				return this.each(function() {
					h.removeData(this, e)
				})
			}
		}), h.extend({
			queue: function(e, t, n) {
				var r;
				if (e) return t = (t || "fx") + "queue", r = h._data(e, t), n && (!r || h.isArray(n) ? r = h._data(e, t, h.makeArray(n)) : r.push(n)), r || []
			},
			dequeue: function(e, t) {
				t = t || "fx";
				var n = h.queue(e, t),
					r = n.length,
					i = n.shift(),
					s = h._queueHooks(e, t),
					o = function() {
						h.dequeue(e, t)
					};
				i === "inprogress" && (i = n.shift(), r--), i && (t === "fx" && n.unshift("inprogress"), delete s.stop, i.call(e, o, s)), !r && s && s.empty.fire()
			},
			_queueHooks: function(e, t) {
				var n = t + "queueHooks";
				return h._data(e, n) || h._data(e, n, {
					empty: h.Callbacks("once memory").add(function() {
						h._removeData(e, t + "queue"), h._removeData(e, n)
					})
				})
			}
		}), h.fn.extend({
			queue: function(e, t) {
				var n = 2;
				return typeof e != "string" && (t = e, e = "fx", n--), arguments.length < n ? h.queue(this[0], e) : t === undefined ? this : this.each(function() {
					var n = h.queue(this, e, t);
					h._queueHooks(this, e), e === "fx" && n[0] !== "inprogress" && h.dequeue(this, e)
				})
			},
			dequeue: function(e) {
				return this.each(function() {
					h.dequeue(this, e)
				})
			},
			clearQueue: function(e) {
				return this.queue(e || "fx", [])
			},
			promise: function(e, t) {
				var n, r = 1,
					i = h.Deferred(),
					s = this,
					o = this.length,
					u = function() {
						--r || i.resolveWith(s, [s])
					};
				typeof e != "string" && (t = e, e = undefined), e = e || "fx";
				while (o--) n = h._data(s[o], e + "queueHooks"), n && n.empty && (r++, n.empty.add(u));
				return u(), i.promise(t)
			}
		});
		var W = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
			X = ["Top", "Right", "Bottom", "Left"],
			V = function(e, t) {
				return e = t || e, h.css(e, "display") === "none" || !h.contains(e.ownerDocument, e)
			},
			$ = h.access = function(e, t, n, r, i, s, o) {
				var u = 0,
					a = e.length,
					f = n == null;
				if (h.type(n) === "object") {
					i = !0;
					for (u in n) h.access(e, t, u, n[u], !0, s, o)
				} else if (r !== undefined) {
					i = !0, h.isFunction(r) || (o = !0), f && (o ? (t.call(e, r), t = null) : (f = t, t = function(e, t, n) {
						return f.call(h(e), n)
					}));
					if (t) for (; u < a; u++) t(e[u], n, o ? r : r.call(e[u], u, t(e[u], n)))
				}
				return i ? e : f ? t.call(e) : a ? t(e[0], n) : s
			},
			J = /^(?:checkbox|radio)$/i;
		(function() {
			var e = T.createElement("input"),
				t = T.createElement("div"),
				n = T.createDocumentFragment();
			t.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>", l.leadingWhitespace = t.firstChild.nodeType === 3, l.tbody = !t.getElementsByTagName("tbody").length, l.htmlSerialize = !! t.getElementsByTagName("link").length, l.html5Clone = T.createElement("nav").cloneNode(!0).outerHTML !== "<:nav></:nav>", e.type = "checkbox", e.checked = !0, n.appendChild(e), l.appendChecked = e.checked, t.innerHTML = "<textarea>x</textarea>", l.noCloneChecked = !! t.cloneNode(!0).lastChild.defaultValue, n.appendChild(t), t.innerHTML = "<input type='radio' checked='checked' name='t'/>", l.checkClone = t.cloneNode(!0).cloneNode(!0).lastChild.checked, l.noCloneEvent = !0, t.attachEvent && (t.attachEvent("onclick", function() {
				l.noCloneEvent = !1
			}), t.cloneNode(!0).click());
			if (l.deleteExpando == null) {
				l.deleteExpando = !0;
				try {
					delete t.test
				} catch (r) {
					l.deleteExpando = !1
				}
			}
		})(), function() {
			var t, n, r = T.createElement("div");
			for (t in {
				submit: !0,
				change: !0,
				focusin: !0
			}) n = "on" + t, (l[t + "Bubbles"] = n in e) || (r.setAttribute(n, "t"), l[t + "Bubbles"] = r.attributes[n].expando === !1);
			r = null
		}();
		var K = /^(?:input|select|textarea)$/i,
			Q = /^key/,
			G = /^(?:mouse|pointer|contextmenu)|click/,
			Y = /^(?:focusinfocus|focusoutblur)$/,
			Z = /^([^.]*)(?:\.(.+)|)$/;
		h.event = {
			global: {},
			add: function(e, t, n, r, i) {
				var s, o, u, a, f, l, c, p, d, v, m, g = h._data(e);
				if (!g) return;
				n.handler && (a = n, n = a.handler, i = a.selector), n.guid || (n.guid = h.guid++), (o = g.events) || (o = g.events = {}), (l = g.handle) || (l = g.handle = function(e) {
					return typeof h === B || !! e && h.event.triggered === e.type ? undefined : h.event.dispatch.apply(l.elem, arguments)
				}, l.elem = e), t = (t || "").match(O) || [""], u = t.length;
				while (u--) {
					s = Z.exec(t[u]) || [], d = m = s[1], v = (s[2] || "").split(".").sort();
					if (!d) continue;
					f = h.event.special[d] || {}, d = (i ? f.delegateType : f.bindType) || d, f = h.event.special[d] || {}, c = h.extend({
						type: d,
						origType: m,
						data: r,
						handler: n,
						guid: n.guid,
						selector: i,
						needsContext: i && h.expr.match.needsContext.test(i),
						namespace: v.join(".")
					}, a);
					if (!(p = o[d])) {
						p = o[d] = [], p.delegateCount = 0;
						if (!f.setup || f.setup.call(e, r, v, l) === !1) e.addEventListener ? e.addEventListener(d, l, !1) : e.attachEvent && e.attachEvent("on" + d, l)
					}
					f.add && (f.add.call(e, c), c.handler.guid || (c.handler.guid = n.guid)), i ? p.splice(p.delegateCount++, 0, c) : p.push(c), h.event.global[d] = !0
				}
				e = null
			},
			remove: function(e, t, n, r, i) {
				var s, o, u, a, f, l, c, p, d, v, m, g = h.hasData(e) && h._data(e);
				if (!g || !(l = g.events)) return;
				t = (t || "").match(O) || [""], f = t.length;
				while (f--) {
					u = Z.exec(t[f]) || [], d = m = u[1], v = (u[2] || "").split(".").sort();
					if (!d) {
						for (d in l) h.event.remove(e, d + t[f], n, r, !0);
						continue
					}
					c = h.event.special[d] || {}, d = (r ? c.delegateType : c.bindType) || d, p = l[d] || [], u = u[2] && new RegExp("(^|\\.)" + v.join("\\.(?:.*\\.|)") + "(\\.|$)"), a = s = p.length;
					while (s--) o = p[s], (i || m === o.origType) && (!n || n.guid === o.guid) && (!u || u.test(o.namespace)) && (!r || r === o.selector || r === "**" && o.selector) && (p.splice(s, 1), o.selector && p.delegateCount--, c.remove && c.remove.call(e, o));
					a && !p.length && ((!c.teardown || c.teardown.call(e, v, g.handle) === !1) && h.removeEvent(e, d, g.handle), delete l[d])
				}
				h.isEmptyObject(l) && (delete g.handle, h._removeData(e, "events"))
			},
			trigger: function(t, n, r, i) {
				var s, o, u, a, l, c, p, d = [r || T],
					v = f.call(t, "type") ? t.type : t,
					m = f.call(t, "namespace") ? t.namespace.split(".") : [];
				u = c = r = r || T;
				if (r.nodeType === 3 || r.nodeType === 8) return;
				if (Y.test(v + h.event.triggered)) return;
				v.indexOf(".") >= 0 && (m = v.split("."), v = m.shift(), m.sort()), o = v.indexOf(":") < 0 && "on" + v, t = t[h.expando] ? t : new h.Event(v, typeof t == "object" && t), t.isTrigger = i ? 2 : 3, t.namespace = m.join("."), t.namespace_re = t.namespace ? new RegExp("(^|\\.)" + m.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, t.result = undefined, t.target || (t.target = r), n = n == null ? [t] : h.makeArray(n, [t]), l = h.event.special[v] || {};
				if (!i && l.trigger && l.trigger.apply(r, n) === !1) return;
				if (!i && !l.noBubble && !h.isWindow(r)) {
					a = l.delegateType || v, Y.test(a + v) || (u = u.parentNode);
					for (; u; u = u.parentNode) d.push(u), c = u;
					c === (r.ownerDocument || T) && d.push(c.defaultView || c.parentWindow || e)
				}
				p = 0;
				while ((u = d[p++]) && !t.isPropagationStopped()) t.type = p > 1 ? a : l.bindType || v, s = (h._data(u, "events") || {})[t.type] && h._data(u, "handle"), s && s.apply(u, n), s = o && u[o], s && s.apply && h.acceptData(u) && (t.result = s.apply(u, n), t.result === !1 && t.preventDefault());
				t.type = v;
				if (!i && !t.isDefaultPrevented() && (!l._default || l._default.apply(d.pop(), n) === !1) && h.acceptData(r) && o && r[v] && !h.isWindow(r)) {
					c = r[o], c && (r[o] = null), h.event.triggered = v;
					try {
						r[v]()
					} catch (g) {}
					h.event.triggered = undefined, c && (r[o] = c)
				}
				return t.result
			},
			dispatch: function(e) {
				e = h.event.fix(e);
				var t, n, i, s, o, u = [],
					a = r.call(arguments),
					f = (h._data(this, "events") || {})[e.type] || [],
					l = h.event.special[e.type] || {};
				a[0] = e, e.delegateTarget = this;
				if (l.preDispatch && l.preDispatch.call(this, e) === !1) return;
				u = h.event.handlers.call(this, e, f), t = 0;
				while ((s = u[t++]) && !e.isPropagationStopped()) {
					e.currentTarget = s.elem, o = 0;
					while ((i = s.handlers[o++]) && !e.isImmediatePropagationStopped()) if (!e.namespace_re || e.namespace_re.test(i.namespace)) e.handleObj = i, e.data = i.data, n = ((h.event.special[i.origType] || {}).handle || i.handler).apply(s.elem, a), n !== undefined && (e.result = n) === !1 && (e.preventDefault(), e.stopPropagation())
				}
				return l.postDispatch && l.postDispatch.call(this, e), e.result
			},
			handlers: function(e, t) {
				var n, r, i, s, o = [],
					u = t.delegateCount,
					a = e.target;
				if (u && a.nodeType && (!e.button || e.type !== "click")) for (; a != this; a = a.parentNode || this) if (a.nodeType === 1 && (a.disabled !== !0 || e.type !== "click")) {
					i = [];
					for (s = 0; s < u; s++) r = t[s], n = r.selector + " ", i[n] === undefined && (i[n] = r.needsContext ? h(n, this).index(a) >= 0 : h.find(n, this, null, [a]).length), i[n] && i.push(r);
					i.length && o.push({
						elem: a,
						handlers: i
					})
				}
				return u < t.length && o.push({
					elem: this,
					handlers: t.slice(u)
				}), o
			},
			fix: function(e) {
				if (e[h.expando]) return e;
				var t, n, r, i = e.type,
					s = e,
					o = this.fixHooks[i];
				o || (this.fixHooks[i] = o = G.test(i) ? this.mouseHooks : Q.test(i) ? this.keyHooks : {}), r = o.props ? this.props.concat(o.props) : this.props, e = new h.Event(s), t = r.length;
				while (t--) n = r[t], e[n] = s[n];
				return e.target || (e.target = s.srcElement || T), e.target.nodeType === 3 && (e.target = e.target.parentNode), e.metaKey = !! e.metaKey, o.filter ? o.filter(e, s) : e
			},
			props: "altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),
			fixHooks: {},
			keyHooks: {
				props: "char charCode key keyCode".split(" "),
				filter: function(e, t) {
					return e.which == null && (e.which = t.charCode != null ? t.charCode : t.keyCode), e
				}
			},
			mouseHooks: {
				props: "button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),
				filter: function(e, t) {
					var n, r, i, s = t.button,
						o = t.fromElement;
					return e.pageX == null && t.clientX != null && (r = e.target.ownerDocument || T, i = r.documentElement, n = r.body, e.pageX = t.clientX + (i && i.scrollLeft || n && n.scrollLeft || 0) - (i && i.clientLeft || n && n.clientLeft || 0), e.pageY = t.clientY + (i && i.scrollTop || n && n.scrollTop || 0) - (i && i.clientTop || n && n.clientTop || 0)), !e.relatedTarget && o && (e.relatedTarget = o === e.target ? t.toElement : o), !e.which && s !== undefined && (e.which = s & 1 ? 1 : s & 2 ? 3 : s & 4 ? 2 : 0), e
				}
			},
			special: {
				load: {
					noBubble: !0
				},
				focus: {
					trigger: function() {
						if (this !== nt() && this.focus) try {
							return this.focus(), !1
						} catch (e) {}
					},
					delegateType: "focusin"
				},
				blur: {
					trigger: function() {
						if (this === nt() && this.blur) return this.blur(), !1
					},
					delegateType: "focusout"
				},
				click: {
					trigger: function() {
						if (h.nodeName(this, "input") && this.type === "checkbox" && this.click) return this.click(), !1
					},
					_default: function(e) {
						return h.nodeName(e.target, "a")
					}
				},
				beforeunload: {
					postDispatch: function(e) {
						e.result !== undefined && e.originalEvent && (e.originalEvent.returnValue = e.result)
					}
				}
			},
			simulate: function(e, t, n, r) {
				var i = h.extend(new h.Event, n, {
					type: e,
					isSimulated: !0,
					originalEvent: {}
				});
				r ? h.event.trigger(i, null, t) : h.event.dispatch.call(t, i), i.isDefaultPrevented() && n.preventDefault()
			}
		}, h.removeEvent = T.removeEventListener ?
		function(e, t, n) {
			e.removeEventListener && e.removeEventListener(t, n, !1)
		} : function(e, t, n) {
			var r = "on" + t;
			e.detachEvent && (typeof e[r] === B && (e[r] = null), e.detachEvent(r, n))
		}, h.Event = function(e, t) {
			if (!(this instanceof h.Event)) return new h.Event(e, t);
			e && e.type ? (this.originalEvent = e, this.type = e.type, this.isDefaultPrevented = e.defaultPrevented || e.defaultPrevented === undefined && e.returnValue === !1 ? et : tt) : this.type = e, t && h.extend(this, t), this.timeStamp = e && e.timeStamp || h.now(), this[h.expando] = !0
		}, h.Event.prototype = {
			isDefaultPrevented: tt,
			isPropagationStopped: tt,
			isImmediatePropagationStopped: tt,
			preventDefault: function() {
				var e = this.originalEvent;
				this.isDefaultPrevented = et;
				if (!e) return;
				e.preventDefault ? e.preventDefault() : e.returnValue = !1
			},
			stopPropagation: function() {
				var e = this.originalEvent;
				this.isPropagationStopped = et;
				if (!e) return;
				e.stopPropagation && e.stopPropagation(), e.cancelBubble = !0
			},
			stopImmediatePropagation: function() {
				var e = this.originalEvent;
				this.isImmediatePropagationStopped = et, e && e.stopImmediatePropagation && e.stopImmediatePropagation(), this.stopPropagation()
			}
		}, h.each({
			mouseenter: "mouseover",
			mouseleave: "mouseout",
			pointerenter: "pointerover",
			pointerleave: "pointerout"
		}, function(e, t) {
			h.event.special[e] = {
				delegateType: t,
				bindType: t,
				handle: function(e) {
					var n, r = this,
						i = e.relatedTarget,
						s = e.handleObj;
					if (!i || i !== r && !h.contains(r, i)) e.type = s.origType, n = s.handler.apply(this, arguments), e.type = t;
					return n
				}
			}
		}), l.submitBubbles || (h.event.special.submit = {
			setup: function() {
				if (h.nodeName(this, "form")) return !1;
				h.event.add(this, "click._submit keypress._submit", function(e) {
					var t = e.target,
						n = h.nodeName(t, "input") || h.nodeName(t, "button") ? t.form : undefined;
					n && !h._data(n, "submitBubbles") && (h.event.add(n, "submit._submit", function(e) {
						e._submit_bubble = !0
					}), h._data(n, "submitBubbles", !0))
				})
			},
			postDispatch: function(e) {
				e._submit_bubble && (delete e._submit_bubble, this.parentNode && !e.isTrigger && h.event.simulate("submit", this.parentNode, e, !0))
			},
			teardown: function() {
				if (h.nodeName(this, "form")) return !1;
				h.event.remove(this, "._submit")
			}
		}), l.changeBubbles || (h.event.special.change = {
			setup: function() {
				if (K.test(this.nodeName)) {
					if (this.type === "checkbox" || this.type === "radio") h.event.add(this, "propertychange._change", function(e) {
						e.originalEvent.propertyName === "checked" && (this._just_changed = !0)
					}), h.event.add(this, "click._change", function(e) {
						this._just_changed && !e.isTrigger && (this._just_changed = !1), h.event.simulate("change", this, e, !0)
					});
					return !1
				}
				h.event.add(this, "beforeactivate._change", function(e) {
					var t = e.target;
					K.test(t.nodeName) && !h._data(t, "changeBubbles") && (h.event.add(t, "change._change", function(e) {
						this.parentNode && !e.isSimulated && !e.isTrigger && h.event.simulate("change", this.parentNode, e, !0)
					}), h._data(t, "changeBubbles", !0))
				})
			},
			handle: function(e) {
				var t = e.target;
				if (this !== t || e.isSimulated || e.isTrigger || t.type !== "radio" && t.type !== "checkbox") return e.handleObj.handler.apply(this, arguments)
			},
			teardown: function() {
				return h.event.remove(this, "._change"), !K.test(this.nodeName)
			}
		}), l.focusinBubbles || h.each({
			focus: "focusin",
			blur: "focusout"
		}, function(e, t) {
			var n = function(e) {
					h.event.simulate(t, e.target, h.event.fix(e), !0)
				};
			h.event.special[t] = {
				setup: function() {
					var r = this.ownerDocument || this,
						i = h._data(r, t);
					i || r.addEventListener(e, n, !0), h._data(r, t, (i || 0) + 1)
				},
				teardown: function() {
					var r = this.ownerDocument || this,
						i = h._data(r, t) - 1;
					i ? h._data(r, t, i) : (r.removeEventListener(e, n, !0), h._removeData(r, t))
				}
			}
		}), h.fn.extend({
			on: function(e, t, n, r, i) {
				var s, o;
				if (typeof e == "object") {
					typeof t != "string" && (n = n || t, t = undefined);
					for (s in e) this.on(s, t, n, e[s], i);
					return this
				}
				n == null && r == null ? (r = t, n = t = undefined) : r == null && (typeof t == "string" ? (r = n, n = undefined) : (r = n, n = t, t = undefined));
				if (r === !1) r = tt;
				else if (!r) return this;
				return i === 1 && (o = r, r = function(e) {
					return h().off(e), o.apply(this, arguments)
				}, r.guid = o.guid || (o.guid = h.guid++)), this.each(function() {
					h.event.add(this, e, r, n, t)
				})
			},
			one: function(e, t, n, r) {
				return this.on(e, t, n, r, 1)
			},
			off: function(e, t, n) {
				var r, i;
				if (e && e.preventDefault && e.handleObj) return r = e.handleObj, h(e.delegateTarget).off(r.namespace ? r.origType + "." + r.namespace : r.origType, r.selector, r.handler), this;
				if (typeof e == "object") {
					for (i in e) this.off(i, t, e[i]);
					return this
				}
				if (t === !1 || typeof t == "function") n = t, t = undefined;
				return n === !1 && (n = tt), this.each(function() {
					h.event.remove(this, e, n, t)
				})
			},
			trigger: function(e, t) {
				return this.each(function() {
					h.event.trigger(e, t, this)
				})
			},
			triggerHandler: function(e, t) {
				var n = this[0];
				if (n) return h.event.trigger(e, t, n, !0)
			}
		});
		var it = "abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video",
			st = / jQuery\d+="(?:null|\d+)"/g,
			ot = new RegExp("<(?:" + it + ")[\\s/>]", "i"),
			ut = /^\s+/,
			at = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,
			ft = /<([\w:]+)/,
			lt = /<tbody/i,
			ct = /<|&#?\w+;/,
			ht = /<(?:script|style|link)/i,
			pt = /checked\s*(?:[^=]|=\s*.checked.)/i,
			dt = /^$|\/(?:java|ecma)script/i,
			vt = /^true\/(.*)/,
			mt = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g,
			gt = {
				option: [1, "<select multiple='multiple'>", "</select>"],
				legend: [1, "<fieldset>", "</fieldset>"],
				area: [1, "<map>", "</map>"],
				param: [1, "<object>", "</object>"],
				thead: [1, "<table>", "</table>"],
				tr: [2, "<table><tbody>", "</tbody></table>"],
				col: [2, "<table><tbody></tbody><colgroup>", "</colgroup></table>"],
				td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
				_default: l.htmlSerialize ? [0, "", ""] : [1, "X<div>", "</div>"]
			},
			yt = rt(T),
			bt = yt.appendChild(T.createElement("div"));
		gt.optgroup = gt.option, gt.tbody = gt.tfoot = gt.colgroup = gt.caption = gt.thead, gt.th = gt.td, h.extend({
			clone: function(e, t, n) {
				var r, i, s, o, u, a = h.contains(e.ownerDocument, e);
				l.html5Clone || h.isXMLDoc(e) || !ot.test("<" + e.nodeName + ">") ? s = e.cloneNode(!0) : (bt.innerHTML = e.outerHTML, bt.removeChild(s = bt.firstChild));
				if ((!l.noCloneEvent || !l.noCloneChecked) && (e.nodeType === 1 || e.nodeType === 11) && !h.isXMLDoc(e)) {
					r = wt(s), u = wt(e);
					for (o = 0;
					(i = u[o]) != null; ++o) r[o] && kt(i, r[o])
				}
				if (t) if (n) {
					u = u || wt(e), r = r || wt(s);
					for (o = 0;
					(i = u[o]) != null; o++) Ct(i, r[o])
				} else Ct(e, s);
				return r = wt(s, "script"), r.length > 0 && Nt(r, !a && wt(e, "script")), r = u = i = null, s
			},
			buildFragment: function(e, t, n, r) {
				var i, s, o, u, a, f, c, p = e.length,
					d = rt(t),
					v = [],
					m = 0;
				for (; m < p; m++) {
					s = e[m];
					if (s || s === 0) if (h.type(s) === "object") h.merge(v, s.nodeType ? [s] : s);
					else if (!ct.test(s)) v.push(t.createTextNode(s));
					else {
						u = u || d.appendChild(t.createElement("div")), a = (ft.exec(s) || ["", ""])[1].toLowerCase(), c = gt[a] || gt._default, u.innerHTML = c[1] + s.replace(at, "<$1></$2>") + c[2], i = c[0];
						while (i--) u = u.lastChild;
						!l.leadingWhitespace && ut.test(s) && v.push(t.createTextNode(ut.exec(s)[0]));
						if (!l.tbody) {
							s = a === "table" && !lt.test(s) ? u.firstChild : c[1] === "<table>" && !lt.test(s) ? u : 0, i = s && s.childNodes.length;
							while (i--) h.nodeName(f = s.childNodes[i], "tbody") && !f.childNodes.length && s.removeChild(f)
						}
						h.merge(v, u.childNodes), u.textContent = "";
						while (u.firstChild) u.removeChild(u.firstChild);
						u = d.lastChild
					}
				}
				u && d.removeChild(u), l.appendChecked || h.grep(wt(v, "input"), Et), m = 0;
				while (s = v[m++]) {
					if (r && h.inArray(s, r) !== -1) continue;
					o = h.contains(s.ownerDocument, s), u = wt(d.appendChild(s), "script"), o && Nt(u);
					if (n) {
						i = 0;
						while (s = u[i++]) dt.test(s.type || "") && n.push(s)
					}
				}
				return u = null, d
			},
			cleanData: function(e, t) {
				var r, i, s, o, u = 0,
					a = h.expando,
					f = h.cache,
					c = l.deleteExpando,
					p = h.event.special;
				for (;
				(r = e[u]) != null; u++) if (t || h.acceptData(r)) {
					s = r[a], o = s && f[s];
					if (o) {
						if (o.events) for (i in o.events) p[i] ? h.event.remove(r, i) : h.removeEvent(r, i, o.handle);
						f[s] && (delete f[s], c ? delete r[a] : typeof r.removeAttribute !== B ? r.removeAttribute(a) : r[a] = null, n.push(s))
					}
				}
			}
		}), h.fn.extend({
			text: function(e) {
				return $(this, function(e) {
					return e === undefined ? h.text(this) : this.empty().append((this[0] && this[0].ownerDocument || T).createTextNode(e))
				}, null, e, arguments.length)
			},
			append: function() {
				return this.domManip(arguments, function(e) {
					if (this.nodeType === 1 || this.nodeType === 11 || this.nodeType === 9) {
						var t = St(this, e);
						t.appendChild(e)
					}
				})
			},
			prepend: function() {
				return this.domManip(arguments, function(e) {
					if (this.nodeType === 1 || this.nodeType === 11 || this.nodeType === 9) {
						var t = St(this, e);
						t.insertBefore(e, t.firstChild)
					}
				})
			},
			before: function() {
				return this.domManip(arguments, function(e) {
					this.parentNode && this.parentNode.insertBefore(e, this)
				})
			},
			after: function() {
				return this.domManip(arguments, function(e) {
					this.parentNode && this.parentNode.insertBefore(e, this.nextSibling)
				})
			},
			remove: function(e, t) {
				var n, r = e ? h.filter(e, this) : this,
					i = 0;
				for (;
				(n = r[i]) != null; i++)!t && n.nodeType === 1 && h.cleanData(wt(n)), n.parentNode && (t && h.contains(n.ownerDocument, n) && Nt(wt(n, "script")), n.parentNode.removeChild(n));
				return this
			},
			empty: function() {
				var e, t = 0;
				for (;
				(e = this[t]) != null; t++) {
					e.nodeType === 1 && h.cleanData(wt(e, !1));
					while (e.firstChild) e.removeChild(e.firstChild);
					e.options && h.nodeName(e, "select") && (e.options.length = 0)
				}
				return this
			},
			clone: function(e, t) {
				return e = e == null ? !1 : e, t = t == null ? e : t, this.map(function() {
					return h.clone(this, e, t)
				})
			},
			html: function(e) {
				return $(this, function(e) {
					var t = this[0] || {},
						n = 0,
						r = this.length;
					if (e === undefined) return t.nodeType === 1 ? t.innerHTML.replace(st, "") : undefined;
					if (typeof e == "string" && !ht.test(e) && (l.htmlSerialize || !ot.test(e)) && (l.leadingWhitespace || !ut.test(e)) && !gt[(ft.exec(e) || ["", ""])[1].toLowerCase()]) {
						e = e.replace(at, "<$1></$2>");
						try {
							for (; n < r; n++) t = this[n] || {}, t.nodeType === 1 && (h.cleanData(wt(t, !1)), t.innerHTML = e);
							t = 0
						} catch (i) {}
					}
					t && this.empty().append(e)
				}, null, e, arguments.length)
			},
			replaceWith: function() {
				var e = arguments[0];
				return this.domManip(arguments, function(t) {
					e = this.parentNode, h.cleanData(wt(this)), e && e.replaceChild(t, this)
				}), e && (e.length || e.nodeType) ? this : this.remove()
			},
			detach: function(e) {
				return this.remove(e, !0)
			},
			domManip: function(e, t) {
				e = i.apply([], e);
				var n, r, s, o, u, a, f = 0,
					c = this.length,
					p = this,
					d = c - 1,
					v = e[0],
					m = h.isFunction(v);
				if (m || c > 1 && typeof v == "string" && !l.checkClone && pt.test(v)) return this.each(function(n) {
					var r = p.eq(n);
					m && (e[0] = v.call(this, n, r.html())), r.domManip(e, t)
				});
				if (c) {
					a = h.buildFragment(e, this[0].ownerDocument, !1, this), n = a.firstChild, a.childNodes.length === 1 && (a = n);
					if (n) {
						o = h.map(wt(a, "script"), xt), s = o.length;
						for (; f < c; f++) r = a, f !== d && (r = h.clone(r, !0, !0), s && h.merge(o, wt(r, "script"))), t.call(this[f], r, f);
						if (s) {
							u = o[o.length - 1].ownerDocument, h.map(o, Tt);
							for (f = 0; f < s; f++) r = o[f], dt.test(r.type || "") && !h._data(r, "globalEval") && h.contains(u, r) && (r.src ? h._evalUrl && h._evalUrl(r.src) : h.globalEval((r.text || r.textContent || r.innerHTML || "").replace(mt, "")))
						}
						a = n = null
					}
				}
				return this
			}
		}), h.each({
			appendTo: "append",
			prependTo: "prepend",
			insertBefore: "before",
			insertAfter: "after",
			replaceAll: "replaceWith"
		}, function(e, t) {
			h.fn[e] = function(e) {
				var n, r = 0,
					i = [],
					o = h(e),
					u = o.length - 1;
				for (; r <= u; r++) n = r === u ? this : this.clone(!0), h(o[r])[t](n), s.apply(i, n.get());
				return this.pushStack(i)
			}
		});
		var Lt, At = {};
		(function() {
			var e;
			l.shrinkWrapBlocks = function() {
				if (e != null) return e;
				e = !1;
				var t, n, r;
				n = T.getElementsByTagName("body")[0];
				if (!n || !n.style) return;
				return t = T.createElement("div"), r = T.createElement("div"), r.style.cssText = "position:absolute;border:0;width:0;height:0;top:0;left:-9999px", n.appendChild(r).appendChild(t), typeof t.style.zoom !== B && (t.style.cssText = "-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:1px;width:1px;zoom:1", t.appendChild(T.createElement("div")).style.width = "5px", e = t.offsetWidth !== 3), n.removeChild(r), e
			}
		})();
		var _t = /^margin/,
			Dt = new RegExp("^(" + W + ")(?!px)[a-z%]+$", "i"),
			Pt, Ht, Bt = /^(top|right|bottom|left)$/;
		e.getComputedStyle ? (Pt = function(t) {
			return t.ownerDocument.defaultView.opener ? t.ownerDocument.defaultView.getComputedStyle(t, null) : e.getComputedStyle(t, null)
		}, Ht = function(e, t, n) {
			var r, i, s, o, u = e.style;
			return n = n || Pt(e), o = n ? n.getPropertyValue(t) || n[t] : undefined, n && (o === "" && !h.contains(e.ownerDocument, e) && (o = h.style(e, t)), Dt.test(o) && _t.test(t) && (r = u.width, i = u.minWidth, s = u.maxWidth, u.minWidth = u.maxWidth = u.width = o, o = n.width, u.width = r, u.minWidth = i, u.maxWidth = s)), o === undefined ? o : o + ""
		}) : T.documentElement.currentStyle && (Pt = function(e) {
			return e.currentStyle
		}, Ht = function(e, t, n) {
			var r, i, s, o, u = e.style;
			return n = n || Pt(e), o = n ? n[t] : undefined, o == null && u && u[t] && (o = u[t]), Dt.test(o) && !Bt.test(t) && (r = u.left, i = e.runtimeStyle, s = i && i.left, s && (i.left = e.currentStyle.left), u.left = t === "fontSize" ? "1em" : o, o = u.pixelLeft + "px", u.left = r, s && (i.left = s)), o === undefined ? o : o + "" || "auto"
		}), function() {
			function a() {
				var t, n, r, a;
				n = T.getElementsByTagName("body")[0];
				if (!n || !n.style) return;
				t = T.createElement("div"), r = T.createElement("div"), r.style.cssText = "position:absolute;border:0;width:0;height:0;top:0;left:-9999px", n.appendChild(r).appendChild(t), t.style.cssText = "-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;display:block;margin-top:1%;top:1%;border:1px;padding:1px;width:4px;position:absolute", i = s = !1, u = !0, e.getComputedStyle && (i = (e.getComputedStyle(t, null) || {}).top !== "1%", s = (e.getComputedStyle(t, null) || {
					width: "4px"
				}).width === "4px", a = t.appendChild(T.createElement("div")), a.style.cssText = t.style.cssText = "-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:0", a.style.marginRight = a.style.width = "0", t.style.width = "1px", u = !parseFloat((e.getComputedStyle(a, null) || {}).marginRight), t.removeChild(a)), t.innerHTML = "<table><tr><td></td><td>t</td></tr></table>", a = t.getElementsByTagName("td"), a[0].style.cssText = "margin:0;border:0;padding:0;display:none", o = a[0].offsetHeight === 0, o && (a[0].style.display = "", a[1].style.display = "none", o = a[0].offsetHeight === 0), n.removeChild(r)
			}
			var t, n, r, i, s, o, u;
			t = T.createElement("div"), t.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>", r = t.getElementsByTagName("a")[0], n = r && r.style;
			if (!n) return;
			n.cssText = "float:left;opacity:.5", l.opacity = n.opacity === "0.5", l.cssFloat = !! n.cssFloat, t.style.backgroundClip = "content-box", t.cloneNode(!0).style.backgroundClip = "", l.clearCloneStyle = t.style.backgroundClip === "content-box", l.boxSizing = n.boxSizing === "" || n.MozBoxSizing === "" || n.WebkitBoxSizing === "", h.extend(l, {
				reliableHiddenOffsets: function() {
					return o == null && a(), o
				},
				boxSizingReliable: function() {
					return s == null && a(), s
				},
				pixelPosition: function() {
					return i == null && a(), i
				},
				reliableMarginRight: function() {
					return u == null && a(), u
				}
			})
		}(), h.swap = function(e, t, n, r) {
			var i, s, o = {};
			for (s in t) o[s] = e.style[s], e.style[s] = t[s];
			i = n.apply(e, r || []);
			for (s in t) e.style[s] = o[s];
			return i
		};
		var Ft = /alpha\([^)]*\)/i,
			It = /opacity\s*=\s*([^)]*)/,
			qt = /^(none|table(?!-c[ea]).+)/,
			Rt = new RegExp("^(" + W + ")(.*)$", "i"),
			Ut = new RegExp("^([+-])=(" + W + ")", "i"),
			zt = {
				position: "absolute",
				visibility: "hidden",
				display: "block"
			},
			Wt = {
				letterSpacing: "0",
				fontWeight: "400"
			},
			Xt = ["Webkit", "O", "Moz", "ms"];
		h.extend({
			cssHooks: {
				opacity: {
					get: function(e, t) {
						if (t) {
							var n = Ht(e, "opacity");
							return n === "" ? "1" : n
						}
					}
				}
			},
			cssNumber: {
				columnCount: !0,
				fillOpacity: !0,
				flexGrow: !0,
				flexShrink: !0,
				fontWeight: !0,
				lineHeight: !0,
				opacity: !0,
				order: !0,
				orphans: !0,
				widows: !0,
				zIndex: !0,
				zoom: !0
			},
			cssProps: {
				"float": l.cssFloat ? "cssFloat" : "styleFloat"
			},
			style: function(e, t, n, r) {
				if (!e || e.nodeType === 3 || e.nodeType === 8 || !e.style) return;
				var i, s, o, u = h.camelCase(t),
					a = e.style;
				t = h.cssProps[u] || (h.cssProps[u] = Vt(a, u)), o = h.cssHooks[t] || h.cssHooks[u];
				if (n === undefined) return o && "get" in o && (i = o.get(e, !1, r)) !== undefined ? i : a[t];
				s = typeof n, s === "string" && (i = Ut.exec(n)) && (n = (i[1] + 1) * i[2] + parseFloat(h.css(e, t)), s = "number");
				if (n == null || n !== n) return;
				s === "number" && !h.cssNumber[u] && (n += "px"), !l.clearCloneStyle && n === "" && t.indexOf("background") === 0 && (a[t] = "inherit");
				if (!o || !("set" in o) || (n = o.set(e, n, r)) !== undefined) try {
					a[t] = n
				} catch (f) {}
			},
			css: function(e, t, n, r) {
				var i, s, o, u = h.camelCase(t);
				return t = h.cssProps[u] || (h.cssProps[u] = Vt(e.style, u)), o = h.cssHooks[t] || h.cssHooks[u], o && "get" in o && (s = o.get(e, !0, n)), s === undefined && (s = Ht(e, t, r)), s === "normal" && t in Wt && (s = Wt[t]), n === "" || n ? (i = parseFloat(s), n === !0 || h.isNumeric(i) ? i || 0 : s) : s
			}
		}), h.each(["height", "width"], function(e, t) {
			h.cssHooks[t] = {
				get: function(e, n, r) {
					if (n) return qt.test(h.css(e, "display")) && e.offsetWidth === 0 ? h.swap(e, zt, function() {
						return Qt(e, t, r)
					}) : Qt(e, t, r)
				},
				set: function(e, n, r) {
					var i = r && Pt(e);
					return Jt(e, n, r ? Kt(e, t, r, l.boxSizing && h.css(e, "boxSizing", !1, i) === "border-box", i) : 0)
				}
			}
		}), l.opacity || (h.cssHooks.opacity = {
			get: function(e, t) {
				return It.test((t && e.currentStyle ? e.currentStyle.filter : e.style.filter) || "") ? .01 * parseFloat(RegExp.$1) + "" : t ? "1" : ""
			},
			set: function(e, t) {
				var n = e.style,
					r = e.currentStyle,
					i = h.isNumeric(t) ? "alpha(opacity=" + t * 100 + ")" : "",
					s = r && r.filter || n.filter || "";
				n.zoom = 1;
				if ((t >= 1 || t === "") && h.trim(s.replace(Ft, "")) === "" && n.removeAttribute) {
					n.removeAttribute("filter");
					if (t === "" || r && !r.filter) return
				}
				n.filter = Ft.test(s) ? s.replace(Ft, i) : s + " " + i
			}
		}), h.cssHooks.marginRight = jt(l.reliableMarginRight, function(e, t) {
			if (t) return h.swap(e, {
				display: "inline-block"
			}, Ht, [e, "marginRight"])
		}), h.each({
			margin: "",
			padding: "",
			border: "Width"
		}, function(e, t) {
			h.cssHooks[e + t] = {
				expand: function(n) {
					var r = 0,
						i = {},
						s = typeof n == "string" ? n.split(" ") : [n];
					for (; r < 4; r++) i[e + X[r] + t] = s[r] || s[r - 2] || s[0];
					return i
				}
			}, _t.test(e) || (h.cssHooks[e + t].set = Jt)
		}), h.fn.extend({
			css: function(e, t) {
				return $(this, function(e, t, n) {
					var r, i, s = {},
						o = 0;
					if (h.isArray(t)) {
						r = Pt(e), i = t.length;
						for (; o < i; o++) s[t[o]] = h.css(e, t[o], !1, r);
						return s
					}
					return n !== undefined ? h.style(e, t, n) : h.css(e, t)
				}, e, t, arguments.length > 1)
			},
			show: function() {
				return $t(this, !0)
			},
			hide: function() {
				return $t(this)
			},
			toggle: function(e) {
				return typeof e == "boolean" ? e ? this.show() : this.hide() : this.each(function() {
					V(this) ? h(this).show() : h(this).hide()
				})
			}
		}), h.Tween = Gt, Gt.prototype = {
			constructor: Gt,
			init: function(e, t, n, r, i, s) {
				this.elem = e, this.prop = n, this.easing = i || "swing", this.options = t, this.start = this.now = this.cur(), this.end = r, this.unit = s || (h.cssNumber[n] ? "" : "px")
			},
			cur: function() {
				var e = Gt.propHooks[this.prop];
				return e && e.get ? e.get(this) : Gt.propHooks._default.get(this)
			},
			run: function(e) {
				var t, n = Gt.propHooks[this.prop];
				return this.options.duration ? this.pos = t = h.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration) : this.pos = t = e, this.now = (this.end - this.start) * t + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), n && n.set ? n.set(this) : Gt.propHooks._default.set(this), this
			}
		}, Gt.prototype.init.prototype = Gt.prototype, Gt.propHooks = {
			_default: {
				get: function(e) {
					var t;
					return e.elem[e.prop] == null || !! e.elem.style && e.elem.style[e.prop] != null ? (t = h.css(e.elem, e.prop, ""), !t || t === "auto" ? 0 : t) : e.elem[e.prop]
				},
				set: function(e) {
					h.fx.step[e.prop] ? h.fx.step[e.prop](e) : e.elem.style && (e.elem.style[h.cssProps[e.prop]] != null || h.cssHooks[e.prop]) ? h.style(e.elem, e.prop, e.now + e.unit) : e.elem[e.prop] = e.now
				}
			}
		}, Gt.propHooks.scrollTop = Gt.propHooks.scrollLeft = {
			set: function(e) {
				e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now)
			}
		}, h.easing = {
			linear: function(e) {
				return e
			},
			swing: function(e) {
				return .5 - Math.cos(e * Math.PI) / 2
			}
		}, h.fx = Gt.prototype.init, h.fx.step = {};
		var Yt, Zt, en = /^(?:toggle|show|hide)$/,
			tn = new RegExp("^(?:([+-])=|)(" + W + ")([a-z%]*)$", "i"),
			nn = /queueHooks$/,
			rn = [fn],
			sn = {
				"*": [function(e, t) {
					var n = this.createTween(e, t),
						r = n.cur(),
						i = tn.exec(t),
						s = i && i[3] || (h.cssNumber[e] ? "" : "px"),
						o = (h.cssNumber[e] || s !== "px" && +r) && tn.exec(h.css(n.elem, e)),
						u = 1,
						a = 20;
					if (o && o[3] !== s) {
						s = s || o[3], i = i || [], o = +r || 1;
						do u = u || ".5", o /= u, h.style(n.elem, e, o + s);
						while (u !== (u = n.cur() / r) && u !== 1 && --a)
					}
					return i && (o = n.start = +o || +r || 0, n.unit = s, n.end = i[1] ? o + (i[1] + 1) * i[2] : +i[2]), n
				}]
			};
		h.Animation = h.extend(cn, {
			tweener: function(e, t) {
				h.isFunction(e) ? (t = e, e = ["*"]) : e = e.split(" ");
				var n, r = 0,
					i = e.length;
				for (; r < i; r++) n = e[r], sn[n] = sn[n] || [], sn[n].unshift(t)
			},
			prefilter: function(e, t) {
				t ? rn.unshift(e) : rn.push(e)
			}
		}), h.speed = function(e, t, n) {
			var r = e && typeof e == "object" ? h.extend({}, e) : {
				complete: n || !n && t || h.isFunction(e) && e,
				duration: e,
				easing: n && t || t && !h.isFunction(t) && t
			};
			r.duration = h.fx.off ? 0 : typeof r.duration == "number" ? r.duration : r.duration in h.fx.speeds ? h.fx.speeds[r.duration] : h.fx.speeds._default;
			if (r.queue == null || r.queue === !0) r.queue = "fx";
			return r.old = r.complete, r.complete = function() {
				h.isFunction(r.old) && r.old.call(this), r.queue && h.dequeue(this, r.queue)
			}, r
		}, h.fn.extend({
			fadeTo: function(e, t, n, r) {
				return this.filter(V).css("opacity", 0).show().end().animate({
					opacity: t
				}, e, n, r)
			},
			animate: function(e, t, n, r) {
				var i = h.isEmptyObject(e),
					s = h.speed(t, n, r),
					o = function() {
						var t = cn(this, h.extend({}, e), s);
						(i || h._data(this, "finish")) && t.stop(!0)
					};
				return o.finish = o, i || s.queue === !1 ? this.each(o) : this.queue(s.queue, o)
			},
			stop: function(e, t, n) {
				var r = function(e) {
						var t = e.stop;
						delete e.stop, t(n)
					};
				return typeof e != "string" && (n = t, t = e, e = undefined), t && e !== !1 && this.queue(e || "fx", []), this.each(function() {
					var t = !0,
						i = e != null && e + "queueHooks",
						s = h.timers,
						o = h._data(this);
					if (i) o[i] && o[i].stop && r(o[i]);
					else for (i in o) o[i] && o[i].stop && nn.test(i) && r(o[i]);
					for (i = s.length; i--;) s[i].elem === this && (e == null || s[i].queue === e) && (s[i].anim.stop(n), t = !1, s.splice(i, 1));
					(t || !n) && h.dequeue(this, e)
				})
			},
			finish: function(e) {
				return e !== !1 && (e = e || "fx"), this.each(function() {
					var t, n = h._data(this),
						r = n[e + "queue"],
						i = n[e + "queueHooks"],
						s = h.timers,
						o = r ? r.length : 0;
					n.finish = !0, h.queue(this, e, []), i && i.stop && i.stop.call(this, !0);
					for (t = s.length; t--;) s[t].elem === this && s[t].queue === e && (s[t].anim.stop(!0), s.splice(t, 1));
					for (t = 0; t < o; t++) r[t] && r[t].finish && r[t].finish.call(this);
					delete n.finish
				})
			}
		}), h.each(["toggle", "show", "hide"], function(e, t) {
			var n = h.fn[t];
			h.fn[t] = function(e, r, i) {
				return e == null || typeof e == "boolean" ? n.apply(this, arguments) : this.animate(un(t, !0), e, r, i)
			}
		}), h.each({
			slideDown: un("show"),
			slideUp: un("hide"),
			slideToggle: un("toggle"),
			fadeIn: {
				opacity: "show"
			},
			fadeOut: {
				opacity: "hide"
			},
			fadeToggle: {
				opacity: "toggle"
			}
		}, function(e, t) {
			h.fn[e] = function(e, n, r) {
				return this.animate(t, e, n, r)
			}
		}), h.timers = [], h.fx.tick = function() {
			var e, t = h.timers,
				n = 0;
			Yt = h.now();
			for (; n < t.length; n++) e = t[n], !e() && t[n] === e && t.splice(n--, 1);
			t.length || h.fx.stop(), Yt = undefined
		}, h.fx.timer = function(e) {
			h.timers.push(e), e() ? h.fx.start() : h.timers.pop()
		}, h.fx.interval = 13, h.fx.start = function() {
			Zt || (Zt = setInterval(h.fx.tick, h.fx.interval))
		}, h.fx.stop = function() {
			clearInterval(Zt), Zt = null
		}, h.fx.speeds = {
			slow: 600,
			fast: 200,
			_default: 400
		}, h.fn.delay = function(e, t) {
			return e = h.fx ? h.fx.speeds[e] || e : e, t = t || "fx", this.queue(t, function(t, n) {
				var r = setTimeout(t, e);
				n.stop = function() {
					clearTimeout(r)
				}
			})
		}, function() {
			var e, t, n, r, i;
			t = T.createElement("div"), t.setAttribute("className", "t"), t.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>", r = t.getElementsByTagName("a")[0], n = T.createElement("select"), i = n.appendChild(T.createElement("option")), e = t.getElementsByTagName("input")[0], r.style.cssText = "top:1px", l.getSetAttribute = t.className !== "t", l.style = /top/.test(r.getAttribute("style")), l.hrefNormalized = r.getAttribute("href") === "/a", l.checkOn = !! e.value, l.optSelected = i.selected, l.enctype = !! T.createElement("form").enctype, n.disabled = !0, l.optDisabled = !i.disabled, e = T.createElement("input"), e.setAttribute("value", ""), l.input = e.getAttribute("value") === "", e.value = "t", e.setAttribute("type", "radio"), l.radioValue = e.value === "t"
		}();
		var hn = /\r/g;
		h.fn.extend({
			val: function(e) {
				var t, n, r, i = this[0];
				if (!arguments.length) {
					if (i) return t = h.valHooks[i.type] || h.valHooks[i.nodeName.toLowerCase()], t && "get" in t && (n = t.get(i, "value")) !== undefined ? n : (n = i.value, typeof n == "string" ? n.replace(hn, "") : n == null ? "" : n);
					return
				}
				return r = h.isFunction(e), this.each(function(n) {
					var i;
					if (this.nodeType !== 1) return;
					r ? i = e.call(this, n, h(this).val()) : i = e, i == null ? i = "" : typeof i == "number" ? i += "" : h.isArray(i) && (i = h.map(i, function(e) {
						return e == null ? "" : e + ""
					})), t = h.valHooks[this.type] || h.valHooks[this.nodeName.toLowerCase()];
					if (!t || !("set" in t) || t.set(this, i, "value") === undefined) this.value = i
				})
			}
		}), h.extend({
			valHooks: {
				option: {
					get: function(e) {
						var t = h.find.attr(e, "value");
						return t != null ? t : h.trim(h.text(e))
					}
				},
				select: {
					get: function(e) {
						var t, n, r = e.options,
							i = e.selectedIndex,
							s = e.type === "select-one" || i < 0,
							o = s ? null : [],
							u = s ? i + 1 : r.length,
							a = i < 0 ? u : s ? i : 0;
						for (; a < u; a++) {
							n = r[a];
							if ((n.selected || a === i) && (l.optDisabled ? !n.disabled : n.getAttribute("disabled") === null) && (!n.parentNode.disabled || !h.nodeName(n.parentNode, "optgroup"))) {
								t = h(n).val();
								if (s) return t;
								o.push(t)
							}
						}
						return o
					},
					set: function(e, t) {
						var n, r, i = e.options,
							s = h.makeArray(t),
							o = i.length;
						while (o--) {
							r = i[o];
							if (h.inArray(h.valHooks.option.get(r), s) >= 0) try {
								r.selected = n = !0
							} catch (u) {
								r.scrollHeight
							} else r.selected = !1
						}
						return n || (e.selectedIndex = -1), i
					}
				}
			}
		}), h.each(["radio", "checkbox"], function() {
			h.valHooks[this] = {
				set: function(e, t) {
					if (h.isArray(t)) return e.checked = h.inArray(h(e).val(), t) >= 0
				}
			}, l.checkOn || (h.valHooks[this].get = function(e) {
				return e.getAttribute("value") === null ? "on" : e.value
			})
		});
		var pn, dn, vn = h.expr.attrHandle,
			mn = /^(?:checked|selected)$/i,
			gn = l.getSetAttribute,
			yn = l.input;
		h.fn.extend({
			attr: function(e, t) {
				return $(this, h.attr, e, t, arguments.length > 1)
			},
			removeAttr: function(e) {
				return this.each(function() {
					h.removeAttr(this, e)
				})
			}
		}), h.extend({
			attr: function(e, t, n) {
				var r, i, s = e.nodeType;
				if (!e || s === 3 || s === 8 || s === 2) return;
				if (typeof e.getAttribute === B) return h.prop(e, t, n);
				if (s !== 1 || !h.isXMLDoc(e)) t = t.toLowerCase(), r = h.attrHooks[t] || (h.expr.match.bool.test(t) ? dn : pn);
				if (n === undefined) return r && "get" in r && (i = r.get(e, t)) !== null ? i : (i = h.find.attr(e, t), i == null ? undefined : i);
				if (n !== null) return r && "set" in r && (i = r.set(e, n, t)) !== undefined ? i : (e.setAttribute(t, n + ""), n);
				h.removeAttr(e, t)
			},
			removeAttr: function(e, t) {
				var n, r, i = 0,
					s = t && t.match(O);
				if (s && e.nodeType === 1) while (n = s[i++]) r = h.propFix[n] || n, h.expr.match.bool.test(n) ? yn && gn || !mn.test(n) ? e[r] = !1 : e[h.camelCase("default-" + n)] = e[r] = !1 : h.attr(e, n, ""), e.removeAttribute(gn ? n : r)
			},
			attrHooks: {
				type: {
					set: function(e, t) {
						if (!l.radioValue && t === "radio" && h.nodeName(e, "input")) {
							var n = e.value;
							return e.setAttribute("type", t), n && (e.value = n), t
						}
					}
				}
			}
		}), dn = {
			set: function(e, t, n) {
				return t === !1 ? h.removeAttr(e, n) : yn && gn || !mn.test(n) ? e.setAttribute(!gn && h.propFix[n] || n, n) : e[h.camelCase("default-" + n)] = e[n] = !0, n
			}
		}, h.each(h.expr.match.bool.source.match(/\w+/g), function(e, t) {
			var n = vn[t] || h.find.attr;
			vn[t] = yn && gn || !mn.test(t) ?
			function(e, t, r) {
				var i, s;
				return r || (s = vn[t], vn[t] = i, i = n(e, t, r) != null ? t.toLowerCase() : null, vn[t] = s), i
			} : function(e, t, n) {
				if (!n) return e[h.camelCase("default-" + t)] ? t.toLowerCase() : null
			}
		});
		if (!yn || !gn) h.attrHooks.value = {
			set: function(e, t, n) {
				if (!h.nodeName(e, "input")) return pn && pn.set(e, t, n);
				e.defaultValue = t
			}
		};
		gn || (pn = {
			set: function(e, t, n) {
				var r = e.getAttributeNode(n);
				r || e.setAttributeNode(r = e.ownerDocument.createAttribute(n)), r.value = t += "";
				if (n === "value" || t === e.getAttribute(n)) return t
			}
		}, vn.id = vn.name = vn.coords = function(e, t, n) {
			var r;
			if (!n) return (r = e.getAttributeNode(t)) && r.value !== "" ? r.value : null
		}, h.valHooks.button = {
			get: function(e, t) {
				var n = e.getAttributeNode(t);
				if (n && n.specified) return n.value
			},
			set: pn.set
		}, h.attrHooks.contenteditable = {
			set: function(e, t, n) {
				pn.set(e, t === "" ? !1 : t, n)
			}
		}, h.each(["width", "height"], function(e, t) {
			h.attrHooks[t] = {
				set: function(e, n) {
					if (n === "") return e.setAttribute(t, "auto"), n
				}
			}
		})), l.style || (h.attrHooks.style = {
			get: function(e) {
				return e.style.cssText || undefined
			},
			set: function(e, t) {
				return e.style.cssText = t + ""
			}
		});
		var bn = /^(?:input|select|textarea|button|object)$/i,
			wn = /^(?:a|area)$/i;
		h.fn.extend({
			prop: function(e, t) {
				return $(this, h.prop, e, t, arguments.length > 1)
			},
			removeProp: function(e) {
				return e = h.propFix[e] || e, this.each(function() {
					try {
						this[e] = undefined, delete this[e]
					} catch (t) {}
				})
			}
		}), h.extend({
			propFix: {
				"for": "htmlFor",
				"class": "className"
			},
			prop: function(e, t, n) {
				var r, i, s, o = e.nodeType;
				if (!e || o === 3 || o === 8 || o === 2) return;
				return s = o !== 1 || !h.isXMLDoc(e), s && (t = h.propFix[t] || t, i = h.propHooks[t]), n !== undefined ? i && "set" in i && (r = i.set(e, n, t)) !== undefined ? r : e[t] = n : i && "get" in i && (r = i.get(e, t)) !== null ? r : e[t]
			},
			propHooks: {
				tabIndex: {
					get: function(e) {
						var t = h.find.attr(e, "tabindex");
						return t ? parseInt(t, 10) : bn.test(e.nodeName) || wn.test(e.nodeName) && e.href ? 0 : -1
					}
				}
			}
		}), l.hrefNormalized || h.each(["href", "src"], function(e, t) {
			h.propHooks[t] = {
				get: function(e) {
					return e.getAttribute(t, 4)
				}
			}
		}), l.optSelected || (h.propHooks.selected = {
			get: function(e) {
				var t = e.parentNode;
				return t && (t.selectedIndex, t.parentNode && t.parentNode.selectedIndex), null
			}
		}), h.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], function() {
			h.propFix[this.toLowerCase()] = this
		}), l.enctype || (h.propFix.enctype = "encoding");
		var En = /[\t\r\n\f]/g;
		h.fn.extend({
			addClass: function(e) {
				var t, n, r, i, s, o, u = 0,
					a = this.length,
					f = typeof e == "string" && e;
				if (h.isFunction(e)) return this.each(function(t) {
					h(this).addClass(e.call(this, t, this.className))
				});
				if (f) {
					t = (e || "").match(O) || [];
					for (; u < a; u++) {
						n = this[u], r = n.nodeType === 1 && (n.className ? (" " + n.className + " ").replace(En, " ") : " ");
						if (r) {
							s = 0;
							while (i = t[s++]) r.indexOf(" " + i + " ") < 0 && (r += i + " ");
							o = h.trim(r), n.className !== o && (n.className = o)
						}
					}
				}
				return this
			},
			removeClass: function(e) {
				var t, n, r, i, s, o, u = 0,
					a = this.length,
					f = arguments.length === 0 || typeof e == "string" && e;
				if (h.isFunction(e)) return this.each(function(t) {
					h(this).removeClass(e.call(this, t, this.className))
				});
				if (f) {
					t = (e || "").match(O) || [];
					for (; u < a; u++) {
						n = this[u], r = n.nodeType === 1 && (n.className ? (" " + n.className + " ").replace(En, " ") : "");
						if (r) {
							s = 0;
							while (i = t[s++]) while (r.indexOf(" " + i + " ") >= 0) r = r.replace(" " + i + " ", " ");
							o = e ? h.trim(r) : "", n.className !== o && (n.className = o)
						}
					}
				}
				return this
			},
			toggleClass: function(e, t) {
				var n = typeof e;
				return typeof t == "boolean" && n === "string" ? t ? this.addClass(e) : this.removeClass(e) : h.isFunction(e) ? this.each(function(n) {
					h(this).toggleClass(e.call(this, n, this.className, t), t)
				}) : this.each(function() {
					if (n === "string") {
						var t, r = 0,
							i = h(this),
							s = e.match(O) || [];
						while (t = s[r++]) i.hasClass(t) ? i.removeClass(t) : i.addClass(t)
					} else if (n === B || n === "boolean") this.className && h._data(this, "__className__", this.className), this.className = this.className || e === !1 ? "" : h._data(this, "__className__") || ""
				})
			},
			hasClass: function(e) {
				var t = " " + e + " ",
					n = 0,
					r = this.length;
				for (; n < r; n++) if (this[n].nodeType === 1 && (" " + this[n].className + " ").replace(En, " ").indexOf(t) >= 0) return !0;
				return !1
			}
		}), h.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "), function(e, t) {
			h.fn[t] = function(e, n) {
				return arguments.length > 0 ? this.on(t, null, e, n) : this.trigger(t)
			}
		}), h.fn.extend({
			hover: function(e, t) {
				return this.mouseenter(e).mouseleave(t || e)
			},
			bind: function(e, t, n) {
				return this.on(e, null, t, n)
			},
			unbind: function(e, t) {
				return this.off(e, null, t)
			},
			delegate: function(e, t, n, r) {
				return this.on(t, e, n, r)
			},
			undelegate: function(e, t, n) {
				return arguments.length === 1 ? this.off(e, "**") : this.off(t, e || "**", n)
			}
		});
		var Sn = h.now(),
			xn = /\?/,
			Tn = /(,)|(\[|{)|(}|])|"(?:[^"\\\r\n]|\\["\\\/bfnrt]|\\u[\da-fA-F]{4})*"\s*:?|true|false|null|-?(?!0\d)\d+(?:\.\d+|)(?:[eE][+-]?\d+|)/g;
		h.parseJSON = function(t) {
			if (e.JSON && e.JSON.parse) return e.JSON.parse(t + "");
			var n, r = null,
				i = h.trim(t + "");
			return i && !h.trim(i.replace(Tn, function(e, t, i, s) {
				return n && t && (r = 0), r === 0 ? e : (n = i || t, r += !s - !i, "")
			})) ? Function("return " + i)() : h.error("Invalid JSON: " + t)
		}, h.parseXML = function(t) {
			var n, r;
			if (!t || typeof t != "string") return null;
			try {
				e.DOMParser ? (r = new DOMParser, n = r.parseFromString(t, "text/xml")) : (n = new ActiveXObject("Microsoft.XMLDOM"), n.async = "false", n.loadXML(t))
			} catch (i) {
				n = undefined
			}
			return (!n || !n.documentElement || n.getElementsByTagName("parsererror").length) && h.error("Invalid XML: " + t), n
		};
		var Nn, Cn, kn = /#.*$/,
			Ln = /([?&])_=[^&]*/,
			An = /^(.*?):[ \t]*([^\r\n]*)\r?$/mg,
			On = /^(?:about|app|app-storage|.+-extension|file|res|widget):$/,
			Mn = /^(?:GET|HEAD)$/,
			_n = /^\/\//,
			Dn = /^([\w.+-]+:)(?:\/\/(?:[^\/?#]*@|)([^\/?#:]*)(?::(\d+)|)|)/,
			Pn = {},
			Hn = {},
			Bn = "*/".concat("*");
		try {
			Cn = location.href
		} catch (jn) {
			Cn = T.createElement("a"), Cn.href = "", Cn = Cn.href
		}
		Nn = Dn.exec(Cn.toLowerCase()) || [], h.extend({
			active: 0,
			lastModified: {},
			etag: {},
			ajaxSettings: {
				url: Cn,
				type: "GET",
				isLocal: On.test(Nn[1]),
				global: !0,
				processData: !0,
				async: !0,
				contentType: "application/x-www-form-urlencoded; charset=UTF-8",
				accepts: {
					"*": Bn,
					text: "text/plain",
					html: "text/html",
					xml: "application/xml, text/xml",
					json: "application/json, text/javascript"
				},
				contents: {
					xml: /xml/,
					html: /html/,
					json: /json/
				},
				responseFields: {
					xml: "responseXML",
					text: "responseText",
					json: "responseJSON"
				},
				converters: {
					"* text": String,
					"text html": !0,
					"text json": h.parseJSON,
					"text xml": h.parseXML
				},
				flatOptions: {
					url: !0,
					context: !0
				}
			},
			ajaxSetup: function(e, t) {
				return t ? qn(qn(e, h.ajaxSettings), t) : qn(h.ajaxSettings, e)
			},
			ajaxPrefilter: Fn(Pn),
			ajaxTransport: Fn(Hn),
			ajax: function(e, t) {
				function x(e, t, n, r) {
					var f, g, y, w, S, x = t;
					if (b === 2) return;
					b = 2, o && clearTimeout(o), a = undefined, s = r || "", E.readyState = e > 0 ? 4 : 0, f = e >= 200 && e < 300 || e === 304, n && (w = Rn(l, E, n)), w = Un(l, w, E, f);
					if (f) l.ifModified && (S = E.getResponseHeader("Last-Modified"), S && (h.lastModified[i] = S), S = E.getResponseHeader("etag"), S && (h.etag[i] = S)), e === 204 || l.type === "HEAD" ? x = "nocontent" : e === 304 ? x = "notmodified" : (x = w.state, g = w.data, y = w.error, f = !y);
					else {
						y = x;
						if (e || !x) x = "error", e < 0 && (e = 0)
					}
					E.status = e, E.statusText = (t || x) + "", f ? d.resolveWith(c, [g, x, E]) : d.rejectWith(c, [E, x, y]), E.statusCode(m), m = undefined, u && p.trigger(f ? "ajaxSuccess" : "ajaxError", [E, l, f ? g : y]), v.fireWith(c, [E, x]), u && (p.trigger("ajaxComplete", [E, l]), --h.active || h.event.trigger("ajaxStop"))
				}
				typeof e == "object" && (t = e, e = undefined), t = t || {};
				var n, r, i, s, o, u, a, f, l = h.ajaxSetup({}, t),
					c = l.context || l,
					p = l.context && (c.nodeType || c.jquery) ? h(c) : h.event,
					d = h.Deferred(),
					v = h.Callbacks("once memory"),
					m = l.statusCode || {},
					g = {},
					y = {},
					b = 0,
					w = "canceled",
					E = {
						readyState: 0,
						getResponseHeader: function(e) {
							var t;
							if (b === 2) {
								if (!f) {
									f = {};
									while (t = An.exec(s)) f[t[1].toLowerCase()] = t[2]
								}
								t = f[e.toLowerCase()]
							}
							return t == null ? null : t
						},
						getAllResponseHeaders: function() {
							return b === 2 ? s : null
						},
						setRequestHeader: function(e, t) {
							var n = e.toLowerCase();
							return b || (e = y[n] = y[n] || e, g[e] = t), this
						},
						overrideMimeType: function(e) {
							return b || (l.mimeType = e), this
						},
						statusCode: function(e) {
							var t;
							if (e) if (b < 2) for (t in e) m[t] = [m[t], e[t]];
							else E.always(e[E.status]);
							return this
						},
						abort: function(e) {
							var t = e || w;
							return a && a.abort(t), x(0, t), this
						}
					};
				d.promise(E).complete = v.add, E.success = E.done, E.error = E.fail, l.url = ((e || l.url || Cn) + "").replace(kn, "").replace(_n, Nn[1] + "//"), l.type = t.method || t.type || l.method || l.type, l.dataTypes = h.trim(l.dataType || "*").toLowerCase().match(O) || [""], l.crossDomain == null && (n = Dn.exec(l.url.toLowerCase()), l.crossDomain = !(!n || n[1] === Nn[1] && n[2] === Nn[2] && (n[3] || (n[1] === "http:" ? "80" : "443")) === (Nn[3] || (Nn[1] === "http:" ? "80" : "443")))), l.data && l.processData && typeof l.data != "string" && (l.data = h.param(l.data, l.traditional)), In(Pn, l, t, E);
				if (b === 2) return E;
				u = h.event && l.global, u && h.active++ === 0 && h.event.trigger("ajaxStart"), l.type = l.type.toUpperCase(), l.hasContent = !Mn.test(l.type), i = l.url, l.hasContent || (l.data && (i = l.url += (xn.test(i) ? "&" : "?") + l.data, delete l.data), l.cache === !1 && (l.url = Ln.test(i) ? i.replace(Ln, "$1_=" + Sn++) : i + (xn.test(i) ? "&" : "?") + "_=" + Sn++)), l.ifModified && (h.lastModified[i] && E.setRequestHeader("If-Modified-Since", h.lastModified[i]), h.etag[i] && E.setRequestHeader("If-None-Match", h.etag[i])), (l.data && l.hasContent && l.contentType !== !1 || t.contentType) && E.setRequestHeader("Content-Type", l.contentType), E.setRequestHeader("Accept", l.dataTypes[0] && l.accepts[l.dataTypes[0]] ? l.accepts[l.dataTypes[0]] + (l.dataTypes[0] !== "*" ? ", " + Bn + "; q=0.01" : "") : l.accepts["*"]);
				for (r in l.headers) E.setRequestHeader(r, l.headers[r]);
				if (!l.beforeSend || l.beforeSend.call(c, E, l) !== !1 && b !== 2) {
					w = "abort";
					for (r in {
						success: 1,
						error: 1,
						complete: 1
					}) E[r](l[r]);
					a = In(Hn, l, t, E);
					if (!a) x(-1, "No Transport");
					else {
						E.readyState = 1, u && p.trigger("ajaxSend", [E, l]), l.async && l.timeout > 0 && (o = setTimeout(function() {
							E.abort("timeout")
						}, l.timeout));
						try {
							b = 1, a.send(g, x)
						} catch (S) {
							if (!(b < 2)) throw S;
							x(-1, S)
						}
					}
					return E
				}
				return E.abort()
			},
			getJSON: function(e, t, n) {
				return h.get(e, t, n, "json")
			},
			getScript: function(e, t) {
				return h.get(e, undefined, t, "script")
			}
		}), h.each(["get", "post"], function(e, t) {
			h[t] = function(e, n, r, i) {
				return h.isFunction(n) && (i = i || r, r = n, n = undefined), h.ajax({
					url: e,
					type: t,
					dataType: i,
					data: n,
					success: r
				})
			}
		}), h._evalUrl = function(e) {
			return h.ajax({
				url: e,
				type: "GET",
				dataType: "script",
				async: !1,
				global: !1,
				"throws": !0
			})
		}, h.fn.extend({
			wrapAll: function(e) {
				if (h.isFunction(e)) return this.each(function(t) {
					h(this).wrapAll(e.call(this, t))
				});
				if (this[0]) {
					var t = h(e, this[0].ownerDocument).eq(0).clone(!0);
					this[0].parentNode && t.insertBefore(this[0]), t.map(function() {
						var e = this;
						while (e.firstChild && e.firstChild.nodeType === 1) e = e.firstChild;
						return e
					}).append(this)
				}
				return this
			},
			wrapInner: function(e) {
				return h.isFunction(e) ? this.each(function(t) {
					h(this).wrapInner(e.call(this, t))
				}) : this.each(function() {
					var t = h(this),
						n = t.contents();
					n.length ? n.wrapAll(e) : t.append(e)
				})
			},
			wrap: function(e) {
				var t = h.isFunction(e);
				return this.each(function(n) {
					h(this).wrapAll(t ? e.call(this, n) : e)
				})
			},
			unwrap: function() {
				return this.parent().each(function() {
					h.nodeName(this, "body") || h(this).replaceWith(this.childNodes)
				}).end()
			}
		}), h.expr.filters.hidden = function(e) {
			return e.offsetWidth <= 0 && e.offsetHeight <= 0 || !l.reliableHiddenOffsets() && (e.style && e.style.display || h.css(e, "display")) === "none"
		}, h.expr.filters.visible = function(e) {
			return !h.expr.filters.hidden(e)
		};
		var zn = /%20/g,
			Wn = /\[\]$/,
			Xn = /\r?\n/g,
			Vn = /^(?:submit|button|image|reset|file)$/i,
			$n = /^(?:input|select|textarea|keygen)/i;
		h.param = function(e, t) {
			var n, r = [],
				i = function(e, t) {
					t = h.isFunction(t) ? t() : t == null ? "" : t, r[r.length] = encodeURIComponent(e) + "=" + encodeURIComponent(t)
				};
			t === undefined && (t = h.ajaxSettings && h.ajaxSettings.traditional);
			if (h.isArray(e) || e.jquery && !h.isPlainObject(e)) h.each(e, function() {
				i(this.name, this.value)
			});
			else for (n in e) Jn(n, e[n], t, i);
			return r.join("&").replace(zn, "+")
		}, h.fn.extend({
			serialize: function() {
				return h.param(this.serializeArray())
			},
			serializeArray: function() {
				return this.map(function() {
					var e = h.prop(this, "elements");
					return e ? h.makeArray(e) : this
				}).filter(function() {
					var e = this.type;
					return this.name && !h(this).is(":disabled") && $n.test(this.nodeName) && !Vn.test(e) && (this.checked || !J.test(e))
				}).map(function(e, t) {
					var n = h(this).val();
					return n == null ? null : h.isArray(n) ? h.map(n, function(e) {
						return {
							name: t.name,
							value: e.replace(Xn, "\r\n")
						}
					}) : {
						name: t.name,
						value: n.replace(Xn, "\r\n")
					}
				}).get()
			}
		}), h.ajaxSettings.xhr = e.ActiveXObject !== undefined ?
		function() {
			return !this.isLocal && /^(get|post|head|put|delete|options)$/i.test(this.type) && Yn() || Zn()
		} : Yn;
		var Kn = 0,
			Qn = {},
			Gn = h.ajaxSettings.xhr();
		e.attachEvent && e.attachEvent("onunload", function() {
			for (var e in Qn) Qn[e](undefined, !0)
		}), l.cors = !! Gn && "withCredentials" in Gn, Gn = l.ajax = !! Gn, Gn && h.ajaxTransport(function(e) {
			if (!e.crossDomain || l.cors) {
				var t;
				return {
					send: function(n, r) {
						var i, s = e.xhr(),
							o = ++Kn;
						s.open(e.type, e.url, e.async, e.username, e.password);
						if (e.xhrFields) for (i in e.xhrFields) s[i] = e.xhrFields[i];
						e.mimeType && s.overrideMimeType && s.overrideMimeType(e.mimeType), !e.crossDomain && !n["X-Requested-With"] && (n["X-Requested-With"] = "XMLHttpRequest");
						for (i in n) n[i] !== undefined && s.setRequestHeader(i, n[i] + "");
						s.send(e.hasContent && e.data || null), t = function(n, i) {
							var u, a, f;
							if (t && (i || s.readyState === 4)) {
								delete Qn[o], t = undefined, s.onreadystatechange = h.noop;
								if (i) s.readyState !== 4 && s.abort();
								else {
									f = {}, u = s.status, typeof s.responseText == "string" && (f.text = s.responseText);
									try {
										a = s.statusText
									} catch (l) {
										a = ""
									}!u && e.isLocal && !e.crossDomain ? u = f.text ? 200 : 404 : u === 1223 && (u = 204)
								}
							}
							f && r(u, a, f, s.getAllResponseHeaders())
						}, e.async ? s.readyState === 4 ? setTimeout(t) : s.onreadystatechange = Qn[o] = t : t()
					},
					abort: function() {
						t && t(undefined, !0)
					}
				}
			}
		}), h.ajaxSetup({
			accepts: {
				script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
			},
			contents: {
				script: /(?:java|ecma)script/
			},
			converters: {
				"text script": function(e) {
					return h.globalEval(e), e
				}
			}
		}), h.ajaxPrefilter("script", function(e) {
			e.cache === undefined && (e.cache = !1), e.crossDomain && (e.type = "GET", e.global = !1)
		}), h.ajaxTransport("script", function(e) {
			if (e.crossDomain) {
				var t, n = T.head || h("head")[0] || T.documentElement;
				return {
					send: function(r, i) {
						t = T.createElement("script"), t.async = !0, e.scriptCharset && (t.charset = e.scriptCharset), t.src = e.url, t.onload = t.onreadystatechange = function(e, n) {
							if (n || !t.readyState || /loaded|complete/.test(t.readyState)) t.onload = t.onreadystatechange = null, t.parentNode && t.parentNode.removeChild(t), t = null, n || i(200, "success")
						}, n.insertBefore(t, n.firstChild)
					},
					abort: function() {
						t && t.onload(undefined, !0)
					}
				}
			}
		});
		var er = [],
			tr = /(=)\?(?=&|$)|\?\?/;
		h.ajaxSetup({
			jsonp: "callback",
			jsonpCallback: function() {
				var e = er.pop() || h.expando + "_" + Sn++;
				return this[e] = !0, e
			}
		}), h.ajaxPrefilter("json jsonp", function(t, n, r) {
			var i, s, o, u = t.jsonp !== !1 && (tr.test(t.url) ? "url" : typeof t.data == "string" && !(t.contentType || "").indexOf("application/x-www-form-urlencoded") && tr.test(t.data) && "data");
			if (u || t.dataTypes[0] === "jsonp") return i = t.jsonpCallback = h.isFunction(t.jsonpCallback) ? t.jsonpCallback() : t.jsonpCallback, u ? t[u] = t[u].replace(tr, "$1" + i) : t.jsonp !== !1 && (t.url += (xn.test(t.url) ? "&" : "?") + t.jsonp + "=" + i), t.converters["script json"] = function() {
				return o || h.error(i + " was not called"), o[0]
			}, t.dataTypes[0] = "json", s = e[i], e[i] = function() {
				o = arguments
			}, r.always(function() {
				e[i] = s, t[i] && (t.jsonpCallback = n.jsonpCallback, er.push(i)), o && h.isFunction(s) && s(o[0]), o = s = undefined
			}), "script"
		}), h.parseHTML = function(e, t, n) {
			if (!e || typeof e != "string") return null;
			typeof t == "boolean" && (n = t, t = !1), t = t || T;
			var r = w.exec(e),
				i = !n && [];
			return r ? [t.createElement(r[1])] : (r = h.buildFragment([e], t, i), i && i.length && h(i).remove(), h.merge([], r.childNodes))
		};
		var nr = h.fn.load;
		h.fn.load = function(e, t, n) {
			if (typeof e != "string" && nr) return nr.apply(this, arguments);
			var r, i, s, o = this,
				u = e.indexOf(" ");
			return u >= 0 && (r = h.trim(e.slice(u, e.length)), e = e.slice(0, u)), h.isFunction(t) ? (n = t, t = undefined) : t && typeof t == "object" && (s = "POST"), o.length > 0 && h.ajax({
				url: e,
				type: s,
				dataType: "html",
				data: t
			}).done(function(e) {
				i = arguments, o.html(r ? h("<div>").append(h.parseHTML(e)).find(r) : e)
			}).complete(n &&
			function(e, t) {
				o.each(n, i || [e.responseText, t, e])
			}), this
		}, h.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], function(e, t) {
			h.fn[t] = function(e) {
				return this.on(t, e)
			}
		}), h.expr.filters.animated = function(e) {
			return h.grep(h.timers, function(t) {
				return e === t.elem
			}).length
		};
		var rr = e.document.documentElement;
		h.offset = {
			setOffset: function(e, t, n) {
				var r, i, s, o, u, a, f, l = h.css(e, "position"),
					c = h(e),
					p = {};
				l === "static" && (e.style.position = "relative"), u = c.offset(), s = h.css(e, "top"), a = h.css(e, "left"), f = (l === "absolute" || l === "fixed") && h.inArray("auto", [s, a]) > -1, f ? (r = c.position(), o = r.top, i = r.left) : (o = parseFloat(s) || 0, i = parseFloat(a) || 0), h.isFunction(t) && (t = t.call(e, n, u)), t.top != null && (p.top = t.top - u.top + o), t.left != null && (p.left = t.left - u.left + i), "using" in t ? t.using.call(e, p) : c.css(p)
			}
		}, h.fn.extend({
			offset: function(e) {
				if (arguments.length) return e === undefined ? this : this.each(function(t) {
					h.offset.setOffset(this, e, t)
				});
				var t, n, r = {
					top: 0,
					left: 0
				},
					i = this[0],
					s = i && i.ownerDocument;
				if (!s) return;
				return t = s.documentElement, h.contains(t, i) ? (typeof i.getBoundingClientRect !== B && (r = i.getBoundingClientRect()), n = ir(s), {
					top: r.top + (n.pageYOffset || t.scrollTop) - (t.clientTop || 0),
					left: r.left + (n.pageXOffset || t.scrollLeft) - (t.clientLeft || 0)
				}) : r
			},
			position: function() {
				if (!this[0]) return;
				var e, t, n = {
					top: 0,
					left: 0
				},
					r = this[0];
				return h.css(r, "position") === "fixed" ? t = r.getBoundingClientRect() : (e = this.offsetParent(), t = this.offset(), h.nodeName(e[0], "html") || (n = e.offset()), n.top += h.css(e[0], "borderTopWidth", !0), n.left += h.css(e[0], "borderLeftWidth", !0)), {
					top: t.top - n.top - h.css(r, "marginTop", !0),
					left: t.left - n.left - h.css(r, "marginLeft", !0)
				}
			},
			offsetParent: function() {
				return this.map(function() {
					var e = this.offsetParent || rr;
					while (e && !h.nodeName(e, "html") && h.css(e, "position") === "static") e = e.offsetParent;
					return e || rr
				})
			}
		}), h.each({
			scrollLeft: "pageXOffset",
			scrollTop: "pageYOffset"
		}, function(e, t) {
			var n = /Y/.test(t);
			h.fn[e] = function(r) {
				return $(this, function(e, r, i) {
					var s = ir(e);
					if (i === undefined) return s ? t in s ? s[t] : s.document.documentElement[r] : e[r];
					s ? s.scrollTo(n ? h(s).scrollLeft() : i, n ? i : h(s).scrollTop()) : e[r] = i
				}, e, r, arguments.length, null)
			}
		}), h.each(["top", "left"], function(e, t) {
			h.cssHooks[t] = jt(l.pixelPosition, function(e, n) {
				if (n) return n = Ht(e, t), Dt.test(n) ? h(e).position()[t] + "px" : n
			})
		}), h.each({
			Height: "height",
			Width: "width"
		}, function(e, t) {
			h.each({
				padding: "inner" + e,
				content: t,
				"": "outer" + e
			}, function(n, r) {
				h.fn[r] = function(r, i) {
					var s = arguments.length && (n || typeof r != "boolean"),
						o = n || (r === !0 || i === !0 ? "margin" : "border");
					return $(this, function(t, n, r) {
						var i;
						return h.isWindow(t) ? t.document.documentElement["client" + e] : t.nodeType === 9 ? (i = t.documentElement, Math.max(t.body["scroll" + e], i["scroll" + e], t.body["offset" + e], i["offset" + e], i["client" + e])) : r === undefined ? h.css(t, n, o) : h.style(t, n, r, o)
					}, t, s ? r : undefined, s, null)
				}
			})
		}), h.fn.size = function() {
			return this.length
		}, h.fn.andSelf = h.fn.addBack, typeof define == "function" && define.amd && define("jquery", [], function() {
			return h
		});
		var sr = e.jQuery,
			or = e.$;
		return h.noConflict = function(t) {
			return e.$ === h && (e.$ = or), t && e.jQuery === h && (e.jQuery = sr), h
		}, typeof t === B && (e.jQuery = e.$ = h), h
	}), !
	function(e, t) {
		typeof define == "function" && define.amd ? define("vendor/modal", ["jquery"], t) : t(e.jQuery)
	}(this, function(e) {
		"use strict";

		function n(n, r) {
			return this.each(function() {
				var i = e(this),
					s = i.data("bs.modal"),
					o = e.extend({}, t.DEFAULTS, i.data(), typeof n == "object" && n);
				s || i.data("bs.modal", s = new t(this, o)), typeof n == "string" ? s[n](r) : o.show && s.show(r)
			})
		}
		var t = function(t, n) {
				this.options = n, this.$body = e(document.body), this.$element = e(t), this.$dialog = this.$element.find(".modal-dialog"), this.$backdrop = null, this.isShown = null, this.originalBodyPad = null, this.scrollbarWidth = 0, this.ignoreBackdropClick = !1, this.options.remote && this.$element.find(".modal-content").load(this.options.remote, e.proxy(function() {
					this.$element.trigger("loaded.bs.modal")
				}, this))
			};
		t.VERSION = "3.3.4", t.TRANSITION_DURATION = 300, t.BACKDROP_TRANSITION_DURATION = 150, t.DEFAULTS = {
			backdrop: !0,
			keyboard: !0,
			show: !0
		}, t.prototype.toggle = function(e) {
			return this.isShown ? this.hide() : this.show(e)
		}, t.prototype.show = function(n) {
			var r = this,
				i = e.Event("show.bs.modal", {
					relatedTarget: n
				});
			this.$element.trigger(i);
			if (this.isShown || i.isDefaultPrevented()) return;
			this.isShown = !0, this.checkScrollbar(), this.setScrollbar(), this.$body.addClass("modal-open"), this.escape(), this.resize(), this.$element.on("click.dismiss.bs.modal", '[data-dismiss="modal"]', e.proxy(this.hide, this)), this.$dialog.on("mousedown.dismiss.bs.modal", function() {
				r.$element.one("mouseup.dismiss.bs.modal", function(t) {
					e(t.target).is(r.$element) && (r.ignoreBackdropClick = !0)
				})
			}), this.backdrop(function() {
				var i = e.support.transition && r.$element.hasClass("fade");
				r.$element.parent().length || r.$element.appendTo(r.$body), r.$element.css({
					display: "-webkit-box"
				}).scrollTop(0), r.adjustDialog(), i && r.$element[0].offsetWidth, r.$element.addClass("in"), r.enforceFocus();
				var s = e.Event("shown.bs.modal", {
					relatedTarget: n
				});
				i ? r.$dialog.one("bsTransitionEnd", function() {
					r.$element.trigger("focus").trigger(s)
				}).emulateTransitionEnd(t.TRANSITION_DURATION) : r.$element.trigger("focus").trigger(s)
			})
		}, t.prototype.hide = function(n) {
			n && n.preventDefault(), n = e.Event("hide.bs.modal"), this.$element.trigger(n);
			if (!this.isShown || n.isDefaultPrevented()) return;
			this.isShown = !1, this.escape(), this.resize(), e(document).off("focusin.bs.modal"), this.$element.removeClass("in").off("click.dismiss.bs.modal").off("mouseup.dismiss.bs.modal"), this.$dialog.off("mousedown.dismiss.bs.modal"), e.support.transition && this.$element.hasClass("fade") ? this.$element.one("bsTransitionEnd", e.proxy(this.hideModal, this)).emulateTransitionEnd(t.TRANSITION_DURATION) : this.hideModal()
		}, t.prototype.enforceFocus = function() {
			e(document).off("focusin.bs.modal").on("focusin.bs.modal", e.proxy(function(e) {
				this.$element[0] !== e.target && !this.$element.has(e.target).length && this.$element.trigger("focus")
			}, this))
		}, t.prototype.escape = function() {
			this.isShown && this.options.keyboard ? this.$element.on("keydown.dismiss.bs.modal", e.proxy(function(e) {
				e.which == 27 && this.hide()
			}, this)) : this.isShown || this.$element.off("keydown.dismiss.bs.modal")
		}, t.prototype.resize = function() {
			this.isShown ? e(window).on("resize.bs.modal", e.proxy(this.handleUpdate, this)) : e(window).off("resize.bs.modal")
		}, t.prototype.hideModal = function() {
			var e = this;
			this.$element.hide(), this.backdrop(function() {
				e.$body.removeClass("modal-open"), e.resetAdjustments(), e.resetScrollbar(), e.$element.trigger("hidden.bs.modal")
			})
		}, t.prototype.removeBackdrop = function() {
			this.$backdrop && this.$backdrop.remove(), this.$backdrop = null
		}, t.prototype.backdrop = function(n) {
			var r = this,
				i = this.$element.hasClass("fade") ? "fade" : "";
			if (this.isShown && this.options.backdrop) {
				var s = e.support.transition && i;
				this.$backdrop = e(document.createElement("div")).addClass("modal-backdrop " + i).appendTo(this.$body), this.$element.on("click.dismiss.bs.modal", e.proxy(function(e) {
					if (this.ignoreBackdropClick) {
						this.ignoreBackdropClick = !1;
						return
					}
					if (e.target !== e.currentTarget) return;
					this.options.backdrop == "static" ? this.$element[0].focus() : this.hide()
				}, this)), s && this.$backdrop[0].offsetWidth, this.$backdrop.addClass("in");
				if (!n) return;
				s ? this.$backdrop.one("bsTransitionEnd", n).emulateTransitionEnd(t.BACKDROP_TRANSITION_DURATION) : n()
			} else if (!this.isShown && this.$backdrop) {
				this.$backdrop.removeClass("in");
				var o = function() {
						r.removeBackdrop(), n && n()
					};
				e.support.transition && this.$element.hasClass("fade") ? this.$backdrop.one("bsTransitionEnd", o).emulateTransitionEnd(t.BACKDROP_TRANSITION_DURATION) : o()
			} else n && n()
		}, t.prototype.handleUpdate = function() {
			this.adjustDialog()
		}, t.prototype.adjustDialog = function() {
			var e = this.$element[0].scrollHeight > document.documentElement.clientHeight;
			this.$element.css({
				paddingLeft: !this.bodyIsOverflowing && e ? this.scrollbarWidth : "",
				paddingRight: this.bodyIsOverflowing && !e ? this.scrollbarWidth : ""
			})
		}, t.prototype.resetAdjustments = function() {
			this.$element.css({
				paddingLeft: "",
				paddingRight: ""
			})
		}, t.prototype.checkScrollbar = function() {
			var e = window.innerWidth;
			if (!e) {
				var t = document.documentElement.getBoundingClientRect();
				e = t.right - Math.abs(t.left)
			}
			this.bodyIsOverflowing = document.body.clientWidth < e, this.scrollbarWidth = this.measureScrollbar()
		}, t.prototype.setScrollbar = function() {
			var e = parseInt(this.$body.css("padding-right") || 0, 10);
			this.originalBodyPad = document.body.style.paddingRight || "", this.bodyIsOverflowing && this.$body.css("padding-right", e + this.scrollbarWidth)
		}, t.prototype.resetScrollbar = function() {
			this.$body.css("padding-right", this.originalBodyPad)
		}, t.prototype.measureScrollbar = function() {
			var e = document.createElement("div");
			e.className = "modal-scrollbar-measure", this.$body.append(e);
			var t = e.offsetWidth - e.clientWidth;
			return this.$body[0].removeChild(e), t
		};
		var r = e.fn.modal;
		e.fn.modal = n, e.fn.modal.Constructor = t, e.fn.modal.noConflict = function() {
			return e.fn.modal = r, this
		}, e(document).on("click.bs.modal.data-api", '[data-toggle="modal"]', function(t) {
			var r = e(this),
				i = r.attr("href"),
				s = e(r.attr("data-target") || i && i.replace(/.*(?=#[^\s]+$)/, "")),
				o = s.data("bs.modal") ? "toggle" : e.extend({
					remote: !/#/.test(i) && i
				}, s.data(), r.data());
			r.is("a") && t.preventDefault(), s.one("show.bs.modal", function(e) {
				if (e.isDefaultPrevented()) return;
				s.one("hidden.bs.modal", function() {
					r.is(":visible") && r.trigger("focus")
				})
			}), n.call(s, o, this)
		})
	}), !
	function(e, t) {
		typeof define == "function" && define.amd ? define("vendor/fileupload", ["jquery"], t) : t(e.jQuery)
	}(this, function($) {
		var initializing = !1,
			fnTest = /xyz/.test(function() {
				xyz
			}) ? /\b_super\b/ : /.*/,
			Class = function() {};
		Class.extend = function(e) {
			function i() {
				!initializing && this.init && this.init.apply(this, arguments)
			}
			var t = this.prototype;
			initializing = !0;
			var n = new this;
			initializing = !1;
			for (var r in e) n[r] = typeof e[r] == "function" && typeof t[r] == "function" && fnTest.test(e[r]) ?
			function(e, n) {
				return function() {
					var r = this._super;
					this._super = t[e];
					var i = n.apply(this, arguments);
					return this._super = r, i
				}
			}(r, e[r]) : e[r];
			return i.prototype = n, i.constructor = i, i.extend = arguments.callee, i
		}, $.gConfig = {
			base: {
				tamsId: "631007155",
				appid: "4007203",
				baseUrl: "http://" + window.location.host + "/",
				uin: "1000001"
			}
		}, $.Upload = Class.extend({
			_ticketUrl: $.gConfig.base.baseUrl + "fileupload/file/ticket",
			_action: "http://upload.act.qq.com/cgi-bin/up_comm_file",
			_iframe: null,
			_form: null,
			opt: {
				id: null,
				require: ["doc", "docx", "xls", "xlsx", "ppt", "pptx", "pdf", "png", "jpg", "gif", "mp3", "wma"],
				tamsId: $.gConfig.base.tamsId,
				uin: $.gConfig.base.uin,
				callback: function() {},
				errorCallback: function() {}
			},
			init: function(e) {
				this.opt = $.extend({}, this.opt, e || {});
				if (!this.opt.tamsId) throw new Error("Please set the tamsId!");
				if (!this._filter()) return !1;
				this._clear(), this._creatIfram(), this._creatForm()
			},
			_filter: function() {
				var e = $.trim($("#" + this.opt.id).val());
				if (e == "") return this.opt.errorCallback.call(this, "您还未选择文件！"), !1;
				var t = new RegExp(".(?:" + this.opt.require.join("|") + ")$", "i");
				if (!t.test(e)) {
					var n = "您上传的文件格式不符合要求！请上传" + this.opt.require.join("、") + "格式文件！";
					return this.opt.errorCallback.call(this, n), !1
				}
				return !0
			},
			_getTicket: function() {
				var e = "";
				return $.ajax({
					url: this._ticketUrl,
					async: !1,
					dataType: "json",
					data: {
						dt: Math.random(),
						tamsId: this.opt.tamsId
					},
					success: function(t) {
						t.code == 0 ? e = t.data.ticket : t.code == "101" ? $.qqLogin() : alert(t.message)
					}
				}), e
			},
			_creatIfram: function() {
				this._iframe && this._iframe.remove(), this._iframe = $("<iframe name='gallop_upload_iframe'>", {
					id: "gallop_upload_iframe",
					src: "about:blank"
				}).hide().appendTo("body")
			},
			_creatForm: function() {
				var ticket = this._getTicket(),
					callbackName = "gallopCallback" + (new Date).getTime();
				eval("window." + callbackName + "=this.opt.callback");
				var formStr = '<input id="uin" name="uin" type="hidden" value="' + this.opt.uin + '"/>' + '<input id="actid" name="actid" type="hidden" value="' + this.opt.tamsId + '"/>' + '<input id="ticket" name="ticket" type="hidden" value="' + ticket + '" />' + '<input id="callbackName" name="callbackName" type="hidden" value="' + callbackName + '"/>';
				this._form && this._form.remove(), this._form = $("<form>", {
					id: "gallop_upload_form",
					action: this._action,
					target: "gallop_upload_iframe",
					enctype: "multipart/form-data",
					method: "post"
				}).html(formStr).hide();
				var node = $("#" + this.opt.id),
					elclone = node.clone(!0);
				node.after(elclone), node.attr("name", "fileField"), this._form.append(node), $("body").append(this._form), this._form.submit()
			},
			_clear: function() {
				$("#gallop_upload_iframe").remove(), $("#gallop_upload_form").remove()
			}
		}), $.UploadPic = $.Upload.extend({
			_action: "http://upload.act.qq.com/cgi-bin/up_pic_sec",
			opt: {
				id: null,
				require: ["png", "gif", "jpg"],
				tamsId: $.gConfig.base.tamsId,
				uin: $.gConfig.base.uin,
				callback: function() {},
				errorCallback: function() {},
				ticketUrl: $.gConfig.base.baseUrl + "fileupload/file/ticket"
			},
			init: function(e) {
				this.opt = $.extend({}, this.opt, e || {}), this._ticketUrl = this.opt.ticketUrl;
				if (!this.opt.tamsId) throw new Error("Please set the tamsId!");
				if (!this._filter()) return !1;
				this._clear(), this._creatIfram(), this._creatForm()
			}
		}), $.UploadVideo = $.UploadPic.extend({
			_ticketUrl: $.gConfig.base.baseUrl + "videoupload/videoupload/ticket",
			_action: "http://upload.act.qq.com/cgi-bin/up_video",
			opt: {
				id: null,
				info: {
					title: "",
					cat: "",
					tags: "",
					desc: ""
				},
				require: ["wmv", "asf", "asx", "rm", "rmvb", "mpg", "mpeg", "mpe", "3gp", "mov", "mp4", "avi", "dat", "mkv", "flv", "vob"],
				tamsId: $.gConfig.base.tamsId,
				uin: $.gConfig.base.uin,
				callback: function() {}
			},
			init: function(e) {
				this.opt = $.extend({}, this.opt, e || {});
				if (!this.opt.tamsId) throw new Error("Please set the tamsId!");
				if (!this._filter()) return !1;
				this._ticketUrl = this._setTicketUrl(), this._clear(), this._creatIfram(), this._creatForm()
			},
			_setTicketUrl: function() {
				var e = [];
				return $.each(self.opt.info, function(t, n) {
					e.push(t + "=" + encodeURIComponent(n || ""))
				}), this._ticketUrl + "?" + e.join("$")
			}
		}), $.upload = function(e) {
			return new $.Upload(e)
		}, $.uploadPic = function(e) {
			return new $.UploadPic(e)
		}, $.uploadVideo = function(e) {
			return new $.UploadVideo(e)
		}, $.uploadCheck = function(e) {
			switch (e.retcode) {
			case 0:
				return {
					ret: 1,
					msg: "上传成功！"
				};
			case -520:
				return {
					ret: -1,
					msg: "您上传的文件格式不符合要求！"
				};
			case -513:
				return {
					ret: -1,
					msg: "您设定的tmasID跟系统不相符！"
				};
			case -514:
				var t = e.rspmsg.split("size_limit:")[1] / 1024;
				return {
					ret: -1,
					msg: "您上传的文件大小超过 " + t + "K 限制！"
				};
			default:
				return {
					ret: -1,
					msg: "您上传的文件失败！"
				}
			}
			return {
				ret: 1,
				msg: "上传成功！"
			}
		}
	}), !
	function(e, t) {
		typeof define == "function" && define.amd ? define("vendor/nouislider", ["jquery"], t) : t(e.jQuery)
	}(this, function(e) {
		(function() {
			"use strict";

			function t(e) {
				return e.split("").reverse().join("")
			}
			function n(e, t) {
				return e.substring(0, t.length) === t
			}
			function r(e, t) {
				return e.slice(-1 * t.length) === t
			}
			function i(e, t, n) {
				if ((e[t] || e[n]) && e[t] === e[n]) throw new Error(t)
			}
			function s(e) {
				return typeof e == "number" && isFinite(e)
			}
			function o(e, t) {
				var n = Math.pow(10, t);
				return (Math.round(e * n) / n).toFixed(t)
			}
			function u(e, n, r, i, u, a, f, l, c, h, p, d) {
				var v = d,
					m, g, y, b = "",
					w = "";
				return a && (d = a(d)), s(d) ? (e !== !1 && parseFloat(d.toFixed(e)) === 0 && (d = 0), d < 0 && (m = !0, d = Math.abs(d)), e !== !1 && (d = o(d, e)), d = d.toString(), d.indexOf(".") !== -1 ? (g = d.split("."), y = g[0], r && (b = r + g[1])) : y = d, n && (y = t(y).match(/.{1,3}/g), y = t(y.join(t(n)))), m && l && (w += l), i && (w += i), m && c && (w += c), w += y, w += b, u && (w += u), h && (w = h(w, v)), w) : !1
			}
			function a(e, t, i, o, u, a, f, l, c, h, p, d) {
				var v = d,
					m, g = "";
				return p && (d = p(d)), !d || typeof d != "string" ? !1 : (l && n(d, l) && (d = d.replace(l, ""), m = !0), o && n(d, o) && (d = d.replace(o, "")), c && n(d, c) && (d = d.replace(c, ""), m = !0), u && r(d, u) && (d = d.slice(0, -1 * u.length)), t && (d = d.split(t).join("")), i && (d = d.replace(i, ".")), m && (g += "-"), g += d, g = g.replace(/[^0-9\.\-.]/g, ""), g === "" ? !1 : (g = Number(g), f && (g = f(g)), s(g) ? g : !1))
			}
			function f(t) {
				var n, r, s, o = {};
				for (n = 0; n < e.length; n += 1) {
					r = e[n], s = t[r];
					if (s === undefined) r === "negative" && !o.negativeBefore ? o[r] = "-" : r === "mark" && o.thousand !== "." ? o[r] = "." : o[r] = !1;
					else if (r === "decimals") {
						if (!(s >= 0 && s < 8)) throw new Error(r);
						o[r] = s
					} else if (r === "encoder" || r === "decoder" || r === "edit" || r === "undo") {
						if (typeof s != "function") throw new Error(r);
						o[r] = s
					} else {
						if (typeof s != "string") throw new Error(r);
						o[r] = s
					}
				}
				return i(o, "mark", "thousand"), i(o, "prefix", "negative"), i(o, "prefix", "negativeBefore"), o
			}
			function l(t, n, r) {
				var i, s = [];
				for (i = 0; i < e.length; i += 1) s.push(t[e[i]]);
				return s.push(r), n.apply("", s)
			}
			function c(e) {
				if (!(this instanceof c)) return new c(e);
				if (typeof e != "object") return;
				e = f(e), this.to = function(t) {
					return l(e, u, t)
				}, this.from = function(t) {
					return l(e, a, t)
				}
			}
			var e = ["decimals", "thousand", "mark", "prefix", "postfix", "encoder", "decoder", "negativeBefore", "negative", "edit", "undo"];
			window.wNumb = c
		})(), function(e) {
			"use strict";

			function t(t) {
				return t instanceof e || e.zepto && e.zepto.isZ(t)
			}
			function n(t, n) {
				if (typeof t == "string" && t.indexOf("-inline-") === 0) return this.method = n || "html", this.target = this.el = e(t.replace("-inline-", "") || "<div/>"), !0
			}
			function r(t) {
				if (typeof t == "string" && t.indexOf("-") !== 0) {
					this.method = "val";
					var n = document.createElement("input");
					return n.name = t, n.type = "hidden", this.target = this.el = e(n), !0
				}
			}
			function i(e) {
				if (typeof e == "function") return this.target = !1, this.method = e, !0
			}
			function s(e, n) {
				if (t(e) && !n) return e.is("input, select, textarea") ? (this.method = "val", this.target = e.on("change.liblink", this.changeHandler)) : (this.target = e, this.method = "html"), !0
			}
			function o(e, n) {
				if (t(e) && (typeof n == "function" || typeof n == "string" && e[n])) return this.method = n, this.target = e, !0
			}
			function a(t, n, r) {
				var i = this,
					s = !1;
				this.changeHandler = function(t) {
					var n = i.formatInstance.from(e(this).val());
					if (n === !1 || isNaN(n)) return e(this).val(i.lastSetValue), !1;
					i.changeHandlerMethod.call("", t, n)
				}, this.el = !1, this.formatInstance = r, e.each(u, function(e, r) {
					return s = r.call(i, t, n), !s
				});
				if (!s) throw new RangeError("(Link) Invalid Link.")
			}
			function f(e) {
				this.items = [], this.elements = [], this.origin = e
			}
			function l(t, n, r, i) {
				t === 0 && (t = this.LinkDefaultFlag), this.linkAPI || (this.linkAPI = {}), this.linkAPI[t] || (this.linkAPI[t] = new f(this));
				var s = new a(n, r, i || this.LinkDefaultFormatter);
				s.target || (s.target = e(this)), s.changeHandlerMethod = this.LinkConfirm(t, s.el), this.linkAPI[t].push(s, s.el), this.LinkUpdate(t)
			}
			var u = [n, r, i, s, o];
			a.prototype.set = function(e) {
				var t = Array.prototype.slice.call(arguments),
					n = t.slice(1);
				this.lastSetValue = this.formatInstance.to(e), n.unshift(this.lastSetValue), (typeof this.method == "function" ? this.method : this.target[this.method]).apply(this.target, n)
			}, f.prototype.push = function(e, t) {
				this.items.push(e), t && this.elements.push(t)
			}, f.prototype.reconfirm = function(e) {
				var t;
				for (t = 0; t < this.elements.length; t += 1) this.origin.LinkConfirm(e, this.elements[t])
			}, f.prototype.remove = function(e) {
				var t;
				for (t = 0; t < this.items.length; t += 1) this.items[t].target.off(".liblink");
				for (t = 0; t < this.elements.length; t += 1) this.elements[t].remove()
			}, f.prototype.change = function(e) {
				if (this.origin.LinkIsEmitting) return !1;
				this.origin.LinkIsEmitting = !0;
				var t = Array.prototype.slice.call(arguments, 1),
					n;
				t.unshift(e);
				for (n = 0; n < this.items.length; n += 1) this.items[n].set.apply(this.items[n], t);
				this.origin.LinkIsEmitting = !1
			}, e.fn.Link = function(t) {
				var n = this;
				if (t === !1) return n.each(function() {
					if (!this.linkAPI) return;
					e.map(this.linkAPI, function(e) {
						e.remove()
					}), delete this.linkAPI
				});
				if (t === undefined) t = 0;
				else if (typeof t != "string") throw new Error("Flag must be string.");
				return {
					to: function(e, r, i) {
						return n.each(function() {
							l.call(this, t, e, r, i)
						})
					}
				}
			}
		}(window.jQuery || window.Zepto), function(e) {
			"use strict";

			function t(t) {
				return e.grep(t, function(n, r) {
					return r === e.inArray(n, t)
				})
			}
			function n(e, t) {
				return Math.round(e / t) * t
			}
			function r(e) {
				return typeof e == "number" && !isNaN(e) && isFinite(e)
			}
			function i(e) {
				var t = Math.pow(10, 7);
				return Number((Math.round(e * t) / t).toFixed(7))
			}
			function s(e, t, n) {
				e.addClass(t), setTimeout(function() {
					e.removeClass(t)
				}, n)
			}
			function o(e) {
				return Math.max(Math.min(e, 100), 0)
			}
			function u(t) {
				return e.isArray(t) ? t : [t]
			}
			function a(e) {
				var t = e.split(".");
				return t.length > 1 ? t[1].length : 0
			}
			function d(e, t) {
				return 100 / (t - e)
			}
			function v(e, t) {
				return t * 100 / (e[1] - e[0])
			}
			function m(e, t) {
				return v(e, e[0] < 0 ? t + Math.abs(e[0]) : t - e[0])
			}
			function g(e, t) {
				return t * (e[1] - e[0]) / 100 + e[0]
			}
			function y(e, t) {
				var n = 1;
				while (e >= t[n]) n += 1;
				return n
			}
			function b(e, t, n) {
				if (n >= e.slice(-1)[0]) return 100;
				var r = y(n, e),
					i, s, o, u;
				return i = e[r - 1], s = e[r], o = t[r - 1], u = t[r], o + m([i, s], n) / d(o, u)
			}
			function w(e, t, n) {
				if (n >= 100) return e.slice(-1)[0];
				var r = y(n, t),
					i, s, o, u;
				return i = e[r - 1], s = e[r], o = t[r - 1], u = t[r], g([i, s], (n - o) * d(o, u))
			}
			function E(e, t, r, i) {
				if (i === 100) return i;
				var s = y(i, e),
					o, u;
				return r ? (o = e[s - 1], u = e[s], i - o > (u - o) / 2 ? u : o) : t[s - 1] ? e[s - 1] + n(i - e[s - 1], t[s - 1]) : i
			}
			function S(e, t, n) {
				var i;
				typeof t == "number" && (t = [t]);
				if (Object.prototype.toString.call(t) !== "[object Array]") throw new Error("noUiSlider: 'range' contains invalid value.");
				e === "min" ? i = 0 : e === "max" ? i = 100 : i = parseFloat(e);
				if (!r(i) || !r(t[0])) throw new Error("noUiSlider: 'range' value isn't numeric.");
				n.xPct.push(i), n.xVal.push(t[0]), i ? n.xSteps.push(isNaN(t[1]) ? !1 : t[1]) : isNaN(t[1]) || (n.xSteps[0] = t[1])
			}
			function x(e, t, n) {
				if (!t) return !0;
				n.xSteps[e] = v([n.xVal[e], n.xVal[e + 1]], t) / d(n.xPct[e], n.xPct[e + 1])
			}
			function T(e, t, n, r) {
				this.xPct = [], this.xVal = [], this.xSteps = [r || !1], this.xNumSteps = [!1], this.snap = t, this.direction = n;
				var i, s = [];
				for (i in e) e.hasOwnProperty(i) && s.push([e[i], i]);
				s.sort(function(e, t) {
					return e[0] - t[0]
				});
				for (i = 0; i < s.length; i++) S(s[i][1], s[i][0], this);
				this.xNumSteps = this.xSteps.slice(0);
				for (i = 0; i < this.xNumSteps.length; i++) x(i, this.xNumSteps[i], this)
			}
			function C(e, t) {
				if (!r(t)) throw new Error("noUiSlider: 'step' is not numeric.");
				e.singleStep = t
			}
			function k(t, n) {
				if (typeof n != "object" || e.isArray(n)) throw new Error("noUiSlider: 'range' is not an object.");
				if (n.min === undefined || n.max === undefined) throw new Error("noUiSlider: Missing 'min' or 'max' in 'range'.");
				t.spectrum = new T(n, t.snap, t.dir, t.singleStep)
			}
			function L(t, n) {
				n = u(n);
				if (!e.isArray(n) || !n.length || n.length > 2) throw new Error("noUiSlider: 'start' option is incorrect.");
				t.handles = n.length, t.start = n
			}
			function A(e, t) {
				e.snap = t;
				if (typeof t != "boolean") throw new Error("noUiSlider: 'snap' option must be a boolean.")
			}
			function O(e, t) {
				e.animate = t;
				if (typeof t != "boolean") throw new Error("noUiSlider: 'animate' option must be a boolean.")
			}
			function M(e, t) {
				if (t === "lower" && e.handles === 1) e.connect = 1;
				else if (t === "upper" && e.handles === 1) e.connect = 2;
				else if (t === !0 && e.handles === 2) e.connect = 3;
				else {
					if (t !== !1) throw new Error("noUiSlider: 'connect' option doesn't match handle count.");
					e.connect = 0
				}
			}
			function _(e, t) {
				switch (t) {
				case "horizontal":
					e.ort = 0;
					break;
				case "vertical":
					e.ort = 1;
					break;
				default:
					throw new Error("noUiSlider: 'orientation' option is invalid.")
				}
			}
			function D(e, t) {
				if (!r(t)) throw new Error("noUiSlider: 'margin' option must be numeric.");
				e.margin = e.spectrum.getMargin(t);
				if (!e.margin) throw new Error("noUiSlider: 'margin' option is only supported on linear sliders.")
			}
			function P(e, t) {
				if (!r(t)) throw new Error("noUiSlider: 'limit' option must be numeric.");
				e.limit = e.spectrum.getMargin(t);
				if (!e.limit) throw new Error("noUiSlider: 'limit' option is only supported on linear sliders.")
			}
			function H(e, t) {
				switch (t) {
				case "ltr":
					e.dir = 0;
					break;
				case "rtl":
					e.dir = 1, e.connect = [0, 2, 1, 3][e.connect];
					break;
				default:
					throw new Error("noUiSlider: 'direction' option was not recognized.")
				}
			}
			function B(e, t) {
				if (typeof t != "string") throw new Error("noUiSlider: 'behaviour' must be a string containing options.");
				var n = t.indexOf("tap") >= 0,
					r = t.indexOf("drag") >= 0,
					i = t.indexOf("fixed") >= 0,
					s = t.indexOf("snap") >= 0;
				e.events = {
					tap: n || s,
					drag: r,
					fixed: i,
					snap: s
				}
			}
			function j(e, t) {
				e.format = t;
				if (typeof t.to == "function" && typeof t.from == "function") return !0;
				throw new Error("noUiSlider: 'format' requires 'to' and 'from' methods.")
			}
			function F(t) {
				var n = {
					margin: 0,
					limit: 0,
					animate: !0,
					format: N
				},
					r;
				return r = {
					step: {
						r: !1,
						t: C
					},
					start: {
						r: !0,
						t: L
					},
					connect: {
						r: !0,
						t: M
					},
					direction: {
						r: !0,
						t: H
					},
					snap: {
						r: !1,
						t: A
					},
					animate: {
						r: !1,
						t: O
					},
					range: {
						r: !0,
						t: k
					},
					orientation: {
						r: !1,
						t: _
					},
					margin: {
						r: !1,
						t: D
					},
					limit: {
						r: !1,
						t: P
					},
					behaviour: {
						r: !0,
						t: B
					},
					format: {
						r: !1,
						t: j
					}
				}, t = e.extend({
					connect: !1,
					direction: "ltr",
					behaviour: "tap",
					orientation: "horizontal"
				}, t), e.each(r, function(e, r) {
					if (t[e] === undefined) {
						if (r.r) throw new Error("noUiSlider: '" + e + "' is required.");
						return !0
					}
					r.t(n, t[e])
				}), n.style = n.ort ? "top" : "left", n
			}
			function I(e, t, n) {
				var r = e + t[0],
					i = e + t[1];
				return n ? (r < 0 && (i += Math.abs(r)), i > 100 && (r -= i - 100), [o(r), o(i)]) : [r, i]
			}
			function q(e) {
				e.preventDefault();
				var t = e.type.indexOf("touch") === 0,
					n = e.type.indexOf("mouse") === 0,
					r = e.type.indexOf("pointer") === 0,
					i, s, o = e;
				e.type.indexOf("MSPointer") === 0 && (r = !0), e.originalEvent && (e = e.originalEvent), t && (i = e.changedTouches[0].pageX, s = e.changedTouches[0].pageY);
				if (n || r)!r && window.pageXOffset === undefined && (window.pageXOffset = document.documentElement.scrollLeft, window.pageYOffset = document.documentElement.scrollTop), i = e.clientX + window.pageXOffset, s = e.clientY + window.pageYOffset;
				return o.points = [i, s], o.cursor = n, o
			}
			function R(t, n) {
				var r = e("<div><div/></div>").addClass(p[2]),
					i = ["-lower", "-upper"];
				return t && i.reverse(), r.children().addClass(p[3] + " " + p[3] + i[n]), r
			}
			function U(e, t, n) {
				switch (e) {
				case 1:
					t.addClass(p[7]), n[0].addClass(p[6]);
					break;
				case 3:
					n[1].addClass(p[6]);
				case 2:
					n[0].addClass(p[7]);
				case 0:
					t.addClass(p[6])
				}
			}
			function z(e, t, n) {
				var r, i = [];
				for (r = 0; r < e; r += 1) i.push(R(t, r).appendTo(n));
				return i
			}
			function W(t, n, r) {
				return r.addClass([p[0], p[8 + t], p[4 + n]].join(" ")), e("<div/>").appendTo(r).addClass(p[1])
			}
			function X(t, n, r) {
				function b() {
					return d[["width", "height"][n.ort]]()
				}
				function w(e) {
					var t, n = [i.val()];
					for (t = 0; t < e.length; t += 1) i.trigger(e[t], n)
				}
				function E(e) {
					return e.length === 1 ? e[0] : n.dir ? e.reverse() : e
				}
				function S(e) {
					return function(t, n) {
						i.val([e ? null : n, e ? n : null], !0)
					}
				}
				function x(t) {
					var n = e.inArray(t, y);
					i[0].linkAPI && i[0].linkAPI[t] && i[0].linkAPI[t].change(g[n], v[n].children(), i)
				}
				function T(t, r) {
					var i = e.inArray(t, y);
					return r && r.appendTo(v[i].children()), n.dir && n.handles > 1 && (i = i === 1 ? 0 : 1), S(i)
				}
				function N() {
					var e, t;
					for (e = 0; e < y.length; e += 1) this.linkAPI && this.linkAPI[t = y[e]] && this.linkAPI[t].reconfirm(t)
				}
				function C(e, t, r, s) {
					return e = e.replace(/\s/g, c + " ") + c, t.on(e, function(e) {
						if ( !! i.attr("disabled")) return !1;
						if (i.hasClass(p[14])) return !1;
						e = q(e), e.calcPoint = e.points[n.ort], r(e, s)
					})
				}
				function k(e, t) {
					var n = t.handles || v,
						r, i = !1,
						s = (e.calcPoint - t.start) * 100 / b(),
						o = n[0][0] !== v[0][0] ? 1 : 0;
					r = I(s, t.positions, n.length > 1), i = _(n[0], r[o], n.length === 1), n.length > 1 && (i = _(n[1], r[o ? 0 : 1], !1) || i), i && w(["slide"])
				}
				function L(t) {
					e("." + p[15]).removeClass(p[15]), t.cursor && e("body").css("cursor", "").off(c), f.off(c), i.removeClass(p[12]), w(["set", "change"])
				}
				function A(t, n) {
					n.handles.length === 1 && n.handles[0].children().addClass(p[15]), t.stopPropagation(), C(h.move, f, k, {
						start: t.calcPoint,
						handles: n.handles,
						positions: [l[0], l[v.length - 1]]
					}), C(h.end, f, L, null), t.cursor && (e("body").css("cursor", e(t.target).css("cursor")), v.length > 1 && i.addClass(p[12]), e("body").on("selectstart" + c, !1))
				}
				function O(t) {
					var r = t.calcPoint,
						o = 0,
						u;
					t.stopPropagation(), e.each(v, function() {
						o += this.offset()[n.style]
					}), o = r < o / 2 || v.length === 1 ? 0 : 1, r -= d.offset()[n.style], u = r * 100 / b(), n.events.snap || s(i, p[14], 300), _(v[o], u), w(["slide", "set", "change"]), n.events.snap && A(t, {
						handles: [v[o]]
					})
				}
				function M(e) {
					var t, n;
					if (!e.fixed) for (t = 0; t < v.length; t += 1) C(h.start, v[t].children(), A, {
						handles: [v[t]]
					});
					e.tap && C(h.start, d, O, {
						handles: v
					}), e.drag && (n = d.find("." + p[7]).addClass(p[10]), e.fixed && (n = n.add(d.children().not(n).children())), C(h.start, n, A, {
						handles: v
					}))
				}
				function _(e, t, r) {
					var i = e[0] !== v[0][0] ? 1 : 0,
						s = l[0] + n.margin,
						u = l[1] - n.margin,
						a = l[0] + n.limit,
						f = l[1] - n.limit;
					return v.length > 1 && (t = i ? Math.max(t, s) : Math.min(t, u)), r !== !1 && n.limit && v.length > 1 && (t = i ? Math.min(t, a) : Math.max(t, f)), t = m.getStep(t), t = o(parseFloat(t.toFixed(7))), t === l[i] ? !1 : (e.css(n.style, t + "%"), e.is(":first-child") && e.toggleClass(p[17], t > 50), l[i] = t, g[i] = m.fromStepping(t), x(y[i]), !0)
				}
				function D(e, t) {
					var r, i, s;
					n.limit && (e += 1);
					for (r = 0; r < e; r += 1) i = r % 2, s = t[i], s !== null && s !== !1 && (typeof s == "number" && (s = String(s)), s = n.format.from(s), (s === !1 || isNaN(s) || _(v[i], m.toStepping(s), r === 3 - n.dir) === !1) && x(y[i]))
				}
				function P(e) {
					if (i[0].LinkIsEmitting) return this;
					var t, r = u(e);
					return n.dir && n.handles > 1 && r.reverse(), n.animate && l[0] !== -1 && s(i, p[14], 300), t = v.length > 1 ? 3 : 1, r.length === 1 && (t = 1), D(t, r), w(["set"]), this
				}
				function H() {
					var e, t = [];
					for (e = 0; e < n.handles; e += 1) t[e] = n.format.to(g[e]);
					return E(t)
				}
				function B() {
					return e(this).off(c).removeClass(p.join(" ")).empty(), delete this.LinkUpdate, delete this.LinkConfirm, delete this.LinkDefaultFormatter, delete this.LinkDefaultFlag, delete this.reappend, delete this.vGet, delete this.vSet, delete this.getCurrentStep, delete this.getInfo, delete this.destroy, r
				}
				function j() {
					var t = e.map(l, function(e, t) {
						var n = m.getApplicableStep(e),
							r = a(String(n[2])),
							i = g[t],
							s = e === 100 ? null : n[2],
							o = Number((i - n[2]).toFixed(r)),
							u = e === 0 ? null : o >= n[1] ? n[2] : n[0] || !1;
						return [[u, s]]
					});
					return E(t)
				}
				function F() {
					return r
				}
				var i = e(t),
					l = [-1, -1],
					d, v, m = n.spectrum,
					g = [],
					y = ["lower", "upper"].slice(0, n.handles);
				n.dir && y.reverse(), t.LinkUpdate = x, t.LinkConfirm = T, t.LinkDefaultFormatter = n.format, t.LinkDefaultFlag = "lower", t.reappend = N;
				if (i.hasClass(p[0])) throw new Error("Slider was already initialized.");
				d = W(n.dir, n.ort, i), v = z(n.handles, n.dir, d), U(n.connect, i, v), M(n.events), t.vSet = P, t.vGet = H, t.destroy = B, t.getCurrentStep = j, t.getOriginalOptions = F, t.getInfo = function() {
					return [m, n.style, n.ort]
				}, i.val(n.start)
			}
			function V(e) {
				var t = F(e, this);
				return this.each(function() {
					X(this, t, e)
				})
			}
			function $(t) {
				return this.each(function() {
					if (!this.destroy) {
						e(this).noUiSlider(t);
						return
					}
					var n = e(this).val(),
						r = this.destroy(),
						i = e.extend({}, r, t);
					e(this).noUiSlider(i), this.reappend(), r.start === i.start && e(this).val(n)
				})
			}
			function J() {
				return this[0][arguments.length ? "vSet" : "vGet"].apply(this[0], arguments)
			}
			function K(t, n, r, i) {
				if (n === "range" || n === "steps") return t.xVal;
				if (n === "count") {
					var s = 100 / (r - 1),
						o, u = 0;
					r = [];
					while ((o = u++ * s) <= 100) r.push(o);
					n = "positions"
				}
				if (n === "positions") return e.map(r, function(e) {
					return t.fromStepping(i ? t.getStep(e) : e)
				});
				if (n === "values") return i ? e.map(r, function(e) {
					return t.fromStepping(t.getStep(t.toStepping(e)))
				}) : r
			}
			function Q(n, r, i, s) {
				var o = n.direction,
					u = {},
					a = n.xVal[0],
					f = n.xVal[n.xVal.length - 1],
					l = !1,
					c = !1,
					h = 0;
				return n.direction = 0, s = t(s.slice().sort(function(e, t) {
					return e - t
				})), s[0] !== a && (s.unshift(a), l = !0), s[s.length - 1] !== f && (s.push(f), c = !0), e.each(s, function(t) {
					var o, a, f, p = s[t],
						d = s[t + 1],
						v, m, g, y, b, w, E;
					i === "steps" && (o = n.xNumSteps[t]), o || (o = d - p);
					if (p === !1 || d === undefined) return;
					for (a = p; a <= d; a += o) {
						v = n.toStepping(a), m = v - h, b = m / r, w = Math.round(b), E = m / w;
						for (f = 1; f <= w; f += 1) g = h + f * E, u[g.toFixed(5)] = ["x", 0];
						y = e.inArray(a, s) > -1 ? 1 : i === "steps" ? 2 : 0, !t && l && (y = 0);
						if (a !== d || !c) u[v.toFixed(5)] = [a, y];
						h = v
					}
				}), n.direction = o, u
			}
			function G(t, n, r, i, s, o) {
				function f(e, t) {
					return ["-normal", "-large", "-sub"][e]
				}
				function l(e, n, r) {
					return 'class="' + n + " " + n + "-" + u + " " + n + f(r[1], r[0]) + '" style="' + t + ": " + e + '%"'
				}
				function c(e, t) {
					r && (e = 100 - e), t[1] = t[1] && s ? s(t[0], t[1]) : t[1], a.append("<div " + l(e, "noUi-marker", t) + "></div>"), t[1] && a.append("<div " + l(e, "noUi-value", t) + ">" + o.to(t[0]) + "</div>")
				}
				var u = ["horizontal", "vertical"][n],
					a = e("<div/>");
				return a.addClass("noUi-pips noUi-pips-" + u), e.each(i, c), a
			}
			var f = e(document),
				l = e.fn.val,
				c = ".nui",
				h = window.navigator.pointerEnabled ? {
					start: "pointerdown",
					move: "pointermove",
					end: "pointerup"
				} : window.navigator.msPointerEnabled ? {
					start: "MSPointerDown",
					move: "MSPointerMove",
					end: "MSPointerUp"
				} : {
					start: "mousedown touchstart",
					move: "mousemove touchmove",
					end: "mouseup touchend"
				},
				p = ["noUi-target", "noUi-base", "noUi-origin", "noUi-handle", "noUi-horizontal", "noUi-vertical", "noUi-background", "noUi-connect", "noUi-ltr", "noUi-rtl", "noUi-dragable", "", "noUi-state-drag", "", "noUi-state-tap", "noUi-active", "", "noUi-stacking"];
			T.prototype.getMargin = function(e) {
				return this.xPct.length === 2 ? v(this.xVal, e) : !1
			}, T.prototype.toStepping = function(e) {
				return e = b(this.xVal, this.xPct, e), this.direction && (e = 100 - e), e
			}, T.prototype.fromStepping = function(e) {
				return this.direction && (e = 100 - e), i(w(this.xVal, this.xPct, e))
			}, T.prototype.getStep = function(e) {
				return this.direction && (e = 100 - e), e = E(this.xPct, this.xSteps, this.snap, e), this.direction && (e = 100 - e), e
			}, T.prototype.getApplicableStep = function(e) {
				var t = y(e, this.xPct),
					n = e === 100 ? 2 : 1;
				return [this.xNumSteps[t - 2], this.xVal[t - n], this.xNumSteps[t - n]]
			}, T.prototype.convert = function(e) {
				return this.getStep(this.toStepping(e))
			};
			var N = {
				to: function(e) {
					return e.toFixed(2)
				},
				from: Number
			};
			e.fn.val = function(t) {
				function n(e) {
					return e.hasClass(p[0]) ? J : l
				}
				if (!arguments.length) {
					var r = e(this[0]);
					return n(r).call(r)
				}
				var i = e.isFunction(t);
				return this.each(function(r) {
					var s = t,
						o = e(this);
					i && (s = t.call(this, r, o.val())), n(o).call(o, s)
				})
			}, e.fn.noUiSlider = function(e, t) {
				switch (e) {
				case "step":
					return this[0].getCurrentStep();
				case "options":
					return this[0].getOriginalOptions()
				}
				return (t ? $ : V).call(this, e)
			}, e.fn.noUiSlider_pips = function(t) {
				var n = t.mode,
					r = t.density || 1,
					i = t.filter || !1,
					s = t.values || !1,
					o = t.format || {
						to: Math.round
					},
					u = t.stepped || !1;
				return this.each(function() {
					var t = this.getInfo(),
						a = K(t[0], n, s, u),
						f = Q(t[0], r, n, a);
					return e(this).append(G(t[1], t[2], t[0].direction, f, i, o))
				})
			}
		}(window.jQuery || window.Zepto)
	}), define("base/util", ["require", "template", "emopr", "base/md5", "base/hosts", "vendor/browser", "vendor/modal", "vendor/fileupload", "vendor/nouislider"], function(e) {
		var t = e("template"),
			n = e("emopr"),
			r = e("base/md5"),
			i = e("base/hosts"),
			s = e("vendor/browser"),
			o = e("vendor/modal"),
			u = e("vendor/fileupload"),
			a = e("vendor/nouislider"),
			f = "images/default/avatar.png",
			l = new Object;
		return l.getACSRFToken = function() {
			var e = l.cookie("skey");
			if ("undefined" == typeof e || !e) e = "";
			if (e == "") {
				var t = l.cookie("lskey");
				if ("undefined" == typeof t || !t) t = "";
				e = t
			}
			var n = 5381;
			for (var r = 0, i = e.length; r < i; ++r) n += (n << 5 & 2147483647) + e.charAt(r).charCodeAt();
			return n & 2147483647
		}, l.setACSRFToken = function() {
			typeof jQuery != "undefined" && jQuery.ajaxSetup({
				beforeSend: function(e, t) {
					var n = l.getACSRFToken(),
						r = t.url;
					return t.type.toLowerCase() == "get" ? t.url += r.indexOf("?") > 0 ? r.indexOf("g_tk=") < 0 ? "&g_tk=" + n : "" : "?g_tk=" + n : t.data ? typeof t.data == "string" && (t.data += t.data.indexOf("g_tk=") < 0 ? "&g_tk=" + n : "") : (t.data = "g_tk=" + n, t.url += r.indexOf("?") > 0 ? r.indexOf("g_tk=") < 0 ? "&g_tk=" + n : "" : "?g_tk=" + n), t
				}
			})
		}, l.isLogin = function() {
			var e = l.cookie("uin"),
				t = l.cookie("skey");
			return e && e.length > 4 && t && t.length > 0 ? !0 : !1
		}, l.logout = function(e) {
			var t = {
				domain: "qq.com",
				path: "/"
			};
			l.cookie("uin", null, t), l.cookie("skey", null, t), l.cookie("luin", null, t), l.cookie("lskey", null, t), e == undefined ? window.location.reload() : typeof e == "string" ? e == "" ? window.location.reload() : window.location.href = e : e()
		}, l.cookie = function(e, t, n) {
			if (typeof t == "undefined") {
				var a = null;
				if (document.cookie && document.cookie != "") {
					var f = document.cookie.split(";");
					for (var l = 0; l < f.length; l++) {
						var c = f[l].replace(/^\s*(.*?)\s*$/, "$1");
						if (c.substring(0, e.length + 1) == e + "=") {
							a = decodeURIComponent(c.substring(e.length + 1));
							break
						}
					}
				}
				return a
			}
			n = n || {}, t === null && (t = "", n.expires = -1);
			var r = "";
			if (n.expires && (typeof n.expires == "number" || n.expires.toUTCString)) {
				var i;
				typeof n.expires == "number" ? (i = new Date, i.setTime(i.getTime() + n.expires * 1e3)) : i = n.expires, r = "; expires=" + i.toUTCString()
			}
			var s = n.path ? "; path=" + n.path : "",
				o = n.domain ? "; domain=" + n.domain : "",
				u = n.secure ? "; secure" : "";
			document.cookie = [e, "=", encodeURIComponent(t), r, s, o, u].join("")
		}, l.resize = function() {
			if (s.msie) return;
			$(".viewport").height() < 600 ? $(".viewport").css({
				zoom: .75
			}) : $(".viewport").css({
				zoom: 1
			})
		}, l.isIE = function() {
			return s.msie
		}, l.getHead = function(e, t, n) {
			var r = this,
				i = function() {
					var n;
					switch (t.user_icon_group) {
					case "1":
						n = f;
						break;
					case "2":
						n = r.getRandomHead(e.name);
						break;
					case "3":
						n = t.user_icon_upload_path;
						break;
					default:
						n = f
					}
					return n
				};
			e.head == "" && (e.head = i()), t.anonymous && (e.head = r.getRandomHead(e.name));
			var s, o = new Image;
			return o.onload = function() {
				if (this.naturalWidth < 121 || this.naturalHeight < 121) s = e.head = i();
				n && n(e.index, e.head)
			}, o.src = e.head, e.head
		}, l.getRandomHead = function(e) {
			e = e || Math.floor(Math.random() * 100 + 1);
			var t = r(e),
				n = t.substring(t.length - 3, t.length - 1);
			return n = parseInt(n, 16) % 20 + 1, "http://" + window.location.host + "/live/widget/head/" + n + ".png"
		}, l.getEmo = function(e) {
			return n(e.toString())
		}, l.getQQNum = function() {
			var e = l.cookie("uin");
			return e == null ? 0 : (e = e.substr(1), e++, e--, e)
		}, l.game = function(e) {
			var n = this;
			$("body").append(t(e.path + "/modal/game", e.model.params));
			var r = $("#game");
			r.modal({
				show: !0
			}), r.on("hidden.bs.modal", function(e) {
				e.target === this && r.remove()
			}), $(".modal-close").on("click", function() {
				setTimeout(function() {
					r.find('[data-dismiss="modal"]').trigger("click")
				}, 100)
			})
		}, l.alert = function(e) {
			var n = this;
			$("body").append(t(e.path + "/modal/alert", e.content));
			var r = $("#alert");
			r.modal({
				show: !0
			})
		}, l.setting = function(e) {
			var n = this;
			$("body").append(t(e.path + "/modal/setting", e.model.data));
			var r = $("#setting");
			r.modal({
				show: !0
			}), r.on("click", ".tab", function(e) {
				e.preventDefault(), $(".tab.active, .slide.active").removeClass("active"), $(this).addClass("active"), $(".slide").eq($(this).index()).addClass("active")
			}), r.on("click", ".theme", function() {
				var e = $(this).data("theme");
				$(".theme").removeClass("active"), $(this).addClass("active"), $("#theme-value").val(e), l.changeTheme(e)
			}), r.on("change", "#upload-img-fileinput", function() {
				n.uploadImg()
			}), r.on("click", ".clear-btn", function() {
				$("#bgurl-value").val(""), $(".upload-img-box img").removeAttr("src"), $("#background_img").removeAttr("style"), $(".blur>div").css({
					"background-image": "none"
				})
			}), r.on("click", "#save-setting", function() {
				var t = {};
				t.theme = $("#theme-value").val(), t.bgurl = $("#bgurl-value").val(), t = $.extend(t, e.model.params), $.ajax({
					url: i.urls.saveSetting,
					dataType: "json",
					data: t
				}).done(function(t) {
					t.code || (n.alert({
						path: e.path,
						content: {
							message: "保存成功"
						}
					}), setTimeout(function() {
						window.location.reload()
					}, 1e3))
				})
			}), $("#messageScrollTimeBar").noUiSlider({
				start: [e.model.data.scrolltime],
				step: 1,
				range: {
					min: [1],
					max: [10]
				},
				format: wNumb({
					decimals: 0,
					postfix: "秒"
				})
			}), $("#messageScrollTimeBar").Link("lower").to($("#messageScrollTimeBar").next("div")), $("#messageScrollTimeBar").on({
				change: function() {
					var e = $(this).val();
					e = e.substring(0, e.length - 1), l.cookie("wxc_message_scrolltime", e)
				}
			}), r.on("change", "#messageInterval", function() {
				var e = $(this).prop("checked");
				e ? l.cookie("wxc_message_interval", 1) : l.cookie("wxc_message_interval", 0)
			}), r.on("change", "#messageAnonymous", function() {
				var e = $(this).prop("checked");
				e ? l.cookie("wxc_message_anonymous", 1) : l.cookie("wxc_message_anonymous", 0)
			}), r.on("click", "#logout", function() {
				window.confirm("确认要切换当前账户？") && l.logout()
			}), r.on("hidden.bs.modal", function(e) {
				e.target === this && r.remove()
			})
		}, l.uploadImg = function() {
			var e = $(".upload-img-box img"),
				t = $("#bgurl-value"),
				n = $("#upload-img-fileinput"),
				r = $("#background_img");
			$blur = $(".blur>div"), e.attr("src", "images/loading.gif");
			var i = {
				uin: l.getQQNum(),
				id: "upload-img-fileinput",
				callback: function(n) {
					var i = $.uploadCheck(n);
					if (i.ret == 1) {
						var s = n.local_url,
							o = n.store_url;
						t.val(o);
						var u = function() {
								e.attr("src", s), r.css({
									"background-image": "url(" + s + ")"
								}), $blur.css({
									"background-image": "url(" + s + ")"
								})
							},
							a = new Image;
						a.src = s;
						if (a.complete) {
							u();
							return
						}
						a.onload = function() {
							u()
						}
					} else alert(i.msg)
				},
				errorCallback: function(e) {
					alert(e), n.val("")
				}
			};
			new $.UploadPic(i)
		}, l.toggleFullscreen = function() {
			document.webkitIsFullScreen ? (document.webkitCancelFullScreen(), $("#fullscreen i").removeClass("icon-cancel-full-screen").addClass("icon-full-screen")) : ($("html")[0].webkitRequestFullScreen(), $("#fullscreen i").removeClass("icon-full-screen").addClass("icon-cancel-full-screen"))
		}, l.changeTheme = function(e) {
			$("#theme").remove();
			var t = document.createElement("link");
			t.id = "theme", t.rel = "stylesheet", t.href = "css/themes/" + e + ".css", document.getElementsByTagName("head")[0].appendChild(t)
		}, l.drawByProbability = function(e) {
			var t = 0,
				n = 0,
				r = Math.random();
			for (var i = e.luck.length - 1; i >= 0; i--) t += e.luck[i];
			r *= t;
			for (var i = e.luck.length - 1; i >= 0; i--) {
				n += e.luck[i];
				if (r <= n) return e.value[i]
			}
			return null
		}, l.ajustFontsize = function(e) {
			var t = 0,
				n = e.length;
			return n <= 8 ? t = 60 : n <= 30 ? t = 45 : t = 26, t
		}, l
	}), define("base/cache", [], function() {
		function r(t) {
			var n = t.name;
			n && t.remote && (t = $.extend({
				data: {},
				params: {},
				maxAge: 0,
				type: "get",
				dataType: "jsonp",
				domain: document.domain
			}, t), e[n] = t)
		}
		var e = {},
			t = window.localStorage,
			n = function() {};
		t || (t = {
			setItem: n,
			getItem: n
		});
		var i = function(e, t, n) {
				return n = n || new Date, Math.floor((n - new Date(parseInt(e._time, 32))) / 1e3) < t
			},
			s = {
				register: function(e) {
					if (e && Object.prototype.toString.call(e) === "[object Array]") for (var t = 0; t < e.length; t++) r(e[t]);
					else r(e);
					return this
				},
				remove: function(t) {
					var n = new RegExp("^nv_data_" + t + "_");
					return Object.keys(localStorage).forEach(function(e) {
						n.test(e) && localStorage.removeItem(e)
					}), e[t].data = {}, this
				},
				clear: function() {
					var t = this,
						n = Object.keys(e);
					return n.forEach(function(e) {
						t.remove(e)
					}), this
				},
				get: function(t, n) {
					var r = +(new Date),
						i = e[t],
						s = $.Deferred();
					if (i) {
						var o = $.extend({}, i.params, n);
						$.ajax({
							type: i.type,
							url: i.remote,
							data: o,
							traditional: !0,
							dataType: i.dataType,
							success: function(e) {
								$.isFunction(i.behavior) && (e = i.behavior(e));
								if (!e) {
									s.reject();
									return
								}
								s.resolve(e)
							},
							error: function() {
								s.reject()
							}
						})
					}
					return s
				}
			};
		return s
	}), define("model/global", ["require", "base/util", "base/cache"], function(e) {
		var t = e("base/util"),
			n = e("base/cache"),
			r = {
				params: null,
				auth: null,
				data: null,
				comments: null
			};
		return r.comments = Array(), r.defaults = {
			offset: 0,
			limit: 500,
			display_offset: 0,
			total: 0,
			interval: 3,
			has_left: !1,
			colorArr: {
				value: [16776960, 10092288, 16711680, 16777215],
				luck: [5, 5, 5, 85]
			},
			modeArr: {
				value: [4, 3, 2, 1],
				luck: [5, 5, 5, 85]
			}
		}, r.saveData = function(e) {
			var t = this;
			t.data = e, t.data.wxqrcode = e.wxqrcode || "http://labs.api.act.qq.com/631007063/qrcode/get_image/?format=png&size=6&msg=" + encodeURIComponent("http://" + window.location.host + "/live/client/index.html#wall?campaign_id=" + t.params.campaign_id), t.data.token = t.data.s_tk, t.data.scrolltime = t.data.scroll_time, t.data.interval = t.data.loop
		}, r.interval = function() {
			var e = this,
				i = function() {
					e.sync = window.setTimeout(function() {
						i()
					}, e.defaults.interval * 1e3), e.defaults.has_left || n.get("WallMsg", {
						offset: e.defaults.offset,
						limit: e.defaults.limit
					}).done(function(n) {
						if (!n.data.data.length) return;
						e.defaults.total = n.data.count;
						var i = n.data.data;
						for (var s = 0; s < i.length; s++) i[s].index = e.defaults.offset, i[s].head = t.getHead(i[s], r.data, function(t, n) {
							e.comments[t].head = n
						}), i[s].type == 0 && (i[s].name = t.getEmo(i[s].name), i[s].content = t.getEmo(i[s].content), e.comments.push(i[s]), e.defaults.offset++)
					})
				};
			i()
		}, r
	}), eval(function(e, t, n, r, i, s) {
		i = function(e) {
			return (e < t ? "" : i(parseInt(e / t))) + ((e %= t) > 35 ? String.fromCharCode(e + 29) : e.toString(36))
		};
		if (!"".replace(/^/, String)) {
			while (n--) s[i(n)] = r[n] || i(n);
			r = [function(e) {
				return s[e]
			}], i = function() {
				return "\\w+"
			}, n = 1
		}
		while (n--) r[n] && (e = e.replace(new RegExp("\\b" + i(n) + "\\b", "g"), r[n]));
		return e
	}("'92 6B';p 7={4z:'0.8.9',4D:'1.0',4u:6y,6F:'8R',8T:['2K-23','5O-5W-2K-23','25-23','3j','2Y','1m-5s'],5H:['2K-23','25-23','1m-5s'],x:(I 6p==='1q')?4e:6p,K:l(a,b,c){o(!b)m a;B(p d 1m b){o(!b.1k(d))1v;o(a.1k(d)&&c===M)1v;o(a[d]!==b[d])a[d]=b[d]}m a},2F:l(a){a=a||6.4u;o(a>32){p b=2H.96(a/32),1h='';1s(b--)1h+=6.2F(32);p c=1h.27(''),48='';1s(c.y>0)48+=c.8W();m 48}p d=2H.5C(2,a)-1,5K=d.R(36).y,1h=2H.6R(2H.2F()*d).R(36);1s(1h.y<5K)1h='0'+1h;m 1h},6W:l(a){p b=[].35(a)[0];m b&&b.2e},42:l(a){p b,i,3k;o(a 2o 1A){b=[];i=a.y;1s(i--)b[i]=7.42(a[i]);m b}V o(I a==='1V'){b=(a===G)?G:{};B(3k 1m a)b[3k]=7.42(a[3k]);m b}V{m a}},8o:l(a,b){B(p i=0,n=a.y;i<n;i++){o(6.2a(b,a[i])!==-1)m a[i]}m G},2a:l(a,b){o(a.2a)m a.2a(b);B(p i=0,n=a.y;i<n;i++){o(a[i]===b)m i}m-1},2k:l(a,b,c){o(a.2k)m a.2k(b,c);p d=[];o(a 2o 1A){B(p i=0,n=a.y;i<n;i++){d.S(b.C(c||G,a[i],i))}}V{B(p e 1m a){o(!a.1k(e))1v;d.S(b.C(c||G,e,a[e]))}}m d},6v:l(a,b,c){p d=[];B(p i=0,n=a.y;i<n;i++){o(b.C(c||G,a[i],i))d.S(a[i])}m d},4E:l(a,b,c,d){p n=a.y,i=-1,3o=0,3v=M;p e=l(){3o-=1;i+=1;o(i===n)m c&&c.C(d);b(a[i],g)};p f=l(){o(3v)m;3v=O;1s(3o>0)e();3v=M};p g=l(){3o+=1;f()};g()},1a:l(c){o(6.1U)m 6.1U(c,l(a,b){m(6[a]2o 1A)?6[a]:b});m 1f.1U(c)},3S:l(a){o(I 4w!=='1q')4w.3R(a)},4C:l(){p a=w 3Q(),4F=a.6Y(),4G=a.8P()+1,4I=a.8S(),4T=a.8U(),55=a.8Y(),57=a.94();p b=l(n){m n<10?'0'+n:3w(n)};m b(4F)+'-'+b(4G)+'-'+b(4I)+' '+b(4T)+':'+b(55)+':'+b(57)}};o(I 4e!=='1q')4e.7=7;7.18=l(a,b){o(I a!=='l'){b=a;a=2V}p c=l(){o(!6.1r)m 6;m 6.1r.2c(6,14)||6};p d=l(){};d.H=a.H;c.H=w d();7.K(c.H,b);m c};7.7s=7.18({1r:l(){6.2z={}},8q:l(a){m 6.2z.1k(a)},8F:l(){p a=7.2F();1s(6.2z.1k(a))a=7.2F();m 6.2z[a]=a},8G:l(a){1n 6.2z[a]}});7.W=7.18({1r:l(a,b,c){6.3F=a;6.1C=1A.H.1x.C(b);6.1c=c},R:l(){m 6.3F+':'+6.1C.2b(',')+':'+6.1c}});7.W.L=l(a){a=a||'';o(!7.3D.4O.1T(a))m w 6(G,[],a);p b=a.27(':'),3F=6s(b[0]),1C=b[1].27(','),a=b[2];m w 6(3F,1C,a)};7.W.6t=l(){m w 6(4W,14,\"6x 51\").R()};7.W.6A=l(){m w 6(6C,14,\"6D 6E 53 6G\").R()};7.W.6K=l(){m w 6(6L,14,\"6M 51\").R()};7.W.6N=l(){m w 6(6P,14,\"6Q 1o\").R()};7.W.6S=l(){m w 6(6T,14,\"3I 59\").R()};7.W.6Z=l(){m w 6(72,14,\"73 75 7c\").R()};7.W.7d=l(){m w 6(7o,14,\"7q 19\").R()};7.W.7t=l(){m w 6(7y,14,\"3I 19\").R()};7.W.7L=l(){m w 6(7O,14,\"7W 19\").R()};7.W.7Y=l(){m w 6(88,14,\"3I 8b\").R()};7.W.8c=l(){m w 6(8i,14,\"8j 26 2T\").R()};7.W.8w=l(){m w 6(8y,14,\"8z 8E 2S\").R()};7.2q={25:l(a,b){o(!a)m;o(6.3N==='1Z')m a.2c(b,6.3t);6.3s=6.3s||[];6.3s.S([a,b])},2P:l(a,b){p c=6;p d=7.x.20(l(){c.12('1J',b)},a*1Q);6.3V=d},40:l(a,b){o(!a)m;o(6.3N==='1J')m a.2c(b,6.3t);6.3f=6.3f||[];6.3f.S([a,b])},12:l(){o(6.3V)7.x.3d(6.3V);p a=1A.H.1x.C(14),1D=a.2t(),2L;6.3N=1D;6.3t=a;o(1D==='1Z')2L=6.3s;V o(1D==='1J')2L=6.3f;o(!2L)m;p b;1s(b=2L.2t())b[0].2c(b[1],6.3t)}};7.3a={52:l(a){o(!6.1e||!6.1e[a])m 0;m 6.1e[a].y},39:l(a,b,c){6.1e=6.1e||{};p d=6.1e[a]=6.1e[a]||[];d.S([b,c])},56:l(a,b,c){o(!6.1e||!6.1e[a])m;o(!b){1n 6.1e[a];m}p d=6.1e[a],i=d.y;1s(i--){o(b!==d[i][0])1v;o(c&&d[i][1]!==c)1v;d.46(i,1)}},11:l(){p a=1A.H.1x.C(14),47=a.2t();o(!6.1e||!6.1e[47])m;p b=6.1e[47].1x(),30;B(p i=0,n=b.y;i<n;i++){30=b[i];30[0].2c(30[1],a)}}};7.5u={4b:l(a,b,c,d){6.1O=6.1O||{};o(6.1O.1k(a))m;p e=6;6.1O[a]=7.x.20(l(){1n e.1O[a];c.C(d)},1Q*b)},5J:l(a){6.1O=6.1O||{};p b=6.1O[a];o(!b)m;3d(b);1n 6.1O[a]}};7.1P={3A:{2S:3,6X:2,13:1,2C:0},4t:'2S',3R:l(a,b){o(!7.3S)m;p c=7.1P.3A;o(c[7.1P.4t]>c[b])m;p a=1A.H.1x.2c(a),3c=' ['+b.74()+'] [7',1p=6.77,1c=a.2t().1B(/\\?/g,l(){3b{m 7.1a(a.2t())}34(e){m'[2V]'}});B(p d 1m 7){o(1p)1v;o(I 7[d]!=='l')1v;o(6 2o 7[d])1p=d}o(1p)3c+='.'+1p;3c+='] ';7.3S(7.4C()+3c+1c)}};(l(){B(p c 1m 7.1P.3A)(l(a,b){7.1P[a]=l(){6.3R(14,a)}})(c,7.1P.3A[c])})();7.3D={7p:/^[a-z]$/,7r:/^[A-Z]$/,7u:/^([a-z]|[A-Z])$/,7v:/^[0-9]$/,7w:/^(([a-z]|[A-Z])|[0-9])$/,7x:/^(\\-|\\Y|\\!|\\~|\\(|\\)|\\$|\\@)$/,7z:/^(((([a-z]|[A-Z])|[0-9])|(\\-|\\Y|\\!|\\~|\\(|\\)|\\$|\\@)| |\\/|\\*|\\.))*$/,7A:/^(((([a-z]|[A-Z])|[0-9])|(\\-|\\Y|\\!|\\~|\\(|\\)|\\$|\\@)))+$/,7B:/^([0-9])+$/,7C:/^(((([a-z]|[A-Z])|[0-9])|(\\-|\\Y|\\!|\\~|\\(|\\)|\\$|\\@)))+$/,7K:/^(((([a-z]|[A-Z])|[0-9])|(\\-|\\Y|\\!|\\~|\\(|\\)|\\$|\\@)))+(\\/(((([a-z]|[A-Z])|[0-9])|(\\-|\\Y|\\!|\\~|\\(|\\)|\\$|\\@)))+)*$/,4K:/^\\/(((([a-z]|[A-Z])|[0-9])|(\\-|\\Y|\\!|\\~|\\(|\\)|\\$|\\@)))+(\\/(((([a-z]|[A-Z])|[0-9])|(\\-|\\Y|\\!|\\~|\\(|\\)|\\$|\\@)))+)*$/,7N:/^\\*{1,2}$/,4L:/^(\\/(((([a-z]|[A-Z])|[0-9])|(\\-|\\Y|\\!|\\~|\\(|\\)|\\$|\\@)))+)*\\/\\*{1,2}$/,7P:/^(([a-z]|[A-Z])|[0-9])(((([a-z]|[A-Z])|[0-9])|\\-|\\Y))*$/,4z:/^([0-9])+(\\.(([a-z]|[A-Z])|[0-9])(((([a-z]|[A-Z])|[0-9])|\\-|\\Y))*)*$/,7Q:/^((([a-z]|[A-Z])|[0-9]))+$/,7R:/^((([a-z]|[A-Z])|[0-9]))+$/,7S:/^(((([a-z]|[A-Z])|[0-9])|(\\-|\\Y|\\!|\\~|\\(|\\)|\\$|\\@)| |\\/|\\*|\\.))*$/,7U:/^(((([a-z]|[A-Z])|[0-9])|(\\-|\\Y|\\!|\\~|\\(|\\)|\\$|\\@)| |\\/|\\*|\\.))*(,(((([a-z]|[A-Z])|[0-9])|(\\-|\\Y|\\!|\\~|\\(|\\)|\\$|\\@)| |\\/|\\*|\\.))*)*$/,7V:/^[0-9][0-9][0-9]$/,4O:/^([0-9][0-9][0-9]:(((([a-z]|[A-Z])|[0-9])|(\\-|\\Y|\\!|\\~|\\(|\\)|\\$|\\@)| |\\/|\\*|\\.))*(,(((([a-z]|[A-Z])|[0-9])|(\\-|\\Y|\\!|\\~|\\(|\\)|\\$|\\@)| |\\/|\\*|\\.))*)*:(((([a-z]|[A-Z])|[0-9])|(\\-|\\Y|\\!|\\~|\\(|\\)|\\$|\\@)| |\\/|\\*|\\.))*|[0-9][0-9][0-9]::(((([a-z]|[A-Z])|[0-9])|(\\-|\\Y|\\!|\\~|\\(|\\)|\\$|\\@)| |\\/|\\*|\\.))*)$/};7.4g={7X:l(a){6.1M=6.1M||[];6.1M.S(a);o(a.4U)a.4U(6)},8a:l(a){o(!6.1M)m;p i=6.1M.y;1s(i--){o(6.1M[i]!==a)1v;6.1M.46(i,1);o(a.4V)a.4V(6)}},4o:l(c,d,e,f){6.2C('8e 8g ? 8h: ?',c,d);o(!6.1M)m e.C(f,d);p g=6.1M.1x();p h=l(a){o(!a)m e.C(f,a);p b=g.2t();o(!b)m e.C(f,a);o(b[c])b[c](a,h);V h(a)};h(d)}};7.K(7.4g,7.1P);7.1b=7.18({1r:l(a){6.1K=6.8p=a},S:l(a){6.11('1c',a)},54:l(){m 6.52('1c')===0}});7.K(7.1b.H,7.3a);7.K(7.1b,{2A:'/22/2s',4i:'/22/1w',5b:'/22/24',5t:'/22/1S',5w:'/22/4k',5D:'22',5F:'90',5G:l(a){p b=6.L(a),3z=['/**',a];p c=b.1x();c[c.y-1]='*';3z.S(6.3K(c));B(p i=1,n=b.y;i<n;i++){c=b.1x(0,i);c.S('**');3z.S(6.3K(c))}m 3z},4n:l(a){m 7.3D.4K.1T(a)||7.3D.4L.1T(a)},L:l(a){o(!6.4n(a))m G;m a.27('/').1x(1)},3K:l(a){m'/'+a.2b('/')},5L:l(a){p b=6.L(a);m b?(b[0]===6.5D):G},5M:l(a){p b=6.L(a);m b?(b[0]===6.5F):G},6u:l(a){o(!6.4n(a))m G;m!6.5L(a)&&!6.5M(a)},4l:7.18({1r:l(){6.U={}},63:l(){p a=[];B(p b 1m 6.U)a.S(b);m a},6d:l(a){1n 6.U[a]},4s:l(a){m 6.U.1k(a)},24:l(a,b,c){o(!b)m;p d;B(p i=0,n=a.y;i<n;i++){d=a[i];p e=6.U[d]=6.U[d]||w 7.1b(d);e.39('1c',b,c)}},1S:l(a,b,c){p d=6.U[a];o(!d)m M;d.56('1c',b,c);o(d.54()){6.6d(a);m O}V{m M}},6k:l(a){p b=7.1b.5G(a.19);B(p i=0,n=b.y;i<n;i++){p c=6.U[b[i]];o(c)c.11('1c',a.1z)}}})});7.4q=7.18(7.2q);7.3r=7.18({1r:l(a,b,c,d){6.21=a;6.U=b;6.3B=c;6.3C=d;6.4h=M},4A:l(){o(6.4h)m;6.21.1S(6.U,6.3B,6.3C);6.4h=O},1S:l(){6.4A()}});7.K(7.3r.H,7.2q);7.1l=7.18({1g:1,2w:2,1R:3,2r:4,2A:'2s',4J:'17',4f:'70',4M:60.0,4N:5.0,4Q:'/76',4R:0.0,1r:l(a,b){6.13('79 59 7a B ?',a);6.2E=b||{};6.1j=a||6.4Q;6.4d=6.2E.4d||{};6.2G={};6.4Y=7.50&&w 7.50();6.4c={};6.3E=[];6.17=6.2E.17||6.4N;6.P=6.1g;6.U=w 7.1b.4l();6.2I=0;6.2Z={};6.1X={31:6.4J,33:1Q*(6.2E.33||6.4R),2P:1Q*(6.2E.2P||6.4M)};o(7.1y)7.1y.2f(7.x,'37',l(){o(7.2a(6.3E,'7D')<0)6.4k()},6)},7I:l(a){6.3E.S(a)},7J:l(a,b){6.4c[a]=b},38:l(){m 6.N},7M:l(){5v(6.P){1I 6.1g:m'1g';1I 6.2w:m'2w';1I 6.1R:m'1R';1I 6.2r:m'2r'}},2s:l(b,c){o(6.1X.31===6.4f)m;o(6.P!==6.1g)m;6.P=6.2w;p d=6;6.13('5x 2s 5z ?',6.1j);6.45(7.5H);6.28({19:7.1b.2A,7T:7.4D,5E:[6.1F.2M]},l(a){o(a.1H){6.P=6.1R;6.N=a.2e;6.45(a.5E);6.13('5I 1H: ?',6.N);6.24(6.U.63(),O);o(b)b.C(c)}V{6.13('5I 81');7.x.20(l(){d.2s(b,c)},6.1X.33);6.P=6.1g}},6)},1w:l(a,b){o(6.1X.31===6.4f)m;o(6.P===6.2r)m;o(6.P===6.1g)m 6.2s(l(){6.1w(a,b)},6);6.25(a,b);o(6.P!==6.1R)m;6.13('82 3g 89 B ?',6.N);6.12('1Z');6.12('3g');o(6.3h)m;6.3h=O;6.13('5x 43 B ?',6.N);6.28({19:7.1b.4i,2e:6.N,2M:6.1F.2M},6.41,6)},4k:l(){o(6.P!==6.1R)m;6.P=6.2r;6.13('8d ?',6.N);6.28({19:7.1b.5w,2e:6.N},l(a){o(a.1H)6.1F.1N()},6);6.13('8f 19 5T B ?',6.N);6.U=w 7.1b.4l()},24:l(d,e,f){o(d 2o 1A)m 7.2k(d,l(c){m 6.24(c,e,f)},6);p g=w 7.3r(6,d,e,f),3Z=(e===O),5Y=6.U.4s(d);o(5Y&&!3Z){6.U.24([d],e,f);g.12('1Z');m g}6.1w(l(){6.13('1l ? 61 26 24 26 ?',6.N,d);o(!3Z)6.U.24([d],e,f);6.28({19:7.1b.5b,2e:6.N,3m:d},l(a){o(!a.1H){g.12('1J',7.W.L(a.2S));m 6.U.1S(d,e,f)}p b=[].35(a.3m);6.13('3r 66 B ? 26 ?',6.N,b);g.12('1Z')},6)},6);m g},1S:l(d,e,f){o(d 2o 1A)m 7.2k(d,l(c){m 6.1S(c,e,f)},6);p g=6.U.1S(d,e,f);o(!g)m;6.1w(l(){6.13('1l ? 61 26 1S 3X ?',6.N,d);6.28({19:7.1b.5t,2e:6.N,3m:d},l(a){o(!a.1H)m;p b=[].35(a.3m);6.13('8r 66 B ? 3X ?',6.N,b)},6)},6)},2T:l(b,c){p d=w 7.4q();6.1w(l(){6.13('1l ? 8s 8t 1c 26 ?: ?',6.N,b,c);6.28({19:b,1z:c,2e:6.N},l(a){o(a.1H)d.12('1Z');V d.12('1J',7.W.L(a.2S))},6)},6);m d},6h:l(c){6.4o('8x',c,l(a){o(!a)m;o(a.3W)6.6m(a.3W);6.6o(a);o(a.1H===1q)m;p b=6.2Z[a.1K];o(!b)m;1n 6.2Z[a.1K];b[0].C(b[1],a)},6)},45:l(b){7.q.4p(6,b,6.3E,l(a){6.2C('8K ? 3U B ?',a.2M,a.1j);o(a===6.1F)m;o(6.1F)6.1F.1N();6.1F=a;6.1F.8Q=6.4Y;6.1F.4r=6.4c;a.39('1L',l(){o(6.2h!==1q&&!6.2h)m;6.2h=M;6.11('3U:1L')},6);a.39('1Y',l(){o(6.2h!==1q&&6.2h)m;6.2h=O;6.11('3U:1Y')},6)},6)},28:l(b,c,d){b.1K=6.4v();o(c)6.2Z[b.1K]=[c,d];6.4o('8X',b,l(a){o(!a)m;6.1F.2Q(a,6.1X.2P/1Q)},6)},4v:l(){6.2I+=1;o(6.2I>=2H.5C(2,32))6.2I=0;m 6.2I.R(36)},6m:l(a){7.K(6.1X,a);o(6.1X.31===6.2A&&6.P!==6.2r){6.P=6.1g;6.N=G;6.41()}},6o:l(a){o(!a.19||a.1z===1q)m;6.13('1l ? 8Z 5T B ? 5z ?',6.N,a.19,a.1z);6.U.6k(a)},4x:l(){o(!6.3h)m;6.3h=G;6.13('91 43 B ?',6.N)},41:l(){6.4x();p a=6;7.x.20(l(){a.1w()},6.1X.33)}});7.K(7.1l.H,7.2q);7.K(7.1l.H,7.3a);7.K(7.1l.H,7.1P);7.K(7.1l.H,7.4g);7.q=7.K(7.18({4y:0.0,3T:O,1r:l(a,b){6.21=a;6.1j=b;6.2u=[]},1N:l(){},2Q:l(a,b){6.2C('1l ? 97 1c 26 ?: ?',6.21.N,6.1j,a);o(!6.3T)m 6.1o([a],b);6.2u.S(a);6.4B=b;o(a.19===7.1b.2A)m 6.4b('2T',0.6r,6.2X,6);o(a.19===7.1b.4i)6.3y=a;o(6.3J&&6.3J(6.2u))m 6.2X();6.4b('2T',6.4y,6.2X,6)},2X:l(){6.5J('2T');o(6.2u.y>1&&6.3y)6.3y.3W={2P:0};6.1o(6.2u,6.4B);6.3y=G;6.2u=[]},2p:l(a){6.2C('1l ? 6w 3X ?: ?',6.21.N,6.1j,a);B(p i=0,n=a.y;i<n;i++){6.21.6h(a[i])}},17:l(a,b){p c=M,17=6.21.17*1Q,J=6;m l(){o(c)m;c=O;7.x.20(l(){J.1o(a,b)},17)}}}),{4H:6z,4p:l(f,g,h,i,j){p k=f.1j;7.4E(6.44,l(c,d){p e=c[0],1p=c[1],2W=f.4d[e]||k;o(7.2a(h,e)>=0)m d();o(7.2a(g,e)<0){1p.1i(f,2W,l(){});m d()}1p.1i(f,2W,l(a){o(!a)m d();p b=1p.1k('2j')?1p.2j(f,2W):w 1p(f,2W);i.C(j,b)})},l(){3H w W('6H 53 6I a 6J 43 4P B '+k);})},Q:l(a,b){6.44.S([a,b]);b.H.2M=a},44:[]});7.K(7.q.H,7.1P);7.K(7.q.H,7.3a);7.K(7.q.H,7.5u);7.1y={2U:[],2f:l(a,b,c,d){p e=l(){c.C(d)};o(a.4S)a.4S(b,e,M);V a.6O('2f'+b,e);6.2U.S({2R:a,3x:b,3B:c,3C:d,3L:e})},3M:l(a,b,c,d){p i=6.2U.y,Q;1s(i--){Q=6.2U[i];o((a&&a!==Q.2R)||(b&&b!==Q.3x)||(c&&c!==Q.3B)||(d&&d!==Q.3C))1v;o(Q.2R.4X)Q.2R.4X(Q.3x,Q.3L,M);V Q.2R.6U('2f'+Q.3x,Q.3L);6.2U.46(i,1);Q=G}}};7.1y.2f(7.x,'6V',7.1y.3M,7.1y);7.1t=7.K(7.18({4Z:l(){p a=[];B(p b 1m 6.1C){o(!6.1C.1k(b))1v;a.S(3O(b)+'='+3O(6.1C[b]))}m a.2b('&')},3P:l(){p a=7.1t.L(7.x.1G.71,M);p b=(a.2x!==6.2x)||(a.2g!==6.2g)||(a.2v!==6.2v);m!b},3q:l(){p a=6.4Z();m 6.2v+'//'+6.2x+(6.2g?':'+6.2g:'')+6.3p+(a?'?'+a:'')+6.58}}),{L:l(e,f){o(I e!=='1h')m e;p g=w 6(),29;p h=l(b,c,d){e=e.1B(c,l(a){g[b]=a;m''});o(g[b]===1q)g[b]=d?7.x.1G[b]:''};h('2v',/^78?\\:/,O);h('2O',/^\\/\\/[^\\/]+/,O);o(!/^\\//.1T(e))e=7.x.1G.3p.1B(/[^\\/]*$/,'')+e;h('3p',/^\\/[^\\?#]*/);h('5a',/^\\?[^#]*/);h('58',/^#.*/);o(/^\\/\\//.1T(g.2O)){g.2O=g.2O.7b(2);29=g.2O.27(':');g.2x=29[0];g.2g=29[1]||''}V{g.2x=7.x.1G.2x;g.2g=7.x.1G.2g}o(f===M){g.1C={}}V{p i=g.5a.1B(/^\\?/,''),3Y=i?i.27('&'):[],n=3Y.y,1z={};1s(n--){29=3Y[n].27('=');1z[5c(29[0]||'')]=5c(29[1]||'')}o(I f==='1V')7.K(1z,f);g.1C=1z}m g}});o(!6.1f){1f={}}(l(){l f(n){m n<10?'0'+n:n}o(I 3Q.H.1a!=='l'){3Q.H.1a=l(a){m 6.7e()+'-'+f(6.7f()+1)+'-'+f(6.7g())+'T'+f(6.7h())+':'+f(6.7i())+':'+f(6.7j())+'Z'};3w.H.1a=7k.H.1a=7l.H.1a=l(a){m 6.7m()}}p e=/[\\7n\\5d\\5e-\\5f\\5g\\5h\\5i\\5j-\\5k\\5l-\\5m\\5n-\\5o\\5p\\5q-\\5r]/g,3l=/[\\\\\\\"\\7E-\\7F\\7G-\\7H\\5d\\5e-\\5f\\5g\\5h\\5i\\5j-\\5k\\5l-\\5m\\5n-\\5o\\5p\\5q-\\5r]/g,1d,2N,22={'\\b':'\\\\b','\\t':'\\\\t','\\n':'\\\\n','\\f':'\\\\f','\\r':'\\\\r','\"':'\\\\\"','\\\\':'\\\\\\\\'},1W;l 3i(b){3l.5y=0;m 3l.1T(b)?'\"'+b.1B(3l,l(a){p c=22[a];m I c==='1h'?c:'\\\\u'+('5A'+a.5B(0).R(16)).1x(-4)})+'\"':'\"'+b+'\"'}l 2y(a,b){p i,k,v,y,2J=1d,1u,E=b[a];o(E&&I E==='1V'&&I E.1a==='l'){E=E.1a(a)}o(I 1W==='l'){E=1W.C(b,a,E)}5v(I E){1I'1h':m 3i(E);1I'49':m 7Z(E)?3w(E):'G';1I'80':1I'G':m 3w(E);1I'1V':o(!E){m'G'}1d+=2N;1u=[];o(2V.H.R.2c(E)==='[1V 1A]'){y=E.y;B(i=0;i<y;i+=1){1u[i]=2y(i,E)||'G'}v=1u.y===0?'[]':1d?'[\\n'+1d+1u.2b(',\\n'+1d)+'\\n'+2J+']':'['+1u.2b(',')+']';1d=2J;m v}o(1W&&I 1W==='1V'){y=1W.y;B(i=0;i<y;i+=1){k=1W[i];o(I k==='1h'){v=2y(k,E);o(v){1u.S(3i(k)+(1d?': ':':')+v)}}}}V{B(k 1m E){o(2V.1k.C(E,k)){v=2y(k,E);o(v){1u.S(3i(k)+(1d?': ':':')+v)}}}}v=1u.y===0?'{}':1d?'{\\n'+1d+1u.2b(',\\n'+1d)+'\\n'+2J+'}':'{'+1u.2b(',')+'}';1d=2J;m v}}7.1U=l(a,b,c){p i;1d='';2N='';o(I c==='49'){B(i=0;i<c;i+=1){2N+=' '}}V o(I c==='1h'){2N=c}1W=b;o(b&&I b!=='l'&&(I b!=='1V'||I b.y!=='49')){3H w W('1f.1U');}m 2y('',{'':a})};o(I 1f.1U!=='l'){1f.1U=7.1U}o(I 1f.L!=='l'){1f.L=l(c,d){p j;l 4a(a,b){p k,v,E=a[b];o(E&&I E==='1V'){B(k 1m E){o(2V.1k.C(E,k)){v=4a(E,k);o(v!==1q){E[k]=v}V{1n E[k]}}}}m d.C(a,b,E)}e.5y=0;o(e.1T(c)){c=c.1B(e,l(a){m'\\\\u'+('5A'+a.5B(0).R(16)).1x(-4)})}o(/^[\\],:{}\\s]*$/.1T(c.1B(/\\\\(?:[\"\\\\\\/83]|u[0-9a-84-F]{4})/g,'@').1B(/\"[^\"\\\\\\n\\r]*\"|O|M|G|-?\\d+(?:\\.\\d*)?(?:[85][+\\-]?\\d+)?/g,']').1B(/(?:^|:|,)(?:\\s*\\[)+/g,''))){j=86('('+c+')');m I d==='l'?4a({'':j},''):j}3H w 87('1f.L');}}}());7.q.1E=7.K(7.18(7.q,{1g:1,2w:2,1R:3,3T:M,1i:l(a,b){6.25(l(){a.C(b,O)});6.40(l(){a.C(b,M)});6.1w()},1o:l(b,c){o(b.y===0)m;6.2l=6.2l||{};B(p i=0,n=b.y;i<n;i++){6.2l[b[i].1K]=b[i]}6.25(l(a){a.2Q(7.1a(b))});6.1w()},1N:l(){o(!6.15)m;6.15.5N=6.15.2m=G;6.15.1N();1n 6.15;6.12('3g');6.P=6.1g},1w:l(){o(7.q.1E.5P)m;6.P=6.P||6.1g;o(6.P!==6.1g)m;6.P=6.2w;p c=7.q.1E.5Q();o(!c)m 6.12('1J');6.15=w c(7.q.1E.5R(6.1j));p d=6;6.15.5S=l(){d.P=d.1R;d.3u=O;d.12('1Z',d.15);d.11('1Y')};6.15.5U=l(a){p b=1f.L(a.1z);o(!b)m;b=[].35(b);B(p i=0,n=b.y;i<n;i++){1n d.2l[b[i].1K]}d.2p(b)};6.15.5N=6.15.2m=l(){p a=(d.P===d.1R);d.12('3g');d.P=d.1g;d.1N();o(a)m d.5V();o(!d.3u)m d.12('1J');p b=d.21.17*1Q;7.x.20(l(){d.1w()},b);d.11('1L')}},5V:l(){o(!6.2l)m;p c=7.2k(6.2l,l(a,b){m b});6.1o(c)}}),{5R:l(a){o(7.1t)a=7.1t.L(a).3q();m a.1B(/^8k(s?):/8l,'8m$1:')},5Q:l(){m(7.1E&&7.1E.1l)||7.x.1E||7.x.8n},1i:l(a,b,c,d){6.2j(a,b).1i(c,d)},2j:l(a,b){p c=a.2G.3j=a.2G.3j||{};c[b]=c[b]||w 6(a,b);m c[b]}});7.K(7.q.1E.H,7.2q);7.q.Q('3j',7.q.1E);o(7.1y)7.1y.2f(7.x,'37',l(){7.q.1E.5P=O});7.q.2D=7.K(7.18(7.q,{1r:l(b,c){7.q.H.1r.C(6,b,c);o(!7.x.2D)m 6.12('1J');6.5X=w 7.q.3n(b,c);p d=w 2D(c+'/'+b.38()),J=6;d.5S=l(){J.3u=O;J.12('1Z');J.11('1Y')};d.2m=l(){o(J.3u){J.11('1L')}V{J.12('1J');d.1N()}};d.5U=l(a){J.2p(1f.L(a.1z));J.11('1Y')};6.15=d},1i:l(a,b){6.25(l(){a.C(b,O)});6.40(l(){a.C(b,M)})},1o:l(a,b){6.5X.1o(a,b)},1N:l(){o(!6.15)m;6.15.2m=G;6.15.1N();1n 6.15}}),{1i:l(b,c,d,e){p f=b.38();o(!f)m d.C(e,M);7.q.3n.1i(b,c,l(a){o(!a)m d.C(e,M);6.2j(b,c).1i(d,e)},6)},2j:l(a,b){p c=a.2G.2Y=a.2G.2Y||{},1K=a.38(),b=b+'/'+(1K||'');c[b]=c[b]||w 6(a,b);m c[b]}});7.K(7.q.2D.H,7.2q);7.q.Q('2Y',7.q.2D);7.q.3n=7.K(7.18(7.q,{1o:l(b,c){p d=6.17(b,c),5Z=7.1t.L(6.1j).3p,J=6,D=7.x.62?w 62(\"8u.8v\"):w 2B();D.64('65',5Z,O);D.2n('8A-8B','8C/8D');D.2n('67','68-69');D.2n('X-8H-8I','2B');p f=6.4r;B(p g 1m f){o(!f.1k(g))1v;D.2n(g,f[g])}p h=l(){D.8J()};7.1y.2f(7.x,'37',h);p i=l(){7.1y.3M(7.x,'37',h);D.6a=l(){};D=G};D.6a=l(){o(D.8L!==4)m;p a=G,1D=D.1D,1H=((1D>=8M&&1D<4W)||1D===8N||1D===8O);o(!1H){i();d();m J.11('1L')}3b{a=1f.L(D.6b)}34(e){}i();o(a){J.2p(a);J.11('1Y')}V{d();J.11('1L')}};D.2Q(7.1a(b))}}),{1i:l(a,b,c,d){c.C(d,7.1t.L(b).3P())}});7.q.Q('2K-23',7.q.3n);7.q.6c=7.K(7.18(7.q,{1o:l(b,c){p d=7.x.4j?4j:2B,D=w d(),17=6.17(b,c),J=6;D.64('65',6.1j,O);o(D.2n)D.2n('67','68-69');p f=l(){o(!D)m M;D.6e=D.2m=D.6f=D.6g=G;D=G;7.x.3d(h);m O};D.6e=l(){p a=G;3b{a=1f.L(D.6b)}34(e){}f();o(a){J.2p(a);J.11('1Y')}V{17();J.11('1L')}};p g=l(){f();17();J.11('1L')};p h=7.x.20(g,1.5*1Q*c);D.2m=g;D.6f=g;D.6g=l(){};D.2Q('1c='+3O(7.1a(b)))}}),{1i:l(a,b,c,d){o(7.1t.L(b).3P())m c.C(d,M);o(7.x.4j)m c.C(d,7.1t.L(b).2v===7.1t.L(7.x.1G).2v);o(7.x.2B){p e=w 7.x.2B();m c.C(d,e.8V!==1q)}m c.C(d,M)}});7.q.Q('5O-5W-2K-23',7.q.6c);7.q.3e=7.K(7.18(7.q,{3J:l(a){p b={1c:7.1a(a),6i:'6j'+7.q.3e.3G+'6l'};p c=7.1t.L(6.1j,b).3q();m c.y>=7.q.4H},1o:l(b,c){p d={1c:7.1a(b)},4m=6n.93('4m')[0],2d=6n.95('2d'),2i=7.q.3e.6q(),1G=7.1t.L(6.1j,d),17=6.17(b,c),J=6;7.x[2i]=l(a){g();J.2p(a);J.11('1Y')};p f=7.x.20(l(){g();17();J.11('1L')},1.5*1Q*c);p g=l(){o(!7.x[2i])m M;7.x[2i]=1q;3b{1n 7.x[2i]}34(e){}7.x.3d(f);2d.98.99(2d);m O};1G.1C.6i=2i;2d.4P='9b/9c';2d.9d=1G.3q();4m.9e(2d)}}),{3G:0,6q:l(){6.3G+=1;m'6j'+6.3G+'6l'},1i:l(a,b,c,d){c.C(d,O)}});7.q.Q('25-23',7.q.3e);", 62, 573, "||||||this|Bayeux||||||||||||||function|return||if|var|Transport||||||new|ENV|length|||for|call|xhr|value||null|prototype|typeof|self|extend|parse|false|_clientId|true|_state|register|toString|push||_channels|else|Error||_|||trigger|setDeferredStatus|info|arguments|_socket||retry|Class|channel|toJSON|Channel|message|gap|_subscribers|JSON|UNCONNECTED|string|isUsable|endpoint|hasOwnProperty|Client|in|delete|request|klass|undefined|initialize|while|URI|partial|continue|connect|slice|Event|data|Array|replace|params|status|WebSocket|_transport|location|successful|case|failed|id|down|_extensions|close|_timeouts|Logging|1000|CONNECTED|unsubscribe|test|stringify|object|rep|_advice|up|succeeded|setTimeout|_client|meta|polling|subscribe|callback|to|split|_send|parts|indexOf|join|apply|script|clientId|on|port|_transportUp|callbackName|create|map|_messages|onerror|setRequestHeader|instanceof|receive|Deferrable|DISCONNECTED|handshake|shift|_outbox|protocol|CONNECTING|hostname|str|_used|HANDSHAKE|XMLHttpRequest|debug|EventSource|_options|random|transports|Math|_messageId|mind|long|callbacks|connectionType|indent|host|timeout|send|_element|error|publish|_registry|Object|connEndpoint|flush|eventsource|_responseCallbacks|listener|reconnect||interval|catch|concat||beforeunload|getClientId|bind|Publisher|try|banner|clearTimeout|JSONP|_errbacks|deferred|_connectRequest|quote|websocket|key|escapable|subscription|XHR|calls|pathname|toURL|Subscription|_callbacks|_deferredArgs|_everConnected|looping|String|_type|_connectMessage|channels|LOG_LEVELS|_callback|_context|Grammar|_disabled|code|_cbCount|throw|Unknown|shouldFlush|unparse|_handler|detach|_deferredStatus|encodeURIComponent|isSameOrigin|Date|log|logger|batching|transport|_timer|advice|from|pairs|force|errback|_cycleConnection|copyObject|connection|_transports|_selectTransport|splice|eventType|result|number|walk|addTimeout|_headers|endpoints|window|NONE|Extensible|_cancelled|CONNECT|XDomainRequest|disconnect|Set|head|isValid|pipeThroughExtensions|get|Publication|headers|hasSubscription|logLevel|ID_LENGTH|_generateMessageId|console|_teardownConnection|MAX_DELAY|VERSION|cancel|_timeout|timestamp|BAYEUX_VERSION|asyncEach|year|month|MAX_URL_LENGTH|day|RETRY|CHANNEL_NAME|CHANNEL_PATTERN|CONNECTION_TIMEOUT|DEFAULT_RETRY|ERROR|type|DEFAULT_ENDPOINT|INTERVAL|addEventListener|hour|added|removed|300|removeEventListener|_cookies|queryString|CookieJar|mismatch|countListeners|not|isUnused|minute|unbind|second|hash|client|search|SUBSCRIBE|decodeURIComponent|u00ad|u0600|u0604|u070f|u17b4|u17b5|u200c|u200f|u2028|u202f|u2060|u206f|ufeff|ufff0|uffff|process|UNSUBSCRIBE|Timeouts|switch|DISCONNECT|Initiating|lastIndex|with|0000|charCodeAt|pow|META|supportedConnectionTypes|SERVICE|expand|MANDATORY_CONNECTION_TYPES|Handshake|removeTimeout|maxSize|isMeta|isService|onclose|cross|_unloaded|getClass|getSocketUrl|onopen|listeners|onmessage|resend|origin|_xhr|hasSubscribe|path||attempting|ActiveXObject|getKeys|open|POST|acknowledged|Pragma|no|cache|onreadystatechange|responseText|CORS|remove|onload|ontimeout|onprogress|receiveMessage|jsonp|__jsonp|distributeMessage|__|_handleAdvice|document|_deliverMessage|global|getCallbackName|01|parseInt|versionMismatch|isSubscribable|filter|received|Version|160|2048|conntypeMismatch|strict|301|Connection|types|JSONP_CALLBACK|supported|Could|find|usable|extMismatch|302|Extension|badRequest|attachEvent|400|Bad|floor|clientUnknown|401|detachEvent|unload|clientIdFromMessages|warn|getFullYear|parameterMissing|none|href|402|Missing|toUpperCase|required|bayeux|className|https|New|created|substr|parameter|channelForbidden|getUTCFullYear|getUTCMonth|getUTCDate|getUTCHours|getUTCMinutes|getUTCSeconds|Number|Boolean|valueOf|u0000|403|LOWALPHA|Forbidden|UPALPHA|Namespace|channelUnknown|ALPHA|DIGIT|ALPHANUM|MARK|404|STRING|TOKEN|INTEGER|CHANNEL_SEGMENT|autodisconnect|x00|x1f|x7f|x9f|disable|setHeader|CHANNEL_SEGMENTS|channelInvalid|getState|WILD_CARD|405|VERSION_ELEMENT|CLIENT_ID|ID|ERROR_MESSAGE|version|ERROR_ARGS|ERROR_CODE|Invalid|addExtension|extUnknown|isFinite|boolean|unsuccessful|Calling|bfnrt|fA|eE|eval|SyntaxError|406|actions|removeExtension|extension|publishFailed|Disconnecting|Passing|Clearing|through|extensions|407|Failed|http|ig|ws|MozWebSocket|commonElement|name|exists|Unsubscription|queueing|published|Microsoft|XMLHTTP|serverError|incoming|500|Internal|Content|Type|application|json|server|generate|release|Requested|With|abort|Selected|readyState|200|304|1223|getMonth|cookies|jsonpcallback|getDate|CONNECTION_TYPES|getHours|withCredentials|pop|outgoing|getMinutes|calling|service|Closed|use|getElementsByTagName|getSeconds|createElement|ceil|sending|parentNode|removeChild||text|javascript|src|appendChild".split("|"), 0, {})), define("bayeux", function(e) {
		return function() {
			var t, n;
			return t || e.bayeux
		}
	}(this)), define("base/remote", ["bayeux"], function() {
		function a(t) {
			t && ($(t.context).unbind(t.type, t.behavior), delete e[t.name])
		}
		function f(t) {
			var n = t.name;
			if (n) {
				if (e[n]) return;
				var r = e[n] = (e[n] && a(e[n]), t)
			}
		}
		var e = {},
			t = function() {},
			n = "http:",
			r = "bayeux.act.qq.com",
			i = "/bayeux",
			s = "641010276",
			o = {
				outgoing: function(e, t) {
					if (e.channel !== "/meta/handshake") return t(e);
					e.ext || (e.ext = {}), e.ext.actId = s, t(e)
				}
			},
			u = new Bayeux.Client(n + "//" + r + "/bayeux");
		u.addExtension(o);
		var l = {
			register: function(e) {
				if (e && Object.prototype.toString.call(e) === "[object Array]") for (var t = 0; t < e.length; t++) f(e[t]);
				else f(e);
				return this
			},
			get: function(t) {
				return e[t]
			},
			remove: function(t) {
				return t && a(e[t]), this
			},
			init: function(t) {
				u.subscribe("/interaction/demo/" + t, function(t) {
					var n = JSON.parse(t),
						r = e[n.name];
					r && r.behavior(n)
				})
			},
			sendMessage: function(e, t) {
				u.publish("/interaction/demo/" + e, JSON.stringify(t))
			}
		};
		return l.register([{
			name: "app-url",
			behavior: function(e) {
				location.href = e.href
			}
		}, {
			name: "app-jump",
			behavior: function(e) {
				location.hash = e.hash
			}
		}, {
			name: "app-click",
			behavior: function(e) {
				$(e.selector).trigger("click")
			}
		}, {
			name: "app-select",
			behavior: function(e) {
				$(e.selector).data("plugin_WXC_Selector").setTarget(e.option)
			}
		}]), l
	}), define("vendor/swiper", ["require"], function(e) {
		var t = function(e, t) {
				"use strict";

				function r(e, t) {
					return document.querySelectorAll ? (t || document).querySelectorAll(e) : jQuery(e, t)
				}
				function b(e) {
					return Object.prototype.toString.apply(e) === "[object Array]" ? !0 : !1
				}
				function x() {
					var e = u - l;
					return t.freeMode && (e = u - l), t.slidesPerView > i.slides.length && !t.centeredSlides && (e = 0), e < 0 && (e = 0), e
				}
				function T() {
					function o(e) {
						var n = new Image;
						n.onload = function() {
							i && i.imagesLoaded && i.imagesLoaded++, i.imagesLoaded === i.imagesToLoad.length && (i.reInit(), t.onImagesReady && i.fireCallback(t.onImagesReady, i))
						}, n.src = e
					}
					var e = i.h.addEventListener,
						n = t.eventTarget === "wrapper" ? i.wrapper : i.container;
					!i.browser.ie10 && !i.browser.ie11 ? (i.support.touch && (e(n, "touchstart", I), e(n, "touchmove", U), e(n, "touchend", z)), t.simulateTouch && (e(n, "mousedown", I), e(document, "mousemove", U), e(document, "mouseup", z))) : (e(n, i.touchEvents.touchStart, I), e(document, i.touchEvents.touchMove, U), e(document, i.touchEvents.touchEnd, z)), t.autoResize && e(window, "resize", i.resizeFix), N(), i._wheelEvent = !1;
					if (t.mousewheelControl) {
						document.onmousewheel !== undefined && (i._wheelEvent = "mousewheel");
						try {
							new WheelEvent("wheel"), i._wheelEvent = "wheel"
						} catch (s) {}
						i._wheelEvent || (i._wheelEvent = "DOMMouseScroll"), i._wheelEvent && e(i.container, i._wheelEvent, A)
					}
					t.keyboardControl && e(document, "keydown", k);
					if (t.updateOnImagesReady) {
						i.imagesToLoad = r("img", i.container);
						for (var u = 0; u < i.imagesToLoad.length; u++) o(i.imagesToLoad[u].getAttribute("src"))
					}
				}
				function N() {
					var e = i.h.addEventListener,
						n;
					if (t.preventLinks) {
						var s = r("a", i.container);
						for (n = 0; n < s.length; n++) e(s[n], "click", P)
					}
					if (t.releaseFormElements) {
						var o = r("input, textarea, select", i.container);
						for (n = 0; n < o.length; n++) e(o[n], i.touchEvents.touchStart, H, !0)
					}
					if (t.onSlideClick) for (n = 0; n < i.slides.length; n++) e(i.slides[n], "click", M);
					if (t.onSlideTouch) for (n = 0; n < i.slides.length; n++) e(i.slides[n], i.touchEvents.touchStart, _)
				}
				function C() {
					var e = i.h.removeEventListener,
						n;
					if (t.onSlideClick) for (n = 0; n < i.slides.length; n++) e(i.slides[n], "click", M);
					if (t.onSlideTouch) for (n = 0; n < i.slides.length; n++) e(i.slides[n], i.touchEvents.touchStart, _);
					if (t.releaseFormElements) {
						var s = r("input, textarea, select", i.container);
						for (n = 0; n < s.length; n++) e(s[n], i.touchEvents.touchStart, H, !0)
					}
					if (t.preventLinks) {
						var o = r("a", i.container);
						for (n = 0; n < o.length; n++) e(o[n], "click", P)
					}
				}
				function k(e) {
					var t = e.keyCode || e.charCode;
					if (e.shiftKey || e.altKey || e.ctrlKey || e.metaKey) return;
					if (t === 37 || t === 39 || t === 38 || t === 40) {
						var n = !1,
							r = i.h.getOffset(i.container),
							s = i.h.windowScroll().left,
							o = i.h.windowScroll().top,
							u = i.h.windowWidth(),
							a = i.h.windowHeight(),
							f = [
								[r.left, r.top],
								[r.left + i.width, r.top],
								[r.left, r.top + i.height],
								[r.left + i.width, r.top + i.height]
							];
						for (var l = 0; l < f.length; l++) {
							var c = f[l];
							c[0] >= s && c[0] <= s + u && c[1] >= o && c[1] <= o + a && (n = !0)
						}
						if (!n) return
					}
					if (d) {
						if (t === 37 || t === 39) e.preventDefault ? e.preventDefault() : e.returnValue = !1;
						t === 39 && i.swipeNext(), t === 37 && i.swipePrev()
					} else {
						if (t === 38 || t === 40) e.preventDefault ? e.preventDefault() : e.returnValue = !1;
						t === 40 && i.swipeNext(), t === 38 && i.swipePrev()
					}
				}
				function A(e) {
					var n = i._wheelEvent,
						r = 0;
					if (e.detail) r = -e.detail;
					else if (n === "mousewheel") if (t.mousewheelControlForceToAxis) if (d) {
						if (!(Math.abs(e.wheelDeltaX) > Math.abs(e.wheelDeltaY))) return;
						r = e.wheelDeltaX
					} else {
						if (!(Math.abs(e.wheelDeltaY) > Math.abs(e.wheelDeltaX))) return;
						r = e.wheelDeltaY
					} else r = e.wheelDelta;
					else if (n === "DOMMouseScroll") r = -e.detail;
					else if (n === "wheel") if (t.mousewheelControlForceToAxis) if (d) {
						if (!(Math.abs(e.deltaX) > Math.abs(e.deltaY))) return;
						r = -e.deltaX
					} else {
						if (!(Math.abs(e.deltaY) > Math.abs(e.deltaX))) return;
						r = -e.deltaY
					} else r = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? -e.deltaX : -e.deltaY;
					if (!t.freeMode)(new Date).getTime() - L > 60 && (r < 0 ? i.swipeNext() : i.swipePrev()), L = (new Date).getTime();
					else {
						var s = i.getWrapperTranslate() + r;
						s > 0 && (s = 0), s < -x() && (s = -x()), i.setWrapperTransition(0), i.setWrapperTranslate(s), i.updateActiveSlide(s);
						if (s === 0 || s === -x()) return
					}
					return t.autoplay && i.stopAutoplay(!0), e.preventDefault ? e.preventDefault() : e.returnValue = !1, !1
				}
				function M(e) {
					i.allowSlideClick && (D(e), i.fireCallback(t.onSlideClick, i, e))
				}
				function _(e) {
					D(e), i.fireCallback(t.onSlideTouch, i, e)
				}
				function D(e) {
					if (!e.currentTarget) {
						var n = e.srcElement;
						do {
							if (n.className.indexOf(t.slideClass) > -1) break;
							n = n.parentNode
						} while (n);
						i.clickedSlide = n
					} else i.clickedSlide = e.currentTarget;
					i.clickedSlideIndex = i.slides.indexOf(i.clickedSlide), i.clickedSlideLoopIndex = i.clickedSlideIndex - (i.loopedSlides || 0)
				}
				function P(e) {
					if (!i.allowLinks) return e.preventDefault ? e.preventDefault() : e.returnValue = !1, t.preventLinksPropagation && "stopPropagation" in e && e.stopPropagation(), !1
				}
				function H(e) {
					return e.stopPropagation ? e.stopPropagation() : e.returnValue = !1, !1
				}
				function I(e) {
					t.preventLinks && (i.allowLinks = !0);
					if (i.isTouched || t.onlyExternal) return !1;
					if (t.noSwiping && (e.target || e.srcElement) && W(e.target || e.srcElement)) return !1;
					F = !1, i.isTouched = !0, B = e.type === "touchstart";
					if (!B || e.targetTouches.length === 1) {
						i.callPlugins("onTouchStartBegin"), !B && !i.isAndroid && (e.preventDefault ? e.preventDefault() : e.returnValue = !1);
						var n = B ? e.targetTouches[0].pageX : e.pageX || e.clientX,
							r = B ? e.targetTouches[0].pageY : e.pageY || e.clientY;
						i.touches.startX = i.touches.currentX = n, i.touches.startY = i.touches.currentY = r, i.touches.start = i.touches.current = d ? n : r, i.setWrapperTransition(0), i.positions.start = i.positions.current = i.getWrapperTranslate(), i.setWrapperTranslate(i.positions.start), i.times.start = (new Date).getTime(), f = undefined, t.moveStartThreshold > 0 && (j = !1), t.onTouchStart && i.fireCallback(t.onTouchStart, i), i.callPlugins("onTouchStartEnd")
					}
				}
				function U(e) {
					if (!i.isTouched || t.onlyExternal) return;
					if (B && e.type === "mousemove") return;
					var n = B ? e.targetTouches[0].pageX : e.pageX || e.clientX,
						r = B ? e.targetTouches[0].pageY : e.pageY || e.clientY;
					typeof f == "undefined" && d && (f = !! (f || Math.abs(r - i.touches.startY) > Math.abs(n - i.touches.startX))), typeof f == "undefined" && !d && (f = !! (f || Math.abs(r - i.touches.startY) < Math.abs(n - i.touches.startX)));
					if (f) {
						i.isTouched = !1;
						return
					}
					if (e.assignedToSwiper) {
						i.isTouched = !1;
						return
					}
					e.assignedToSwiper = !0, t.preventLinks && (i.allowLinks = !1), t.onSlideClick && (i.allowSlideClick = !1), t.autoplay && i.stopAutoplay(!0);
					if (!B || e.touches.length === 1) {
						i.isMoved || (i.callPlugins("onTouchMoveStart"), t.loop && (i.fixLoop(), i.positions.start = i.getWrapperTranslate()), t.onTouchMoveStart && i.fireCallback(t.onTouchMoveStart, i)), i.isMoved = !0, e.preventDefault ? e.preventDefault() : e.returnValue = !1, i.touches.current = d ? n : r, i.positions.current = (i.touches.current - i.touches.start) * t.touchRatio + i.positions.start, i.positions.current > 0 && t.onResistanceBefore && i.fireCallback(t.onResistanceBefore, i, i.positions.current), i.positions.current < -x() && t.onResistanceAfter && i.fireCallback(t.onResistanceAfter, i, Math.abs(i.positions.current + x()));
						if (t.resistance && t.resistance !== "100%") {
							var s;
							i.positions.current > 0 && (s = 1 - i.positions.current / l / 2, s < .5 ? i.positions.current = l / 2 : i.positions.current = i.positions.current * s);
							if (i.positions.current < -x()) {
								var o = (i.touches.current - i.touches.start) * t.touchRatio + (x() + i.positions.start);
								s = (l + o) / l;
								var u = i.positions.current - o * (1 - s) / 2,
									a = -x() - l / 2;
								u < a || s <= 0 ? i.positions.current = a : i.positions.current = u
							}
						}
						t.resistance && t.resistance === "100%" && (i.positions.current > 0 && (!t.freeMode || !! t.freeModeFluid) && (i.positions.current = 0), i.positions.current < -x() && (!t.freeMode || !! t.freeModeFluid) && (i.positions.current = -x()));
						if (!t.followFinger) return;
						if (!t.moveStartThreshold) i.setWrapperTranslate(i.positions.current);
						else if (Math.abs(i.touches.current - i.touches.start) > t.moveStartThreshold || j) {
							if (!j) {
								j = !0, i.touches.start = i.touches.current;
								return
							}
							i.setWrapperTranslate(i.positions.current)
						} else i.positions.current = i.positions.start;
						return (t.freeMode || t.watchActiveIndex) && i.updateActiveSlide(i.positions.current), t.grabCursor && (i.container.style.cursor = "move", i.container.style.cursor = "grabbing", i.container.style.cursor = "-moz-grabbin", i.container.style.cursor = "-webkit-grabbing"), q || (q = i.touches.current), R || (R = (new Date).getTime()), i.velocity = (i.touches.current - q) / ((new Date).getTime() - R) / 2, Math.abs(i.touches.current - q) < 2 && (i.velocity = 0), q = i.touches.current, R = (new Date).getTime(), i.callPlugins("onTouchMoveEnd"), t.onTouchMove && i.fireCallback(t.onTouchMove, i), !1
					}
				}
				function z(e) {
					f && i.swipeReset();
					if (t.onlyExternal || !i.isTouched) return;
					i.isTouched = !1, t.grabCursor && (i.container.style.cursor = "move", i.container.style.cursor = "grab", i.container.style.cursor = "-moz-grab", i.container.style.cursor = "-webkit-grab"), !i.positions.current && i.positions.current !== 0 && (i.positions.current = i.positions.start), t.followFinger && i.setWrapperTranslate(i.positions.current), i.times.end = (new Date).getTime(), i.touches.diff = i.touches.current - i.touches.start, i.touches.abs = Math.abs(i.touches.diff), i.positions.diff = i.positions.current - i.positions.start, i.positions.abs = Math.abs(i.positions.diff);
					var n = i.positions.diff,
						r = i.positions.abs,
						s = i.times.end - i.times.start;
					r < 5 && s < 300 && i.allowLinks === !1 && (!t.freeMode && r !== 0 && i.swipeReset(), t.preventLinks && (i.allowLinks = !0), t.onSlideClick && (i.allowSlideClick = !0)), setTimeout(function() {
						t.preventLinks && (i.allowLinks = !0), t.onSlideClick && (i.allowSlideClick = !0)
					}, 100);
					var u = x();
					if (!i.isMoved && t.freeMode) {
						i.isMoved = !1, t.onTouchEnd && i.fireCallback(t.onTouchEnd, i), i.callPlugins("onTouchEnd");
						return
					}
					if (!i.isMoved || i.positions.current > 0 || i.positions.current < -u) {
						i.swipeReset(), t.onTouchEnd && i.fireCallback(t.onTouchEnd, i), i.callPlugins("onTouchEnd");
						return
					}
					i.isMoved = !1;
					if (t.freeMode) {
						if (t.freeModeFluid) {
							var c = 1e3 * t.momentumRatio,
								h = i.velocity * c,
								p = i.positions.current + h,
								v = !1,
								m, g = Math.abs(i.velocity) * 20 * t.momentumBounceRatio;
							p < -u && (t.momentumBounce && i.support.transitions ? (p + u < -g && (p = -u - g), m = -u, v = !0, F = !0) : p = -u), p > 0 && (t.momentumBounce && i.support.transitions ? (p > g && (p = g), m = 0, v = !0, F = !0) : p = 0), i.velocity !== 0 && (c = Math.abs((p - i.positions.current) / i.velocity)), i.setWrapperTranslate(p), i.setWrapperTransition(c), t.momentumBounce && v && i.wrapperTransitionEnd(function() {
								if (!F) return;
								t.onMomentumBounce && i.fireCallback(t.onMomentumBounce, i), i.callPlugins("onMomentumBounce"), i.setWrapperTranslate(m), i.setWrapperTransition(300)
							}), i.updateActiveSlide(p)
						}(!t.freeModeFluid || s >= 300) && i.updateActiveSlide(i.positions.current), t.onTouchEnd && i.fireCallback(t.onTouchEnd, i), i.callPlugins("onTouchEnd");
						return
					}
					a = n < 0 ? "toNext" : "toPrev", a === "toNext" && s <= 300 && (r < 30 || !t.shortSwipes ? i.swipeReset() : i.swipeNext(!0)), a === "toPrev" && s <= 300 && (r < 30 || !t.shortSwipes ? i.swipeReset() : i.swipePrev(!0));
					var y = 0;
					if (t.slidesPerView === "auto") {
						var b = Math.abs(i.getWrapperTranslate()),
							w = 0,
							E;
						for (var S = 0; S < i.slides.length; S++) {
							E = d ? i.slides[S].getWidth(!0) : i.slides[S].getHeight(!0), w += E;
							if (w > b) {
								y = E;
								break
							}
						}
						y > l && (y = l)
					} else y = o * t.slidesPerView;
					a === "toNext" && s > 300 && (r >= y * t.longSwipesRatio ? i.swipeNext(!0) : i.swipeReset()), a === "toPrev" && s > 300 && (r >= y * t.longSwipesRatio ? i.swipePrev(!0) : i.swipeReset()), t.onTouchEnd && i.fireCallback(t.onTouchEnd, i), i.callPlugins("onTouchEnd")
				}
				function W(e) {
					var n = !1;
					do e.className.indexOf(t.noSwipingClass) > -1 && (n = !0), e = e.parentElement;
					while (!n && e.parentElement && e.className.indexOf(t.wrapperClass) === -1);
					return !n && e.className.indexOf(t.wrapperClass) > -1 && e.className.indexOf(t.noSwipingClass) > -1 && (n = !0), n
				}
				function X(e, t) {
					var n = document.createElement("div"),
						r;
					return n.innerHTML = t, r = n.firstChild, r.className += " " + e, r.outerHTML
				}
				function V(e, n, r) {
					function u() {
						var n = +(new Date),
							r = n - o;
						a += f * r / (1e3 / 60), c = l === "toNext" ? a > e : a < e, c ? (i.setWrapperTranslate(Math.round(a)), i._DOMAnimating = !0, window.setTimeout(function() {
							u()
						}, 1e3 / 60)) : (t.onSlideChangeEnd && i.fireCallback(t.onSlideChangeEnd, i), i.setWrapperTranslate(e), i._DOMAnimating = !1)
					}
					var s = n === "to" && r.speed >= 0 ? r.speed : t.speed,
						o = +(new Date);
					if (i.support.transitions || !t.DOMAnimation) i.setWrapperTranslate(e), i.setWrapperTransition(s);
					else {
						var a = i.getWrapperTranslate(),
							f = Math.ceil((e - a) / s * (1e3 / 60)),
							l = a > e ? "toNext" : "toPrev",
							c = l === "toNext" ? a > e : a < e;
						if (i._DOMAnimating) return;
						u()
					}
					i.updateActiveSlide(e), t.onSlideNext && n === "next" && i.fireCallback(t.onSlideNext, i, e), t.onSlidePrev && n === "prev" && i.fireCallback(t.onSlidePrev, i, e), t.onSlideReset && n === "reset" && i.fireCallback(t.onSlideReset, i, e), (n === "next" || n === "prev" || n === "to" && r.runCallbacks === !0) && $(n)
				}
				function $(e) {
					i.callPlugins("onSlideChangeStart");
					if (t.onSlideChangeStart) if (t.queueStartCallbacks && i.support.transitions) {
						if (i._queueStartCallbacks) return;
						i._queueStartCallbacks = !0, i.fireCallback(t.onSlideChangeStart, i, e), i.wrapperTransitionEnd(function() {
							i._queueStartCallbacks = !1
						})
					} else i.fireCallback(t.onSlideChangeStart, i, e);
					if (t.onSlideChangeEnd) if (i.support.transitions) if (t.queueEndCallbacks) {
						if (i._queueEndCallbacks) return;
						i._queueEndCallbacks = !0, i.wrapperTransitionEnd(function(n) {
							i.fireCallback(t.onSlideChangeEnd, n, e)
						})
					} else i.wrapperTransitionEnd(function(n) {
						i.fireCallback(t.onSlideChangeEnd, n, e)
					});
					else t.DOMAnimation || setTimeout(function() {
						i.fireCallback(t.onSlideChangeEnd, i, e)
					}, 10)
				}
				function J() {
					var e = i.paginationButtons;
					if (e) for (var t = 0; t < e.length; t++) i.h.removeEventListener(e[t], "click", Q)
				}
				function K() {
					var e = i.paginationButtons;
					if (e) for (var t = 0; t < e.length; t++) i.h.addEventListener(e[t], "click", Q)
				}
				function Q(e) {
					var t, n = e.target || e.srcElement,
						r = i.paginationButtons;
					for (var s = 0; s < r.length; s++) n === r[s] && (t = s);
					i.swipeTo(t)
				}
				function Z() {
					G = setTimeout(function() {
						t.loop ? (i.fixLoop(), i.swipeNext(!0)) : i.swipeNext(!0) || (t.autoplayStopOnLast ? (clearTimeout(G), G = undefined) : i.swipeTo(0)), i.wrapperTransitionEnd(function() {
							typeof G != "undefined" && Z()
						})
					}, t.autoplay)
				}
				function et() {
					i.calcSlides(), t.loader.slides.length > 0 && i.slides.length === 0 && i.loadSlides(), t.loop && i.createLoop(), i.init(), T(), t.pagination && i.createPagination(!0), t.loop || t.initialSlide > 0 ? i.swipeTo(t.initialSlide, 0, !1) : i.updateActiveSlide(0), t.autoplay && i.startAutoplay(), i.centerIndex = i.activeIndex, t.onSwiperCreated && i.fireCallback(t.onSwiperCreated, i), i.callPlugins("onSwiperCreated")
				}
				if (document.body.__defineGetter__ && HTMLElement) {
					var n = HTMLElement.prototype;
					n.__defineGetter__ && n.__defineGetter__("outerHTML", function() {
						return (new XMLSerializer).serializeToString(this)
					})
				}
				window.getComputedStyle || (window.getComputedStyle = function(e, t) {
					return this.el = e, this.getPropertyValue = function(t) {
						var n = /(\-([a-z]){1})/g;
						return t === "float" && (t = "styleFloat"), n.test(t) && (t = t.replace(n, function() {
							return arguments[2].toUpperCase()
						})), e.currentStyle[t] ? e.currentStyle[t] : null
					}, this
				}), Array.prototype.indexOf || (Array.prototype.indexOf = function(e, t) {
					for (var n = t || 0, r = this.length; n < r; n++) if (this[n] === e) return n;
					return -1
				});
				if (!document.querySelectorAll && !window.jQuery) return;
				if (typeof e == "undefined") return;
				if (!e.nodeType && r(e).length === 0) return;
				var i = this;
				i.touches = {
					start: 0,
					startX: 0,
					startY: 0,
					current: 0,
					currentX: 0,
					currentY: 0,
					diff: 0,
					abs: 0
				}, i.positions = {
					start: 0,
					abs: 0,
					diff: 0,
					current: 0
				}, i.times = {
					start: 0,
					end: 0
				}, i.id = (new Date).getTime(), i.container = e.nodeType ? e : r(e)[0], i.isTouched = !1, i.isMoved = !1, i.activeIndex = 0, i.centerIndex = 0, i.activeLoaderIndex = 0, i.activeLoopIndex = 0, i.previousIndex = null, i.velocity = 0, i.snapGrid = [], i.slidesGrid = [], i.imagesToLoad = [], i.imagesLoaded = 0, i.wrapperLeft = 0, i.wrapperRight = 0, i.wrapperTop = 0, i.wrapperBottom = 0, i.isAndroid = navigator.userAgent.toLowerCase().indexOf("android") >= 0;
				var s, o, u, a, f, l, c = {
					eventTarget: "wrapper",
					mode: "horizontal",
					touchRatio: 1,
					speed: 300,
					freeMode: !1,
					freeModeFluid: !1,
					momentumRatio: 1,
					momentumBounce: !0,
					momentumBounceRatio: 1,
					slidesPerView: 1,
					slidesPerGroup: 1,
					slidesPerViewFit: !0,
					simulateTouch: !0,
					followFinger: !0,
					shortSwipes: !0,
					longSwipesRatio: .5,
					moveStartThreshold: !1,
					onlyExternal: !1,
					createPagination: !0,
					pagination: !1,
					paginationElement: "span",
					paginationClickable: !1,
					paginationAsRange: !0,
					resistance: !0,
					scrollContainer: !1,
					preventLinks: !0,
					preventLinksPropagation: !1,
					noSwiping: !1,
					noSwipingClass: "swiper-no-swiping",
					initialSlide: 0,
					keyboardControl: !1,
					mousewheelControl: !1,
					mousewheelControlForceToAxis: !1,
					useCSS3Transforms: !0,
					autoplay: !1,
					autoplayDisableOnInteraction: !0,
					autoplayStopOnLast: !1,
					loop: !1,
					loopAdditionalSlides: 0,
					calculateHeight: !1,
					cssWidthAndHeight: !1,
					updateOnImagesReady: !0,
					releaseFormElements: !0,
					watchActiveIndex: !1,
					visibilityFullFit: !1,
					offsetPxBefore: 0,
					offsetPxAfter: 0,
					offsetSlidesBefore: 0,
					offsetSlidesAfter: 0,
					centeredSlides: !1,
					queueStartCallbacks: !1,
					queueEndCallbacks: !1,
					autoResize: !0,
					resizeReInit: !1,
					DOMAnimation: !0,
					loader: {
						slides: [],
						slidesHTMLType: "inner",
						surroundGroups: 1,
						logic: "reload",
						loadAllSlides: !1
					},
					slideElement: "div",
					slideClass: "swiper-slide",
					slideActiveClass: "swiper-slide-active",
					slideVisibleClass: "swiper-slide-visible",
					slideDuplicateClass: "swiper-slide-duplicate",
					wrapperClass: "swiper-wrapper",
					paginationElementClass: "swiper-pagination-switch",
					paginationActiveClass: "swiper-active-switch",
					paginationVisibleClass: "swiper-visible-switch"
				};
				t = t || {};
				for (var h in c) if (h in t && typeof t[h] == "object") for (var p in c[h]) p in t[h] || (t[h][p] = c[h][p]);
				else h in t || (t[h] = c[h]);
				i.params = t, t.scrollContainer && (t.freeMode = !0, t.freeModeFluid = !0), t.loop && (t.resistance = "100%");
				var d = t.mode === "horizontal",
					v = ["mousedown", "mousemove", "mouseup"];
				i.browser.ie10 && (v = ["MSPointerDown", "MSPointerMove", "MSPointerUp"]), i.browser.ie11 && (v = ["pointerdown", "pointermove", "pointerup"]), i.touchEvents = {
					touchStart: i.support.touch || !t.simulateTouch ? "touchstart" : v[0],
					touchMove: i.support.touch || !t.simulateTouch ? "touchmove" : v[1],
					touchEnd: i.support.touch || !t.simulateTouch ? "touchend" : v[2]
				};
				for (var m = i.container.childNodes.length - 1; m >= 0; m--) if (i.container.childNodes[m].className) {
					var g = i.container.childNodes[m].className.split(/\s+/);
					for (var y = 0; y < g.length; y++) g[y] === t.wrapperClass && (s = i.container.childNodes[m])
				}
				i.wrapper = s, i._extendSwiperSlide = function(e) {
					return e.append = function() {
						return t.loop ? e.insertAfter(i.slides.length - i.loopedSlides) : (i.wrapper.appendChild(e), i.reInit()), e
					}, e.prepend = function() {
						return t.loop ? (i.wrapper.insertBefore(e, i.slides[i.loopedSlides]), i.removeLoopedSlides(), i.calcSlides(), i.createLoop()) : i.wrapper.insertBefore(e, i.wrapper.firstChild), i.reInit(), e
					}, e.insertAfter = function(n) {
						if (typeof n == "undefined") return !1;
						var r;
						return t.loop ? (r = i.slides[n + 1 + i.loopedSlides], r ? i.wrapper.insertBefore(e, r) : i.wrapper.appendChild(e), i.removeLoopedSlides(), i.calcSlides(), i.createLoop()) : (r = i.slides[n + 1], i.wrapper.insertBefore(e, r)), i.reInit(), e
					}, e.clone = function() {
						return i._extendSwiperSlide(e.cloneNode(!0))
					}, e.remove = function() {
						i.wrapper.removeChild(e), i.reInit()
					}, e.html = function(t) {
						return typeof t == "undefined" ? e.innerHTML : (e.innerHTML = t, e)
					}, e.index = function() {
						var t;
						for (var n = i.slides.length - 1; n >= 0; n--) e === i.slides[n] && (t = n);
						return t
					}, e.isActive = function() {
						return e.index() === i.activeIndex ? !0 : !1
					}, e.swiperSlideDataStorage || (e.swiperSlideDataStorage = {}), e.getData = function(t) {
						return e.swiperSlideDataStorage[t]
					}, e.setData = function(t, n) {
						return e.swiperSlideDataStorage[t] = n, e
					}, e.data = function(t, n) {
						return typeof n == "undefined" ? e.getAttribute("data-" + t) : (e.setAttribute("data-" + t, n), e)
					}, e.getWidth = function(t) {
						return i.h.getWidth(e, t)
					}, e.getHeight = function(t) {
						return i.h.getHeight(e, t)
					}, e.getOffset = function() {
						return i.h.getOffset(e)
					}, e
				}, i.calcSlides = function(e) {
					var n = i.slides ? i.slides.length : !1;
					i.slides = [], i.displaySlides = [];
					for (var r = 0; r < i.wrapper.childNodes.length; r++) if (i.wrapper.childNodes[r].className) {
						var s = i.wrapper.childNodes[r].className,
							o = s.split(/\s+/);
						for (var u = 0; u < o.length; u++) o[u] === t.slideClass && i.slides.push(i.wrapper.childNodes[r])
					}
					for (r = i.slides.length - 1; r >= 0; r--) i._extendSwiperSlide(i.slides[r]);
					if (n === !1) return;
					if (n !== i.slides.length || e) C(), N(), i.updateActiveSlide(), i.params.pagination && i.createPagination(), i.callPlugins("numberOfSlidesChanged")
				}, i.createSlide = function(e, n, r) {
					n = n || i.params.slideClass, r = r || t.slideElement;
					var s = document.createElement(r);
					return s.innerHTML = e || "", s.className = n, i._extendSwiperSlide(s)
				}, i.appendSlide = function(e, t, n) {
					if (!e) return;
					return e.nodeType ? i._extendSwiperSlide(e).append() : i.createSlide(e, t, n).append()
				}, i.prependSlide = function(e, t, n) {
					if (!e) return;
					return e.nodeType ? i._extendSwiperSlide(e).prepend() : i.createSlide(e, t, n).prepend()
				}, i.insertSlideAfter = function(e, t, n, r) {
					return typeof e == "undefined" ? !1 : t.nodeType ? i._extendSwiperSlide(t).insertAfter(e) : i.createSlide(t, n, r).insertAfter(e)
				}, i.removeSlide = function(e) {
					if (i.slides[e]) {
						if (t.loop) {
							if (!i.slides[e + i.loopedSlides]) return !1;
							i.slides[e + i.loopedSlides].remove(), i.removeLoopedSlides(), i.calcSlides(), i.createLoop()
						} else i.slides[e].remove();
						return !0
					}
					return !1
				}, i.removeLastSlide = function() {
					return i.slides.length > 0 ? (t.loop ? (i.slides[i.slides.length - 1 - i.loopedSlides].remove(), i.removeLoopedSlides(), i.calcSlides(), i.createLoop()) : i.slides[i.slides.length - 1].remove(), !0) : !1
				}, i.removeAllSlides = function() {
					for (var e = i.slides.length - 1; e >= 0; e--) i.slides[e].remove()
				}, i.getSlide = function(e) {
					return i.slides[e]
				}, i.getLastSlide = function() {
					return i.slides[i.slides.length - 1]
				}, i.getFirstSlide = function() {
					return i.slides[0]
				}, i.activeSlide = function() {
					return i.slides[i.activeIndex]
				}, i.fireCallback = function() {
					var e = arguments[0];
					if (Object.prototype.toString.call(e) === "[object Array]") for (var n = 0; n < e.length; n++) typeof e[n] == "function" && e[n](arguments[1], arguments[2], arguments[3], arguments[4], arguments[5]);
					else Object.prototype.toString.call(e) === "[object String]" ? t["on" + e] && i.fireCallback(t["on" + e]) : e(arguments[1], arguments[2], arguments[3], arguments[4], arguments[5])
				}, i.addCallback = function(e, t) {
					var n = this,
						r;
					if (!n.params["on" + e]) return this.params["on" + e] = [], this.params["on" + e].push(t);
					if (b(this.params["on" + e])) return this.params["on" + e].push(t);
					if (typeof this.params["on" + e] == "function") return r = this.params["on" + e], this.params["on" + e] = [], this.params["on" + e].push(r), this.params["on" + e].push(t)
				}, i.removeCallbacks = function(e) {
					i.params["on" + e] && (i.params["on" + e] = null)
				};
				var w = [];
				for (var E in i.plugins) if (t[E]) {
					var S = i.plugins[E](i, t[E]);
					S && w.push(S)
				}
				i.callPlugins = function(e, t) {
					t || (t = {});
					for (var n = 0; n < w.length; n++) e in w[n] && w[n][e](t)
				}, (i.browser.ie10 || i.browser.ie11) && !t.onlyExternal && i.wrapper.classList.add("swiper-wp8-" + (d ? "horizontal" : "vertical")), t.freeMode && (i.container.className += " swiper-free-mode"), i.initialized = !1, i.init = function(e, n) {
					var r = Math.round(i.h.getWidth(i.container)),
						s = Math.round(i.h.getHeight(i.container));
					if (r === i.width && s === i.height && !e) return;
					if (r === 0 || s === 0) return;
					i.width = r, i.height = s;
					var a, f, c, h, p, v, m;
					l = d ? r : s;
					var g = i.wrapper;
					e && i.calcSlides(n);
					if (t.slidesPerView === "auto") {
						var y = 0,
							b = 0;
						t.slidesOffset > 0 && (g.style.paddingLeft = "", g.style.paddingRight = "", g.style.paddingTop = "", g.style.paddingBottom = ""), g.style.width = "", g.style.height = "", t.offsetPxBefore > 0 && (d ? i.wrapperLeft = t.offsetPxBefore : i.wrapperTop = t.offsetPxBefore), t.offsetPxAfter > 0 && (d ? i.wrapperRight = t.offsetPxAfter : i.wrapperBottom = t.offsetPxAfter), t.centeredSlides && (d ? (i.wrapperLeft = (l - this.slides[0].getWidth(!0)) / 2, i.wrapperRight = (l - i.slides[i.slides.length - 1].getWidth(!0)) / 2) : (i.wrapperTop = (l - i.slides[0].getHeight(!0)) / 2, i.wrapperBottom = (l - i.slides[i.slides.length - 1].getHeight(!0)) / 2)), d ? (i.wrapperLeft >= 0 && (g.style.paddingLeft = i.wrapperLeft + "px"), i.wrapperRight >= 0 && (g.style.paddingRight = i.wrapperRight + "px")) : (i.wrapperTop >= 0 && (g.style.paddingTop = i.wrapperTop + "px"), i.wrapperBottom >= 0 && (g.style.paddingBottom = i.wrapperBottom + "px")), v = 0;
						var w = 0;
						i.snapGrid = [], i.slidesGrid = [], c = 0;
						for (m = 0; m < i.slides.length; m++) {
							a = i.slides[m].getWidth(!0), f = i.slides[m].getHeight(!0), t.calculateHeight && (c = Math.max(c, f));
							var E = d ? a : f;
							if (t.centeredSlides) {
								var S = m === i.slides.length - 1 ? 0 : i.slides[m + 1].getWidth(!0),
									x = m === i.slides.length - 1 ? 0 : i.slides[m + 1].getHeight(!0),
									T = d ? S : x;
								if (E > l) {
									if (t.slidesPerViewFit) i.snapGrid.push(v + i.wrapperLeft), i.snapGrid.push(v + E - l + i.wrapperLeft);
									else for (var N = 0; N <= Math.floor(E / (l + i.wrapperLeft)); N++) N === 0 ? i.snapGrid.push(v + i.wrapperLeft) : i.snapGrid.push(v + i.wrapperLeft + l * N);
									i.slidesGrid.push(v + i.wrapperLeft)
								} else i.snapGrid.push(w), i.slidesGrid.push(w);
								w += E / 2 + T / 2
							} else {
								if (E > l) if (t.slidesPerViewFit) i.snapGrid.push(v), i.snapGrid.push(v + E - l);
								else for (var C = 0; C <= Math.floor(E / l); C++) i.snapGrid.push(v + l * C);
								else i.snapGrid.push(v);
								i.slidesGrid.push(v)
							}
							v += E, y += a, b += f
						}
						t.calculateHeight && (i.height = c), d ? (u = y + i.wrapperRight + i.wrapperLeft, g.style.width = y + "px", g.style.height = i.height + "px") : (u = b + i.wrapperTop + i.wrapperBottom, g.style.width = i.width + "px", g.style.height = b + "px")
					} else if (t.scrollContainer) g.style.width = "", g.style.height = "", h = i.slides[0].getWidth(!0), p = i.slides[0].getHeight(!0), u = d ? h : p, g.style.width = h + "px", g.style.height = p + "px", o = d ? h : p;
					else {
						if (t.calculateHeight) {
							c = 0, p = 0, d || (i.container.style.height = ""), g.style.height = "";
							for (m = 0; m < i.slides.length; m++) i.slides[m].style.height = "", c = Math.max(i.slides[m].getHeight(!0), c), d || (p += i.slides[m].getHeight(!0));
							f = c, i.height = f, d ? p = f : (l = f, i.container.style.height = l + "px")
						} else f = d ? i.height : i.height / t.slidesPerView, p = d ? i.height : i.slides.length * f;
						a = d ? i.width / t.slidesPerView : i.width, h = d ? i.slides.length * a : i.width, o = d ? a : f, t.offsetSlidesBefore > 0 && (d ? i.wrapperLeft = o * t.offsetSlidesBefore : i.wrapperTop = o * t.offsetSlidesBefore), t.offsetSlidesAfter > 0 && (d ? i.wrapperRight = o * t.offsetSlidesAfter : i.wrapperBottom = o * t.offsetSlidesAfter), t.offsetPxBefore > 0 && (d ? i.wrapperLeft = t.offsetPxBefore : i.wrapperTop = t.offsetPxBefore), t.offsetPxAfter > 0 && (d ? i.wrapperRight = t.offsetPxAfter : i.wrapperBottom = t.offsetPxAfter), t.centeredSlides && (d ? (i.wrapperLeft = (l - o) / 2, i.wrapperRight = (l - o) / 2) : (i.wrapperTop = (l - o) / 2, i.wrapperBottom = (l - o) / 2)), d ? (i.wrapperLeft > 0 && (g.style.paddingLeft = i.wrapperLeft + "px"), i.wrapperRight > 0 && (g.style.paddingRight = i.wrapperRight + "px")) : (i.wrapperTop > 0 && (g.style.paddingTop = i.wrapperTop + "px"), i.wrapperBottom > 0 && (g.style.paddingBottom = i.wrapperBottom + "px")), u = d ? h + i.wrapperRight + i.wrapperLeft : p + i.wrapperTop + i.wrapperBottom, t.cssWidthAndHeight || (parseFloat(h) > 0 && (g.style.width = h + "px"), parseFloat(p) > 0 && (g.style.height = p + "px")), v = 0, i.snapGrid = [], i.slidesGrid = [];
						for (m = 0; m < i.slides.length; m++) i.snapGrid.push(v), i.slidesGrid.push(v), v += o, t.cssWidthAndHeight || (parseFloat(a) > 0 && (i.slides[m].style.width = a + "px"), parseFloat(f) > 0 && (i.slides[m].style.height = f + "px"))
					}
					i.initialized ? (i.callPlugins("onInit"), t.onInit && i.fireCallback(t.onInit, i)) : (i.callPlugins("onFirstInit"), t.onFirstInit && i.fireCallback(t.onFirstInit, i)), i.initialized = !0
				}, i.reInit = function(e) {
					i.init(!0, e)
				}, i.resizeFix = function(e) {
					i.callPlugins("beforeResizeFix"), i.init(t.resizeReInit || e), t.freeMode ? i.getWrapperTranslate() < -x() && (i.setWrapperTransition(0), i.setWrapperTranslate(-x())) : (i.swipeTo(t.loop ? i.activeLoopIndex : i.activeIndex, 0, !1), t.autoplay && (i.support.transitions && typeof G != "undefined" ? typeof G != "undefined" && (clearTimeout(G), G = undefined, i.startAutoplay()) : typeof Y != "undefined" && (clearInterval(Y), Y = undefined, i.startAutoplay()))), i.callPlugins("afterResizeFix")
				}, i.destroy = function() {
					var e = i.h.removeEventListener,
						n = t.eventTarget === "wrapper" ? i.wrapper : i.container;
					!i.browser.ie10 && !i.browser.ie11 ? (i.support.touch && (e(n, "touchstart", I), e(n, "touchmove", U), e(n, "touchend", z)), t.simulateTouch && (e(n, "mousedown", I), e(document, "mousemove", U), e(document, "mouseup", z))) : (e(n, i.touchEvents.touchStart, I), e(document, i.touchEvents.touchMove, U), e(document, i.touchEvents.touchEnd, z)), t.autoResize && e(window, "resize", i.resizeFix), C(), t.paginationClickable && J(), t.mousewheelControl && i._wheelEvent && e(i.container, i._wheelEvent, A), t.keyboardControl && e(document, "keydown", k), t.autoplay && i.stopAutoplay(), i.callPlugins("onDestroy"), i = null
				}, i.disableKeyboardControl = function() {
					t.keyboardControl = !1, i.h.removeEventListener(document, "keydown", k)
				}, i.enableKeyboardControl = function() {
					t.keyboardControl = !0, i.h.addEventListener(document, "keydown", k)
				};
				var L = (new Date).getTime();
				if (t.grabCursor) {
					var O = i.container.style;
					O.cursor = "move", O.cursor = "grab", O.cursor = "-moz-grab", O.cursor = "-webkit-grab"
				}
				i.allowSlideClick = !0, i.allowLinks = !0;
				var B = !1,
					j, F = !0,
					q, R;
				i.swipeNext = function(e) {
					!e && t.loop && i.fixLoop(), !e && t.autoplay && i.stopAutoplay(!0), i.callPlugins("onSwipeNext");
					var n = i.getWrapperTranslate(),
						r = n;
					if (t.slidesPerView === "auto") {
						for (var s = 0; s < i.snapGrid.length; s++) if (-n >= i.snapGrid[s] && -n < i.snapGrid[s + 1]) {
							r = -i.snapGrid[s + 1];
							break
						}
					} else {
						var u = o * t.slidesPerGroup;
						r = -(Math.round(Math.abs(n) / Math.floor(u)) * u + u)
					}
					return r < -x() && (r = -x()), r === n ? !1 : (V(r, "next"), !0)
				}, i.swipePrev = function(e) {
					!e && t.loop && i.fixLoop(), !e && t.autoplay && i.stopAutoplay(!0), i.callPlugins("onSwipePrev");
					var n = Math.ceil(i.getWrapperTranslate()),
						r;
					if (t.slidesPerView === "auto") {
						r = 0;
						for (var s = 1; s < i.snapGrid.length; s++) {
							if (-n === i.snapGrid[s]) {
								r = -i.snapGrid[s - 1];
								break
							}
							if (-n > i.snapGrid[s] && -n < i.snapGrid[s + 1]) {
								r = -i.snapGrid[s];
								break
							}
						}
					} else {
						var u = o * t.slidesPerGroup;
						r = -(Math.ceil(-n / u) - 1) * u
					}
					return r > 0 && (r = 0), r === n ? !1 : (V(r, "prev"), !0)
				}, i.swipeReset = function() {
					i.callPlugins("onSwipeReset");
					var e = i.getWrapperTranslate(),
						n = o * t.slidesPerGroup,
						r, s = -x();
					if (t.slidesPerView === "auto") {
						r = 0;
						for (var u = 0; u < i.snapGrid.length; u++) {
							if (-e === i.snapGrid[u]) return;
							if (-e >= i.snapGrid[u] && -e < i.snapGrid[u + 1]) {
								i.positions.diff > 0 ? r = -i.snapGrid[u + 1] : r = -i.snapGrid[u];
								break
							}
						} - e >= i.snapGrid[i.snapGrid.length - 1] && (r = -i.snapGrid[i.snapGrid.length - 1]), e <= -x() && (r = -x())
					} else r = e < 0 ? Math.round(e / n) * n : 0;
					return t.scrollContainer && (r = e < 0 ? e : 0), r < -x() && (r = -x()), t.scrollContainer && l > o && (r = 0), r === e ? !1 : (V(r, "reset"), !0)
				}, i.swipeTo = function(e, n, r) {
					e = parseInt(e, 10), i.callPlugins("onSwipeTo", {
						index: e,
						speed: n
					}), t.loop && (e += i.loopedSlides);
					var s = i.getWrapperTranslate();
					if (e > i.slides.length - 1 || e < 0) return;
					var u;
					return t.slidesPerView === "auto" ? u = -i.slidesGrid[e] : u = -e * o, u < -x() && (u = -x()), u === s ? !1 : (r = r === !1 ? !1 : !0, V(u, "to", {
						index: e,
						speed: n,
						runCallbacks: r
					}), !0)
				}, i._queueStartCallbacks = !1, i._queueEndCallbacks = !1, i.updateActiveSlide = function(e) {
					if (!i.initialized) return;
					if (i.slides.length === 0) return;
					i.previousIndex = i.activeIndex, typeof e == "undefined" && (e = i.getWrapperTranslate()), e > 0 && (e = 0);
					if (t.slidesPerView === "auto") {
						var n = 0;
						i.activeIndex = i.slidesGrid.indexOf(-e);
						if (i.activeIndex < 0) {
							for (var r = 0; r < i.slidesGrid.length - 1; r++) if (-e > i.slidesGrid[r] && -e < i.slidesGrid[r + 1]) break;
							var s = Math.abs(i.slidesGrid[r] + e),
								u = Math.abs(i.slidesGrid[r + 1] + e);
							s <= u ? i.activeIndex = r : i.activeIndex = r + 1
						}
					} else i.activeIndex = Math[t.visibilityFullFit ? "ceil" : "round"](-e / o);
					i.activeIndex === i.slides.length && (i.activeIndex = i.slides.length - 1), i.activeIndex < 0 && (i.activeIndex = 0);
					if (!i.slides[i.activeIndex]) return;
					i.calcVisibleSlides(e);
					var a = new RegExp("\\s*" + t.slideActiveClass),
						f = new RegExp("\\s*" + t.slideVisibleClass);
					for (var l = 0; l < i.slides.length; l++) i.slides[l].className = i.slides[l].className.replace(a, "").replace(f, ""), i.visibleSlides.indexOf(i.slides[l]) >= 0 && (i.slides[l].className += " " + t.slideVisibleClass);
					i.slides[i.activeIndex].className += " " + t.slideActiveClass;
					if (t.loop) {
						var c = i.loopedSlides;
						i.activeLoopIndex = i.activeIndex - c, i.activeLoopIndex >= i.slides.length - c * 2 && (i.activeLoopIndex = i.slides.length - c * 2 - i.activeLoopIndex), i.activeLoopIndex < 0 && (i.activeLoopIndex = i.slides.length - c * 2 + i.activeLoopIndex), i.activeLoopIndex < 0 && (i.activeLoopIndex = 0)
					} else i.activeLoopIndex = i.activeIndex;
					t.pagination && i.updatePagination(e)
				}, i.createPagination = function(e) {
					t.paginationClickable && i.paginationButtons && J(), i.paginationContainer = t.pagination.nodeType ? t.pagination : r(t.pagination)[0];
					if (t.createPagination) {
						var n = "",
							s = i.slides.length,
							o = s;
						t.loop && (o -= i.loopedSlides * 2);
						for (var u = 0; u < o; u++) n += "<" + t.paginationElement + ' class="' + t.paginationElementClass + '"></' + t.paginationElement + ">";
						i.paginationContainer.innerHTML = n
					}
					i.paginationButtons = r("." + t.paginationElementClass, i.paginationContainer), e || i.updatePagination(), i.callPlugins("onCreatePagination"), t.paginationClickable && K()
				}, i.updatePagination = function(e) {
					if (!t.pagination) return;
					if (i.slides.length < 1) return;
					var n = r("." + t.paginationActiveClass, i.paginationContainer);
					if (!n) return;
					var s = i.paginationButtons;
					if (s.length === 0) return;
					for (var o = 0; o < s.length; o++) s[o].className = t.paginationElementClass;
					var u = t.loop ? i.loopedSlides : 0;
					if (t.paginationAsRange) {
						i.visibleSlides || i.calcVisibleSlides(e);
						var a = [],
							f;
						for (f = 0; f < i.visibleSlides.length; f++) {
							var l = i.slides.indexOf(i.visibleSlides[f]) - u;
							t.loop && l < 0 && (l = i.slides.length - i.loopedSlides * 2 + l), t.loop && l >= i.slides.length - i.loopedSlides * 2 && (l = i.slides.length - i.loopedSlides * 2 - l, l = Math.abs(l)), a.push(l)
						}
						for (f = 0; f < a.length; f++) s[a[f]] && (s[a[f]].className += " " + t.paginationVisibleClass);
						t.loop ? s[i.activeLoopIndex] !== undefined && (s[i.activeLoopIndex].className += " " + t.paginationActiveClass) : s[i.activeIndex].className += " " + t.paginationActiveClass
					} else t.loop ? s[i.activeLoopIndex] && (s[i.activeLoopIndex].className += " " + t.paginationActiveClass + " " + t.paginationVisibleClass) : s[i.activeIndex].className += " " + t.paginationActiveClass + " " + t.paginationVisibleClass
				}, i.calcVisibleSlides = function(e) {
					var n = [],
						r = 0,
						s = 0,
						u = 0;
					d && i.wrapperLeft > 0 && (e += i.wrapperLeft), !d && i.wrapperTop > 0 && (e += i.wrapperTop);
					for (var a = 0; a < i.slides.length; a++) {
						r += s, t.slidesPerView === "auto" ? s = d ? i.h.getWidth(i.slides[a], !0) : i.h.getHeight(i.slides[a], !0) : s = o, u = r + s;
						var f = !1;
						t.visibilityFullFit ? (r >= -e && u <= -e + l && (f = !0), r <= -e && u >= -e + l && (f = !0)) : (u > -e && u <= -e + l && (f = !0), r >= -e && r < -e + l && (f = !0), r < -e && u > -e + l && (f = !0)), f && n.push(i.slides[a])
					}
					n.length === 0 && (n = [i.slides[i.activeIndex]]), i.visibleSlides = n
				};
				var G, Y;
				i.startAutoplay = function() {
					if (i.support.transitions) {
						if (typeof G != "undefined") return !1;
						if (!t.autoplay) return;
						i.callPlugins("onAutoplayStart"), Z()
					} else {
						if (typeof Y != "undefined") return !1;
						if (!t.autoplay) return;
						i.callPlugins("onAutoplayStart"), Y = setInterval(function() {
							t.loop ? (i.fixLoop(), i.swipeNext(!0)) : i.swipeNext(!0) || (t.autoplayStopOnLast ? (clearInterval(Y), Y = undefined) : i.swipeTo(0))
						}, t.autoplay)
					}
				}, i.stopAutoplay = function(e) {
					if (i.support.transitions) {
						if (!G) return;
						G && clearTimeout(G), G = undefined, e && !t.autoplayDisableOnInteraction && i.wrapperTransitionEnd(function() {
							Z()
						}), i.callPlugins("onAutoplayStop")
					} else Y && clearInterval(Y), Y = undefined, i.callPlugins("onAutoplayStop")
				}, i.loopCreated = !1, i.removeLoopedSlides = function() {
					if (i.loopCreated) for (var e = 0; e < i.slides.length; e++) i.slides[e].getData("looped") === !0 && i.wrapper.removeChild(i.slides[e])
				}, i.createLoop = function() {
					if (i.slides.length === 0) return;
					t.slidesPerView === "auto" ? i.loopedSlides = t.loopedSlides || 1 : i.loopedSlides = t.slidesPerView + t.loopAdditionalSlides, i.loopedSlides > i.slides.length && (i.loopedSlides = i.slides.length);
					var e = "",
						n = "",
						r, o = "",
						u = i.slides.length,
						a = Math.floor(i.loopedSlides / u),
						f = i.loopedSlides % u;
					for (r = 0; r < a * u; r++) {
						var l = r;
						if (r >= u) {
							var c = Math.floor(r / u);
							l = r - u * c
						}
						o += i.slides[l].outerHTML
					}
					for (r = 0; r < f; r++) n += X(t.slideDuplicateClass, i.slides[r].outerHTML);
					for (r = u - f; r < u; r++) e += X(t.slideDuplicateClass, i.slides[r].outerHTML);
					var h = e + o + s.innerHTML + o + n;
					s.innerHTML = h, i.loopCreated = !0, i.calcSlides();
					for (r = 0; r < i.slides.length; r++)(r < i.loopedSlides || r >= i.slides.length - i.loopedSlides) && i.slides[r].setData("looped", !0);
					i.callPlugins("onCreateLoop")
				}, i.fixLoop = function() {
					var e;
					if (i.activeIndex < i.loopedSlides) e = i.slides.length - i.loopedSlides * 3 + i.activeIndex, i.swipeTo(e, 0, !1);
					else if (t.slidesPerView === "auto" && i.activeIndex >= i.loopedSlides * 2 || i.activeIndex > i.slides.length - t.slidesPerView * 2) e = -i.slides.length + i.activeIndex + i.loopedSlides, i.swipeTo(e, 0, !1)
				}, i.loadSlides = function() {
					var e = "";
					i.activeLoaderIndex = 0;
					var n = t.loader.slides,
						r = t.loader.loadAllSlides ? n.length : t.slidesPerView * (1 + t.loader.surroundGroups);
					for (var s = 0; s < r; s++) t.loader.slidesHTMLType === "outer" ? e += n[s] : e += "<" + t.slideElement + ' class="' + t.slideClass + '" data-swiperindex="' + s + '">' + n[s] + "</" + t.slideElement + ">";
					i.wrapper.innerHTML = e, i.calcSlides(!0), t.loader.loadAllSlides || i.wrapperTransitionEnd(i.reloadSlides, !0)
				}, i.reloadSlides = function() {
					var e = t.loader.slides,
						n = parseInt(i.activeSlide().data("swiperindex"), 10);
					if (n < 0 || n > e.length - 1) return;
					i.activeLoaderIndex = n;
					var r = Math.max(0, n - t.slidesPerView * t.loader.surroundGroups),
						s = Math.min(n + t.slidesPerView * (1 + t.loader.surroundGroups) - 1, e.length - 1);
					if (n > 0) {
						var u = -o * (n - r);
						i.setWrapperTranslate(u), i.setWrapperTransition(0)
					}
					var a;
					if (t.loader.logic === "reload") {
						i.wrapper.innerHTML = "";
						var f = "";
						for (a = r; a <= s; a++) f += t.loader.slidesHTMLType === "outer" ? e[a] : "<" + t.slideElement + ' class="' + t.slideClass + '" data-swiperindex="' + a + '">' + e[a] + "</" + t.slideElement + ">";
						i.wrapper.innerHTML = f
					} else {
						var l = 1e3,
							c = 0;
						for (a = 0; a < i.slides.length; a++) {
							var h = i.slides[a].data("swiperindex");
							h < r || h > s ? i.wrapper.removeChild(i.slides[a]) : (l = Math.min(h, l), c = Math.max(h, c))
						}
						for (a = r; a <= s; a++) {
							var p;
							a < l && (p = document.createElement(t.slideElement), p.className = t.slideClass, p.setAttribute("data-swiperindex", a), p.innerHTML = e[a], i.wrapper.insertBefore(p, i.wrapper.firstChild)), a > c && (p = document.createElement(t.slideElement), p.className = t.slideClass, p.setAttribute("data-swiperindex", a), p.innerHTML = e[a], i.wrapper.appendChild(p))
						}
					}
					i.reInit(!0)
				}, et()
			};
		return t.prototype = {
			plugins: {},
			wrapperTransitionEnd: function(e, t) {
				"use strict";

				function o() {
					e(n), n.params.queueEndCallbacks && (n._queueEndCallbacks = !1);
					if (!t) for (s = 0; s < i.length; s++) n.h.removeEventListener(r, i[s], o)
				}
				var n = this,
					r = n.wrapper,
					i = ["webkitTransitionEnd", "transitionend", "oTransitionEnd", "MSTransitionEnd", "msTransitionEnd"],
					s;
				if (e) for (s = 0; s < i.length; s++) n.h.addEventListener(r, i[s], o)
			},
			getWrapperTranslate: function(e) {
				"use strict";
				var t = this.wrapper,
					n, r, i, s;
				return typeof e == "undefined" && (e = this.params.mode === "horizontal" ? "x" : "y"), this.support.transforms && this.params.useCSS3Transforms ? (i = window.getComputedStyle(t, null), window.WebKitCSSMatrix ? s = new WebKitCSSMatrix(i.webkitTransform) : (s = i.MozTransform || i.OTransform || i.MsTransform || i.msTransform || i.transform || i.getPropertyValue("transform").replace("translate(", "matrix(1, 0, 0, 1,"), n = s.toString().split(",")), e === "x" && (window.WebKitCSSMatrix ? r = s.m41 : n.length === 16 ? r = parseFloat(n[12]) : r = parseFloat(n[4])), e === "y" && (window.WebKitCSSMatrix ? r = s.m42 : n.length === 16 ? r = parseFloat(n[13]) : r = parseFloat(n[5]))) : (e === "x" && (r = parseFloat(t.style.left, 10) || 0), e === "y" && (r = parseFloat(t.style.top, 10) || 0)), r || 0
			},
			setWrapperTranslate: function(e, t, n) {
				"use strict";
				var r = this.wrapper.style,
					i = {
						x: 0,
						y: 0,
						z: 0
					},
					s;
				arguments.length === 3 ? (i.x = e, i.y = t, i.z = n) : (typeof t == "undefined" && (t = this.params.mode === "horizontal" ? "x" : "y"), i[t] = e), this.support.transforms && this.params.useCSS3Transforms ? (s = this.support.transforms3d ? "translate3d(" + i.x + "px, " + i.y + "px, " + i.z + "px)" : "translate(" + i.x + "px, " + i.y + "px)", r.webkitTransform = r.MsTransform = r.msTransform = r.MozTransform = r.OTransform = r.transform = s) : (r.left = i.x + "px", r.top = i.y + "px"), this.callPlugins("onSetWrapperTransform", i), this.params.onSetWrapperTransform && this.fireCallback(this.params.onSetWrapperTransform, this, i)
			},
			setWrapperTransition: function(e) {
				"use strict";
				var t = this.wrapper.style;
				t.webkitTransitionDuration = t.MsTransitionDuration = t.msTransitionDuration = t.MozTransitionDuration = t.OTransitionDuration = t.transitionDuration = e / 1e3 + "s", this.callPlugins("onSetWrapperTransition", {
					duration: e
				}), this.params.onSetWrapperTransition && this.fireCallback(this.params.onSetWrapperTransition, this, e)
			},
			h: {
				getWidth: function(e, t) {
					"use strict";
					var n = window.getComputedStyle(e, null).getPropertyValue("width"),
						r = parseFloat(n);
					if (isNaN(r) || n.indexOf("%") > 0) r = e.offsetWidth - parseFloat(window.getComputedStyle(e, null).getPropertyValue("padding-left")) - parseFloat(window.getComputedStyle(e, null).getPropertyValue("padding-right"));
					return t && (r += parseFloat(window.getComputedStyle(e, null).getPropertyValue("padding-left")) + parseFloat(window.getComputedStyle(e, null).getPropertyValue("padding-right"))), r
				},
				getHeight: function(e, t) {
					"use strict";
					if (t) return e.offsetHeight;
					var n = window.getComputedStyle(e, null).getPropertyValue("height"),
						r = parseFloat(n);
					if (isNaN(r) || n.indexOf("%") > 0) r = e.offsetHeight - parseFloat(window.getComputedStyle(e, null).getPropertyValue("padding-top")) - parseFloat(window.getComputedStyle(e, null).getPropertyValue("padding-bottom"));
					return t && (r += parseFloat(window.getComputedStyle(e, null).getPropertyValue("padding-top")) + parseFloat(window.getComputedStyle(e, null).getPropertyValue("padding-bottom"))), r
				},
				getOffset: function(e) {
					"use strict";
					var t = e.getBoundingClientRect(),
						n = document.body,
						r = e.clientTop || n.clientTop || 0,
						i = e.clientLeft || n.clientLeft || 0,
						s = window.pageYOffset || e.scrollTop,
						o = window.pageXOffset || e.scrollLeft;
					return document.documentElement && !window.pageYOffset && (s = document.documentElement.scrollTop, o = document.documentElement.scrollLeft), {
						top: t.top + s - r,
						left: t.left + o - i
					}
				},
				windowWidth: function() {
					"use strict";
					if (window.innerWidth) return window.innerWidth;
					if (document.documentElement && document.documentElement.clientWidth) return document.documentElement.clientWidth
				},
				windowHeight: function() {
					"use strict";
					if (window.innerHeight) return window.innerHeight;
					if (document.documentElement && document.documentElement.clientHeight) return document.documentElement.clientHeight
				},
				windowScroll: function() {
					"use strict";
					if (typeof pageYOffset != "undefined") return {
						left: window.pageXOffset,
						top: window.pageYOffset
					};
					if (document.documentElement) return {
						left: document.documentElement.scrollLeft,
						top: document.documentElement.scrollTop
					}
				},
				addEventListener: function(e, t, n, r) {
					"use strict";
					typeof r == "undefined" && (r = !1), e.addEventListener ? e.addEventListener(t, n, r) : e.attachEvent && e.attachEvent("on" + t, n)
				},
				removeEventListener: function(e, t, n, r) {
					"use strict";
					typeof r == "undefined" && (r = !1), e.removeEventListener ? e.removeEventListener(t, n, r) : e.detachEvent && e.detachEvent("on" + t, n)
				}
			},
			setTransform: function(e, t) {
				"use strict";
				var n = e.style;
				n.webkitTransform = n.MsTransform = n.msTransform = n.MozTransform = n.OTransform = n.transform = t
			},
			setTranslate: function(e, t) {
				"use strict";
				var n = e.style,
					r = {
						x: t.x || 0,
						y: t.y || 0,
						z: t.z || 0
					},
					i = this.support.transforms3d ? "translate3d(" + r.x + "px," + r.y + "px," + r.z + "px)" : "translate(" + r.x + "px," + r.y + "px)";
				n.webkitTransform = n.MsTransform = n.msTransform = n.MozTransform = n.OTransform = n.transform = i, this.support.transforms || (n.left = r.x + "px", n.top = r.y + "px")
			},
			setTransition: function(e, t) {
				"use strict";
				var n = e.style;
				n.webkitTransitionDuration = n.MsTransitionDuration = n.msTransitionDuration = n.MozTransitionDuration = n.OTransitionDuration = n.transitionDuration = t + "ms"
			},
			support: {
				touch: window.Modernizr && Modernizr.touch === !0 ||
				function() {
					"use strict";
					return !!("ontouchstart" in window || window.DocumentTouch && document instanceof DocumentTouch)
				}(),
				transforms3d: window.Modernizr && Modernizr.csstransforms3d === !0 ||
				function() {
					"use strict";
					var e = document.createElement("div").style;
					return "webkitPerspective" in e || "MozPerspective" in e || "OPerspective" in e || "MsPerspective" in e || "perspective" in e
				}(),
				transforms: window.Modernizr && Modernizr.csstransforms === !0 ||
				function() {
					"use strict";
					var e = document.createElement("div").style;
					return "transform" in e || "WebkitTransform" in e || "MozTransform" in e || "msTransform" in e || "MsTransform" in e || "OTransform" in e
				}(),
				transitions: window.Modernizr && Modernizr.csstransitions === !0 ||
				function() {
					"use strict";
					var e = document.createElement("div").style;
					return "transition" in e || "WebkitTransition" in e || "MozTransition" in e || "msTransition" in e || "MsTransition" in e || "OTransition" in e
				}()
			},
			browser: {
				ie8: function() {
					"use strict";
					var e = -1;
					if (navigator.appName === "Microsoft Internet Explorer") {
						var t = navigator.userAgent,
							n = new RegExp(/MSIE ([0-9]{1,}[\.0-9]{0,})/);
						n.exec(t) !== null && (e = parseFloat(RegExp.$1))
					}
					return e !== -1 && e < 9
				}(),
				ie10: window.navigator.msPointerEnabled,
				ie11: window.navigator.pointerEnabled
			}
		}, t
	});
	var pt = function() {
			var params = {},
				callbacks = {},
				uiUrl = "",
				appendTo = null,
				ptuiWidth = 625,
				ptuiHeight = 400,
				lastUrl = "",
				loginHost = "",
				mask = null,
				e = {
					_counter: 0,
					_uid: function() {
						return "h" + e._counter++
					},
					add: function(t, n, r) {
						if (document.addEventListener) t.addEventListener(n, r, !1);
						else if (document.attachEvent) {
							if (e._find(t, n, r) != -1) return;
							var i = function(e) {
									e || (e = window.event);
									var n = {
										_event: e,
										type: e.type,
										target: e.srcElement,
										currentTarget: t,
										relatedTarget: e.fromElement ? e.fromElement : e.toElement,
										eventPhase: e.srcElement == t ? 2 : 3,
										clientX: e.clientX,
										clientY: e.clientY,
										screenX: e.screenX,
										screenY: e.screenY,
										altKey: e.altKey,
										ctrlKey: e.ctrlKey,
										shiftKey: e.shiftKey,
										keyCode: e.keyCode,
										origin: e.origin,
										data: e.data,
										stopPropagation: function() {
											this._event.cancelBubble = !0
										},
										preventDefault: function() {
											this._event.returnValue = !1
										}
									};
									Function.prototype.call ? r.call(t, n) : (t._currentHandler = r, t._currentHandler(n), t._currentHandler = null)
								};
							t.attachEvent("on" + n, i);
							var s = {
								element: t,
								eventType: n,
								handler: r,
								wrappedHandler: i
							},
								o = t.document || t,
								u = o.parentWindow,
								a = e._uid();
							u._allHandlers || (u._allHandlers = {}), u._allHandlers[a] = s, t._handlers || (t._handlers = []), t._handlers.push(a), u._onunloadHandlerRegistered || (u._onunloadHandlerRegistered = !0, u.attachEvent("onunload", e._removeAllHandlers))
						}
					},
					remove: function(t, n, r) {
						if (document.addEventListener) t.removeEventListener(n, r, !1);
						else if (document.attachEvent) {
							var i = e._find(t, n, r);
							if (i == -1) return;
							var s = t.document || t,
								o = s.parentWindow,
								u = t._handlers[i],
								a = o._allHandlers[u];
							t.detachEvent("on" + n, a.wrappedHandler), t._handlers.splice(i, 1), delete o._allHandlers[u]
						}
					},
					_find: function(e, t, n) {
						var r = e._handlers;
						if (!r) return -1;
						var i = e.document || e,
							s = i.parentWindow;
						for (var o = r.length - 1; o >= 0; o--) {
							var u = r[o],
								a = s._allHandlers[u];
							if (a.eventType == t && a.handler == n) return o
						}
						return -1
					},
					_removeAllHandlers: function() {
						var e = this;
						for (id in e._allHandlers) {
							var t = e._allHandlers[id];
							t.element.detachEvent("on" + t.eventType, t.wrappedHandler), delete e._allHandlers[id]
						}
					},
					src: function(e) {
						return e ? e.target : event.srcElement
					},
					stopPropagation: function(e) {
						e ? e.stopPropagation() : event.cancelBubble = !0
					}
				},
				getCookie = function(e) {
					var t = document.cookie.match(new RegExp("(^| )" + e + "=([^;]*)(;|$)"));
					return t ? decodeURIComponent(t[2]) : ""
				},
				delCookie = function(e, t, n) {
					document.cookie = e + "=; expires=Mon, 26 Jul 1997 05:00:00 GMT; path=" + (n ? n : "/") + "; " + (t ? "domain=" + t + ";" : "")
				},
				preload = function(e) {
					var t = new Image;
					t.src = e
				},
				monitor = function(e, t) {
					if (Math.random() > (t || 1)) return;
					var n = location.protocol + "//ui.ptlogin2.qq.com/cgi-bin/report?id=" + e + "&v=" + Math.random();
					preload(n)
				},
				setParam = function(e, t) {
					params[e] = t
				},
				setParams = function(e) {
					params = e
				},
				setCallback = function(e, t) {
					callbacks[e] = t
				},
				getUiUrl = function() {
					var e = params.protocol || "http:";
					e += "//";
					var t = params.domain || "qq.com";
					params.protocol == "https:" && t != "qq.com" && t != "tenpay.com" && (e = "https://ssl."), uiUrl = e + "xui.ptlogin2." + t, loginHost = uiUrl;
					var n = uiUrl + "/cgi-bin/xlogin?",
						r = "";
					for (var i in params) {
						if (i == "protocol" || i == "domain") continue;
						r += i + "=" + encodeURIComponent(params[i]) + "&"
					}
					return n += r, n
				},
				createPtui = function(e, t) {
					if (!t) {
						appendTo = document.createElement("div"), document.body.appendChild(appendTo);
						var n = "left:50%;";
						n += "top:50%;", n += "position:fixed;", n += "z-index:9999;", n += "background:none;", n += "_position:absolute;", n += "_top:expression(eval(document.documentElement.scrollTop+(document.documentElement.clientHeight-this.offsetHeight)/2));", n += "_margin-top:0px;", appendTo.style.cssText = n
					} else appendTo = t;
					appendTo.innerHTML = '<iframe name="ui_ptlogin" id="ui_ptlogin" allowtransparency="true" scrolling="no" frameborder="0" width="100%" height="100%" style="top:0; left:0;' + (params.border_radius == 1 ? "border-radius:5px;" : "") + '" src="' + e + '">'
				},
				showPtui = function(e) {
					var t = getUiUrl();
					lastUrl ? t != lastUrl && (document.getElementById("ui_ptlogin").src = t) : (createPtui(t, e), !-[1] && !window.XMLHttpRequest && ptlogin2_onResize(ptuiWidth - 1, ptuiHeight - 1)), lastUrl = t, showMask(), appendTo.style.display = "block"
				},
				hidePtui = function() {
					appendTo.style.display = "none", hideMask()
				},
				showMask = function() {
					var e = params.maskOpacity;
					if (e == 0) return;
					if (!mask) {
						var t = "background-color:#000;overflow:hidden;position:fixed;left:0;top:0;width:100%;height:100%;z-index:9998;opacity:" + e / 100 + ";filter:alpha(opacity=" + e + ");";
						t += "_position:absolute;_height:expression(eval(document.documentElement.scrollTop+document.documentElement.clientHeight));_width:expression(eval(document.documentElement.scrollLeft+document.documentElement.clientWidth));", mask = document.createElement("div"), mask.style.cssText = t, document.body.appendChild(mask)
					}
					mask.style.display = "block"
				},
				hideMask = function() {
					mask && (mask.style.display = "none")
				},
				ptlogin2_onResize = function(e, t) {
					var n = appendTo;
					n && e > 1 && t > 1 && (ptuiWidth != e || ptuiHeight != t) && (typeof callbacks.resize == "function" ? callbacks.resize(parseInt(e), parseInt(t)) : (n.style.width = e + "px", n.style.height = t + "px", n.style.marginLeft = -e / 2 + "px", n.style.marginTop = -t / 2 + "px")), ptuiWidth = e, ptuiHeight = t
				},
				ptlogin2_onClose = function() {
					hidePtui(), typeof callbacks.close == "function" && callbacks.close()
				},
				str2JSON = function(str) {
					var data;
					return typeof JSON != "undefined" ? data = JSON.parse(str) : eval("data=" + str), data
				},
				bindEvent = function() {
					typeof window.postMessage != "undefined" ? e.add(window, "message", function(e) {
						var t = e.origin;
						if (t != loginHost) return;
						var n = str2JSON(e.data);
						switch (n.action) {
						case "close":
							ptlogin2_onClose();
							break;
						case "resize":
							ptlogin2_onResize(n.width, n.height);
							break;
						default:
						}
					}) : navigator.ptlogin_callback = function(e) {
						var t = str2JSON(e);
						switch (t.action) {
						case "close":
							ptlogin2_onClose();
							break;
						case "resize":
							ptlogin2_onResize(t.width, t.height);
							break;
						default:
						}
					}
				},
				init = function() {
					bindEvent(), window.setTimeout(function() {
						monitor(447926, 1)
					}, 1e3)
				},
				appDomain = "",
				mainDomain = "",
				initDomain = function() {
					mainDomain = location.hostname.match(/\w*\.(com|cn)$/), mainDomain = mainDomain ? mainDomain[0] : "", appDomain = location.hostname.match(/\w+(\.\w+){2}$/), appDomain = appDomain ? appDomain[0] : "", mainDomain != "qq.com" && (appDomain = mainDomain)
				},
				getLogoutUrl = function(e) {
					var t = getCookie("pt4_token"),
						n = getCookie("skey"),
						r = hash33(n),
						i = getCookie("ptcz"),
						s = hash33(i),
						o = e ? "qq.com" : mainDomain,
						u = (location.protocol == "https:" ? "https://ssl." : "http://") + "ptlogin2." + o + "/logout?";
					return u += "pt4_token=" + t + "&pt4_hkey=" + r + "&pt4_ptcz=" + s + "&deep_logout=1", u
				},
				hash33 = function(e) {
					var t = 0;
					for (var n = 0, r = e.length; n < r; ++n) t += (t << 5) + e.charCodeAt(n);
					return t & 2147483647
				},
				clearCookie = function() {
					delCookie("uin", mainDomain), delCookie("skey", mainDomain), delCookie("p_uin", appDomain), delCookie("p_skey", appDomain), delCookie("p_luin", appDomain), delCookie("p_lskey", appDomain), delCookie("pt4_token", appDomain), delCookie("pt_mbkey", mainDomain), appDomain != "" && getCookie("skey_m") != "" && (delCookie("uin_m", appDomain), delCookie("skey_m", appDomain))
				},
				logout = function(e, t) {
					initDomain();
					var n = getCookie("pt4_token"),
						r = getCookie("skey"),
						i = getCookie("ptcz"),
						s = getLogoutUrl(t);
					!n && !r && !i || preload(s), window.setTimeout(function() {
						clearCookie(), e && e(2)
					}, 100)
				},
				logoutQQCom = function(e) {
					logout(e, !0)
				};
			return init(), {
				showPtui: showPtui,
				hidePtui: hidePtui,
				setParam: setParam,
				setParams: setParams,
				setCallback: setCallback,
				logout: logout,
				logoutQQCom: logoutQQCom
			}
		}();
	define("ptlogin", function(e) {
		return function() {
			var t, n;
			return t || e.ptlogin
		}
	}(this));
	var BinArray = function() {
			var e = {};
			return e.bsearch = function(e, t, n) {
				if (e.length === 0) return 0;
				if (n(t, e[0]) < 0) return 0;
				if (n(t, e[e.length - 1]) >= 0) return e.length;
				var r = 0,
					i = 0,
					s = 0,
					o = e.length - 1;
				while (r <= o) {
					i = Math.floor((o + r + 1) / 2), s++;
					if (n(t, e[i - 1]) >= 0 && n(t, e[i]) < 0) return i;
					n(t, e[i - 1]) < 0 ? o = i - 1 : n(t, e[i]) >= 0 ? r = i : console.error("Program Error"), s > 1500 && console.error("Too many run cycles.")
				}
				return -1
			}, e.binsert = function(t, n, r) {
				var i = e.bsearch(t, n, r);
				return t.splice(i, 0, n), i
			}, e
		}(),
		__extends = this.__extends ||
	function(e, t) {
		function r() {
			this.constructor = e
		}
		for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n]);
		r.prototype = t.prototype, e.prototype = new r
	}, CommentSpaceAllocator = function() {
		function e(e, t) {
			typeof e == "undefined" && (e = 0), typeof t == "undefined" && (t = 0), this._pools = [
				[]
			], this.avoid = 1, this._width = e, this._height = t
		}
		return e.prototype.willCollide = function(e, t) {
			return e.stime + e.ttl >= t.stime + t.ttl / 2
		}, e.prototype.pathCheck = function(e, t, n) {
			var r = e + t.height,
				i = t.right;
			for (var s = 0; s < n.length; s++) {
				if (n[s].y > r || n[s].bottom < e) continue;
				if (n[s].right < t.x || n[s].x > i) {
					if (this.willCollide(n[s], t)) return !1;
					continue
				}
				return !1
			}
			return !0
		}, e.prototype.assign = function(e, t) {
			while (this._pools.length <= t) this._pools.push([]);
			var n = this._pools[t];
			if (n.length === 0) return e.cindex = t, 0;
			if (this.pathCheck(0, e, n)) return e.cindex = t, 0;
			var r = 0;
			for (var i = 0; i < n.length; i++) {
				r = n[i].bottom + this.avoid;
				if (r + e.height > this._height) break;
				if (this.pathCheck(r, e, n)) return e.cindex = t, r
			}
			return this.assign(e, t + 1)
		}, e.prototype.add = function(e) {
			e.height > this._height ? (e.cindex = -2, e.y = 0) : (e.y = this.assign(e, 0), BinArray.binsert(this._pools[e.cindex], e, function(e, t) {
				return e.bottom < t.bottom ? -1 : e.bottom > t.bottom ? 1 : 0
			}))
		}, e.prototype.remove = function(e) {
			if (e.cindex < 0) return;
			if (e.cindex >= this._pools.length) throw new Error("cindex out of bounds");
			var t = this._pools[e.cindex].indexOf(e);
			if (t < 0) return;
			this._pools[e.cindex].splice(t, 1)
		}, e.prototype.setBounds = function(e, t) {
			this._width = e, this._height = t
		}, e
	}(), AnchorCommentSpaceAllocator = function(e) {
		function t() {
			e.apply(this, arguments)
		}
		return __extends(t, e), t.prototype.add = function(t) {
			e.prototype.add.call(this, t), t.x = (this._width - t.width) / 2
		}, t.prototype.willCollide = function(e, t) {
			return !0
		}, t.prototype.pathCheck = function(e, t, n) {
			var r = e + t.height;
			for (var i = 0; i < n.length; i++) {
				if (n[i].y > r || n[i].bottom < e) continue;
				return !1
			}
			return !0
		}, t
	}(CommentSpaceAllocator), __extends = this.__extends ||
	function(e, t) {
		function r() {
			this.constructor = e
		}
		for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n]);
		r.prototype = t.prototype, e.prototype = new r
	}, CoreComment = function() {
		function e(t, n) {
			typeof n == "undefined" && (n = {}), this.mode = 1, this.stime = 0, this.text = "", this.ttl = 12e3, this.dur = 12e3, this.cindex = -1, this.motion = [], this.movable = !0, this._alphaMotion = null, this.absolute = !0, this.align = 0, this._alpha = 1, this._size = 25, this._color = 16777215, this._border = !1, this._shadow = !0, this._font = "";
			if (!t) throw new Error("Comment not bound to comment manager.");
			this.parent = t, n.hasOwnProperty("stime") && (this.stime = n.stime), n.hasOwnProperty("mode") ? this.mode = n.mode : this.mode = 1, n.hasOwnProperty("dur") && (this.dur = n.dur, this.ttl = this.dur), this.dur *= this.parent.options.global.scale, this.ttl *= this.parent.options.global.scale, n.hasOwnProperty("text") && (this.text = n.text);
			if (n.hasOwnProperty("motion")) {
				this._motionStart = [], this._motionEnd = [], this.motion = n.motion;
				var r = 0;
				for (var i = 0; i < n.motion.length; i++) {
					this._motionStart.push(r);
					var s = 0;
					for (var o in n.motion[i]) {
						var u = n.motion[i][o];
						s = Math.max(u.dur, s);
						if (u.easing === null || u.easing === undefined) n.motion[i][o].easing = e.LINEAR
					}
					r += s, this._motionEnd.push(r)
				}
				this._curMotion = 0
			}
			n.hasOwnProperty("color") && (this._color = n.color), n.hasOwnProperty("size") && (this._size = n.size), n.hasOwnProperty("border") && (this._border = n.border), n.hasOwnProperty("opacity") && (this._alpha = n.opacity), n.hasOwnProperty("alpha") && (this._alphaMotion = n.alpha), n.hasOwnProperty("font") && (this._font = n.font), n.hasOwnProperty("x") && (this._x = n.x), n.hasOwnProperty("y") && (this._y = n.y), n.hasOwnProperty("shadow") && (this._shadow = n.shadow), n.hasOwnProperty("head") && (this._head = n.head), n.hasOwnProperty("position") && n.position === "relative" && (this.absolute = !1, this.mode < 7 && console.warn("Using relative position for CSA comment."))
		}
		return e.prototype.init = function(e) {
			typeof e == "undefined" && (e = null), e !== null ? this.dom = e.dom : this.dom = document.createElement("div"), this.dom.className = this.parent.options.global.className, this.dom.appendChild(document.createTextNode(this.text)), this.dom.innerHTML = this.text, this.size = this._size, this._color != 16777215 && (this.color = this._color), this.shadow = this._shadow, this._border && (this.border = this._border), this._font !== "" && (this.font = this._font), this._x !== undefined && (this.x = this._x), this._y !== undefined && (this.y = this._y);
			if (this._alpha !== 1 || this.parent.options.global.opacity < 1) this.alpha = this._alpha;
			this.motion.length > 0 && this.animate();
			if (this._head !== undefined) {
				var t = document.createElement("img");
				t.src = this._head, this.dom.insertBefore(t, this.dom.firstChild)
			}
		}, Object.defineProperty(e.prototype, "x", {
			get: function() {
				if (this._x === null || this._x === undefined) this.align % 2 === 0 ? this._x = this.dom.offsetLeft : this._x = this.parent.width - this.dom.offsetLeft - this.width;
				return this.absolute ? this._x : this._x / this.parent.width
			},
			set: function(e) {
				this._x = e, this.absolute || (this._x *= this.parent.width), this.align % 2 === 0 ? this.dom.style.left = this._x + "px" : this.dom.style.right = this._x + "px"
			},
			enumerable: !0,
			configurable: !0
		}), Object.defineProperty(e.prototype, "y", {
			get: function() {
				if (this._y === null || this._y === undefined) this.align < 2 ? this._y = this.dom.offsetTop : this._y = this.parent.height - this.dom.offsetTop - this.height;
				return this.absolute ? this._y : this._y / this.parent.height
			},
			set: function(e) {
				this._y = e, this.absolute || (this._y *= this.parent.height), this.align < 2 ? this.dom.style.top = this._y + "px" : this.dom.style.bottom = this._y + "px"
			},
			enumerable: !0,
			configurable: !0
		}), Object.defineProperty(e.prototype, "bottom", {
			get: function() {
				return this.y + this.height
			},
			enumerable: !0,
			configurable: !0
		}), Object.defineProperty(e.prototype, "right", {
			get: function() {
				return this.x + this.width
			},
			enumerable: !0,
			configurable: !0
		}), Object.defineProperty(e.prototype, "width", {
			get: function() {
				if (this._width === null || this._width === undefined) this._width = this.dom.offsetWidth;
				return this._width
			},
			set: function(e) {
				this._width = e, this.dom.style.width = this._width + "px"
			},
			enumerable: !0,
			configurable: !0
		}), Object.defineProperty(e.prototype, "height", {
			get: function() {
				if (this._height === null || this._height === undefined) this._height = this.dom.offsetHeight;
				return this._height
			},
			set: function(e) {
				this._height = e, this.dom.style.height = this._height + "px"
			},
			enumerable: !0,
			configurable: !0
		}), Object.defineProperty(e.prototype, "size", {
			get: function() {
				return this._size
			},
			set: function(e) {
				this._size = e, this.dom.style.fontSize = this._size + "px"
			},
			enumerable: !0,
			configurable: !0
		}), Object.defineProperty(e.prototype, "color", {
			get: function() {
				return this._color
			},
			set: function(e) {
				this._color = e;
				var t = e.toString(16);
				t = t.length >= 6 ? t : (new Array(6 - t.length + 1)).join("0") + t, this.dom.style.color = "#" + t, this._color === 0 && (this.dom.className = this.parent.options.global.className + " rshadow")
			},
			enumerable: !0,
			configurable: !0
		}), Object.defineProperty(e.prototype, "alpha", {
			get: function() {
				return this._alpha
			},
			set: function(e) {
				this._alpha = e, this.dom.style.opacity = Math.min(this._alpha, this.parent.options.global.opacity) + ""
			},
			enumerable: !0,
			configurable: !0
		}), Object.defineProperty(e.prototype, "border", {
			get: function() {
				return this._border
			},
			set: function(e) {
				this._border = e, this._border ? this.dom.style.border = "1px solid #00ffff" : this.dom.style.border = "none"
			},
			enumerable: !0,
			configurable: !0
		}), Object.defineProperty(e.prototype, "shadow", {
			get: function() {
				return this._shadow
			},
			set: function(e) {
				this._shadow = e, this._shadow || (this.dom.className = this.parent.options.global.className + " noshadow")
			},
			enumerable: !0,
			configurable: !0
		}), Object.defineProperty(e.prototype, "font", {
			get: function() {
				return this._font
			},
			set: function(e) {
				this._font = e, this._font.length > 0 ? this.dom.style.fontFamily = this._font : this.dom.style.fontFamily = ""
			},
			enumerable: !0,
			configurable: !0
		}), e.prototype.time = function(e) {
			this.ttl -= e, this.ttl < 0 && (this.ttl = 0), this.movable && this.update(), this.ttl <= 0 && this.finish()
		}, e.prototype.update = function() {
			this.animate()
		}, e.prototype.invalidate = function() {
			this._x = null, this._y = null, this._width = null, this._height = null
		}, e.prototype._execMotion = function(e, t) {
			for (var n in e) if (e.hasOwnProperty(n)) {
				var r = e[n];
				this[n] = r.easing(Math.min(Math.max(t - r.delay, 0), r.dur), r.from, r.to - r.from, r.dur)
			}
		}, e.prototype.animate = function() {
			this._alphaMotion && (this.alpha = (this.dur - this.ttl) * (this._alphaMotion.to - this._alphaMotion.from) / this.dur + this._alphaMotion.from);
			if (this.motion.length === 0) return;
			var e = Math.max(this.ttl, 0),
				t = this.dur - e - this._motionStart[this._curMotion];
			this._execMotion(this.motion[this._curMotion], t);
			if (this.dur - e > this._motionEnd[this._curMotion]) {
				this._curMotion++, this._curMotion >= this.motion.length && (this._curMotion = this.motion.length - 1);
				return
			}
		}, e.prototype.finish = function() {
			this.parent.finish(this)
		}, e.prototype.toString = function() {
			return ["[", this.stime, "|", this.ttl, "/", this.dur, "]", "(", this.mode, ")", this.text].join("")
		}, e.LINEAR = function(e, t, n, r) {
			return e * n / r + t
		}, e
	}(), ScrollComment = function(e) {
		function t(t, n) {
			e.call(this, t, n), this.dur *= this.parent.options.scroll.scale, this.ttl *= this.parent.options.scroll.scale
		}
		return __extends(t, e), Object.defineProperty(t.prototype, "alpha", {
			set: function(e) {
				this._alpha = e, this.dom.style.opacity = Math.min(Math.min(this._alpha, this.parent.options.global.opacity), this.parent.options.scroll.opacity) + ""
			},
			enumerable: !0,
			configurable: !0
		}), t.prototype.init = function(t) {
			typeof t == "undefined" && (t = null), e.prototype.init.call(this, t), this.x = this.parent.width, this.parent.options.scroll.opacity < 1 && (this.alpha = this._alpha), this.absolute = !0
		}, t.prototype.update = function() {
			this.x = this.ttl / this.dur * (this.parent.width + this.width) - this.width
		}, t
	}(CoreComment), CommentManager = function() {
		function t(e) {
			var t = 0;
			this._listeners = {}, this.stage = e, this.options = {
				global: {
					opacity: 1,
					scale: 1,
					className: "cmt"
				},
				scroll: {
					opacity: 1,
					scale: 1
				},
				limit: 0
			}, this.timeline = [], this.runline = [], this.position = 0, this.limiter = 0, this.filter = null, this.csa = {
				scroll: new CommentSpaceAllocator(0, 0),
				top: new AnchorCommentSpaceAllocator(0, 0),
				bottom: new AnchorCommentSpaceAllocator(0, 0),
				reverse: new CommentSpaceAllocator(0, 0),
				scrollbtm: new CommentSpaceAllocator(0, 0)
			}, this.width = this.stage.offsetWidth, this.height = this.stage.offsetHeight, this.startTimer = function() {
				if (t > 0) return;
				var e = (new Date).getTime(),
					n = this;
				t = window.setInterval(function() {
					var t = (new Date).getTime() - e;
					e = (new Date).getTime(), n.onTimerEvent(t, n)
				}, 10)
			}, this.stopTimer = function() {
				window.clearInterval(t), t = 0
			}
		}
		var e = function(e, t) {
				var n = Math.PI / 180,
					r = e * n,
					i = t * n,
					s = Math.cos,
					o = Math.sin,
					u = [s(r) * s(i), s(r) * o(i), o(r), 0, -o(i), s(i), 0, 0, -o(r) * s(i), -o(r) * o(i), s(r), 0, 0, 0, 0, 1];
				for (var a = 0; a < u.length; a++) Math.abs(u[a]) < 1e-6 && (u[a] = 0);
				return "matrix3d(" + u.join(",") + ")"
			};
		return t.prototype.stop = function() {
			this.stopTimer()
		}, t.prototype.start = function() {
			this.startTimer()
		}, t.prototype.seek = function(e) {
			this.position = BinArray.bsearch(this.timeline, e, function(e, t) {
				return e < t.stime ? -1 : e > t.stime ? 1 : 0
			})
		}, t.prototype.validate = function(e) {
			return e == null ? !1 : this.filter.doValidate(e)
		}, t.prototype.load = function(e) {
			this.timeline = e, this.timeline.sort(function(e, t) {
				if (e.stime > t.stime) return 2;
				if (e.stime < t.stime) return -2;
				if (e.date > t.date) return 1;
				if (e.date < t.date) return -1;
				if (e.dbid != null && t.dbid != null) return e.dbid > t.dbid ? 1 : e.dbid < t.dbid ? -1 : 0;
				return 0
			}), this.dispatchEvent("load")
		}, t.prototype.insert = function(e) {
			var t = BinArray.binsert(this.timeline, e, function(e, t) {
				if (e.stime > t.stime) return 2;
				if (e.stime < t.stime) return -2;
				if (e.date > t.date) return 1;
				if (e.date < t.date) return -1;
				if (e.dbid != null && t.dbid != null) return e.dbid > t.dbid ? 1 : e.dbid < t.dbid ? -1 : 0;
				return 0
			});
			t <= this.position && this.position++, this.dispatchEvent("insert")
		}, t.prototype.clear = function() {
			while (this.runline.length > 0) this.runline[0].finish();
			this.dispatchEvent("clear")
		}, t.prototype.setBounds = function() {
			this.width = this.stage.offsetWidth, this.height = this.stage.offsetHeight, this.dispatchEvent("resize");
			for (var e in this.csa) this.csa[e].setBounds(this.width, this.height);
			this.stage.style.perspective = this.width * Math.tan(40 * Math.PI / 180) / 2 + "px", this.stage.style.webkitPerspective = this.width * Math.tan(40 * Math.PI / 180) / 2 + "px"
		}, t.prototype.init = function() {
			this.setBounds(), this.filter == null && (this.filter = new CommentFilter)
		}, t.prototype.time = function(e) {
			e -= 1;
			if (this.position >= this.timeline.length || Math.abs(this.lastPos - e) >= 2e3) {
				this.seek(e), this.lastPos = e;
				if (this.timeline.length <= this.position) return
			} else this.lastPos = e;
			for (; this.position < this.timeline.length; this.position++) {
				if (this.options.limit > 0 && this.runline.length > this.limiter) break;
				if (!(this.validate(this.timeline[this.position]) && this.timeline[this.position].stime <= e)) break;
				this.send(this.timeline[this.position])
			}
		}, t.prototype.rescale = function() {}, t.prototype.send = function(t) {
			if (t.mode === 8) {
				console.log(t), this.scripting && console.log(this.scripting.eval(t.code));
				return
			}
			if (this.filter != null) {
				t = this.filter.doModify(t);
				if (t == null) return
			}
			if (t.mode === 1 || t.mode === 2 || t.mode === 6) var n = new ScrollComment(this, t);
			else var n = new CoreComment(this, t);
			switch (n.mode) {
			case 1:
				n.align = 0;
				break;
			case 2:
				n.align = 2;
				break;
			case 4:
				n.align = 2;
				break;
			case 5:
				n.align = 0;
				break;
			case 6:
				n.align = 1
			}
			n.init(), this.stage.appendChild(n.dom);
			switch (n.mode) {
			default:
			case 1:
				this.csa.scroll.add(n);
				break;
			case 2:
				this.csa.scrollbtm.add(n);
				break;
			case 4:
				this.csa.bottom.add(n);
				break;
			case 5:
				this.csa.top.add(n);
				break;
			case 6:
				this.csa.reverse.add(n);
				break;
			case 17:
			case 7:
				if (t.rY !== 0 || t.rZ !== 0) n.dom.style.transform = e(t.rY, t.rZ), n.dom.style.webkitTransform = e(t.rY, t.rZ), n.dom.style.OTransform = e(t.rY, t.rZ), n.dom.style.MozTransform = e(t.rY, t.rZ), n.dom.style.MSTransform = e(t.rY, t.rZ)
			}
			n.y = n.y, this.dispatchEvent("enterComment", n), this.runline.push(n)
		}, t.prototype.sendComment = function(e) {
			console.log("CommentManager.sendComment is deprecated. Please use send instead"), this.send(e)
		}, t.prototype.finish = function(e) {
			this.dispatchEvent("exitComment", e), this.stage.removeChild(e.dom);
			var t = this.runline.indexOf(e);
			t >= 0 && this.runline.splice(t, 1);
			switch (e.mode) {
			default:
			case 1:
				this.csa.scroll.remove(e);
				break;
			case 2:
				this.csa.scrollbtm.remove(e);
				break;
			case 4:
				this.csa.bottom.remove(e);
				break;
			case 5:
				this.csa.top.remove(e);
				break;
			case 6:
				this.csa.reverse.remove(e);
				break;
			case 7:
			}
		}, t.prototype.addEventListener = function(e, t) {
			typeof this._listeners[e] != "undefined" ? this._listeners[e].push(t) : this._listeners[e] = [t]
		}, t.prototype.dispatchEvent = function(e, t) {
			if (typeof this._listeners[e] != "undefined") for (var n = 0; n < this._listeners[e].length; n++) try {
				this._listeners[e][n](t)
			} catch (r) {
				console.err(r.stack)
			}
		}, t.prototype.onTimerEvent = function(e, t) {
			for (var n = 0; n < t.runline.length; n++) {
				var r = t.runline[n];
				if (r.hold) continue;
				r.time(e)
			}
		}, t
	}();
	define("vendor/CommentCoreLibrary", function() {}), define("base/global", ["require", "base/hosts", "template", "model/global", "base/util", "base/remote", "base/cache", "vendor/swiper", "ptlogin", "vendor/CommentCoreLibrary"], function(e) {
		var t = e("base/hosts"),
			n = e("template"),
			r = e("model/global"),
			i = e("base/util"),
			s = e("base/remote"),
			o = e("base/cache"),
			u = e("vendor/swiper");
		i.setACSRFToken();
		var a = e("ptlogin"),
			f = new Object;
		if (!i.isIE()) var l = e("vendor/CommentCoreLibrary");
		return f.model = r, f.prepareData = function(e) {
			var n = this;
			r.params = e, r.params.campaign_id == 1 && t.setUrls("demo")
		}, f.renderLayout = function() {
			var e = this;
			f.path = r.data.theme || "default", f.path = "component/" + f.path, r.data.theme && r.data.theme != "default" && i.changeTheme(r.data.theme), $("#wrapper").html(n(f.path + "/layout/main", r.data)), $("#header").html(n(f.path + "/header/main", r.data)), $("#toolkit").html(n(f.path + "/toolkit/main", r.params)), e.init_slogen(), e.init_bullet(), e.bindEvent(), i.resize(), $(window).on("resize", function() {
				i.resize()
			})
		}, f.checkLogin = function() {
			var e = $.Deferred(),
				t = this,
				n = function() {
					if (pt) if (!i.isLogin()) pt.setParams({
						appid: 4007203,
						s_url: window.location.href,
						style: 20,
						protocol: "https:",
						domain: "qq.com",
						border_radius: 1,
						target: "top",
						maskOpacity: 40
					}), i.isIE() && setInterval(function() {
						if (!i.isLogin()) return;
						window.location.reload()
					}, 100), setTimeout(function() {
						pt.showPtui()
					}, 100), e.reject();
					else {
						var r = $("#ui_ptlogin");
						r.length && ($(r.parent().next("div")).remove(), $(r.parent()).remove()), t.checkPrivilege(e)
					} else window.setTimeout(n, 100)
				};
			return n(), e.promise()
		}, f.checkPrivilege = function(e) {
			var n = this;
			$.ajax({
				url: t.urls.getUserAuth,
				dataType: "json",
				async: !1,
				data: {
					campaign_id: r.params.campaign_id
				}
			}).done(function(t) {
				return t.code && (window.location.hash = "#error/1"), r.auth = t.data, e.resolve(), e.promise()
			}).error(function() {
				window.location.hash = "#error/1"
			})
		}, f.getInfo = function(e) {
			var n = this,
				i = $.Deferred();
			return r.data ? (i.resolve(), i.promise()) : ($.ajax({
				url: t.urls.getInfo,
				dataType: "json",
				async: !1,
				data: {
					campaign_id: r.params.campaign_id
				}
			}).done(function(e) {
				e.code ? window.location.hash = "#2/error" : (r.saveData(e.data), n.register(), s.init(r.data.token), n.ready = !0), i.resolve()
			}), i.promise())
		}, f.render = function() {
			var e = this;
			e.renderLayout(), document.title = $("<p>" + r.data.name + "</p>").text() + "-- 腾讯微现场", r.params.campaign_id == 1 && $("#ribbon").removeClass("hide"), $(".loading_con").addClass("hide");
			if (i.isIE()) {
				var t = $("#background_img").css("background-image");
				t = t.substr(5, t.length - 7), $("#background_img").html('<img src="' + t + '" style="width:100%;height:100%"/>')
			}
			for (var n in r.data.enable) e.isActive(n) || $("#toolkit ." + n).addClass("hide");
			r.data.enable.register && $("#toolkit .signin").removeClass("hide")
		}, f.isActive = function(e) {
			var t = this;
			return typeof r.data.enable != "undefined" && r.data.enable[e] ? !0 : !1
		}, f.highlight = function(e) {
			var t = this;
			$("#toolkit .icon").removeClass("active"), $("#toolkit .icon-" + e).addClass("active"), e == "message" || e == "image" ? $("#toolkit .action-bar").removeClass("hide") : $("#toolkit .action-bar").addClass("hide"), r.auth.role == "superadmin" || $.inArray("bullet", r.auth.privileges) != -1 ? $("#shoot").removeClass("hide") : r.params.campaign_id == 1 ? $("#shoot").removeClass("hide") : $("#shoot").addClass("hide")
		}, f.register = function(e) {
			return o.register([{
				name: "Info",
				maxAge: 0,
				dataType: "json",
				remote: t.urls.getInfo,
				params: f.model.params
			}, {
				name: "SignList",
				maxAge: 0,
				dataType: "json",
				remote: t.urls.getSignList,
				params: f.model.params
			}, {
				name: "WallMsg",
				maxAge: 0,
				dataType: "json",
				remote: t.urls.getWallMsg,
				params: f.model.params
			}, {
				name: "LotteryUserList",
				maxAge: 0,
				dataType: "json",
				remote: t.urls.getLotteryUserList,
				params: f.model.params
			}, {
				name: "VoteList",
				maxAge: 0,
				dataType: "json",
				remote: t.urls.getVoteList,
				params: f.model.params
			}, {
				name: "VoteDetail",
				maxAge: 0,
				dataType: "json",
				remote: t.urls.getVoteDetail,
				params: f.model.params
			}, {
				name: "SigninUserList",
				maxAge: 0,
				dataType: "json",
				remote: t.urls.getSigninUserList,
				params: f.model.params
			}, {
				name: "SigninGR",
				maxAge: 0,
				dataType: "json",
				remote: t.urls.getSigninGR,
				params: f.model.params
			}, {
				name: "SigninType",
				maxAge: 0,
				dataType: "json",
				remote: t.urls.getSigninType,
				params: f.model.params
			}, {
				name: "Draw",
				maxAge: 0,
				dataType: "json",
				remote: t.urls.drawAward,
				params: f.model.params
			}, {
				name: "BrandMatrix",
				maxAge: 0,
				dataType: "json",
				remote: t.urls.getBrandMatrix,
				params: f.model.params
			}, {
				name: "AwardList",
				maxAge: 0,
				dataType: "json",
				remote: t.urls.getAwardList,
				params: f.model.params
			}, {
				name: "PoolList",
				maxAge: 0,
				dataType: "json",
				remote: t.urls.getPoolList,
				params: f.model.params
			}, {
				name: "WinnerHistory",
				maxAge: 0,
				dataType: "json",
				remote: t.urls.getWinnerHistory,
				params: f.model.params,
				behaivor: function(e) {
					if (!e.code && e.message) return e
				}
			}, {
				name: "userAuth",
				maxAge: 0,
				dataType: "json",
				remote: t.urls.getUserAuth,
				params: f.model.params
			}, {
				name: "Setting",
				maxAge: 0,
				dataType: "json",
				remote: t.urls.saveSettting,
				params: f.model.params
			}, {
				name: "GameWinner",
				maxAge: 0,
				type: "post",
				dataType: "json",
				remote: t.urls.saveGameWinner,
				params: f.model.params
			}, {
				name: "GuessingDuration",
				maxAge: 0,
				dataType: "json",
				remote: t.urls.setGuessingDuration,
				params: f.model.params
			}, {
				name: "GuessingRank",
				maxAge: 0,
				dataType: "json",
				remote: t.urls.getGuessingRank,
				params: f.model.params
			}, {
				name: "GuessingStatus",
				maxAge: 0,
				dataType: "json",
				remote: t.urls.getGuessingStatus,
				params: f.model.params
			}])
		}, f.init_slogen = function() {
			var e = this,
				t = $("#slogen");
			t.html(n(f.path + "/slogen/main", r.data));
			var s = new u("#slogen-swiper-con", {
				speed: 500,
				autoplay: 5e3,
				simulateTouch: !1,
				loop: !0
			});
			s.slides.length == 1 && s.stopAutoplay(), i.isIE() || window.setTimeout(function() {
				$("#ctrlbar").removeClass("hover")
			}, 1e4)
		}, f.init_bullet = function() {
			if (i.isIE()) return;
			var e = this;
			e.commentManager = new CommentManager($("#comment-stage")[0]), e.commentManager.init()
		}, f.bindEvent = function() {
			var e = this;
			$("#toolkit").on("click", "#fullscreen", function() {
				i.toggleFullscreen()
			}), $("#toolkit").on("click", "#shoot", function() {
				if (i.isIE()) return;
				if (!e.model.bullet) {
					e.model.bullet = !0, $(".gallery-con").removeClass("invisible"), $(".icon-rocket").addClass("active"), e.addCommentInterval(), e.commentManager.start(), e.model.has_left = !1;
					if (e.model.sync) return;
					e.model.interval()
				} else e.model.bullet = !1, e.model.has_left = !0, $(".gallery-con").addClass("invisible"), $(".icon-rocket").removeClass("active"), clearTimeout(e.addComment), e.commentManager.clear()
			}), $("#toolkit").on("click", "#setting-btn", function() {
				i.setting({
					path: e.path,
					model: e.model
				})
			}), $("#toolkit").on("click", "#game-btn", function() {
				i.game({
					path: e.path,
					model: e.model
				})
			})
		}, f.addCommentInterval = function() {
			var e = this,
				t = function() {
					e.addComment = window.setTimeout(function() {
						t()
					}, 1e3);
					if (r.comments && typeof r.comments[r.defaults.display_offset] != "undefined") {
						if (r.comments[r.defaults.display_offset].type == 0) {
							var n = r.comments[r.defaults.display_offset],
								s = i.drawByProbability(r.defaults.modeArr),
								o = i.drawByProbability(r.defaults.colorArr),
								u = {
									mode: s,
									text: n.content,
									head: n.head,
									stime: 1e3,
									size: 45,
									color: o
								};
							e.commentManager.send(u)
						}
						r.defaults.display_offset++
					} else r.defaults.display_offset = 0
				};
			t()
		}, f
	}), define("model/message", ["require", "base/global", "base/hosts", "base/cache", "base/util", "template"], function(e) {
		var t = e("base/global"),
			n = e("base/hosts"),
			r = e("base/cache"),
			i = e("base/util"),
			s = e("template"),
			o = new Object;
		return o.defaults = {
			type: 0,
			offset: 0,
			limit: 500,
			total: 0,
			interval: 3,
			dimension: [3, 1],
			mode: 0,
			swiper: null,
			autoplay_speed: 4,
			current: 0,
			has_load: !1,
			has_stopped: !1,
			has_left: !1,
			height: 180,
			head: "images/default/avatar.png",
			welcome: [{
				id: 0,
				name: "微现场",
				head: "images/default/wx_avatar.jpg",
				type: 0,
				approve: 1,
				content: "欢迎使用腾讯微现场",
				approve_time: "2014-11-20 18:43:33",
				time: "2014-11-20 18:43:33",
				fontsize: 55,
				index: 0
			}, {
				id: 1,
				name: "微现场",
				head: "images/default/wx_avatar.jpg",
				type: 0,
				approve: 1,
				content: "微信扫描二维码发送消息，通过后台审核后即可上墙啦",
				approve_time: "2014-11-20 18:43:33",
				time: "2014-11-20 18:43:33",
				fontsize: 45,
				index: 1
			}]
		}, o.collection = Array(), o.images = Array(), o.texts = Array(), o.init = function(e) {
			var n = this,
				o = function() {
					r.get("WallMsg", {
						offset: n.defaults.offset,
						limit: n.defaults.limit
					}).done(function(e) {
						if (!e.data.data.length) {
							$(".message-loading-con").addClass("hide"), n.defaults.has_load = !0, n.redraw("next"), n.interval(), n.defaults.type == 0 && n.defaults.offset == 0 && (n.defaults.welcome[0].height = n.defaults.height, n.defaults.welcome[1].height = n.defaults.height, n.defaults.swiper.appendSlide(s(t.path + "/message/item", n.defaults.welcome[0])), n.defaults.swiper.appendSlide(s(t.path + "/message/item", n.defaults.welcome[1])));
							return
						}
						n.defaults.total = e.data.count;
						var r = e.data.data;
						for (var u = 0; u < r.length; u++) r[u].index = n.defaults.offset, r[u].head = i.getHead(r[u], t.model.data, function(e, t) {
							n.collection[e].head = t, $("#userhead_" + e).attr("src", t)
						}), t.model.data.anonymous ? r[u].anonymous = 1 : r[u].anonymous = 0, n.collection.push(r[u]), r[u].type == 1 ? n.images.push(r[u]) : (r[u].fontsize = i.ajustFontsize(r[u].content), r[u].content = i.getEmo(r[u].content), n.texts.push(r[u])), r[u].name = i.getEmo(r[u].name), n.defaults.offset++;
						var a = parseInt(n.defaults.offset / n.defaults.total * 100);
						n.setProgressBar(a), o()
					})
				};
			o()
		}, o.interval = function() {
			var e = this,
				n = function() {
					e.sync = window.setTimeout(function() {
						n()
					}, e.defaults.interval * 1e3), e.defaults.has_left || r.get("WallMsg", {
						offset: e.defaults.offset,
						limit: e.defaults.limit
					}).done(function(n) {
						if (!n.data.data.length && !n.data.insert.length) return;
						e.defaults.total = n.data.count;
						var r = n.data.data;
						for (var s = 0; s < r.length; s++) r[s].head = i.getHead(r[s], t.model.data, function(t, n) {
							e.collection[t].head = n, $("#userhead_" + t).attr("src", n)
						}), t.model.data.anonymous ? r[s].anonymous = 1 : r[s].anonymous = 0, r[s].type == 1 ? e.images.push(r[s]) : (r[s].fontsize = i.ajustFontsize(r[s].content), r[s].content = i.getEmo(r[s].content), e.texts.push(r[s])), r[s].name = i.getEmo(r[s].name), e.collection.push(r[s]), e.defaults.offset++;
						var o = n.data.insert;
						for (var s = 0; s < o.length; s++) o[s].head = i.getHead(o[s], t.model.data), t.model.data.anonymous ? o[s].anonymous = 1 : o[s].anonymous = 0, o[s].fontsize = i.ajustFontsize(o[s].content), o[s].content = i.getEmo(o[s].content), o[s].name = i.getEmo(o[s].name), e.insert(o[s])
					})
				};
			n()
		}, o.insert = function(e) {
			var t = this,
				n = null;
			t.defaults.mode ? n = $(t.defaults.swiper.activeSlide()).find(".detail").data("index") || 0 : n = $(t.defaults.swiper.activeSlide()).find(".item").data("index") || 0, t.collection.splice(n + t.defaults.dimension[t.defaults.mode], 1, e)
		}, o.setProgressBar = function(e) {
			$(".message-loading-progress-bar").css({
				width: e + "%"
			}), $(".message-loading-progress-bar").html(e + "%")
		}, o._calcFontSize = function() {}, o.actions = function(e) {
			var t = this;
			switch (e) {
			case "backward":
				t.stopAutoPlay(), t.redraw("top"), t.defaults.swiper.swipeTo(0), t.startAutoPlay();
				break;
			case "step-backward":
				t.stopAutoPlay(), t.redraw("prev"), t.defaults.swiper.swipePrev(!0), t.startAutoPlay();
				break;
			case "play":
				t.defaults.has_stopped ? (t.defaults.has_stopped = !1, t.startAutoPlay()) : (t.stopAutoPlay(), t.defaults.has_stopped = !0);
				break;
			case "step-forward":
				t.stopAutoPlay(), t.redraw("next"), t.defaults.swiper.swipeNext(!0), t.startAutoPlay();
				break;
			case "forward":
				t.stopAutoPlay(), t.redraw("bottom"), t.defaults.swiper.swipeTo(t.defaults.swiper.slides.length - 1), t.startAutoPlay()
			}
		}, o.startAutoPlay = function() {
			var e = this;
			e.defaults.swiper && !e.defaults.has_stopped && (e.autoplay = window.setInterval(function() {
				e.play()
			}, e.defaults.autoplay_speed * 1e3))
		}, o.stopAutoPlay = function() {
			var e = this;
			e.defaults.swiper && e.autoplay && (clearTimeout(e.autoplay), e.autoplay = null)
		}, o.play = function() {
			var e = this;
			e.defaults.has_load && (e.redraw("next"), e.defaults.swiper.swipeNext(!0))
		}, o.setCurrentSwiper = function(e, t) {
			var n = this;
			t = t || 0, n.stopAutoPlay(), n.defaults.swiper = e, n.redraw("switch", t), n.startAutoPlay()
		}, o.redraw = function(e, n) {
			var r = this;
			if (r.defaults.offset == 0) return;
			if (r.defaults.type == 0) {
				switch (e) {
				case "prev":
					if (r.defaults.mode) var i = $(r.defaults.swiper.activeSlide()).find(".detail").data("index") || 0;
					else var i = $(r.defaults.swiper.activeSlide()).find(".item").data("index") || 0;
					var o = r.defaults.swiper.activeIndex % r.defaults.dimension[r.defaults.mode] + r.defaults.dimension[r.defaults.mode];
					break;
				case "next":
					if (r.defaults.mode) var i = $(r.defaults.swiper.activeSlide()).find(".detail").data("index") || 0;
					else var i = $(r.defaults.swiper.activeSlide()).find(".item").data("index") || 0;
					var o = r.defaults.swiper.activeIndex % r.defaults.dimension[r.defaults.mode];
					break;
				case "top":
					var i = 0,
						o = 0;
					break;
				case "bottom":
					var i = r.collection.length - 1,
						o = r.defaults.dimension[r.defaults.mode] * 2 - 1;
					break;
				case "switch":
					if (r.defaults.mode == 1) var i = n;
					else var i = n - 2;
					var o = 0
				}
				r.defaults.swiper.removeAllSlides();
				for (var u = i - o; u < i - o + r.defaults.dimension[r.defaults.mode] * 2; u++) {
					var a = r.collection[u];
					if (!a) {
						if (!t.model.data.interval) continue;
						var f = u % r.collection.length;
						f < 0 && (f += r.collection.length), a = r.collection[f], a.index = f
					} else a.index = u;
					r.defaults.mode ? (a.height = r.defaults.height * 3 + 40, r.defaults.swiper.appendSlide(s(t.path + "/message/detail", a))) : (a.height = r.defaults.height, r.defaults.swiper.appendSlide(s(t.path + "/message/item", a)))
				}
				r.defaults.swiper.swipeTo(o, 0, !1)
			} else {
				switch (e) {
				case "prev":
					var i = $(r.defaults.swiper.activeSlide()).find(".image").data("index") || 0,
						o = r.defaults.swiper.activeIndex % 1 + 1;
					break;
				case "next":
					var i = $(r.defaults.swiper.activeSlide()).find(".image").data("index") || 0,
						o = r.defaults.swiper.activeIndex % 1;
					break;
				case "top":
					var i = 0,
						o = 0;
					break;
				case "bottom":
					var i = r.images.length - 1,
						o = 1;
				case "switch":
					var i = n,
						o = 0
				}
				r.defaults.swiper.removeAllSlides();
				for (var u = i - o; u < i - o + 2; u++) {
					var a = r.images[u];
					if (!a) {
						if (!t.model.data.interval) continue;
						var f = u % r.images.length;
						f < 0 && (f += r.images.length), a = r.images[f], a.index = f
					} else a.index = u;
					r.defaults.swiper.appendSlide(s(t.path + "/image/detail", a)), r.setImgPosition(a)
				}
				r.defaults.swiper.swipeTo(o, 0, !1)
			}
		}, o.setImgPosition = function(e) {
			var t = $(".image .body").width(),
				n = $(".image .body").height(),
				r = function() {
					var r = {};
					if (i.width / i.height >= t / n) {
						var s = i.height / i.width * t;
						r.top = (n - s) / 2 + "px", r.width = t + "px"
					} else {
						var o = i.width / i.height * n;
						r.left = (t - o) / 2 + "px", r.height = n + "px"
					}
					$("#FullImg_" + e.index).css(r)
				},
				i = new Image;
			i.src = e.content;
			if (i.complete) {
				r();
				return
			}
			i.onload = function() {
				r()
			}
		}, o.unload = function() {
			var e = this;
			e.defaults.mode = 0, e.defaults.has_left = !0, o.stopAutoPlay()
		}, o
	}), define("controller/message", ["require", "base/controller", "base/global", "base/util", "base/directive", "base/remote", "model/message", "template", "vendor/swiper"], function(e) {
		"use strict";
		var t = e("base/controller"),
			n = e("base/global"),
			r = e("base/util"),
			i = e("base/directive"),
			s = e("base/remote"),
			o = e("model/message"),
			u = e("template"),
			a = e("vendor/swiper"),
			f, l, c = 1,
			h, p, d, v = {
				container: null,
				offset: 0,
				index: 0,
				mode: 0,
				swiper: 0,
				head: "images/default/avatar.png"
			},
			m = new Object;
		return m.render = function() {
			var e = this;
			if (!n.isActive("wall")) {
				r.alert({
					path: n.path,
					content: {
						message: "大屏幕上墙功能没有开启"
					}
				});
				return
			}
			$(".viewport").html(f), o.defaults.autoplay_speed = n.model.data.scrolltime || o.defaults.autoplay_speed, o.defaults.type = 0, n.highlight("message"), o.defaults.has_load ? ($(".message-loading-con").addClass("hide"), o.defaults.has_left = !1) : o.init("message"), p = new a("#container_list", {
				speed: 500,
				slidesPerView: 3,
				slidesPerGroup: 3,
				autoplayStopOnLast: !0,
				simulateTouch: !1,
				mode: "vertical"
			}), d = new a("#container_detail", {
				speed: 500,
				autoplayStopOnLast: !0,
				simulateTouch: !1
			}), o.setCurrentSwiper(p, o.defaults.current), e.bindEvent(), e.resize()
		}, m.setSwiperList = function(e) {
			var t = this;
			o.defaults.mode = 0, $("#container_detail").addClass("hide"), $("#container_list").removeClass("hide"), o.setCurrentSwiper(p, e)
		}, m.setSwiperDetail = function(e) {
			var t = this;
			o.defaults.mode = 1, $("#container_list").addClass("hide"), $("#container_detail").removeClass("hide"), o.setCurrentSwiper(d, e)
		}, m.changeMessageMode = function(e, t) {
			e == 0 ? m.setSwiperList(t) : m.setSwiperDetail(t)
		}, m.bindEvent = function() {
			var e = this;
			$("#container_list").on("click", ".item", function() {
				var t = $(this).data("index");
				e.changeMessageMode(1, t)
			}), $("#container_detail").on("click", ".detail .close", function() {
				var t = $(this).parents(".detail").data("index");
				e.changeMessageMode(0, t)
			}), $("#mask, #mask_btn, #mask .close").on("click", function() {
				c ? ($("#mask").removeClass("hide"), c = 0) : ($("#mask").addClass("hide"), c = 1)
			}), $(window).on("resize", function() {
				e.resize()
			}), i.register({
				name: "message-action",
				behavior: function() {
					var e = $(this).attr("message-action");
					o.actions(e);
					if (e != "play") return;
					o.defaults.has_stopped ? $(this).find("i").removeClass("icon-pause").addClass("icon-play") : $(this).find("i").removeClass("icon-play").addClass("icon-pause")
				}
			}), s.register({
				name: "message-switch",
				behavior: function() {
					if (o.defaults.mode == 0) {
						var t = $(o.defaults.swiper.activeSlide()).find(".item").data("index");
						e.changeMessageMode(1, t)
					} else {
						var n = $(o.defaults.swiper.activeSlide()).find(".detail").data("index");
						e.changeMessageMode(0, t)
					}
				}
			}), s.register({
				name: "message-action",
				behavior: function(e) {
					o.actions(e.action)
				}
			})
		}, m.resize = function() {
			var e = $(".viewport").height() - 40;
			$(".message-con").height(e), o.defaults.height = (e - 60) / 3, $("#message .item").height(o.defaults.height)
		}, m.unload = function() {
			o.unload()
		}, m.init = function(e) {
			t.register({
				name: "message",
				before: function() {
					n.prepareData(e), $.when(n.checkLogin()).done(function() {
						$.when(n.getInfo()).done(function() {
							n.ready && n.render()
						})
					})
				},
				controller: function(e) {
					n.ready && (f = u(n.path + "/message/layout", n.model.data), l = u(n.path + "/message/sidebar", n.model.data), m.render())
				},
				unload: function() {
					m.unload()
				}
			}), t.get("message").controller()
		}, m
	}), define("model/lottery", ["require", "base/global", "base/hosts", "base/cache", "base/util", "template"], function(e) {
		var t = e("base/global"),
			n = e("base/hosts"),
			r = e("base/cache"),
			i = e("base/util"),
			s = e("template"),
			o = new Object;
		return o.defaults = {
			ready: !1,
			pool: null,
			award: null,
			single: !1,
			quantity: 1,
			head: "images/default/avatar.png"
		}, o.history_list = Array(), o.awards_list = Array(), o.getUserList = function(e) {
			var n = this;
			r.get("LotteryUserList").done(function(r) {
				function a() {}
				if (!r.data.list.length) {
					e();
					return
				}
				var s = r.data.list;
				n.user_list = s;
				for (var o = 0, u = s.length; o < u; o++) s[o].index = o, s[o].head = i.getHead(s[o], t.model.data), s[o].name = i.getEmo(s[o].name);
				e && e()
			})
		}, o.getAwardsList = function(e) {
			var t = this;
			r.get("AwardList").done(function(n) {
				if (!n.data.length) return;
				t.awards_list = n.data, e()
			})
		}, o.getHistoryList = function(e) {
			var n = this;
			r.get("WinnerHistory").done(function(r) {
				n.history_list = r.data.winners;
				for (var s in n.history_list) for (var o in n.history_list[s].winner) n.history_list[s].winner[o].head = i.getHead(n.history_list[s].winner[o], t.model.data), n.history_list[s].winner[o].name = i.getEmo(n.history_list[s].winner[o].name);
				setTimeout(e, 1e3)
			})
		}, o.draw = function() {
			var e = this;
			e.result = null, r.get("Draw", {
				award_id: e.defaults.award,
				quantity: e.defaults.quantity
			}).done(function(n) {
				e.result = n;
				if (e.result.code == 0) for (var r = 0, s = e.result.data.winners.length; r < s; r++) e.result.data.winners[r].head = i.getHead(e.result.data.winners[r], t.model.data), e.result.data.winners[r].name = i.getEmo(e.result.data.winners[r].name)
			}).fail(function() {
				e.result = null
			})
		}, o
	}), !
	function(e, t) {
		typeof define == "function" && define.amd ? define("vendor/selector", ["jquery"], t) : t(e.jQuery)
	}(this, function(e) {
		"use strict";

		function r(r, i) {
			this.element = e(r), this.options = e.extend({}, n, i), this.target = null, this._name = t, this.init(), this.addEventListener()
		}
		var t = "WXC_Selector",
			n = {
				opened: !1,
				empty: !0
			};
		r.prototype = {
			init: function() {
				var e = this;
				e.element.empty(), this.options.empty === !1 ? (e.element.html('<a class="select-btn"><span>' + this.options.text + '</span> <i class="select-btn-arrow icon icon-arrow"></i></a>'), e.element.append('<ul class="select-options hide">' + this.options.optionsHTML + "</ul>")) : (this.options.emptyText = this.options.emptyText || this.options.text, e.element.html('<a class="select-btn"><span>' + this.options.emptyText + "</span></a>"))
			},
			addEventListener: function() {
				var t = this;
				t.element.on("click", ".select-btn", function() {
					e(".select-options").addClass("hide"), t.options.opened ? (t.element.find(".select-btn i").removeClass("rotate"), t.element.find(".select-options").addClass("hide"), t.options.opened = !1) : (t.element.find(".select-btn i").addClass("rotate"), t.element.find(".select-options").removeClass("hide"), t.options.opened = !0)
				}), t.element.on("click", ".options", function() {
					t.target = e(this).data("target"), t.element.find(".select-btn span").text(e(this).data("option")), t.element.find(".select-btn i").removeClass("rotate"), t.element.find(".select-options").addClass("hide"), t.options.opened = !1, t.options.callback(t.target)
				})
			},
			update: function(t) {
				var n = this;
				n.options = e.extend({}, n.options, t), n.init()
			},
			setTarget: function(t) {
				var n = this,
					r = n.element.find(".options");
				for (var i = 0; i < r.length; i++) if (e(r[i]).data("target") == t) {
					e(r[i]).trigger("click");
					break
				}
			}
		}, e.fn[t] = function(n) {
			return this.each(function() {
				e(this).data("plugin_" + t) || e(this).data("plugin_" + t, new r(this, n))
			})
		}
	}), define("controller/lottery", ["require", "base/controller", "base/global", "base/util", "base/remote", "template", "model/lottery", "vendor/swiper", "vendor/selector", "vendor/modal"], function(e) {
		"use strict";

		function g(e, t) {
			return Math.floor(Math.random() * (t - e) + e)
		}
		var t = e("base/controller"),
			n = e("base/global"),
			r = e("base/util"),
			i = e("base/remote"),
			s = e("template"),
			o = e("model/lottery"),
			u = e("vendor/swiper"),
			a = e("vendor/selector"),
			f = e("vendor/modal"),
			l, c, h, p, d, v = {
				item: {
					head: "images/default/avatar.png",
					name: "......"
				},
				slot_num: 1,
				status: 0,
				interval: null,
				swiper: null,
				historyClosed: !0,
				timer: null
			},
			m = new Object;
		return m.render = function() {
			var e = this;
			if (!n.isActive("lottery")) {
				r.alert({
					path: n.path,
					content: {
						message: "大屏幕抽奖功能没有开启"
					}
				});
				return
			}
			n.highlight("lottery"), $(".viewport").html(l), e.bindEvent(), o.getAwardsList(e.rendorAwardsList), o.getUserList(), e.rendorLotteryBtn()
		}, m.rendorLotteryBtn = function() {
			var e = window.setInterval(function() {
				o.awards_list && ($(".lottery-btn").html("开始抽奖"), $(".lottery-btn").addClass("ready"), v.status = "ready", clearInterval(e))
			}, 50)
		}, m.rendorAwardsList = function() {
			var e = h.data("plugin_WXC_Selector"),
				t = s(n.path + "/lottery/awards", {
					list: o.awards_list
				});
			e.update({
				empty: !1,
				optionsHTML: t
			})
		}, m.renderQuantityList = function(e) {
			o.defaults.quantity = 0;
			var t = d.data("plugin_WXC_Selector"),
				r = o.getRemain(o.defaults.award);
			if (typeof r == "undefined" || typeof o.user_list == "undefined") return;
			e && r > o.user_list.length && (r = o.user_list.length);
			if (r === 0) t.update({
				empty: !0,
				emptyText: "已抽完"
			});
			else {
				var i = s(n.path + "/lottery/quantity", {
					list: new Array(r)
				});
				t.update({
					empty: !1,
					optionsHTML: i
				})
			}
		}, m.renderLotteryResult = function() {
			$(".slot-box-wrapper").empty();
			if (!o.result) {
				$(".slot-box-wrapper").append(s(n.path + "/lottery/slot", {
					item: v.item,
					inner: !1
				})), r.alert({
					path: n.path,
					content: {
						title: "抽奖失败!",
						message: "由于网络原因抽奖失败，请去后台校验数据"
					}
				});
				return
			}
			if (o.result.code) {
				for (var e = 0; e < v.slot_num; e++) $(".slot-box-wrapper").append(s(n.path + "/lottery/slot", {
					item: v.item,
					inner: !1
				}));
				r.alert({
					path: n.path,
					content: {
						message: o.result.message
					}
				})
			} else {
				var t = $(".slot-box-item"),
					i = o.result.data.winners;
				for (var u = 0; u < i.length; u++) i[u].head || (i[u].head = r.getHead(i[u], n.model.data)), $(".slot-box-wrapper").append(s(n.path + "/lottery/slot", {
					item: i[u],
					inner: !1
				}));
				setTimeout(function() {
					$(".slot-box-wrapper").find(".slot-avatar").addClass("win")
				}, 100), setTimeout(function() {
					if ($(".slot-box").height() + 1 < $(".slot-box")[0].scrollHeight) {
						var e = $(".slot-box"),
							t = $(".slot-box-wrapper"),
							n = $(".slot-box-wrapper").clone(),
							r = 20;
						n.addClass("clone"), e.append(n);
						var i = function() {
								var n = e.scrollTop(),
									r = t.height();
								n >= r ? e.scrollTop(0) : e.scrollTop(e.scrollTop() + 1)
							};
						v.timer = setInterval(i, r), e[0].onmouseover = function() {
							clearInterval(v.timer)
						}, e[0].onmouseout = function() {
							v.timer = setInterval(i, r)
						}
					}
				}, 1e3)
			}
		}, m.renderHistory = function() {
			$("#history .modal-body").empty().append(s(n.path + "/lottery/list", {
				list: o.history_list
			})), v.swiper = new u("#history-swiper-con", {
				speed: 500,
				simulateTouch: !1,
				loop: !0
			})
		}, m.changeAward = function(e) {
			v.slot_num = o.defaults.quantity;
			for (var t in o.awards_list) if (e && o.awards_list[t].id == e) {
				if (!o.awards_list[t].image || o.awards_list[t].image == "") o.awards_list[t].image = "images/default/gift.png";
				$(".award-img-wrapper").html('<img src="' + o.awards_list[t].image + '" />');
				break
			}
			if (!v.slot_num) return;
			clearInterval(v.timer), $(".slot-box").scrollTop(0), $(".slot-box-wrapper.clone").remove(), $(".slot-box-wrapper").empty();
			if (o.defaults.single) $(".slot-box-wrapper").append(s(n.path + "/lottery/slot", {
				item: v.item,
				inner: !1
			}));
			else for (var t = 0; t < v.slot_num; t++) $(".slot-box-wrapper").append(s(n.path + "/lottery/slot", {
				item: v.item,
				inner: !1
			}))
		}, m.changePool = function() {
			o.getUserList(m.renderQuantityList)
		}, m.startAnimate = function() {
			var e = o.user_list,
				t = g(0, e.length),
				r = 0,
				i = $(".slot-box-item");
			v.interval = window.setInterval(function() {
				for (var o = 0; o < v.slot_num; o++) {
					var u = (t + r + o) % e.length;
					e[u].head || (e[u].head = v.item.head), i.eq(o).html(s(n.path + "/lottery/slot", {
						item: e[u],
						inner: !0
					}))
				}
				r++, r == e.length && (r = 0)
			}, 100), $(".lottery-btn").html("停止"), v.status = "result"
		}, m.stopAnimate = function() {
			clearInterval(v.interval), $(".lottery-btn").html("开始抽奖"), v.status = "ready"
		}, m.bindEvent = function() {
			var e = this;
			h = $("#award-selector").WXC_Selector({
				text: "请选择奖品类别",
				callback: function(t) {
					o.defaults.award = t, e.changeAward(o.defaults.award)
				}
			}), $("#lottery").on("click", ".minus", function() {
				o.defaults.quantity > 0 && (o.defaults.quantity -= 1), $("#lotteryNum").val(parseInt(o.defaults.quantity)), e.changeAward()
			}), $("#lottery").on("click", ".add", function() {
				o.defaults.quantity < 1e3 && (o.defaults.quantity += 1), $("#lotteryNum").val(parseInt(o.defaults.quantity)), e.changeAward()
			}), $("#lottery").on("blur", "#lotteryNum", function() {
				var e = parseInt($(this).val());
				/^[0-9]*$/.test(e) && e > 0 ? o.defaults.quantity = e : (r.alert({
					path: n.path,
					content: {
						message: "奖品数输入大于0的数字"
					}
				}), $(this).val(o.defaults.quantity))
			}), $(".controll-box").on("click", ".lottery-btn.ready", function() {
				switch (v.status) {
				case "ready":
					var t = o.user_list;
					if (o.defaults.award === null) {
						r.alert({
							path: n.path,
							content: {
								message: "请选择一个奖品"
							}
						});
						return
					}
					if (o.defaults.quantity == 0) {
						r.alert({
							path: n.path,
							content: {
								message: "请选择奖品数量"
							}
						});
						return
					}
					$(".slot-box-wrapper").removeClass("autoScroll"), e.startAnimate(), o.draw();
					break;
				case "result":
					e.stopAnimate(), e.renderLotteryResult()
				}
			}), $(".controll-box").on("click", ".lottery-history", function() {
				$("body").append(s(n.path + "/modal/winners"));
				var t = $("#history");
				t.modal({
					show: !0
				}), t.on("hidden.bs.modal", function(e) {
					e.target === this && t.remove()
				}), o.getHistoryList(e.renderHistory)
			}), $("body").on("click", ".winners-prev", function(e) {
				e.preventDefault(), v.swiper.swipePrev()
			}), $("body").on("click", ".winners-next", function(e) {
				e.preventDefault(), v.swiper.swipeNext()
			}), i.register({
				name: "lottery-config",
				behavior: function(e) {
					switch (e.target) {
					case "award":
						var t = h.data("plugin_WXC_Selector");
						t.setTarget(e.value);
						break;
					case "pool":
						var t = p.data("plugin_WXC_Selector");
						t.setTarget(e.value);
						break;
					case "quantity":
						var t = d.data("plugin_WXC_Selector");
						t.setTarget(e.value)
					}
				}
			}), i.register({
				name: "lottery-draw",
				behavior: function() {
					$(".lottery-btn.ready").trigger("click")
				}
			}), i.register({
				name: "lottery-history",
				behavior: function() {
					v.historyClosed ? ($(".lottery-history").trigger("click"), v.historyClosed = !1) : ($(".close").trigger("click"), v.historyClosed = !0)
				}
			})
		}, m.init = function(e) {
			var r = this;
			t.register({
				name: "lottery",
				before: function() {
					n.prepareData(e), $.when(n.checkLogin()).done(function() {
						$.when(n.getInfo()).done(function() {
							n.render()
						})
					})
				},
				controller: function(e) {
					n.ready && (l = s(n.path + "/lottery/layout", n.model.data), m.render())
				},
				unload: function() {
					r.stopAnimate()
				}
			}), t.get("lottery").controller()
		}, m
	}), define("controller/image", ["require", "base/controller", "base/global", "base/util", "base/directive", "base/remote", "model/message", "template", "vendor/swiper"], function(e) {
		"use strict";
		var t = e("base/controller"),
			n = e("base/global"),
			r = e("base/util"),
			i = e("base/directive"),
			s = e("base/remote"),
			o = e("model/message"),
			u = e("template"),
			a = e("vendor/swiper"),
			f, l, c = 1,
			h, p, d = {
				container: null,
				offset: 0,
				index: 0,
				mode: 0,
				head: "images/default/avatar.png"
			},
			v = new Object;
		return v.render = function() {
			var e = this;
			if (!n.isActive("wall")) {
				r.alert({
					path: n.path,
					content: {
						message: "大屏幕上墙功能没有开启"
					}
				});
				return
			}
			o.defaults.type = 1, o.defaults.autoplay_speed = 10, n.highlight("image"), $(".viewport").html(f), o.defaults.has_load ? ($(".message-loading-con").addClass("hide"), o.defaults.has_left = !1) : o.init("image"), p = new a("#container_image", {
				speed: 500,
				autoplayStopOnLast: !0,
				simulateTouch: !1
			}), o.setCurrentSwiper(p), e.bindEvent()
		}, v.bindEvent = function() {
			var e = this;
			i.register({
				name: "message-action",
				behavior: function() {
					var e = $(this).attr("message-action");
					o.actions(e);
					if (e != "play") return;
					o.defaults.has_stopped ? $(this).find("i").removeClass("icon-pause").addClass("icon-play") : $(this).find("i").removeClass("icon-play").addClass("icon-pause")
				}
			}), s.register({
				name: "message-action",
				behavior: function(e) {
					o.actions(e.action)
				}
			})
		}, v.unload = function() {
			o.unload()
		}, v.init = function(e) {
			t.register({
				name: "image",
				before: function() {
					n.prepareData(e), $.when(n.checkLogin()).done(function() {
						$.when(n.getInfo()).done(function() {
							n.ready && n.render()
						})
					})
				},
				controller: function(e) {
					n.ready && (f = u(n.path + "/image/layout", n.model.data), v.render())
				},
				unload: function() {
					clearTimeout(d.addone), v.unload()
				}
			}), t.get("image").controller()
		}, v
	}), define("model/signin", ["require", "base/global", "base/hosts", "base/cache", "base/util", "template"], function(e) {
		var t = e("base/global"),
			n = e("base/hosts"),
			r = e("base/cache"),
			i = e("base/util"),
			s = e("template"),
			o, u = {};
		return u.defaults = {
			view_offset: 0,
			offset: 0,
			limit: 5,
			interval: 2,
			head: "images/default/avatar.png"
		}, u.collection = [], u.firstloaded = !1, u.getType = function(e) {
			r.get("SigninType", {}).done(function(t) {
				var n = t.data;
				n.screen_type == 2 && e.brand(), n.screen_type == 1 && e.normal()
			})
		}, u.getalluser = function(e) {
			var n = this;
			n.collection = [], r.get("SigninUserList", {}).done(function(r) {
				var s = r.data;
				for (var o = 0; o < s.length; o++) s.length - o < 48 && (s[o].head = i.getHead(s[o], t.model.data)), n.collection.push(s[o]), n.defaults.offset++;
				n.firstloaded = !0, e && e()
			})
		}, u.getuser = function() {
			var e = this;
			e.getuserInterval = setInterval(function() {
				e.getusers()
			}, e.defaults.interval * 1e3)
		}, u.stopgetuser = function() {
			var e = this;
			e.collection = [], e.offset = 0, e.view_offset = 0, clearInterval(e.getuserInterval)
		}, u.getusers = function() {
			var e = this;
			r.get("SigninUserList", {
				limit: e.defaults.limit,
				offset: e.defaults.offset
			}).done(function(n) {
				var r = n.data;
				for (var s = 0; s < r.length; s++) r[s].head = i.getHead(r[s], t.model.data), e.collection.push(r[s]), e.defaults.offset++
			})
		}, u
	}), define("controller/signin", ["require", "base/controller", "base/global", "base/util", "base/hosts", "base/directive", "base/remote", "model/signin", "template", "vendor/swiper"], function(e) {
		"use strict";
		var t = e("base/controller"),
			n = e("base/global"),
			r = e("base/util"),
			i = e("base/hosts"),
			s = e("base/directive"),
			o = e("base/remote"),
			u = e("model/signin"),
			a = e("template"),
			f = e("vendor/swiper"),
			l, c = 1,
			h = {
				item_num: 0,
				interval: 2,
				top: 0
			},
			p = new Object;
		return p.rendorSigninItemInit = function() {
			var e = this;
			if (!$(".signin-content").length) return;
			$(".signin-content").html(""), u.getalluser(function() {
				var t = u.collection.length;
				if (t > 0) {
					for (var r = t - 48 > 0 ? t - 48 : 0; r < t; r++) $(".signin-content").append(a(n.path + "/signin/item", u.collection[r]));
					var i = t;
					$(".signin-content").scrollTop($(".signin-content")[0].scrollHeight), setTimeout(function() {
						$(".signin-content").find(".signin-item").addClass("signin-item-show"), $(".signin-header-num").text(i)
					}, 100)
				}
				u.defaults.view_offset = u.collection.length, e.rendorSigninItemNew()
			})
		}, p.rendorSigninItemNew = function() {
			var e = this;
			u.getuser(), e.rendorInterval = setInterval(function() {
				u.collection[u.defaults.view_offset] && ($(".signin-content").append(a(n.path + "/signin/item", u.collection[u.defaults.view_offset])), setTimeout(function() {
					$(".signin-content").find(".signin-item").addClass("signin-item-show"), $(".signin-header-num").text(u.collection.length)
				}, 300), u.defaults.view_offset++, $(".signin-content").scrollTop($(".signin-content")[0].scrollHeight))
			}, h.interval * 1e3)
		}, p.generateQrcodeUrl = function() {
			var e = n.model.params.campaign_id,
				t;
			$.ajax({
				type: "POST",
				async: !1,
				url: i.urls.getSigninGR + "?campaign_id=" + e,
				dataType: "json",
				data: {},
				error: function(e) {},
				success: function(e) {
					if (e.code) {
						r.alert({
							path: n.path,
							content: {
								message: "活动已结束"
							}
						});
						return
					}
					t = e.data.g_r
				}
			});
			var s = window.location.host,
				o = encodeURIComponent(i.hostname + "/live/client/index.html#/signin?campaign_id=" + e),
				u = i.hostname + "/common/getqrcodeimage?level=3&size=20&content=" + o + "&name=signin";
			return u
		}, p.bindEvent = function() {
			$(".signin-qrcode, .signin-qrcode-btn").on("click", function() {
				c ? ($(".signin-qrcode").removeClass("hide"), c = 0) : ($(".signin-qrcode").addClass("hide"), c = 1)
			})
		}, p.unload = function() {
			var e = this;
			u.stopgetuser(), clearInterval(e.rendorInterval)
		}, p.render = function() {
			var e = this;
			if (!n.isActive("register") && !n.isActive("signin")) {
				r.alert({
					path: n.path,
					content: {
						message: "大屏幕签到墙功能没有开启"
					}
				});
				return
			}
			u.getType({
				normal: function() {
					e.rendorSigninItemInit(), e.bindEvent()
				},
				brand: function(e) {
					window.location.hash = "#" + n.model.params.campaign_id + "/brand"
				}
			}), n.highlight("signin");
			var t = e.generateQrcodeUrl(),
				i = a(n.path + "/signin/layout", {
					item_num: h.item_num,
					img_src: t
				});
			$(".viewport").html(i), u.defaults.offset = 0
		}, p.getSigninType = function() {}, p.init = function(e) {
			t.register({
				name: "signin",
				before: function() {
					n.prepareData(e), $.when(n.checkLogin()).done(function() {
						$.when(n.getInfo()).done(function() {
							n.render()
						})
					})
				},
				controller: function(e) {
					n.ready && p.render()
				},
				unload: function() {
					p.unload()
				}
			}), t.get("signin").controller()
		}, p
	}), define("model/vote", ["require", "base/global", "base/hosts", "base/cache", "base/util", "model/message", "template"], function(e) {
		var t = e("base/global"),
			n = e("base/hosts"),
			r = e("base/cache"),
			i = e("base/util"),
			s = e("model/message"),
			o = e("template"),
			u = new Object;
		return u.defaults = {
			current_id: null,
			order: !1,
			total: 0,
			colors: ["#f16b67", "#59d0fc", "#57f37b", "#fed65c", "#42eecb", "#fb9c50", "#E95A7F", "#A4FE5C", "#EB83F4", "#81F9FD"]
		}, u.vote_list = Array(), u.collection = Object(), u.getVoteList = function(e) {
			var t = this;
			t.vote_list = [], r.get("VoteList").done(function(n) {
				t.vote_list = n.data, e && e()
			})
		}, u.getVoteDetail = function(e) {
			var t = this;
			t.collection = [], r.get("VoteDetail", {
				vote_id: t.defaults.current_id
			}).done(function(n) {
				var r = n.data.list,
					i = 0,
					s = 0;
				for (var o = 0; o < r.length; o++) i += r[o].count, s < r[o].count && (s = r[o].count);
				for (var o = 0; o < r.length; o++) r[o].percent = parseInt(r[o].count / i * 100) || 0, r[o].scale = parseInt(r[o].count / s * 100) || 0, r[o].color = u.defaults.colors[o % 10];
				var a = function(e) {
						return function(t, n) {
							var r, i;
							if (typeof t == "object" && typeof n == "object" && t && n) return r = t[e], i = n[e], r === i ? 0 : r < i ? -1 : 1;
							throw "error"
						}
					};
				t.defaults.order && (r = r.sort(a("count")), r = r.reverse()), t.collection[t.defaults.current_id] = r, u.defaults.total = i, e && e()
			})
		}, u
	}), define("controller/vote", ["require", "base/controller", "base/global", "base/util", "base/hosts", "base/directive", "base/remote", "model/vote", "template", "vendor/swiper"], function(e) {
		"use strict";
		var t = e("base/controller"),
			n = e("base/global"),
			r = e("base/util"),
			i = e("base/hosts"),
			s = e("base/directive"),
			o = e("base/remote"),
			u = e("model/vote"),
			a = e("template"),
			f = e("vendor/swiper"),
			l = {
				swiper: null,
				interval_time: 3,
				interval: null,
				maxColumnNum: 8,
				width: 0,
				slide_index: 0,
				isMaskClosed: 1
			},
			c = new Array,
			h = new Array,
			p = new Array,
			d = new Array,
			v = new Array,
			m = new Array,
			g = new Array,
			y = new Array,
			b = 0,
			w = !1,
			E = !1,
			S = !0,
			x = new Object;
		return x.voteInit = function() {
			var e = this;
			l.width = $(".vote-scrollbar-move").width(), u.defaults.current_id = u.vote_list[l.slide_index].vote_id, u.getVoteDetail(function() {
				x.refresh()
			}), l.interval = window.setInterval(function() {
				u.getVoteDetail(function() {
					x.refresh()
				})
			}, l.interval_time * 1e3)
		}, x.refresh = function() {
			var e = u.collection[u.defaults.current_id],
				t = e.length;
			if (t > l.maxColumnNum) {
				var r = l.width * (t / l.maxColumnNum);
				$(".vote-scrollbar-move").width(r)
			}
			var i = $(".vote-scrollbar-move").height() * .85 - 50;
			$("#vote-" + u.defaults.current_id).find(".vote-title-num").html(u.defaults.total);
			for (var s = 0; s < e.length; s++) {
				var o = e[s];
				o.height = i * o.scale / 100, o.vote_id = u.defaults.current_id, $("#vote-column-" + o.item_id).length ? ($("#vote-column-" + o.item_id).find(".vote-column-bar").height(o.height), $("#vote-column-" + o.item_id).find(".vote-column-count").css({
					bottom: o.height + 15
				}).html(a(n.path + "/vote/count", {
					item: o
				}))) : $("#vote-" + u.defaults.current_id + " .vote-scrollbar-move").append(a(n.path + "/vote/column", {
					item: o
				}))
			}
			setTimeout(function() {
				$("#vote-" + u.defaults.current_id + " .vote-scrollbar-move").empty();
				for (var t = 0; t < e.length; t++) {
					var r = e[t];
					r.height = i * r.scale / 100, r.vote_id = u.defaults.current_id, $("#vote-" + u.defaults.current_id + " .vote-scrollbar-move").append(a(n.path + "/vote/column", {
						item: r
					}))
				}
			}, 550)
		}, x.generateQrcodeUrl = function() {
			var e = n.model.params.campaign_id,
				t = encodeURIComponent(i.hostname + "/live/client/index.html#/vote?campaign_id=" + e),
				r = i.hostname + "/common/getqrcodeimage?level=3&size=20&content=" + t + "&name=vote";
			return r
		}, x.bindEvent = function() {
			var e = this;
			$("#vote").on("click", ".vote-prev", function(e) {
				e.preventDefault(), l.slide_index--, u.defaults.current_id = u.vote_list[l.slide_index].vote_id, $("#vote-" + u.defaults.current_id + " .vote-scrollbar-move").empty();
				var t = l.swiper;
				t.swipePrev(), t.activeIndex == 0 ? $(".vote-prev").hide() : $(".vote-prev").show(), t.activeIndex == t.slides.length - 1 ? $(".vote-next").hide() : $(".vote-next").show()
			}), $("#vote").on("click", ".vote-next", function(e) {
				e.preventDefault(), l.slide_index++, u.defaults.current_id = u.vote_list[l.slide_index].vote_id, $("#vote-" + u.defaults.current_id + " .vote-scrollbar-move").empty();
				var t = l.swiper;
				t.swipeNext(), t.activeIndex == 0 ? $(".vote-prev").hide() : $(".vote-prev").show(), t.activeIndex == t.slides.length - 1 ? $(".vote-next").hide() : $(".vote-next").show()
			}), $(".vote-qrcode, .vote-qrcode-btn").on("click", function() {
				l.isMaskClosed ? ($(".vote-qrcode").removeClass("hide"), l.isMaskClosed = 0) : ($(".vote-qrcode").addClass("hide"), l.isMaskClosed = 1)
			}), $(".vote-shade").on("click", ".vote-qrcode-big", function() {
				$(".vote-shade").hide()
			}), $(".order-switch").on("change", function() {
				$(this).prop("checked") ? u.defaults.order = !0 : u.defaults.order = !1
			})
		}, x.renderSwiper = function() {
			l.swiper = new f("#vote_list", {
				speed: 500,
				simulateTouch: !1,
				loop: !1
			}), l.swiper.slides.length > 1 && $(".vote-next").show()
		}, x.unload = function() {
			clearInterval(l.interval)
		}, x.render = function() {
			var e = this;
			if (!n.isActive("vote")) {
				r.alert({
					path: n.path,
					content: {
						message: "大屏幕投票功能没有开启"
					}
				});
				return
			}
			n.highlight("vote"), u.getVoteList(function() {
				if (u.vote_list.length == 0) {
					r.alert({
						path: n.path,
						content: {
							message: "未配置投票"
						}
					});
					return
				}
				var t = e.generateQrcodeUrl(),
					i = a(n.path + "/vote/layout", {
						list: u.vote_list,
						qrcode: t
					});
				$(".viewport").html(i), e.renderSwiper(), e.bindEvent(), e.voteInit()
			})
		}, x.init = function(e) {
			t.register({
				name: "vote",
				before: function() {
					n.prepareData(e), $.when(n.checkLogin()).done(function() {
						$.when(n.getInfo()).done(function() {
							n.render()
						})
					})
				},
				controller: function(e) {
					n.ready && x.render()
				},
				unload: function() {
					x.unload()
				}
			}), t.get("vote").controller()
		}, x
	}), define("model/brand", ["require", "base/global", "base/hosts", "base/cache", "base/util", "template"], function(e) {
		var t = e("base/global"),
			n = e("base/hosts"),
			r = e("base/cache"),
			i = e("base/util"),
			s = e("template"),
			o = {};
		return o.defaults = {
			offset: 0,
			limit: 5,
			interval: 2,
			head: "images/default/avatar.png"
		}, o.matrix = [], o.collection = [], o.getType = function(e) {
			r.get("SigninType", {}).done(function(t) {
				var n = t.data;
				n.screen_type == 2 && e.brand(), n.screen_type == 1 && e.normal()
			})
		}, o.getMatrix = function(e) {
			var t = this;
			r.get("BrandMatrix", {}).done(function(n) {
				t.matrix = n.data.screen_word_matrix, e && e()
			})
		}, o.getItemAll = function(e) {
			var n = this;
			n.collection = [], r.get("SigninUserList", {}).done(function(r) {
				var s = r.data;
				for (var o = 0; o < s.length; o++) s[o].head = i.getHead(s[o], t.model.data), n.collection.push(s[o]), n.defaults.offset++;
				e && e()
			})
		}, o.getItemNew = function() {
			var e = this;
			e.getUsersInterval = setInterval(function() {
				e.getUsers()
			}, e.defaults.interval * 1e3)
		}, o.getUsers = function() {
			var e = this;
			r.get("SigninUserList", {
				limit: e.defaults.limit,
				offset: e.defaults.offset
			}).done(function(n) {
				var r = n.data;
				for (var s = 0; s < r.length; s++) r[s].head = i.getHead(r[s], t.model.data), e.collection.push(r[s]), e.defaults.offset++
			})
		}, o.getUsers = function() {
			var e = this;
			r.get("SigninUserList", {
				limit: e.defaults.limit,
				offset: e.defaults.offset
			}).done(function(n) {
				var r = n.data;
				for (var s = 0; s < r.length; s++) r[s].head = i.getHead(r[s], t.model.data), e.collection.push(r[s]), e.defaults.offset++
			})
		}, o.stopGetUsers = function() {
			clearInterval(this.getUsersInterval)
		}, o
	}), define("controller/brand", ["require", "base/controller", "base/global", "base/util", "base/hosts", "base/directive", "base/remote", "model/brand", "template"], function(e) {
		"use strict";
		var t = e("base/controller"),
			n = e("base/global"),
			r = e("base/util"),
			i = e("base/hosts"),
			s = e("base/directive"),
			o = e("base/remote"),
			u = e("model/brand"),
			a = e("template"),
			f = {
				item_num: 0,
				interval: 5,
				top: 0
			},
			l = {},
			c = [],
			h, p, d, v, m, g, y, b, w, E = 0,
			S = 1;
		return l.main = function() {
			var e = this,
				t, n, r, i;
			u.getMatrix(function() {
				e.initCanvas(), p = u.matrix, d = p.length, t = e.getWidthNum(p), n = e.getHeightNum(p), m = parseInt($("#brand-canvas").css("width")), g = parseInt($("#brand-canvas").css("height")), r = m / t, i = g / n, r > i ? (v = i, y = (m - v * t) / 2, b = 0) : (v = r, y = 0, b = (g - v * n) / 2);
				for (var s = 0; s < d; s++) c[s] = !0;
				for (var s = 0; s < p.length; s++) {
					var o = p[s];
					h.fillRect(o.x * v + y, o.y * v + b, v, v), h.strokeRect(o.x * v + y, o.y * v + b, v, v)
				}
				e.rendorAll()
			})
		}, l.rendorAll = function() {
			var e = this;
			u.getItemAll(function() {
				var t = u.collection.length;
				if (t > 0) {
					for (var n = 0; n < t; n++) e.drawAvatar(n, !0);
					$(".brand-header-num").text(t)
				}
				e.rendorNew()
			})
		}, l.rendorNew = function() {
			var e = this,
				t = u.defaults.offset;
			u.getItemNew(), e.rendorInterval = setInterval(function() {
				u.collection[t] && (e.drawAvatar(t, !1), $(".brand-header-num").text(++t))
			}, f.interval * 1100)
		}, l.drawAvatar = function(e, t) {
			var n = this,
				r = n.getRandomKey(),
				i = p[r],
				s = new Image;
			s.src = u.collection[e].head;
			var o = u.collection[e].name;
			s.onload = function() {
				if (t) h.drawImage(s, i.x * v + y, i.y * v + b, v, v);
				else {
					$("#brand-avatar").html('<div class="avatar-outer"><img class="avatar-img"/><img class="avatar-logo" src="http://appmedia.qq.com/media/yangjiewu/brand_logo_default.png" /><div class="avatar-name"></div></div>');
					var e = parseInt($(".avatar-outer").css("height")) * 17 / 20,
						r = parseInt($(".avatar-outer").css("height")) * 15 / 20,
						u = parseInt($(".avatar-outer").css("height")) * 1 / 20,
						a = parseInt($(".avatar-outer").css("height")) * 15 / 20,
						l = parseInt($(".avatar-outer").css("height")) * .5 / 20,
						c = parseInt($(".avatar-outer").css("height")) * 5 / 20,
						p = parseInt($(".avatar-outer").css("height")) * 4.5 / 20,
						d = parseInt($(".avatar-outer").css("height")) * 16 / 20;
					$(".avatar-outer").css("width", e), $(".avatar-img").attr("src", s.src), $(".avatar-img").css("top", u), $(".avatar-img").css("left", u), $(".avatar-img").css("width", r), $(".avatar-img").css("height", r), $(".avatar-logo").css("top", a), $(".avatar-logo").css("left", l), $(".avatar-logo").css("width", c), $(".avatar-logo").css("height", p), $(".avatar-name").css("top", d), $(".avatar-name").css("width", e), $(".avatar-name").css("line-height", $(".avatar-name").css("height")), $(".avatar-name").text(o), n.updateAnimate(i, r), setTimeout(function() {
						$("#brand-avatar").html(""), h.drawImage(s, i.x * v + y, i.y * v + b, v, v)
					}, f.interval * 1e3)
				}
				E++
			}
		}, l.updateAnimate = function(e, t) {
			var n, r;
			n = (e.x + .5) * v - m / 2 + y, r = (e.y + .5) * v - g / 2 + b;
			var i = v / t;
			$("#brand-style").html("<style>@-webkit-keyframes avatar {0% {opacity: 0;-webkit-transform: scale3d(.1, .1, .1) translate3d(0, -1000px, 0);-webkit-animation-timing-function: cubic-bezier(0.550, 0.055, 0.675, 0.190);}40% {opacity: 1;-webkit-transform: scale3d(.475, .475, .475) translate3d(0, 60px, 0);-webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.320, 1);}90% {opacity: 1;-webkit-transform: translate(0, 0) scale(1);}100% {opacity: 1;-webkit-transform: translate(" + n + "px, " + r + "px) scale(" + i + ");" + "}" + "}" + "</style>")
		}, l.getRandomKey = function() {
			var e = !0;
			for (var t = 0; t < d; t++) if (c[t]) {
				e = !1;
				break
			}
			if (e) for (var t = 0; t < d; t++) c[t] = !0;
			var n = Math.floor(Math.random() * d);
			return c[n] ? (c[n] = !1, n) : this.getRandomKey()
		}, l.initCanvas = function() {
			var e = $("#brand-canvas").css("width"),
				t = $("#brand-canvas").css("height");
			$("#brand-canvas").attr("width", e), $("#brand-canvas").attr("height", t);
			var n = document.getElementById("brand-canvas");
			h = n.getContext("2d"), h.lineWidth = .5, h.fillStyle = "rgba(255, 255, 255, .2)", h.strokeStyle = "rgba(0, 0, 0, .2)"
		}, l.getWidthNum = function(e) {
			var t = 1;
			for (var n = 0; n < e.length; n++) {
				var r = e[n];
				r.x > t && (t = r.x)
			}
			return t + 1
		}, l.getHeightNum = function(e) {
			var t = 1;
			for (var n = 0; n < e.length; n++) {
				var r = e[n];
				r.y > t && (t = r.y)
			}
			return t + 1
		}, l.bindEvent = function() {
			$(".brand-qrcode, .brand-qrcode-btn").on("click", function() {
				S ? ($(".brand-qrcode").removeClass("hide"), S = 0) : ($(".brand-qrcode").addClass("hide"), S = 1)
			})
		}, l.generateQrcodeUrl = function() {
			var e = n.model.params.campaign_id,
				t = window.location.host,
				r = encodeURIComponent(i.hostname + "/live/client/index.html#/signin?campaign_id=" + e),
				s = i.hostname + "/common/getqrcodeimage?level=3&size=20&content=" + r + "&name=signin";
			return s
		}, l.unload = function() {
			var e = this;
			u.stopGetUsers(), clearInterval(e.rendorInterval)
		}, l.render = function() {
			var e = this;
			if (!n.isActive("register") && !n.isActive("signin")) {
				r.alert({
					path: n.path,
					content: {
						message: "大屏幕签到墙功能没有开启"
					}
				});
				return
			}
			u.getType({
				normal: function() {
					window.location.hash = "#" + n.model.params.campaign_id + "/signin"
				},
				brand: function(t) {
					e.main(), e.bindEvent()
				}
			}), n.highlight("signin");
			var t = e.generateQrcodeUrl(),
				i = a(n.path + "/brand/layout", {
					item_num: f.item_num,
					img_src: t
				});
			$(".viewport").html(i)
		}, l.init = function(e) {
			t.register({
				name: "brand",
				before: function() {
					n.prepareData(e), $.when(n.checkLogin()).done(function() {
						$.when(n.getInfo()).done(function() {
							n.render()
						})
					})
				},
				controller: function(e) {
					n.ready && l.render()
				},
				unload: function() {
					l.unload()
				}
			}), t.get("brand").controller()
		}, l
	}), !
	function(e) {
		if ("object" == typeof exports && "undefined" != typeof module) module.exports = e();
		else if ("function" == typeof define && define.amd) define("vendor/socket.io", [], e);
		else {
			var t;
			"undefined" != typeof window ? t = window : "undefined" != typeof global ? t = global : "undefined" != typeof self && (t = self), t.io = e()
		}
	}(function() {
		var e, t, n;
		return function r(e, t, n) {
			function i(o, u) {
				if (!t[o]) {
					if (!e[o]) {
						var a = typeof require == "function" && require;
						if (!u && a) return a(o, !0);
						if (s) return s(o, !0);
						throw new Error("Cannot find module '" + o + "'")
					}
					var f = t[o] = {
						exports: {}
					};
					e[o][0].call(f.exports, function(t) {
						var n = e[o][1][t];
						return i(n ? n : t)
					}, f, f.exports, r, e, t, n)
				}
				return t[o].exports
			}
			var s = typeof require == "function" && require;
			for (var o = 0; o < n.length; o++) i(n[o]);
			return i
		}({
			1: [function(e, t, n) {
				t.exports = e("./lib/")
			}, {
				"./lib/": 2
			}],
			2: [function(e, t, n) {
				function a(e, t) {
					typeof e == "object" && (t = e, e = undefined), t = t || {};
					var n = r(e),
						i = n.source,
						a = n.id,
						f;
					return t.forceNew || t["force new connection"] || !1 === t.multiplex ? (o("ignoring socket cache for %s", i), f = s(i, t)) : (u[a] || (o("new io instance for %s", i), u[a] = s(i, t)), f = u[a]), f.socket(n.path)
				}
				var r = e("./url"),
					i = e("socket.io-parser"),
					s = e("./manager"),
					o = e("debug")("socket.io-client");
				t.exports = n = a;
				var u = n.managers = {};
				n.protocol = i.protocol, n.connect = a, n.Manager = e("./manager"), n.Socket = e("./socket")
			}, {
				"./manager": 3,
				"./socket": 5,
				"./url": 6,
				debug: 10,
				"socket.io-parser": 44
			}],
			3: [function(e, t, n) {
				function d(e, t) {
					if (!(this instanceof d)) return new d(e, t);
					e && "object" == typeof e && (t = e, e = undefined), t = t || {}, t.path = t.path || "/socket.io", this.nsps = {}, this.subs = [], this.opts = t, this.reconnection(t.reconnection !== !1), this.reconnectionAttempts(t.reconnectionAttempts || Infinity), this.reconnectionDelay(t.reconnectionDelay || 1e3), this.reconnectionDelayMax(t.reconnectionDelayMax || 5e3), this.randomizationFactor(t.randomizationFactor || .5), this.backoff = new p({
						min: this.reconnectionDelay(),
						max: this.reconnectionDelayMax(),
						jitter: this.randomizationFactor()
					}), this.timeout(null == t.timeout ? 2e4 : t.timeout), this.readyState = "closed", this.uri = e, this.connected = [], this.encoding = !1, this.packetBuffer = [], this.encoder = new u.Encoder, this.decoder = new u.Decoder, this.autoConnect = t.autoConnect !== !1, this.autoConnect && this.open()
				}
				var r = e("./url"),
					i = e("engine.io-client"),
					s = e("./socket"),
					o = e("component-emitter"),
					u = e("socket.io-parser"),
					a = e("./on"),
					f = e("component-bind"),
					l = e("object-component"),
					c = e("debug")("socket.io-client:manager"),
					h = e("indexof"),
					p = e("backo2");
				t.exports = d, d.prototype.emitAll = function() {
					this.emit.apply(this, arguments);
					for (var e in this.nsps) this.nsps[e].emit.apply(this.nsps[e], arguments)
				}, d.prototype.updateSocketIds = function() {
					for (var e in this.nsps) this.nsps[e].id = this.engine.id
				}, o(d.prototype), d.prototype.reconnection = function(e) {
					return arguments.length ? (this._reconnection = !! e, this) : this._reconnection
				}, d.prototype.reconnectionAttempts = function(e) {
					return arguments.length ? (this._reconnectionAttempts = e, this) : this._reconnectionAttempts
				}, d.prototype.reconnectionDelay = function(e) {
					return arguments.length ? (this._reconnectionDelay = e, this.backoff && this.backoff.setMin(e), this) : this._reconnectionDelay
				}, d.prototype.randomizationFactor = function(e) {
					return arguments.length ? (this._randomizationFactor = e, this.backoff && this.backoff.setJitter(e), this) : this._randomizationFactor
				}, d.prototype.reconnectionDelayMax = function(e) {
					return arguments.length ? (this._reconnectionDelayMax = e, this.backoff && this.backoff.setMax(e), this) : this._reconnectionDelayMax
				}, d.prototype.timeout = function(e) {
					return arguments.length ? (this._timeout = e, this) : this._timeout
				}, d.prototype.maybeReconnectOnOpen = function() {
					!this.reconnecting && this._reconnection && this.backoff.attempts === 0 && this.reconnect()
				}, d.prototype.open = d.prototype.connect = function(e) {
					c("readyState %s", this.readyState);
					if (~this.readyState.indexOf("open")) return this;
					c("opening %s", this.uri), this.engine = i(this.uri, this.opts);
					var t = this.engine,
						n = this;
					this.readyState = "opening", this.skipReconnect = !1;
					var r = a(t, "open", function() {
						n.onopen(), e && e()
					}),
						s = a(t, "error", function(t) {
							c("connect_error"), n.cleanup(), n.readyState = "closed", n.emitAll("connect_error", t);
							if (e) {
								var r = new Error("Connection error");
								r.data = t, e(r)
							} else n.maybeReconnectOnOpen()
						});
					if (!1 !== this._timeout) {
						var o = this._timeout;
						c("connect attempt will timeout after %d", o);
						var u = setTimeout(function() {
							c("connect attempt timed out after %d", o), r.destroy(), t.close(), t.emit("error", "timeout"), n.emitAll("connect_timeout", o)
						}, o);
						this.subs.push({
							destroy: function() {
								clearTimeout(u)
							}
						})
					}
					return this.subs.push(r), this.subs.push(s), this
				}, d.prototype.onopen = function() {
					c("open"), this.cleanup(), this.readyState = "open", this.emit("open");
					var e = this.engine;
					this.subs.push(a(e, "data", f(this, "ondata"))), this.subs.push(a(this.decoder, "decoded", f(this, "ondecoded"))), this.subs.push(a(e, "error", f(this, "onerror"))), this.subs.push(a(e, "close", f(this, "onclose")))
				}, d.prototype.ondata = function(e) {
					this.decoder.add(e)
				}, d.prototype.ondecoded = function(e) {
					this.emit("packet", e)
				}, d.prototype.onerror = function(e) {
					c("error", e), this.emitAll("error", e)
				}, d.prototype.socket = function(e) {
					var t = this.nsps[e];
					if (!t) {
						t = new s(this, e), this.nsps[e] = t;
						var n = this;
						t.on("connect", function() {
							t.id = n.engine.id, ~h(n.connected, t) || n.connected.push(t)
						})
					}
					return t
				}, d.prototype.destroy = function(e) {
					var t = h(this.connected, e);~t && this.connected.splice(t, 1);
					if (this.connected.length) return;
					this.close()
				}, d.prototype.packet = function(e) {
					c("writing packet %j", e);
					var t = this;
					t.encoding ? t.packetBuffer.push(e) : (t.encoding = !0, this.encoder.encode(e, function(e) {
						for (var n = 0; n < e.length; n++) t.engine.write(e[n]);
						t.encoding = !1, t.processPacketQueue()
					}))
				}, d.prototype.processPacketQueue = function() {
					if (this.packetBuffer.length > 0 && !this.encoding) {
						var e = this.packetBuffer.shift();
						this.packet(e)
					}
				}, d.prototype.cleanup = function() {
					var e;
					while (e = this.subs.shift()) e.destroy();
					this.packetBuffer = [], this.encoding = !1, this.decoder.destroy()
				}, d.prototype.close = d.prototype.disconnect = function() {
					this.skipReconnect = !0, this.backoff.reset(), this.readyState = "closed", this.engine && this.engine.close()
				}, d.prototype.onclose = function(e) {
					c("close"), this.cleanup(), this.backoff.reset(), this.readyState = "closed", this.emit("close", e), this._reconnection && !this.skipReconnect && this.reconnect()
				}, d.prototype.reconnect = function() {
					if (this.reconnecting || this.skipReconnect) return this;
					var e = this;
					if (this.backoff.attempts >= this._reconnectionAttempts) c("reconnect failed"), this.backoff.reset(), this.emitAll("reconnect_failed"), this.reconnecting = !1;
					else {
						var t = this.backoff.duration();
						c("will wait %dms before reconnect attempt", t), this.reconnecting = !0;
						var n = setTimeout(function() {
							if (e.skipReconnect) return;
							c("attempting reconnect"), e.emitAll("reconnect_attempt", e.backoff.attempts), e.emitAll("reconnecting", e.backoff.attempts);
							if (e.skipReconnect) return;
							e.open(function(t) {
								t ? (c("reconnect attempt error"), e.reconnecting = !1, e.reconnect(), e.emitAll("reconnect_error", t.data)) : (c("reconnect success"), e.onreconnect())
							})
						}, t);
						this.subs.push({
							destroy: function() {
								clearTimeout(n)
							}
						})
					}
				}, d.prototype.onreconnect = function() {
					var e = this.backoff.attempts;
					this.reconnecting = !1, this.backoff.reset(), this.updateSocketIds(), this.emitAll("reconnect", e)
				}
			}, {
				"./on": 4,
				"./socket": 5,
				"./url": 6,
				backo2: 7,
				"component-bind": 8,
				"component-emitter": 9,
				debug: 10,
				"engine.io-client": 11,
				indexof: 40,
				"object-component": 41,
				"socket.io-parser": 44
			}],
			4: [function(e, t, n) {
				function r(e, t, n) {
					return e.on(t, n), {
						destroy: function() {
							e.removeListener(t, n)
						}
					}
				}
				t.exports = r
			}, {}],
			5: [function(e, t, n) {
				function h(e, t) {
					this.io = e, this.nsp = t, this.json = this, this.ids = 0, this.acks = {}, this.io.autoConnect && this.open(), this.receiveBuffer = [], this.sendBuffer = [], this.connected = !1, this.disconnected = !0
				}
				var r = e("socket.io-parser"),
					i = e("component-emitter"),
					s = e("to-array"),
					o = e("./on"),
					u = e("component-bind"),
					a = e("debug")("socket.io-client:socket"),
					f = e("has-binary");
				t.exports = n = h;
				var l = {
					connect: 1,
					connect_error: 1,
					connect_timeout: 1,
					disconnect: 1,
					error: 1,
					reconnect: 1,
					reconnect_attempt: 1,
					reconnect_failed: 1,
					reconnect_error: 1,
					reconnecting: 1
				},
					c = i.prototype.emit;
				i(h.prototype), h.prototype.subEvents = function() {
					if (this.subs) return;
					var e = this.io;
					this.subs = [o(e, "open", u(this, "onopen")), o(e, "packet", u(this, "onpacket")), o(e, "close", u(this, "onclose"))]
				}, h.prototype.open = h.prototype.connect = function() {
					return this.connected ? this : (this.subEvents(), this.io.open(), "open" == this.io.readyState && this.onopen(), this)
				}, h.prototype.send = function() {
					var e = s(arguments);
					return e.unshift("message"), this.emit.apply(this, e), this
				}, h.prototype.emit = function(e) {
					if (l.hasOwnProperty(e)) return c.apply(this, arguments), this;
					var t = s(arguments),
						n = r.EVENT;
					f(t) && (n = r.BINARY_EVENT);
					var i = {
						type: n,
						data: t
					};
					return "function" == typeof t[t.length - 1] && (a("emitting packet with ack id %d", this.ids), this.acks[this.ids] = t.pop(), i.id = this.ids++), this.connected ? this.packet(i) : this.sendBuffer.push(i), this
				}, h.prototype.packet = function(e) {
					e.nsp = this.nsp, this.io.packet(e)
				}, h.prototype.onopen = function() {
					a("transport is open - connecting"), "/" != this.nsp && this.packet({
						type: r.CONNECT
					})
				}, h.prototype.onclose = function(e) {
					a("close (%s)", e), this.connected = !1, this.disconnected = !0, delete this.id, this.emit("disconnect", e)
				}, h.prototype.onpacket = function(e) {
					if (e.nsp != this.nsp) return;
					switch (e.type) {
					case r.CONNECT:
						this.onconnect();
						break;
					case r.EVENT:
						this.onevent(e);
						break;
					case r.BINARY_EVENT:
						this.onevent(e);
						break;
					case r.ACK:
						this.onack(e);
						break;
					case r.BINARY_ACK:
						this.onack(e);
						break;
					case r.DISCONNECT:
						this.ondisconnect();
						break;
					case r.ERROR:
						this.emit("error", e.data)
					}
				}, h.prototype.onevent = function(e) {
					var t = e.data || [];
					a("emitting event %j", t), null != e.id && (a("attaching ack callback to event"), t.push(this.ack(e.id))), this.connected ? c.apply(this, t) : this.receiveBuffer.push(t)
				}, h.prototype.ack = function(e) {
					var t = this,
						n = !1;
					return function() {
						if (n) return;
						n = !0;
						var i = s(arguments);
						a("sending ack %j", i);
						var o = f(i) ? r.BINARY_ACK : r.ACK;
						t.packet({
							type: o,
							id: e,
							data: i
						})
					}
				}, h.prototype.onack = function(e) {
					a("calling ack %s with %j", e.id, e.data);
					var t = this.acks[e.id];
					t.apply(this, e.data), delete this.acks[e.id]
				}, h.prototype.onconnect = function() {
					this.connected = !0, this.disconnected = !1, this.emit("connect"), this.emitBuffered()
				}, h.prototype.emitBuffered = function() {
					var e;
					for (e = 0; e < this.receiveBuffer.length; e++) c.apply(this, this.receiveBuffer[e]);
					this.receiveBuffer = [];
					for (e = 0; e < this.sendBuffer.length; e++) this.packet(this.sendBuffer[e]);
					this.sendBuffer = []
				}, h.prototype.ondisconnect = function() {
					a("server disconnect (%s)", this.nsp), this.destroy(), this.onclose("io server disconnect")
				}, h.prototype.destroy = function() {
					if (this.subs) {
						for (var e = 0; e < this.subs.length; e++) this.subs[e].destroy();
						this.subs = null
					}
					this.io.destroy(this)
				}, h.prototype.close = h.prototype.disconnect = function() {
					return this.connected && (a("performing disconnect (%s)", this.nsp), this.packet({
						type: r.DISCONNECT
					})), this.destroy(), this.connected && this.onclose("io client disconnect"), this
				}
			}, {
				"./on": 4,
				"component-bind": 8,
				"component-emitter": 9,
				debug: 10,
				"has-binary": 36,
				"socket.io-parser": 44,
				"to-array": 48
			}],
			6: [function(e, t, n) {
				(function(n) {
					function s(e, t) {
						var s = e,
							t = t || n.location;
						return null == e && (e = t.protocol + "//" + t.host), "string" == typeof e && ("/" == e.charAt(0) && ("/" == e.charAt(1) ? e = t.protocol + e : e = t.hostname + e), /^(https?|wss?):\/\//.test(e) || (i("protocol-less url %s", e), "undefined" != typeof t ? e = t.protocol + "//" + e : e = "https://" + e), i("parse %s", e), s = r(e)), s.port || (/^(http|ws)$/.test(s.protocol) ? s.port = "80" : /^(http|ws)s$/.test(s.protocol) && (s.port = "443")), s.path = s.path || "/", s.id = s.protocol + "://" + s.host + ":" + s.port, s.href = s.protocol + "://" + s.host + (t && t.port == s.port ? "" : ":" + s.port), s
					}
					var r = e("parseuri"),
						i = e("debug")("socket.io-client:url");
					t.exports = s
				}).call(this, typeof self != "undefined" ? self : typeof window != "undefined" ? window : {})
			}, {
				debug: 10,
				parseuri: 42
			}],
			7: [function(e, t, n) {
				function r(e) {
					e = e || {}, this.ms = e.min || 100, this.max = e.max || 1e4, this.factor = e.factor || 2, this.jitter = e.jitter > 0 && e.jitter <= 1 ? e.jitter : 0, this.attempts = 0
				}
				t.exports = r, r.prototype.duration = function() {
					var e = this.ms * Math.pow(this.factor, this.attempts++);
					if (this.jitter) {
						var t = Math.random(),
							n = Math.floor(t * this.jitter * e);
						e = (Math.floor(t * 10) & 1) == 0 ? e - n : e + n
					}
					return Math.min(e, this.max) | 0
				}, r.prototype.reset = function() {
					this.attempts = 0
				}, r.prototype.setMin = function(e) {
					this.ms = e
				}, r.prototype.setMax = function(e) {
					this.max = e
				}, r.prototype.setJitter = function(e) {
					this.jitter = e
				}
			}, {}],
			8: [function(e, t, n) {
				var r = [].slice;
				t.exports = function(e, t) {
					"string" == typeof t && (t = e[t]);
					if ("function" != typeof t) throw new Error("bind() requires a function");
					var n = r.call(arguments, 2);
					return function() {
						return t.apply(e, n.concat(r.call(arguments)))
					}
				}
			}, {}],
			9: [function(e, t, n) {
				function r(e) {
					if (e) return i(e)
				}
				function i(e) {
					for (var t in r.prototype) e[t] = r.prototype[t];
					return e
				}
				t.exports = r, r.prototype.on = r.prototype.addEventListener = function(e, t) {
					return this._callbacks = this._callbacks || {}, (this._callbacks[e] = this._callbacks[e] || []).push(t), this
				}, r.prototype.once = function(e, t) {
					function r() {
						n.off(e, r), t.apply(this, arguments)
					}
					var n = this;
					return this._callbacks = this._callbacks || {}, r.fn = t, this.on(e, r), this
				}, r.prototype.off = r.prototype.removeListener = r.prototype.removeAllListeners = r.prototype.removeEventListener = function(e, t) {
					this._callbacks = this._callbacks || {};
					if (0 == arguments.length) return this._callbacks = {}, this;
					var n = this._callbacks[e];
					if (!n) return this;
					if (1 == arguments.length) return delete this._callbacks[e], this;
					var r;
					for (var i = 0; i < n.length; i++) {
						r = n[i];
						if (r === t || r.fn === t) {
							n.splice(i, 1);
							break
						}
					}
					return this
				}, r.prototype.emit = function(e) {
					this._callbacks = this._callbacks || {};
					var t = [].slice.call(arguments, 1),
						n = this._callbacks[e];
					if (n) {
						n = n.slice(0);
						for (var r = 0, i = n.length; r < i; ++r) n[r].apply(this, t)
					}
					return this
				}, r.prototype.listeners = function(e) {
					return this._callbacks = this._callbacks || {}, this._callbacks[e] || []
				}, r.prototype.hasListeners = function(e) {
					return !!this.listeners(e).length
				}
			}, {}],
			10: [function(e, t, n) {
				function r(e) {
					return r.enabled(e) ?
					function(t) {
						t = i(t);
						var n = new Date,
							s = n - (r[e] || n);
						r[e] = n, t = e + " " + t + " +" + r.humanize(s), window.console && console.log && Function.prototype.apply.call(console.log, console, arguments)
					} : function() {}
				}
				function i(e) {
					return e instanceof Error ? e.stack || e.message : e
				}
				t.exports = r, r.names = [], r.skips = [], r.enable = function(e) {
					try {
						localStorage.debug = e
					} catch (t) {}
					var n = (e || "").split(/[\s,]+/),
						i = n.length;
					for (var s = 0; s < i; s++) e = n[s].replace("*", ".*?"), e[0] === "-" ? r.skips.push(new RegExp("^" + e.substr(1) + "$")) : r.names.push(new RegExp("^" + e + "$"))
				}, r.disable = function() {
					r.enable("")
				}, r.humanize = function(e) {
					var t = 1e3,
						n = 6e4,
						r = 60 * n;
					return e >= r ? (e / r).toFixed(1) + "h" : e >= n ? (e / n).toFixed(1) + "m" : e >= t ? (e / t | 0) + "s" : e + "ms"
				}, r.enabled = function(e) {
					for (var t = 0, n = r.skips.length; t < n; t++) if (r.skips[t].test(e)) return !1;
					for (var t = 0, n = r.names.length; t < n; t++) if (r.names[t].test(e)) return !0;
					return !1
				};
				try {
					window.localStorage && r.enable(localStorage.debug)
				} catch (s) {}
			}, {}],
			11: [function(e, t, n) {
				t.exports = e("./lib/")
			}, {
				"./lib/": 12
			}],
			12: [function(e, t, n) {
				t.exports = e("./socket"), t.exports.parser = e("engine.io-parser")
			}, {
				"./socket": 13,
				"engine.io-parser": 25
			}],
			13: [function(e, t, n) {
				(function(n) {
					function c() {}
					function h(e, t) {
						if (!(this instanceof h)) return new h(e, t);
						t = t || {}, e && "object" == typeof e && (t = e, e = null), e && (e = a(e), t.host = e.host, t.secure = e.protocol == "https" || e.protocol == "wss", t.port = e.port, e.query && (t.query = e.query)), this.secure = null != t.secure ? t.secure : n.location && "https:" == location.protocol;
						if (t.host) {
							var r = t.host.split(":");
							t.hostname = r.shift(), r.length ? t.port = r.pop() : t.port || (t.port = this.secure ? "443" : "80")
						}
						this.agent = t.agent || !1, this.hostname = t.hostname || (n.location ? location.hostname : "localhost"), this.port = t.port || (n.location && location.port ? location.port : this.secure ? 443 : 80), this.query = t.query || {}, "string" == typeof this.query && (this.query = l.decode(this.query)), this.upgrade = !1 !== t.upgrade, this.path = (t.path || "/engine.io").replace(/\/$/, "") + "/", this.forceJSONP = !! t.forceJSONP, this.jsonp = !1 !== t.jsonp, this.forceBase64 = !! t.forceBase64, this.enablesXDR = !! t.enablesXDR, this.timestampParam = t.timestampParam || "t", this.timestampRequests = t.timestampRequests, this.transports = t.transports || ["polling", "websocket"], this.readyState = "", this.writeBuffer = [], this.callbackBuffer = [], this.policyPort = t.policyPort || 843, this.rememberUpgrade = t.rememberUpgrade || !1, this.binaryType = null, this.onlyBinaryUpgrades = t.onlyBinaryUpgrades, this.pfx = t.pfx || null, this.key = t.key || null, this.passphrase = t.passphrase || null, this.cert = t.cert || null, this.ca = t.ca || null, this.ciphers = t.ciphers || null, this.rejectUnauthorized = t.rejectUnauthorized || null, this.open()
					}
					function p(e) {
						var t = {};
						for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n]);
						return t
					}
					var r = e("./transports"),
						i = e("component-emitter"),
						s = e("debug")("engine.io-client:socket"),
						o = e("indexof"),
						u = e("engine.io-parser"),
						a = e("parseuri"),
						f = e("parsejson"),
						l = e("parseqs");
					t.exports = h, h.priorWebsocketSuccess = !1, i(h.prototype), h.protocol = u.protocol, h.Socket = h, h.Transport = e("./transport"), h.transports = e("./transports"), h.parser = e("engine.io-parser"), h.prototype.createTransport = function(e) {
						s('creating transport "%s"', e);
						var t = p(this.query);
						t.EIO = u.protocol, t.transport = e, this.id && (t.sid = this.id);
						var n = new r[e]({
							agent: this.agent,
							hostname: this.hostname,
							port: this.port,
							secure: this.secure,
							path: this.path,
							query: t,
							forceJSONP: this.forceJSONP,
							jsonp: this.jsonp,
							forceBase64: this.forceBase64,
							enablesXDR: this.enablesXDR,
							timestampRequests: this.timestampRequests,
							timestampParam: this.timestampParam,
							policyPort: this.policyPort,
							socket: this,
							pfx: this.pfx,
							key: this.key,
							passphrase: this.passphrase,
							cert: this.cert,
							ca: this.ca,
							ciphers: this.ciphers,
							rejectUnauthorized: this.rejectUnauthorized
						});
						return n
					}, h.prototype.open = function() {
						var e;
						if (this.rememberUpgrade && h.priorWebsocketSuccess && this.transports.indexOf("websocket") != -1) e = "websocket";
						else {
							if (0 == this.transports.length) {
								var t = this;
								setTimeout(function() {
									t.emit("error", "No transports available")
								}, 0);
								return
							}
							e = this.transports[0]
						}
						this.readyState = "opening";
						var e;
						try {
							e = this.createTransport(e)
						} catch (n) {
							this.transports.shift(), this.open();
							return
						}
						e.open(), this.setTransport(e)
					}, h.prototype.setTransport = function(e) {
						s("setting transport %s", e.name);
						var t = this;
						this.transport && (s("clearing existing transport %s", this.transport.name), this.transport.removeAllListeners()), this.transport = e, e.on("drain", function() {
							t.onDrain()
						}).on("packet", function(e) {
							t.onPacket(e)
						}).on("error", function(e) {
							t.onError(e)
						}).on("close", function() {
							t.onClose("transport close")
						})
					}, h.prototype.probe = function(e) {
						function i() {
							if (r.onlyBinaryUpgrades) {
								var i = !this.supportsBinary && r.transport.supportsBinary;
								n = n || i
							}
							if (n) return;
							s('probe transport "%s" opened', e), t.send([{
								type: "ping",
								data: "probe"
							}]), t.once("packet", function(i) {
								if (n) return;
								if ("pong" == i.type && "probe" == i.data) {
									s('probe transport "%s" pong', e), r.upgrading = !0, r.emit("upgrading", t);
									if (!t) return;
									h.priorWebsocketSuccess = "websocket" == t.name, s('pausing current transport "%s"', r.transport.name), r.transport.pause(function() {
										if (n) return;
										if ("closed" == r.readyState) return;
										s("changing transport and sending upgrade packet"), c(), r.setTransport(t), t.send([{
											type: "upgrade"
										}]), r.emit("upgrade", t), t = null, r.upgrading = !1, r.flush()
									})
								} else {
									s('probe transport "%s" failed', e);
									var o = new Error("probe error");
									o.transport = t.name, r.emit("upgradeError", o)
								}
							})
						}
						function o() {
							if (n) return;
							n = !0, c(), t.close(), t = null
						}
						function u(n) {
							var i = new Error("probe error: " + n);
							i.transport = t.name, o(), s('probe transport "%s" failed because of error: %s', e, n), r.emit("upgradeError", i)
						}
						function a() {
							u("transport closed")
						}
						function f() {
							u("socket closed")
						}
						function l(e) {
							t && e.name != t.name && (s('"%s" works - aborting "%s"', e.name, t.name), o())
						}
						function c() {
							t.removeListener("open", i), t.removeListener("error", u), t.removeListener("close", a), r.removeListener("close", f), r.removeListener("upgrading", l)
						}
						s('probing transport "%s"', e);
						var t = this.createTransport(e, {
							probe: 1
						}),
							n = !1,
							r = this;
						h.priorWebsocketSuccess = !1, t.once("open", i), t.once("error", u), t.once("close", a), this.once("close", f), this.once("upgrading", l), t.open()
					}, h.prototype.onOpen = function() {
						s("socket open"), this.readyState = "open", h.priorWebsocketSuccess = "websocket" == this.transport.name, this.emit("open"), this.flush();
						if ("open" == this.readyState && this.upgrade && this.transport.pause) {
							s("starting upgrade probes");
							for (var e = 0, t = this.upgrades.length; e < t; e++) this.probe(this.upgrades[e])
						}
					}, h.prototype.onPacket = function(e) {
						if ("opening" == this.readyState || "open" == this.readyState) {
							s('socket receive: type "%s", data "%s"', e.type, e.data), this.emit("packet", e), this.emit("heartbeat");
							switch (e.type) {
							case "open":
								this.onHandshake(f(e.data));
								break;
							case "pong":
								this.setPing();
								break;
							case "error":
								var t = new Error("server error");
								t.code = e.data, this.emit("error", t);
								break;
							case "message":
								this.emit("data", e.data), this.emit("message", e.data)
							}
						} else s('packet received with socket readyState "%s"', this.readyState)
					}, h.prototype.onHandshake = function(e) {
						this.emit("handshake", e), this.id = e.sid, this.transport.query.sid = e.sid, this.upgrades = this.filterUpgrades(e.upgrades), this.pingInterval = e.pingInterval, this.pingTimeout = e.pingTimeout, this.onOpen();
						if ("closed" == this.readyState) return;
						this.setPing(), this.removeListener("heartbeat", this.onHeartbeat), this.on("heartbeat", this.onHeartbeat)
					}, h.prototype.onHeartbeat = function(e) {
						clearTimeout(this.pingTimeoutTimer);
						var t = this;
						t.pingTimeoutTimer = setTimeout(function() {
							if ("closed" == t.readyState) return;
							t.onClose("ping timeout")
						}, e || t.pingInterval + t.pingTimeout)
					}, h.prototype.setPing = function() {
						var e = this;
						clearTimeout(e.pingIntervalTimer), e.pingIntervalTimer = setTimeout(function() {
							s("writing ping packet - expecting pong within %sms", e.pingTimeout), e.ping(), e.onHeartbeat(e.pingTimeout)
						}, e.pingInterval)
					}, h.prototype.ping = function() {
						this.sendPacket("ping")
					}, h.prototype.onDrain = function() {
						for (var e = 0; e < this.prevBufferLen; e++) this.callbackBuffer[e] && this.callbackBuffer[e]();
						this.writeBuffer.splice(0, this.prevBufferLen), this.callbackBuffer.splice(0, this.prevBufferLen), this.prevBufferLen = 0, this.writeBuffer.length == 0 ? this.emit("drain") : this.flush()
					}, h.prototype.flush = function() {
						"closed" != this.readyState && this.transport.writable && !this.upgrading && this.writeBuffer.length && (s("flushing %d packets in socket", this.writeBuffer.length), this.transport.send(this.writeBuffer), this.prevBufferLen = this.writeBuffer.length, this.emit("flush"))
					}, h.prototype.write = h.prototype.send = function(e, t) {
						return this.sendPacket("message", e, t), this
					}, h.prototype.sendPacket = function(e, t, n) {
						if ("closing" == this.readyState || "closed" == this.readyState) return;
						var r = {
							type: e,
							data: t
						};
						this.emit("packetCreate", r), this.writeBuffer.push(r), this.callbackBuffer.push(n), this.flush()
					}, h.prototype.close = function() {
						if ("opening" == this.readyState || "open" == this.readyState) {
							this.readyState = "closing";
							var e = this;

							function t() {
								e.onClose("forced close"), s("socket closing - telling transport to close"), e.transport.close()
							}
							function n() {
								e.removeListener("upgrade", n), e.removeListener("upgradeError", n), t()
							}
							function r() {
								e.once("upgrade", n), e.once("upgradeError", n)
							}
							this.writeBuffer.length ? this.once("drain", function() {
								this.upgrading ? r() : t()
							}) : this.upgrading ? r() : t()
						}
						return this
					}, h.prototype.onError = function(e) {
						s("socket error %j", e), h.priorWebsocketSuccess = !1, this.emit("error", e), this.onClose("transport error", e)
					}, h.prototype.onClose = function(e, t) {
						if ("opening" == this.readyState || "open" == this.readyState || "closing" == this.readyState) {
							s('socket close with reason: "%s"', e);
							var n = this;
							clearTimeout(this.pingIntervalTimer), clearTimeout(this.pingTimeoutTimer), setTimeout(function() {
								n.writeBuffer = [], n.callbackBuffer = [], n.prevBufferLen = 0
							}, 0), this.transport.removeAllListeners("close"), this.transport.close(), this.transport.removeAllListeners(), this.readyState = "closed", this.id = null, this.emit("close", e, t)
						}
					}, h.prototype.filterUpgrades = function(e) {
						var t = [];
						for (var n = 0, r = e.length; n < r; n++)~o(this.transports, e[n]) && t.push(e[n]);
						return t
					}
				}).call(this, typeof self != "undefined" ? self : typeof window != "undefined" ? window : {})
			}, {
				"./transport": 14,
				"./transports": 15,
				"component-emitter": 9,
				debug: 22,
				"engine.io-parser": 25,
				indexof: 40,
				parsejson: 32,
				parseqs: 33,
				parseuri: 34
			}],
			14: [function(e, t, n) {
				function s(e) {
					this.path = e.path, this.hostname = e.hostname, this.port = e.port, this.secure = e.secure, this.query = e.query, this.timestampParam = e.timestampParam, this.timestampRequests = e.timestampRequests, this.readyState = "", this.agent = e.agent || !1, this.socket = e.socket, this.enablesXDR = e.enablesXDR, this.pfx = e.pfx, this.key = e.key, this.passphrase = e.passphrase, this.cert = e.cert, this.ca = e.ca, this.ciphers = e.ciphers, this.rejectUnauthorized = e.rejectUnauthorized
				}
				var r = e("engine.io-parser"),
					i = e("component-emitter");
				t.exports = s, i(s.prototype), s.timestamps = 0, s.prototype.onError = function(e, t) {
					var n = new Error(e);
					return n.type = "TransportError", n.description = t, this.emit("error", n), this
				}, s.prototype.open = function() {
					if ("closed" == this.readyState || "" == this.readyState) this.readyState = "opening", this.doOpen();
					return this
				}, s.prototype.close = function() {
					if ("opening" == this.readyState || "open" == this.readyState) this.doClose(), this.onClose();
					return this
				}, s.prototype.send = function(e) {
					if ("open" != this.readyState) throw new Error("Transport not open");
					this.write(e)
				}, s.prototype.onOpen = function() {
					this.readyState = "open", this.writable = !0, this.emit("open")
				}, s.prototype.onData = function(e) {
					var t = r.decodePacket(e, this.socket.binaryType);
					this.onPacket(t)
				}, s.prototype.onPacket = function(e) {
					this.emit("packet", e)
				}, s.prototype.onClose = function() {
					this.readyState = "closed", this.emit("close")
				}
			}, {
				"component-emitter": 9,
				"engine.io-parser": 25
			}],
			15: [function(e, t, n) {
				(function(t) {
					function u(e) {
						var n, o = !1,
							u = !1,
							a = !1 !== e.jsonp;
						if (t.location) {
							var f = "https:" == location.protocol,
								l = location.port;
							l || (l = f ? 443 : 80), o = e.hostname != location.hostname || l != e.port, u = e.secure != f
						}
						e.xdomain = o, e.xscheme = u, n = new r(e);
						if ("open" in n && !e.forceJSONP) return new i(e);
						if (!a) throw new Error("JSONP disabled");
						return new s(e)
					}
					var r = e("xmlhttprequest"),
						i = e("./polling-xhr"),
						s = e("./polling-jsonp"),
						o = e("./websocket");
					n.polling = u, n.websocket = o
				}).call(this, typeof self != "undefined" ? self : typeof window != "undefined" ? window : {})
			}, {
				"./polling-jsonp": 16,
				"./polling-xhr": 17,
				"./websocket": 19,
				xmlhttprequest: 20
			}],
			16: [function(e, t, n) {
				(function(n) {
					function f() {}
					function l(e) {
						r.call(this, e), this.query = this.query || {}, u || (n.___eio || (n.___eio = []), u = n.___eio), this.index = u.length;
						var t = this;
						u.push(function(e) {
							t.onData(e)
						}), this.query.j = this.index, n.document && n.addEventListener && n.addEventListener("beforeunload", function() {
							t.script && (t.script.onerror = f)
						}, !1)
					}
					var r = e("./polling"),
						i = e("component-inherit");
					t.exports = l;
					var s = /\n/g,
						o = /\\n/g,
						u, a = 0;
					i(l, r), l.prototype.supportsBinary = !1, l.prototype.doClose = function() {
						this.script && (this.script.parentNode.removeChild(this.script), this.script = null), this.form && (this.form.parentNode.removeChild(this.form), this.form = null, this.iframe = null), r.prototype.doClose.call(this)
					}, l.prototype.doPoll = function() {
						var e = this,
							t = document.createElement("script");
						this.script && (this.script.parentNode.removeChild(this.script), this.script = null), t.async = !0, t.src = this.uri(), t.onerror = function(t) {
							e.onError("jsonp poll error", t)
						};
						var n = document.getElementsByTagName("script")[0];
						n.parentNode.insertBefore(t, n), this.script = t;
						var r = "undefined" != typeof navigator && /gecko/i.test(navigator.userAgent);
						r && setTimeout(function() {
							var e = document.createElement("iframe");
							document.body.appendChild(e), document.body.removeChild(e)
						}, 100)
					}, l.prototype.doWrite = function(e, t) {
						function f() {
							l(), t()
						}
						function l() {
							if (n.iframe) try {
								n.form.removeChild(n.iframe)
							} catch (e) {
								n.onError("jsonp polling iframe removal error", e)
							}
							try {
								var t = '<iframe src="javascript:0" name="' + n.iframeId + '">';
								a = document.createElement(t)
							} catch (e) {
								a = document.createElement("iframe"), a.name = n.iframeId, a.src = "javascript:0"
							}
							a.id = n.iframeId, n.form.appendChild(a), n.iframe = a
						}
						var n = this;
						if (!this.form) {
							var r = document.createElement("form"),
								i = document.createElement("textarea"),
								u = this.iframeId = "eio_iframe_" + this.index,
								a;
							r.className = "socketio", r.style.position = "absolute", r.style.top = "-1000px", r.style.left = "-1000px", r.target = u, r.method = "POST", r.setAttribute("accept-charset", "utf-8"), i.name = "d", r.appendChild(i), document.body.appendChild(r), this.form = r, this.area = i
						}
						this.form.action = this.uri(), l(), e = e.replace(o, "\\\n"), this.area.value = e.replace(s, "\\n");
						try {
							this.form.submit()
						} catch (c) {}
						this.iframe.attachEvent ? this.iframe.onreadystatechange = function() {
							n.iframe.readyState == "complete" && f()
						} : this.iframe.onload = f
					}
				}).call(this, typeof self != "undefined" ? self : typeof window != "undefined" ? window : {})
			}, {
				"./polling": 18,
				"component-inherit": 21
			}],
			17: [function(e, t, n) {
				(function(n) {
					function a() {}
					function f(e) {
						i.call(this, e);
						if (n.location) {
							var t = "https:" == location.protocol,
								r = location.port;
							r || (r = t ? 443 : 80), this.xd = e.hostname != n.location.hostname || r != e.port, this.xs = e.secure != t
						}
					}
					function l(e) {
						this.method = e.method || "GET", this.uri = e.uri, this.xd = !! e.xd, this.xs = !! e.xs, this.async = !1 !== e.async, this.data = undefined != e.data ? e.data : null, this.agent = e.agent, this.isBinary = e.isBinary, this.supportsBinary = e.supportsBinary, this.enablesXDR = e.enablesXDR, this.pfx = e.pfx, this.key = e.key, this.passphrase = e.passphrase, this.cert = e.cert, this.ca = e.ca, this.ciphers = e.ciphers, this.rejectUnauthorized = e.rejectUnauthorized, this.create()
					}
					function c() {
						for (var e in l.requests) l.requests.hasOwnProperty(e) && l.requests[e].abort()
					}
					var r = e("xmlhttprequest"),
						i = e("./polling"),
						s = e("component-emitter"),
						o = e("component-inherit"),
						u = e("debug")("engine.io-client:polling-xhr");
					t.exports = f, t.exports.Request = l, o(f, i), f.prototype.supportsBinary = !0, f.prototype.request = function(e) {
						return e = e || {}, e.uri = this.uri(), e.xd = this.xd, e.xs = this.xs, e.agent = this.agent || !1, e.supportsBinary = this.supportsBinary, e.enablesXDR = this.enablesXDR, e.pfx = this.pfx, e.key = this.key, e.passphrase = this.passphrase, e.cert = this.cert, e.ca = this.ca, e.ciphers = this.ciphers, e.rejectUnauthorized = this.rejectUnauthorized, new l(e)
					}, f.prototype.doWrite = function(e, t) {
						var n = typeof e != "string" && e !== undefined,
							r = this.request({
								method: "POST",
								data: e,
								isBinary: n
							}),
							i = this;
						r.on("success", t), r.on("error", function(e) {
							i.onError("xhr post error", e)
						}), this.sendXhr = r
					}, f.prototype.doPoll = function() {
						u("xhr poll");
						var e = this.request(),
							t = this;
						e.on("data", function(e) {
							t.onData(e)
						}), e.on("error", function(e) {
							t.onError("xhr poll error", e)
						}), this.pollXhr = e
					}, s(l.prototype), l.prototype.create = function() {
						var e = {
							agent: this.agent,
							xdomain: this.xd,
							xscheme: this.xs,
							enablesXDR: this.enablesXDR
						};
						e.pfx = this.pfx, e.key = this.key, e.passphrase = this.passphrase, e.cert = this.cert, e.ca = this.ca, e.ciphers = this.ciphers, e.rejectUnauthorized = this.rejectUnauthorized;
						var t = this.xhr = new r(e),
							i = this;
						try {
							u("xhr open %s: %s", this.method, this.uri), t.open(this.method, this.uri, this.async), this.supportsBinary && (t.responseType = "arraybuffer");
							if ("POST" == this.method) try {
								this.isBinary ? t.setRequestHeader("Content-type", "application/octet-stream") : t.setRequestHeader("Content-type", "text/plain;charset=UTF-8")
							} catch (s) {}
							"withCredentials" in t && (t.withCredentials = !0), this.hasXDR() ? (t.onload = function() {
								i.onLoad()
							}, t.onerror = function() {
								i.onError(t.responseText)
							}) : t.onreadystatechange = function() {
								if (4 != t.readyState) return;
								200 == t.status || 1223 == t.status ? i.onLoad() : setTimeout(function() {
									i.onError(t.status)
								}, 0)
							}, u("xhr data %s", this.data), t.send(this.data)
						} catch (s) {
							setTimeout(function() {
								i.onError(s)
							}, 0);
							return
						}
						n.document && (this.index = l.requestsCount++, l.requests[this.index] = this)
					}, l.prototype.onSuccess = function() {
						this.emit("success"), this.cleanup()
					}, l.prototype.onData = function(e) {
						this.emit("data", e), this.onSuccess()
					}, l.prototype.onError = function(e) {
						this.emit("error", e), this.cleanup(!0)
					}, l.prototype.cleanup = function(e) {
						if ("undefined" == typeof this.xhr || null === this.xhr) return;
						this.hasXDR() ? this.xhr.onload = this.xhr.onerror = a : this.xhr.onreadystatechange = a;
						if (e) try {
							this.xhr.abort()
						} catch (t) {}
						n.document && delete l.requests[this.index], this.xhr = null
					}, l.prototype.onLoad = function() {
						var e;
						try {
							var t;
							try {
								t = this.xhr.getResponseHeader("Content-Type").split(";")[0]
							} catch (n) {}
							t === "application/octet-stream" ? e = this.xhr.response : this.supportsBinary ? e = "ok" : e = this.xhr.responseText
						} catch (n) {
							this.onError(n)
						}
						null != e && this.onData(e)
					}, l.prototype.hasXDR = function() {
						return "undefined" != typeof n.XDomainRequest && !this.xs && this.enablesXDR
					}, l.prototype.abort = function() {
						this.cleanup()
					}, n.document && (l.requestsCount = 0, l.requests = {}, n.attachEvent ? n.attachEvent("onunload", c) : n.addEventListener && n.addEventListener("beforeunload", c, !1))
				}).call(this, typeof self != "undefined" ? self : typeof window != "undefined" ? window : {})
			}, {
				"./polling": 18,
				"component-emitter": 9,
				"component-inherit": 21,
				debug: 22,
				xmlhttprequest: 20
			}],
			18: [function(e, t, n) {
				function f(e) {
					var t = e && e.forceBase64;
					if (!a || t) this.supportsBinary = !1;
					r.call(this, e)
				}
				var r = e("../transport"),
					i = e("parseqs"),
					s = e("engine.io-parser"),
					o = e("component-inherit"),
					u = e("debug")("engine.io-client:polling");
				t.exports = f;
				var a = function() {
						var t = e("xmlhttprequest"),
							n = new t({
								xdomain: !1
							});
						return null != n.responseType
					}();
				o(f, r), f.prototype.name = "polling", f.prototype.doOpen = function() {
					this.poll()
				}, f.prototype.pause = function(e) {
					function r() {
						u("paused"), n.readyState = "paused", e()
					}
					var t = 0,
						n = this;
					this.readyState = "pausing";
					if (this.polling || !this.writable) {
						var i = 0;
						this.polling && (u("we are currently polling - waiting to pause"), i++, this.once("pollComplete", function() {
							u("pre-pause polling complete"), --i || r()
						})), this.writable || (u("we are currently writing - waiting to pause"), i++, this.once("drain", function() {
							u("pre-pause writing complete"), --i || r()
						}))
					} else r()
				}, f.prototype.poll = function() {
					u("polling"), this.polling = !0, this.doPoll(), this.emit("poll")
				}, f.prototype.onData = function(e) {
					var t = this;
					u("polling got data %s", e);
					var n = function(e, n, r) {
							"opening" == t.readyState && t.onOpen();
							if ("close" == e.type) return t.onClose(), !1;
							t.onPacket(e)
						};
					s.decodePayload(e, this.socket.binaryType, n), "closed" != this.readyState && (this.polling = !1, this.emit("pollComplete"), "open" == this.readyState ? this.poll() : u('ignoring poll - transport state "%s"', this.readyState))
				}, f.prototype.doClose = function() {
					function t() {
						u("writing close packet"), e.write([{
							type: "close"
						}])
					}
					var e = this;
					"open" == this.readyState ? (u("transport open - closing"), t()) : (u("transport not open - deferring close"), this.once("open", t))
				}, f.prototype.write = function(e) {
					var t = this;
					this.writable = !1;
					var n = function() {
							t.writable = !0, t.emit("drain")
						},
						t = this;
					s.encodePayload(e, this.supportsBinary, function(e) {
						t.doWrite(e, n)
					})
				}, f.prototype.uri = function() {
					var e = this.query || {},
						t = this.secure ? "https" : "http",
						n = "";
					return !1 !== this.timestampRequests && (e[this.timestampParam] = +(new Date) + "-" + r.timestamps++), !this.supportsBinary && !e.sid && (e.b64 = 1), e = i.encode(e), this.port && ("https" == t && this.port != 443 || "http" == t && this.port != 80) && (n = ":" + this.port), e.length && (e = "?" + e), t + "://" + this.hostname + n + this.path + e
				}
			}, {
				"../transport": 14,
				"component-inherit": 21,
				debug: 22,
				"engine.io-parser": 25,
				parseqs: 33,
				xmlhttprequest: 20
			}],
			19: [function(e, t, n) {
				function f(e) {
					var t = e && e.forceBase64;
					t && (this.supportsBinary = !1), r.call(this, e)
				}
				var r = e("../transport"),
					i = e("engine.io-parser"),
					s = e("parseqs"),
					o = e("component-inherit"),
					u = e("debug")("engine.io-client:websocket"),
					a = e("ws");
				t.exports = f, o(f, r), f.prototype.name = "websocket", f.prototype.supportsBinary = !0, f.prototype.doOpen = function() {
					if (!this.check()) return;
					var e = this,
						t = this.uri(),
						n = void 0,
						r = {
							agent: this.agent
						};
					r.pfx = this.pfx, r.key = this.key, r.passphrase = this.passphrase, r.cert = this.cert, r.ca = this.ca, r.ciphers = this.ciphers, r.rejectUnauthorized = this.rejectUnauthorized, this.ws = new a(t, n, r), this.ws.binaryType === undefined && (this.supportsBinary = !1), this.ws.binaryType = "arraybuffer", this.addEventListeners()
				}, f.prototype.addEventListeners = function() {
					var e = this;
					this.ws.onopen = function() {
						e.onOpen()
					}, this.ws.onclose = function() {
						e.onClose()
					}, this.ws.onmessage = function(t) {
						e.onData(t.data)
					}, this.ws.onerror = function(t) {
						e.onError("websocket error", t)
					}
				}, "undefined" != typeof navigator && /iPad|iPhone|iPod/i.test(navigator.userAgent) && (f.prototype.onData = function(e) {
					var t = this;
					setTimeout(function() {
						r.prototype.onData.call(t, e)
					}, 0)
				}), f.prototype.write = function(e) {
					function s() {
						t.writable = !0, t.emit("drain")
					}
					var t = this;
					this.writable = !1;
					for (var n = 0, r = e.length; n < r; n++) i.encodePacket(e[n], this.supportsBinary, function(e) {
						try {
							t.ws.send(e)
						} catch (n) {
							u("websocket closed before onclose event")
						}
					});
					setTimeout(s, 0)
				}, f.prototype.onClose = function() {
					r.prototype.onClose.call(this)
				}, f.prototype.doClose = function() {
					typeof this.ws != "undefined" && this.ws.close()
				}, f.prototype.uri = function() {
					var e = this.query || {},
						t = this.secure ? "wss" : "ws",
						n = "";
					return this.port && ("wss" == t && this.port != 443 || "ws" == t && this.port != 80) && (n = ":" + this.port), this.timestampRequests && (e[this.timestampParam] = +(new Date)), this.supportsBinary || (e.b64 = 1), e = s.encode(e), e.length && (e = "?" + e), t + "://" + this.hostname + n + this.path + e
				}, f.prototype.check = function() {
					return !!a && !("__initialize" in a && this.name === f.prototype.name)
				}
			}, {
				"../transport": 14,
				"component-inherit": 21,
				debug: 22,
				"engine.io-parser": 25,
				parseqs: 33,
				ws: 35
			}],
			20: [function(e, t, n) {
				var r = e("has-cors");
				t.exports = function(e) {
					var t = e.xdomain,
						n = e.xscheme,
						i = e.enablesXDR;
					try {
						if ("undefined" != typeof XMLHttpRequest && (!t || r)) return new XMLHttpRequest
					} catch (s) {}
					try {
						if ("undefined" != typeof XDomainRequest && !n && i) return new XDomainRequest
					} catch (s) {}
					if (!t) try {
						return new ActiveXObject("Microsoft.XMLHTTP")
					} catch (s) {}
				}
			}, {
				"has-cors": 38
			}],
			21: [function(e, t, n) {
				t.exports = function(e, t) {
					var n = function() {};
					n.prototype = t.prototype, e.prototype = new n, e.prototype.constructor = e
				}
			}, {}],
			22: [function(e, t, n) {
				function r() {
					return "WebkitAppearance" in document.documentElement.style || window.console && (console.firebug || console.exception && console.table) || navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/) && parseInt(RegExp.$1, 10) >= 31
				}
				function i() {
					var e = arguments,
						t = this.useColors;
					e[0] = (t ? "%c" : "") + this.namespace + (t ? " %c" : " ") + e[0] + (t ? "%c " : " ") + "+" + n.humanize(this.diff);
					if (!t) return e;
					var r = "color: " + this.color;
					e = [e[0], r, "color: inherit"].concat(Array.prototype.slice.call(e, 1));
					var i = 0,
						s = 0;
					return e[0].replace(/%[a-z%]/g, function(e) {
						if ("%%" === e) return;
						i++, "%c" === e && (s = i)
					}), e.splice(s, 0, r), e
				}
				function s() {
					return "object" == typeof console && "function" == typeof console.log && Function.prototype.apply.call(console.log, console, arguments)
				}
				function o(e) {
					try {
						null == e ? localStorage.removeItem("debug") : localStorage.debug = e
					} catch (t) {}
				}
				function u() {
					var e;
					try {
						e = localStorage.debug
					} catch (t) {}
					return e
				}
				n = t.exports = e("./debug"), n.log = s, n.formatArgs = i, n.save = o, n.load = u, n.useColors = r, n.colors = ["lightseagreen", "forestgreen", "goldenrod", "dodgerblue", "darkorchid", "crimson"], n.formatters.j = function(e) {
					return JSON.stringify(e)
				}, n.enable(u())
			}, {
				"./debug": 23
			}],
			23: [function(e, t, n) {
				function s() {
					return n.colors[r++ % n.colors.length]
				}
				function o(e) {
					function t() {}
					function r() {
						var e = r,
							t = +(new Date),
							o = t - (i || t);
						e.diff = o, e.prev = i, e.curr = t, i = t, null == e.useColors && (e.useColors = n.useColors()), null == e.color && e.useColors && (e.color = s());
						var u = Array.prototype.slice.call(arguments);
						u[0] = n.coerce(u[0]), "string" != typeof u[0] && (u = ["%o"].concat(u));
						var a = 0;
						u[0] = u[0].replace(/%([a-z%])/g, function(t, r) {
							if (t === "%%") return t;
							a++;
							var i = n.formatters[r];
							if ("function" == typeof i) {
								var s = u[a];
								t = i.call(e, s), u.splice(a, 1), a--
							}
							return t
						}), "function" == typeof n.formatArgs && (u = n.formatArgs.apply(e, u));
						var f = r.log || n.log || console.log.bind(console);
						f.apply(e, u)
					}
					t.enabled = !1, r.enabled = !0;
					var o = n.enabled(e) ? r : t;
					return o.namespace = e, o
				}
				function u(e) {
					n.save(e);
					var t = (e || "").split(/[\s,]+/),
						r = t.length;
					for (var i = 0; i < r; i++) {
						if (!t[i]) continue;
						e = t[i].replace(/\*/g, ".*?"), e[0] === "-" ? n.skips.push(new RegExp("^" + e.substr(1) + "$")) : n.names.push(new RegExp("^" + e + "$"))
					}
				}
				function a() {
					n.enable("")
				}
				function f(e) {
					var t, r;
					for (t = 0, r = n.skips.length; t < r; t++) if (n.skips[t].test(e)) return !1;
					for (t = 0, r = n.names.length; t < r; t++) if (n.names[t].test(e)) return !0;
					return !1
				}
				function l(e) {
					return e instanceof Error ? e.stack || e.message : e
				}
				n = t.exports = o, n.coerce = l, n.disable = a, n.enable = u, n.enabled = f, n.humanize = e("ms"), n.names = [], n.skips = [], n.formatters = {};
				var r = 0,
					i
			}, {
				ms: 24
			}],
			24: [function(e, t, n) {
				function a(e) {
					var t = /^((?:\d+)?\.?\d+) *(ms|seconds?|s|minutes?|m|hours?|h|days?|d|years?|y)?$/i.exec(e);
					if (!t) return;
					var n = parseFloat(t[1]),
						a = (t[2] || "ms").toLowerCase();
					switch (a) {
					case "years":
					case "year":
					case "y":
						return n * u;
					case "days":
					case "day":
					case "d":
						return n * o;
					case "hours":
					case "hour":
					case "h":
						return n * s;
					case "minutes":
					case "minute":
					case "m":
						return n * i;
					case "seconds":
					case "second":
					case "s":
						return n * r;
					case "ms":
						return n
					}
				}
				function f(e) {
					return e >= o ? Math.round(e / o) + "d" : e >= s ? Math.round(e / s) + "h" : e >= i ? Math.round(e / i) + "m" : e >= r ? Math.round(e / r) + "s" : e + "ms"
				}
				function l(e) {
					return c(e, o, "day") || c(e, s, "hour") || c(e, i, "minute") || c(e, r, "second") || e + " ms"
				}
				function c(e, t, n) {
					if (e < t) return;
					return e < t * 1.5 ? Math.floor(e / t) + " " + n : Math.ceil(e / t) + " " + n + "s"
				}
				var r = 1e3,
					i = r * 60,
					s = i * 60,
					o = s * 24,
					u = o * 365.25;
				t.exports = function(e, t) {
					return t = t || {}, "string" == typeof e ? a(e) : t.long ? l(e) : f(e)
				}
			}, {}],
			25: [function(e, t, n) {
				(function(t) {
					function m(e, t) {
						var r = "b" + n.packets[e.type] + e.data.data;
						return t(r)
					}
					function g(e, t, r) {
						if (!t) return n.encodeBase64Packet(e, r);
						var i = e.data,
							s = new Uint8Array(i),
							o = new Uint8Array(1 + i.byteLength);
						o[0] = h[e.type];
						for (var u = 0; u < s.length; u++) o[u + 1] = s[u];
						return r(o.buffer)
					}
					function y(e, t, r) {
						if (!t) return n.encodeBase64Packet(e, r);
						var i = new FileReader;
						return i.onload = function() {
							e.data = i.result, n.encodePacket(e, t, !0, r)
						}, i.readAsArrayBuffer(e.data)
					}
					function b(e, t, r) {
						if (!t) return n.encodeBase64Packet(e, r);
						if (c) return y(e, t, r);
						var i = new Uint8Array(1);
						i[0] = h[e.type];
						var s = new v([i.buffer, e.data]);
						return r(s)
					}
					function w(e, t, n) {
						var r = new Array(e.length),
							i = u(e.length, n),
							s = function(e, n, i) {
								t(n, function(t, n) {
									r[e] = n, i(t, r)
								})
							};
						for (var o = 0; o < e.length; o++) s(o, e[o], i)
					}
					var r = e("./keys"),
						i = e("has-binary"),
						s = e("arraybuffer.slice"),
						o = e("base64-arraybuffer"),
						u = e("after"),
						a = e("utf8"),
						f = navigator.userAgent.match(/Android/i),
						l = /PhantomJS/i.test(navigator.userAgent),
						c = f || l;
					n.protocol = 3;
					var h = n.packets = {
						open: 0,
						close: 1,
						ping: 2,
						pong: 3,
						message: 4,
						upgrade: 5,
						noop: 6
					},
						p = r(h),
						d = {
							type: "error",
							data: "parser error"
						},
						v = e("blob");
					n.encodePacket = function(e, n, r, i) {
						"function" == typeof n && (i = n, n = !1), "function" == typeof r && (i = r, r = null);
						var s = e.data === undefined ? undefined : e.data.buffer || e.data;
						if (t.ArrayBuffer && s instanceof ArrayBuffer) return g(e, n, i);
						if (v && s instanceof t.Blob) return b(e, n, i);
						if (s && s.base64) return m(e, i);
						var o = h[e.type];
						return undefined !== e.data && (o += r ? a.encode(String(e.data)) : String(e.data)), i("" + o)
					}, n.encodeBase64Packet = function(e, r) {
						var i = "b" + n.packets[e.type];
						if (v && e.data instanceof v) {
							var s = new FileReader;
							return s.onload = function() {
								var e = s.result.split(",")[1];
								r(i + e)
							}, s.readAsDataURL(e.data)
						}
						var o;
						try {
							o = String.fromCharCode.apply(null, new Uint8Array(e.data))
						} catch (u) {
							var a = new Uint8Array(e.data),
								f = new Array(a.length);
							for (var l = 0; l < a.length; l++) f[l] = a[l];
							o = String.fromCharCode.apply(null, f)
						}
						return i += t.btoa(o), r(i)
					}, n.decodePacket = function(e, t, r) {
						if (typeof e == "string" || e === undefined) {
							if (e.charAt(0) == "b") return n.decodeBase64Packet(e.substr(1), t);
							if (r) try {
								e = a.decode(e)
							} catch (i) {
								return d
							}
							var o = e.charAt(0);
							return Number(o) != o || !p[o] ? d : e.length > 1 ? {
								type: p[o],
								data: e.substring(1)
							} : {
								type: p[o]
							}
						}
						var u = new Uint8Array(e),
							o = u[0],
							f = s(e, 1);
						return v && t === "blob" && (f = new v([f])), {
							type: p[o],
							data: f
						}
					}, n.decodeBase64Packet = function(e, n) {
						var r = p[e.charAt(0)];
						if (!t.ArrayBuffer) return {
							type: r,
							data: {
								base64: !0,
								data: e.substr(1)
							}
						};
						var i = o.decode(e.substr(1));
						return n === "blob" && v && (i = new v([i])), {
							type: r,
							data: i
						}
					}, n.encodePayload = function(e, t, r) {
						function o(e) {
							return e.length + ":" + e
						}
						function u(e, r) {
							n.encodePacket(e, s ? t : !1, !0, function(e) {
								r(null, o(e))
							})
						}
						typeof t == "function" && (r = t, t = null);
						var s = i(e);
						if (t && s) return v && !c ? n.encodePayloadAsBlob(e, r) : n.encodePayloadAsArrayBuffer(e, r);
						if (!e.length) return r("0:");
						w(e, u, function(e, t) {
							return r(t.join(""))
						})
					}, n.decodePayload = function(e, t, r) {
						if (typeof e != "string") return n.decodePayloadAsBinary(e, t, r);
						typeof t == "function" && (r = t, t = null);
						var i;
						if (e == "") return r(d, 0, 1);
						var s = "",
							o, u;
						for (var a = 0, f = e.length; a < f; a++) {
							var l = e.charAt(a);
							if (":" != l) s += l;
							else {
								if ("" == s || s != (o = Number(s))) return r(d, 0, 1);
								u = e.substr(a + 1, o);
								if (s != u.length) return r(d, 0, 1);
								if (u.length) {
									i = n.decodePacket(u, t, !0);
									if (d.type == i.type && d.data == i.data) return r(d, 0, 1);
									var c = r(i, a + o, f);
									if (!1 === c) return
								}
								a += o, s = ""
							}
						}
						if (s != "") return r(d, 0, 1)
					}, n.encodePayloadAsArrayBuffer = function(e, t) {
						function r(e, t) {
							n.encodePacket(e, !0, !0, function(e) {
								return t(null, e)
							})
						}
						if (!e.length) return t(new ArrayBuffer(0));
						w(e, r, function(e, n) {
							var r = n.reduce(function(e, t) {
								var n;
								return typeof t == "string" ? n = t.length : n = t.byteLength, e + n.toString().length + n + 2
							}, 0),
								i = new Uint8Array(r),
								s = 0;
							return n.forEach(function(e) {
								var t = typeof e == "string",
									n = e;
								if (t) {
									var r = new Uint8Array(e.length);
									for (var o = 0; o < e.length; o++) r[o] = e.charCodeAt(o);
									n = r.buffer
								}
								t ? i[s++] = 0 : i[s++] = 1;
								var u = n.byteLength.toString();
								for (var o = 0; o < u.length; o++) i[s++] = parseInt(u[o]);
								i[s++] = 255;
								var r = new Uint8Array(n);
								for (var o = 0; o < r.length; o++) i[s++] = r[o]
							}), t(i.buffer)
						})
					}, n.encodePayloadAsBlob = function(e, t) {
						function r(e, t) {
							n.encodePacket(e, !0, !0, function(e) {
								var n = new Uint8Array(1);
								n[0] = 1;
								if (typeof e == "string") {
									var r = new Uint8Array(e.length);
									for (var i = 0; i < e.length; i++) r[i] = e.charCodeAt(i);
									e = r.buffer, n[0] = 0
								}
								var s = e instanceof ArrayBuffer ? e.byteLength : e.size,
									o = s.toString(),
									u = new Uint8Array(o.length + 1);
								for (var i = 0; i < o.length; i++) u[i] = parseInt(o[i]);
								u[o.length] = 255;
								if (v) {
									var a = new v([n.buffer, u.buffer, e]);
									t(null, a)
								}
							})
						}
						w(e, r, function(e, n) {
							return t(new v(n))
						})
					}, n.decodePayloadAsBinary = function(e, t, r) {
						typeof t == "function" && (r = t, t = null);
						var i = e,
							o = [],
							u = !1;
						while (i.byteLength > 0) {
							var a = new Uint8Array(i),
								f = a[0] === 0,
								l = "";
							for (var c = 1;; c++) {
								if (a[c] == 255) break;
								if (l.length > 310) {
									u = !0;
									break
								}
								l += a[c]
							}
							if (u) return r(d, 0, 1);
							i = s(i, 2 + l.length), l = parseInt(l);
							var h = s(i, 0, l);
							if (f) try {
								h = String.fromCharCode.apply(null, new Uint8Array(h))
							} catch (p) {
								var v = new Uint8Array(h);
								h = "";
								for (var c = 0; c < v.length; c++) h += String.fromCharCode(v[c])
							}
							o.push(h), i = s(i, l)
						}
						var m = o.length;
						o.forEach(function(e, i) {
							r(n.decodePacket(e, t, !0), i, m)
						})
					}
				}).call(this, typeof self != "undefined" ? self : typeof window != "undefined" ? window : {})
			}, {
				"./keys": 26,
				after: 27,
				"arraybuffer.slice": 28,
				"base64-arraybuffer": 29,
				blob: 30,
				"has-binary": 36,
				utf8: 31
			}],
			26: [function(e, t, n) {
				t.exports = Object.keys ||
				function(t) {
					var n = [],
						r = Object.prototype.hasOwnProperty;
					for (var i in t) r.call(t, i) && n.push(i);
					return n
				}
			}, {}],
			27: [function(e, t, n) {
				function r(e, t, n) {
					function s(e, i) {
						if (s.count <= 0) throw new Error("after called too many times");
						--s.count, e ? (r = !0, t(e), t = n) : s.count === 0 && !r && t(null, i)
					}
					var r = !1;
					return n = n || i, s.count = e, e === 0 ? t() : s
				}
				function i() {}
				t.exports = r
			}, {}],
			28: [function(e, t, n) {
				t.exports = function(e, t, n) {
					var r = e.byteLength;
					t = t || 0, n = n || r;
					if (e.slice) return e.slice(t, n);
					t < 0 && (t += r), n < 0 && (n += r), n > r && (n = r);
					if (t >= r || t >= n || r === 0) return new ArrayBuffer(0);
					var i = new Uint8Array(e),
						s = new Uint8Array(n - t);
					for (var o = t, u = 0; o < n; o++, u++) s[u] = i[o];
					return s.buffer
				}
			}, {}],
			29: [function(e, t, n) {
				(function(e) {
					"use strict";
					n.encode = function(t) {
						var n = new Uint8Array(t),
							r, i = n.length,
							s = "";
						for (r = 0; r < i; r += 3) s += e[n[r] >> 2], s += e[(n[r] & 3) << 4 | n[r + 1] >> 4], s += e[(n[r + 1] & 15) << 2 | n[r + 2] >> 6], s += e[n[r + 2] & 63];
						return i % 3 === 2 ? s = s.substring(0, s.length - 1) + "=" : i % 3 === 1 && (s = s.substring(0, s.length - 2) + "=="), s
					}, n.decode = function(t) {
						var n = t.length * .75,
							r = t.length,
							i, s = 0,
							o, u, a, f;
						t[t.length - 1] === "=" && (n--, t[t.length - 2] === "=" && n--);
						var l = new ArrayBuffer(n),
							c = new Uint8Array(l);
						for (i = 0; i < r; i += 4) o = e.indexOf(t[i]), u = e.indexOf(t[i + 1]), a = e.indexOf(t[i + 2]), f = e.indexOf(t[i + 3]), c[s++] = o << 2 | u >> 4, c[s++] = (u & 15) << 4 | a >> 2, c[s++] = (a & 3) << 6 | f & 63;
						return l
					}
				})("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/")
			}, {}],
			30: [function(e, t, n) {
				(function(e) {
					function o(e) {
						for (var t = 0; t < e.length; t++) {
							var n = e[t];
							if (n.buffer instanceof ArrayBuffer) {
								var r = n.buffer;
								if (n.byteLength !== r.byteLength) {
									var i = new Uint8Array(n.byteLength);
									i.set(new Uint8Array(r, n.byteOffset, n.byteLength)), r = i.buffer
								}
								e[t] = r
							}
						}
					}
					function u(e, t) {
						t = t || {};
						var r = new n;
						o(e);
						for (var i = 0; i < e.length; i++) r.append(e[i]);
						return t.type ? r.getBlob(t.type) : r.getBlob()
					}
					function a(e, t) {
						return o(e), new Blob(e, t || {})
					}
					var n = e.BlobBuilder || e.WebKitBlobBuilder || e.MSBlobBuilder || e.MozBlobBuilder,
						r = function() {
							try {
								var e = new Blob(["hi"]);
								return e.size === 2
							} catch (t) {
								return !1
							}
						}(),
						i = r &&
					function() {
						try {
							var e = new Blob([new Uint8Array([1, 2])]);
							return e.size === 2
						} catch (t) {
							return !1
						}
					}(), s = n && n.prototype.append && n.prototype.getBlob;
					t.exports = function() {
						return r ? i ? e.Blob : a : s ? u : undefined
					}()
				}).call(this, typeof self != "undefined" ? self : typeof window != "undefined" ? window : {})
			}, {}],
			31: [function(t, n, r) {
				(function(t) {
					(function(i) {
						function f(e) {
							var t = [],
								n = 0,
								r = e.length,
								i, s;
							while (n < r) i = e.charCodeAt(n++), i >= 55296 && i <= 56319 && n < r ? (s = e.charCodeAt(n++), (s & 64512) == 56320 ? t.push(((i & 1023) << 10) + (s & 1023) + 65536) : (t.push(i), n--)) : t.push(i);
							return t
						}
						function l(e) {
							var t = e.length,
								n = -1,
								r, i = "";
							while (++n < t) r = e[n], r > 65535 && (r -= 65536, i += a(r >>> 10 & 1023 | 55296), r = 56320 | r & 1023), i += a(r);
							return i
						}
						function c(e) {
							if (e >= 55296 && e <= 57343) throw Error("Lone surrogate U+" + e.toString(16).toUpperCase() + " is not a scalar value")
						}
						function h(e, t) {
							return a(e >> t & 63 | 128)
						}
						function p(e) {
							if ((e & 4294967168) == 0) return a(e);
							var t = "";
							return (e & 4294965248) == 0 ? t = a(e >> 6 & 31 | 192) : (e & 4294901760) == 0 ? (c(e), t = a(e >> 12 & 15 | 224), t += h(e, 6)) : (e & 4292870144) == 0 && (t = a(e >> 18 & 7 | 240), t += h(e, 12), t += h(e, 6)), t += a(e & 63 | 128), t
						}
						function d(e) {
							var t = f(e),
								n = t.length,
								r = -1,
								i, s = "";
							while (++r < n) i = t[r], s += p(i);
							return s
						}
						function v() {
							if (b >= y) throw Error("Invalid byte index");
							var e = g[b] & 255;
							b++;
							if ((e & 192) == 128) return e & 63;
							throw Error("Invalid continuation byte")
						}
						function m() {
							var e, t, n, r, i;
							if (b > y) throw Error("Invalid byte index");
							if (b == y) return !1;
							e = g[b] & 255, b++;
							if ((e & 128) == 0) return e;
							if ((e & 224) == 192) {
								var t = v();
								i = (e & 31) << 6 | t;
								if (i >= 128) return i;
								throw Error("Invalid continuation byte")
							}
							if ((e & 240) == 224) {
								t = v(), n = v(), i = (e & 15) << 12 | t << 6 | n;
								if (i >= 2048) return c(i), i;
								throw Error("Invalid continuation byte")
							}
							if ((e & 248) == 240) {
								t = v(), n = v(), r = v(), i = (e & 15) << 18 | t << 12 | n << 6 | r;
								if (i >= 65536 && i <= 1114111) return i
							}
							throw Error("Invalid UTF-8 detected")
						}
						function w(e) {
							g = f(e), y = g.length, b = 0;
							var t = [],
								n;
							while ((n = m()) !== !1) t.push(n);
							return l(t)
						}
						var s = typeof r == "object" && r,
							o = typeof n == "object" && n && n.exports == s && n,
							u = typeof t == "object" && t;
						if (u.global === u || u.window === u) i = u;
						var a = String.fromCharCode,
							g, y, b, E = {
								version: "2.0.0",
								encode: d,
								decode: w
							};
						if (typeof e == "function" && typeof e.amd == "object" && e.amd) e(function() {
							return E
						});
						else if (s && !s.nodeType) if (o) o.exports = E;
						else {
							var S = {},
								x = S.hasOwnProperty;
							for (var T in E) x.call(E, T) && (s[T] = E[T])
						} else i.utf8 = E
					})(this)
				}).call(this, typeof self != "undefined" ? self : typeof window != "undefined" ? window : {})
			}, {}],
			32: [function(e, t, n) {
				(function(e) {
					var n = /^[\],:{}\s]*$/,
						r = /\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g,
						i = /"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g,
						s = /(?:^|:|,)(?:\s*\[)+/g,
						o = /^\s+/,
						u = /\s+$/;
					t.exports = function(a) {
						if ("string" != typeof a || !a) return null;
						a = a.replace(o, "").replace(u, "");
						if (e.JSON && JSON.parse) return JSON.parse(a);
						if (n.test(a.replace(r, "@").replace(i, "]").replace(s, ""))) return (new Function("return " + a))()
					}
				}).call(this, typeof self != "undefined" ? self : typeof window != "undefined" ? window : {})
			}, {}],
			33: [function(e, t, n) {
				n.encode = function(e) {
					var t = "";
					for (var n in e) e.hasOwnProperty(n) && (t.length && (t += "&"), t += encodeURIComponent(n) + "=" + encodeURIComponent(e[n]));
					return t
				}, n.decode = function(e) {
					var t = {},
						n = e.split("&");
					for (var r = 0, i = n.length; r < i; r++) {
						var s = n[r].split("=");
						t[decodeURIComponent(s[0])] = decodeURIComponent(s[1])
					}
					return t
				}
			}, {}],
			34: [function(e, t, n) {
				var r = /^(?:(?![^:@]+:[^:@\/]*@)(http|https|ws|wss):\/\/)?((?:(([^:@]*)(?::([^:@]*))?)?@)?((?:[a-f0-9]{0,4}:){2,7}[a-f0-9]{0,4}|[^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/,
					i = ["source", "protocol", "authority", "userInfo", "user", "password", "host", "port", "relative", "path", "directory", "file", "query", "anchor"];
				t.exports = function(t) {
					var n = t,
						s = t.indexOf("["),
						o = t.indexOf("]");
					s != -1 && o != -1 && (t = t.substring(0, s) + t.substring(s, o).replace(/:/g, ";") + t.substring(o, t.length));
					var u = r.exec(t || ""),
						a = {},
						f = 14;
					while (f--) a[i[f]] = u[f] || "";
					return s != -1 && o != -1 && (a.source = n, a.host = a.host.substring(1, a.host.length - 1).replace(/;/g, ":"), a.authority = a.authority.replace("[", "").replace("]", "").replace(/;/g, ":"), a.ipv6uri = !0), a
				}
			}, {}],
			35: [function(e, t, n) {
				function s(e, t, n) {
					var r;
					return t ? r = new i(e, t) : r = new i(e), r
				}
				var r = function() {
						return this
					}(),
					i = r.WebSocket || r.MozWebSocket;
				t.exports = i ? s : null, i && (s.prototype = i.prototype)
			}, {}],
			36: [function(e, t, n) {
				(function(n) {
					function i(e) {
						function t(e) {
							if (!e) return !1;
							if (n.Buffer && n.Buffer.isBuffer(e) || n.ArrayBuffer && e instanceof ArrayBuffer || n.Blob && e instanceof Blob || n.File && e instanceof File) return !0;
							if (r(e)) {
								for (var i = 0; i < e.length; i++) if (t(e[i])) return !0
							} else if (e && "object" == typeof e) {
								e.toJSON && (e = e.toJSON());
								for (var s in e) if (Object.prototype.hasOwnProperty.call(e, s) && t(e[s])) return !0
							}
							return !1
						}
						return t(e)
					}
					var r = e("isarray");
					t.exports = i
				}).call(this, typeof self != "undefined" ? self : typeof window != "undefined" ? window : {})
			}, {
				isarray: 37
			}],
			37: [function(e, t, n) {
				t.exports = Array.isArray ||
				function(e) {
					return Object.prototype.toString.call(e) == "[object Array]"
				}
			}, {}],
			38: [function(e, t, n) {
				var r = e("global");
				try {
					t.exports = "XMLHttpRequest" in r && "withCredentials" in new r.XMLHttpRequest
				} catch (i) {
					t.exports = !1
				}
			}, {
				global: 39
			}],
			39: [function(e, t, n) {
				t.exports = function() {
					return this
				}()
			}, {}],
			40: [function(e, t, n) {
				var r = [].indexOf;
				t.exports = function(e, t) {
					if (r) return e.indexOf(t);
					for (var n = 0; n < e.length; ++n) if (e[n] === t) return n;
					return -1
				}
			}, {}],
			41: [function(e, t, n) {
				var r = Object.prototype.hasOwnProperty;
				n.keys = Object.keys ||
				function(e) {
					var t = [];
					for (var n in e) r.call(e, n) && t.push(n);
					return t
				}, n.values = function(e) {
					var t = [];
					for (var n in e) r.call(e, n) && t.push(e[n]);
					return t
				}, n.merge = function(e, t) {
					for (var n in t) r.call(t, n) && (e[n] = t[n]);
					return e
				}, n.length = function(e) {
					return n.keys(e).length
				}, n.isEmpty = function(e) {
					return 0 == n.length(e)
				}
			}, {}],
			42: [function(e, t, n) {
				var r = /^(?:(?![^:@]+:[^:@\/]*@)(http|https|ws|wss):\/\/)?((?:(([^:@]*)(?::([^:@]*))?)?@)?((?:[a-f0-9]{0,4}:){2,7}[a-f0-9]{0,4}|[^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/,
					i = ["source", "protocol", "authority", "userInfo", "user", "password", "host", "port", "relative", "path", "directory", "file", "query", "anchor"];
				t.exports = function(t) {
					var n = r.exec(t || ""),
						s = {},
						o = 14;
					while (o--) s[i[o]] = n[o] || "";
					return s
				}
			}, {}],
			43: [function(e, t, n) {
				(function(t) {
					var r = e("isarray"),
						i = e("./is-buffer");
					n.deconstructPacket = function(e) {
						function s(e) {
							if (!e) return e;
							if (i(e)) {
								var n = {
									_placeholder: !0,
									num: t.length
								};
								return t.push(e), n
							}
							if (r(e)) {
								var o = new Array(e.length);
								for (var u = 0; u < e.length; u++) o[u] = s(e[u]);
								return o
							}
							if ("object" != typeof e || e instanceof Date) return e;
							var o = {};
							for (var a in e) o[a] = s(e[a]);
							return o
						}
						var t = [],
							n = e.data,
							o = e;
						return o.data = s(n), o.attachments = t.length, {
							packet: o,
							buffers: t
						}
					}, n.reconstructPacket = function(e, t) {
						function i(e) {
							if (e && e._placeholder) {
								var n = t[e.num];
								return n
							}
							if (r(e)) {
								for (var s = 0; s < e.length; s++) e[s] = i(e[s]);
								return e
							}
							if (e && "object" == typeof e) {
								for (var o in e) e[o] = i(e[o]);
								return e
							}
							return e
						}
						var n = 0;
						return e.data = i(e.data), e.attachments = undefined, e
					}, n.removeBlobs = function(e, n) {
						function s(e, a, f) {
							if (!e) return e;
							if (t.Blob && e instanceof Blob || t.File && e instanceof File) {
								o++;
								var l = new FileReader;
								l.onload = function() {
									f ? f[a] = this.result : u = this.result, --o || n(u)
								}, l.readAsArrayBuffer(e)
							} else if (r(e)) for (var c = 0; c < e.length; c++) s(e[c], c, e);
							else if (e && "object" == typeof e && !i(e)) for (var h in e) s(e[h], h, e)
						}
						var o = 0,
							u = e;
						s(u), o || n(u)
					}
				}).call(this, typeof self != "undefined" ? self : typeof window != "undefined" ? window : {})
			}, {
				"./is-buffer": 45,
				isarray: 46
			}],
			44: [function(e, t, n) {
				function f() {}
				function l(e) {
					var t = "",
						s = !1;
					t += e.type;
					if (n.BINARY_EVENT == e.type || n.BINARY_ACK == e.type) t += e.attachments, t += "-";
					return e.nsp && "/" != e.nsp && (s = !0, t += e.nsp), null != e.id && (s && (t += ",", s = !1), t += e.id), null != e.data && (s && (t += ","), t += i.stringify(e.data)), r("encoded %j as %s", e, t), t
				}
				function c(e, t) {
					function n(e) {
						var n = u.deconstructPacket(e),
							r = l(n.packet),
							i = n.buffers;
						i.unshift(r), t(i)
					}
					u.removeBlobs(e, n)
				}
				function h() {
					this.reconstructor = null
				}
				function p(e) {
					var t = {},
						s = 0;
					t.type = Number(e.charAt(0));
					if (null == n.types[t.type]) return v();
					if (n.BINARY_EVENT == t.type || n.BINARY_ACK == t.type) {
						var o = "";
						while (e.charAt(++s) != "-") {
							o += e.charAt(s);
							if (s == e.length) break
						}
						if (o != Number(o) || e.charAt(s) != "-") throw new Error("Illegal attachments");
						t.attachments = Number(o)
					}
					if ("/" == e.charAt(s + 1)) {
						t.nsp = "";
						while (++s) {
							var u = e.charAt(s);
							if ("," == u) break;
							t.nsp += u;
							if (s == e.length) break
						}
					} else t.nsp = "/";
					var a = e.charAt(s + 1);
					if ("" !== a && Number(a) == a) {
						t.id = "";
						while (++s) {
							var u = e.charAt(s);
							if (null == u || Number(u) != u) {
								--s;
								break
							}
							t.id += e.charAt(s);
							if (s == e.length) break
						}
						t.id = Number(t.id)
					}
					if (e.charAt(++s)) try {
						t.data = i.parse(e.substr(s))
					} catch (f) {
						return v()
					}
					return r("decoded %s as %j", e, t), t
				}
				function d(e) {
					this.reconPack = e, this.buffers = []
				}
				function v(e) {
					return {
						type: n.ERROR,
						data: "parser error"
					}
				}
				var r = e("debug")("socket.io-parser"),
					i = e("json3"),
					s = e("isarray"),
					o = e("component-emitter"),
					u = e("./binary"),
					a = e("./is-buffer");
				n.protocol = 4, n.types = ["CONNECT", "DISCONNECT", "EVENT", "BINARY_EVENT", "ACK", "BINARY_ACK", "ERROR"], n.CONNECT = 0, n.DISCONNECT = 1, n.EVENT = 2, n.ACK = 3, n.ERROR = 4, n.BINARY_EVENT = 5, n.BINARY_ACK = 6, n.Encoder = f, n.Decoder = h, f.prototype.encode = function(e, t) {
					r("encoding packet %j", e);
					if (n.BINARY_EVENT == e.type || n.BINARY_ACK == e.type) c(e, t);
					else {
						var i = l(e);
						t([i])
					}
				}, o(h.prototype), h.prototype.add = function(e) {
					var t;
					if ("string" == typeof e) t = p(e), n.BINARY_EVENT == t.type || n.BINARY_ACK == t.type ? (this.reconstructor = new d(t), this.reconstructor.reconPack.attachments === 0 && this.emit("decoded", t)) : this.emit("decoded", t);
					else {
						if (!a(e) && !e.base64) throw new Error("Unknown type: " + e);
						if (!this.reconstructor) throw new Error("got binary data when not reconstructing a packet");
						t = this.reconstructor.takeBinaryData(e), t && (this.reconstructor = null, this.emit("decoded", t))
					}
				}, h.prototype.destroy = function() {
					this.reconstructor && this.reconstructor.finishedReconstruction()
				}, d.prototype.takeBinaryData = function(e) {
					this.buffers.push(e);
					if (this.buffers.length == this.reconPack.attachments) {
						var t = u.reconstructPacket(this.reconPack, this.buffers);
						return this.finishedReconstruction(), t
					}
					return null
				}, d.prototype.finishedReconstruction = function() {
					this.reconPack = null, this.buffers = []
				}
			}, {
				"./binary": 43,
				"./is-buffer": 45,
				"component-emitter": 9,
				debug: 10,
				isarray: 46,
				json3: 47
			}],
			45: [function(e, t, n) {
				(function(e) {
					function n(t) {
						return e.Buffer && e.Buffer.isBuffer(t) || e.ArrayBuffer && t instanceof ArrayBuffer
					}
					t.exports = n
				}).call(this, typeof self != "undefined" ? self : typeof window != "undefined" ? window : {})
			}, {}],
			46: [function(e, t, n) {
				t.exports = e(37)
			}, {}],
			47: [function(t, n, r) {
				(function(t) {
					function h(e) {
						if (h[e] !== o) return h[e];
						var t;
						if (e == "bug-string-char-index") t = "a" [0] != "a";
						else if (e == "json") t = h("json-stringify") && h("json-parse");
						else {
							var r, i = '{"a":[1,true,false,null,"\\u0000\\b\\n\\f\\r\\t"]}';
							if (e == "json-stringify") {
								var s = f.stringify,
									u = typeof s == "function" && l;
								if (u) {
									(r = function() {
										return 1
									}).toJSON = r;
									try {
										u = s(0) === "0" && s(new Number) === "0" && s(new String) == '""' && s(n) === o && s(o) === o && s() === o && s(r) === "1" && s([r]) == "[1]" && s([o]) == "[null]" && s(null) == "null" && s([o, n, null]) == "[null,null,null]" && s({
											a: [r, true, false, null, "\0\b\n\f\r	"]
										}) == i && s(null, r) === "1" && s([1, 2], null, 1) == "[\n 1,\n 2\n]" && s(new Date(-864e13)) == '"-271821-04-20T00:00:00.000Z"' && s(new Date(864e13)) == '"+275760-09-13T00:00:00.000Z"' && s(new Date(-621987552e5)) == '"-000001-01-01T00:00:00.000Z"' && s(new Date(-1)) == '"1969-12-31T23:59:59.999Z"'
									} catch (a) {
										u = !1
									}
								}
								t = u
							}
							if (e == "json-parse") {
								var c = f.parse;
								if (typeof c == "function") try {
									if (c("0") === 0 && !c(!1)) {
										r = c(i);
										var p = r["a"].length == 5 && r.a[0] === 1;
										if (p) {
											try {
												p = !c('"	"')
											} catch (a) {}
											if (p) try {
												p = c("01") !== 1
											} catch (a) {}
											if (p) try {
												p = c("1.") !== 1
											} catch (a) {}
										}
									}
								} catch (a) {
									p = !1
								}
								t = p
							}
						}
						return h[e] = !! t
					}
					var n = {}.toString,
						i, s, o, u = typeof e == "function" && e.amd,
						a = typeof JSON == "object" && JSON,
						f = typeof r == "object" && r && !r.nodeType && r;
					f && a ? (f.stringify = a.stringify, f.parse = a.parse) : f = t.JSON = a || {};
					var l = new Date(-0xc782b5b800cec);
					try {
						l = l.getUTCFullYear() == -109252 && l.getUTCMonth() === 0 && l.getUTCDate() === 1 && l.getUTCHours() == 10 && l.getUTCMinutes() == 37 && l.getUTCSeconds() == 6 && l.getUTCMilliseconds() == 708
					} catch (c) {}
					if (!h("json")) {
						var p = "[object Function]",
							d = "[object Date]",
							v = "[object Number]",
							m = "[object String]",
							g = "[object Array]",
							y = "[object Boolean]",
							b = h("bug-string-char-index");
						if (!l) var w = Math.floor,
							E = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334],
							S = function(e, t) {
								return E[t] + 365 * (e - 1970) + w((e - 1969 + (t = +(t > 1))) / 4) - w((e - 1901 + t) / 100) + w((e - 1601 + t) / 400)
							};
						(i = {}.hasOwnProperty) || (i = function(e) {
							var t = {},
								r;
							return (t.__proto__ = null, t.__proto__ = {
								toString: 1
							}, t).toString != n ? i = function(e) {
								var t = this.__proto__,
									n = e in (this.__proto__ = null, this);
								return this.__proto__ = t, n
							} : (r = t.constructor, i = function(e) {
								var t = (this.constructor || r).prototype;
								return e in this && !(e in t && this[e] === t[e])
							}), t = null, i.call(this, e)
						});
						var x = {
							"boolean": 1,
							number: 1,
							string: 1,
							"undefined": 1
						},
							T = function(e, t) {
								var n = typeof e[t];
								return n == "object" ? !! e[t] : !x[n]
							};
						s = function(e, t) {
							var r = 0,
								o, u, a;
							(o = function() {
								this.valueOf = 0
							}).prototype.valueOf = 0, u = new o;
							for (a in u) i.call(u, a) && r++;
							return o = u = null, r ? r == 2 ? s = function(e, t) {
								var r = {},
									s = n.call(e) == p,
									o;
								for (o in e)(!s || o != "prototype") && !i.call(r, o) && (r[o] = 1) && i.call(e, o) && t(o)
							} : s = function(e, t) {
								var r = n.call(e) == p,
									s, o;
								for (s in e)(!r || s != "prototype") && i.call(e, s) && !(o = s === "constructor") && t(s);
								(o || i.call(e, s = "constructor")) && t(s)
							} : (u = ["valueOf", "toString", "toLocaleString", "propertyIsEnumerable", "isPrototypeOf", "hasOwnProperty", "constructor"], s = function(e, t) {
								var r = n.call(e) == p,
									s, o, a = !r && typeof e.constructor != "function" && T(e, "hasOwnProperty") ? e.hasOwnProperty : i;
								for (s in e)(!r || s != "prototype") && a.call(e, s) && t(s);
								for (o = u.length; s = u[--o]; a.call(e, s) && t(s));
							}), s(e, t)
						};
						if (!h("json-stringify")) {
							var N = {
								92: "\\\\",
								34: '\\"',
								8: "\\b",
								12: "\\f",
								10: "\\n",
								13: "\\r",
								9: "\\t"
							},
								C = "000000",
								k = function(e, t) {
									return (C + (t || 0)).slice(-e)
								},
								L = "\\u00",
								A = function(e) {
									var t = '"',
										n = 0,
										r = e.length,
										i = r > 10 && b,
										s;
									i && (s = e.split(""));
									for (; n < r; n++) {
										var o = e.charCodeAt(n);
										switch (o) {
										case 8:
										case 9:
										case 10:
										case 12:
										case 13:
										case 34:
										case 92:
											t += N[o];
											break;
										default:
											if (o < 32) {
												t += L + k(2, o.toString(16));
												break
											}
											t += i ? s[n] : b ? e.charAt(n) : e[n]
										}
									}
									return t + '"'
								},
								O = function(e, t, r, u, a, f, l) {
									var c, h, p, b, E, x, T, N, C, L, M, _, D, P, H, B;
									try {
										c = t[e]
									} catch (j) {}
									if (typeof c == "object" && c) {
										h = n.call(c);
										if (h == d && !i.call(c, "toJSON")) if (c > -1 / 0 && c < 1 / 0) {
											if (S) {
												E = w(c / 864e5);
												for (p = w(E / 365.2425) + 1970 - 1; S(p + 1, 0) <= E; p++);
												for (b = w((E - S(p, 0)) / 30.42); S(p, b + 1) <= E; b++);
												E = 1 + E - S(p, b), x = (c % 864e5 + 864e5) % 864e5, T = w(x / 36e5) % 24, N = w(x / 6e4) % 60, C = w(x / 1e3) % 60, L = x % 1e3
											} else p = c.getUTCFullYear(), b = c.getUTCMonth(), E = c.getUTCDate(), T = c.getUTCHours(), N = c.getUTCMinutes(), C = c.getUTCSeconds(), L = c.getUTCMilliseconds();
											c = (p <= 0 || p >= 1e4 ? (p < 0 ? "-" : "+") + k(6, p < 0 ? -p : p) : k(4, p)) + "-" + k(2, b + 1) + "-" + k(2, E) + "T" + k(2, T) + ":" + k(2, N) + ":" + k(2, C) + "." + k(3, L) + "Z"
										} else c = null;
										else typeof c.toJSON == "function" && (h != v && h != m && h != g || i.call(c, "toJSON")) && (c = c.toJSON(e))
									}
									r && (c = r.call(t, e, c));
									if (c === null) return "null";
									h = n.call(c);
									if (h == y) return "" + c;
									if (h == v) return c > -1 / 0 && c < 1 / 0 ? "" + c : "null";
									if (h == m) return A("" + c);
									if (typeof c == "object") {
										for (P = l.length; P--;) if (l[P] === c) throw TypeError();
										l.push(c), M = [], H = f, f += a;
										if (h == g) {
											for (D = 0, P = c.length; D < P; D++) _ = O(D, c, r, u, a, f, l), M.push(_ === o ? "null" : _);
											B = M.length ? a ? "[\n" + f + M.join(",\n" + f) + "\n" + H + "]" : "[" + M.join(",") + "]" : "[]"
										} else s(u || c, function(e) {
											var t = O(e, c, r, u, a, f, l);
											t !== o && M.push(A(e) + ":" + (a ? " " : "") + t)
										}), B = M.length ? a ? "{\n" + f + M.join(",\n" + f) + "\n" + H + "}" : "{" + M.join(",") + "}" : "{}";
										return l.pop(), B
									}
								};
							f.stringify = function(e, t, r) {
								var i, s, o, u;
								if (typeof t == "function" || typeof t == "object" && t) if ((u = n.call(t)) == p) s = t;
								else if (u == g) {
									o = {};
									for (var a = 0, f = t.length, l; a < f; l = t[a++], (u = n.call(l), u == m || u == v) && (o[l] = 1));
								}
								if (r) if ((u = n.call(r)) == v) {
									if ((r -= r % 1) > 0) for (i = "", r > 10 && (r = 10); i.length < r; i += " ");
								} else u == m && (i = r.length <= 10 ? r : r.slice(0, 10));
								return O("", (l = {}, l[""] = e, l), s, o, i, "", [])
							}
						}
						if (!h("json-parse")) {
							var M = String.fromCharCode,
								_ = {
									92: "\\",
									34: '"',
									47: "/",
									98: "\b",
									116: "	",
									110: "\n",
									102: "\f",
									114: "\r"
								},
								D, P, H = function() {
									throw D = P = null, SyntaxError()
								},
								B = function() {
									var e = P,
										t = e.length,
										n, r, i, s, o;
									while (D < t) {
										o = e.charCodeAt(D);
										switch (o) {
										case 9:
										case 10:
										case 13:
										case 32:
											D++;
											break;
										case 123:
										case 125:
										case 91:
										case 93:
										case 58:
										case 44:
											return n = b ? e.charAt(D) : e[D], D++, n;
										case 34:
											for (n = "@", D++; D < t;) {
												o = e.charCodeAt(D);
												if (o < 32) H();
												else if (o == 92) {
													o = e.charCodeAt(++D);
													switch (o) {
													case 92:
													case 34:
													case 47:
													case 98:
													case 116:
													case 110:
													case 102:
													case 114:
														n += _[o], D++;
														break;
													case 117:
														r = ++D;
														for (i = D + 4; D < i; D++) o = e.charCodeAt(D), o >= 48 && o <= 57 || o >= 97 && o <= 102 || o >= 65 && o <= 70 || H();
														n += M("0x" + e.slice(r, D));
														break;
													default:
														H()
													}
												} else {
													if (o == 34) break;
													o = e.charCodeAt(D), r = D;
													while (o >= 32 && o != 92 && o != 34) o = e.charCodeAt(++D);
													n += e.slice(r, D)
												}
											}
											if (e.charCodeAt(D) == 34) return D++, n;
											H();
										default:
											r = D, o == 45 && (s = !0, o = e.charCodeAt(++D));
											if (o >= 48 && o <= 57) {
												o == 48 && (o = e.charCodeAt(D + 1), o >= 48 && o <= 57) && H(), s = !1;
												for (; D < t && (o = e.charCodeAt(D), o >= 48 && o <= 57); D++);
												if (e.charCodeAt(D) == 46) {
													i = ++D;
													for (; i < t && (o = e.charCodeAt(i), o >= 48 && o <= 57); i++);
													i == D && H(), D = i
												}
												o = e.charCodeAt(D);
												if (o == 101 || o == 69) {
													o = e.charCodeAt(++D), (o == 43 || o == 45) && D++;
													for (i = D; i < t && (o = e.charCodeAt(i), o >= 48 && o <= 57); i++);
													i == D && H(), D = i
												}
												return +e.slice(r, D)
											}
											s && H();
											if (e.slice(D, D + 4) == "true") return D += 4, !0;
											if (e.slice(D, D + 5) == "false") return D += 5, !1;
											if (e.slice(D, D + 4) == "null") return D += 4, null;
											H()
										}
									}
									return "$"
								},
								j = function(e) {
									var t, n;
									e == "$" && H();
									if (typeof e == "string") {
										if ((b ? e.charAt(0) : e[0]) == "@") return e.slice(1);
										if (e == "[") {
											t = [];
											for (;; n || (n = !0)) {
												e = B();
												if (e == "]") break;
												n && (e == "," ? (e = B(), e == "]" && H()) : H()), e == "," && H(), t.push(j(e))
											}
											return t
										}
										if (e == "{") {
											t = {};
											for (;; n || (n = !0)) {
												e = B();
												if (e == "}") break;
												n && (e == "," ? (e = B(), e == "}" && H()) : H()), (e == "," || typeof e != "string" || (b ? e.charAt(0) : e[0]) != "@" || B() != ":") && H(), t[e.slice(1)] = j(B())
											}
											return t
										}
										H()
									}
									return e
								},
								F = function(e, t, n) {
									var r = I(e, t, n);
									r === o ? delete e[t] : e[t] = r
								},
								I = function(e, t, r) {
									var i = e[t],
										o;
									if (typeof i == "object" && i) if (n.call(i) == g) for (o = i.length; o--;) F(i, o, r);
									else s(i, function(e) {
										F(i, e, r)
									});
									return r.call(e, t, i)
								};
							f.parse = function(e, t) {
								var r, i;
								return D = 0, P = "" + e, r = j(B()), B() != "$" && H(), D = P = null, t && n.call(t) == p ? I((i = {}, i[""] = r, i), "", t) : r
							}
						}
					}
					u && e(function() {
						return f
					})
				})(this)
			}, {}],
			48: [function(e, t, n) {
				function r(e, t) {
					var n = [];
					t = t || 0;
					for (var r = t || 0; r < e.length; r++) n[r - t] = e[r];
					return n
				}
				t.exports = r
			}, {}]
		}, {}, [1])(1)
	}), define("model/shake", ["require", "base/global", "base/hosts", "base/cache", "base/util", "template"], function(e) {
		var t = e("base/global"),
			n = e("base/hosts"),
			r = e("base/cache"),
			i = e("base/util"),
			s = e("template"),
			o = new Object;
		return o.defaults = {
			gameStatus: 0,
			count: 0
		}, o.config = {
			count: 0,
			total: 10
		}, o.user = new Array, o.rankTrend = new Array, o.join = function(e) {
			var t = this,
				n = o.user.length;
			try {
				return $.each(t.user, function(t, n) {
					if (n.openid == e.openid) throw !1
				}), t.user.push({
					openID: e.openid,
					name: e.name,
					head: e.head,
					score: 0
				}), !0
			} catch (r) {
				return !1
			}
		}, o.addShakeTime = function(e) {
			o.defaults.gameStatus == 1 && o.user[e] && o.user[e].shakeTime++, o.user[e]["shakeTime"] == o.config.total && (o.defaults.gameStatus = 2)
		}, o.ranking = function() {
			var e = function(e) {
					return function(t, n) {
						var r, i;
						if (typeof t == "object" && typeof n == "object" && t && n) return r = t[e], i = n[e], r === i ? 0 : r < i ? -1 : 1;
						throw "error"
					}
				},
				t = $.extend(!0, [], o.user);
			t = t.sort(e("shakeTime")), t = t.reverse(), o.rankTrend.push(t)
		}, o.percent = function(e) {
			return Math.round(e / o.config.total * 100)
		}, o.sendRecord = function(e) {
			var t = new Array,
				n = new Array,
				i = new Array;
			$.each(e, function(e, r) {
				t.push(r.name), n.push(r.head), i.push(r.openid)
			}), r.get("GameWinner", {
				"names[]": t,
				"heads[]": n,
				"accounts[]": i
			}).done(function(e) {
				console.log(e)
			})
		}, o
	}), define("controller/shake", ["require", "base/controller", "base/global", "base/util", "base/directive", "base/remote", "vendor/socket.io", "model/shake", "template", "vendor/swiper"], function(e) {
		"use strict";
		var t = e("base/controller"),
			n = e("base/global"),
			r = e("base/util"),
			i = e("base/directive"),
			s = e("base/remote"),
			o = e("vendor/socket.io"),
			u = e("model/shake"),
			a = e("template"),
			f = e("vendor/swiper"),
			l, c, h, p, d = null,
			v = new Object;
		return v.render = function() {
			var e = this;
			if (!n.isActive("shake")) {
				r.alert({
					path: n.path,
					content: {
						message: "摇一摇互动游戏功能没有开启"
					}
				});
				return
			}
			$(".viewport").html(l), e.bindEvent(), e.initSocket()
		}, v.gameOver = function(e) {
			var t = this;
			clearInterval(t.sync), $(".game-result-overlay").html(a(n.path + "/game/shake/record", {
				list: e
			})), $(".game-process").addClass("hide"), $(".game-result-overlay").addClass("show"), u.sendRecord(e)
		}, v.gameStart = function(e) {
			var t = this;
			e || d.emit("start", {
				count: u.config.total
			});
			var r = $(".game-process ul"),
				i = $.extend(!0, [], u.user);
			u.rankTrend.push(i), $.each(u.rankTrend[u.rankTrend.length - 1], function(e, t) {
				t.index = e, t.score = 0;
				var i = $("#process_item_" + t.openid);
				i.length == 0 && (t.top = 15 + e * 125, r.append(a(n.path + "/game/shake/rank", t)))
			}), t.sync = window.setInterval(function() {
				d.emit("rank")
			}, 1e3)
		}, v.gameProcess = function() {
			var e = $(".game-process ul");
			e.empty(), $.each(u.rankTrend[u.rankTrend.length - 1], function(t, r) {
				r.index = t;
				var i = $("#process_item_" + r.openid);
				i.length == 0 && (r.top = 15 + t * 125, e.append(a(n.path + "/game/shake/rank", r)), i = $("#process_item_" + r.openid));
				var s = 5 + t * 125;
				i.css({
					top: s + "px"
				});
				var o = u.percent(r.score);
				i.find(".val").css({
					"-webkit-transform": "translateX(-" + (100 - o) + "%)"
				}), i.find(".run").css({
					right: 100 - o + "%"
				}), i.find(".percent").html(r.score + "次");
				var f;
				t < 3 ? f = '<span class="medal rank' + (t + 1) + '"></span>' : '<span class="num">' + (t + 1) + "</span>", i.find(".rank").html(f)
			})
		}, v.wakeUpAll = function() {
			$.each(u.user, function(e, t) {
				var r = n.model.data.token + t.openid,
					i = {
						status: 1,
						msg: "游戏开始，小伙伴们疯狂摇起来！",
						total: u.config.total
					};
				s.sendMessage(r, i)
			})
		}, v.sleepAll = function() {
			$.each(u.user, function(e, t) {
				var r = n.model.data.token + t.openid,
					i = {
						status: 2,
						msg: "游戏结束，请关注大屏幕显示比赛结果"
					};
				s.sendMessage(r, i)
			})
		}, v.gameReset = function() {
			d.emit("reset")
		}, v.initSocket = function() {
			var e = this,
				t = n.model.data.token;
			d = new o("http://bayeux.events.qq.com/screen", {
				query: {
					campaign_id: n.model.params.campaign_id,
					s_tk: t
				}
			}), d.on("error", function(e) {
				console.log("socket error")
			}), d.on("connect", function(e) {
				console.log("socket connect"), d.emit("init")
			}), d.on("init", function(t) {
				t.running ? ($(".count-overlay").removeClass("show"), $(".game-process").removeClass("hide"), $(".game-prepare").addClass("hide"), $(".game-sidebar").addClass("hide"), u.config.total = t.count, e.gameStart(!0)) : e.showUser(t.list)
			}), d.on("disconnect", function(e) {
				console.log("screen disconnect"), console.log(e)
			}), d.on("new player", function(t) {
				console.log("new player"), e.joinUser(t)
			}), d.on("player disconnect", function(t) {
				console.log("player disconnect"), e.removeUser(t)
			}), d.on("game over", function(e) {
				console.log("game over"), v.gameOver(e)
			}), d.on("rank", function(t) {
				u.rankTrend.push(t), e.gameProcess()
			})
		}, v.joinUser = function(e) {
			u.config.count = e.count;
			var t = !1;
			u.user.forEach(function(n) {
				n.openid == e.openid && (t = !0)
			}), t || u.user.push({
				openid: e.openid,
				name: e.name,
				head: e.head
			}), $(".game-userlist-nouser").addClass("hide"), $(".game-userlist-con ul").empty(), u.user.forEach(function(e) {
				$(".game-userlist-con ul").append(a(n.path + "/game/shake/join", e))
			}), $("#join_num").html(u.config.count), $(".game-userlist-con").scrollTop($(".game-userlist-con").height())
		}, v.removeUser = function(e) {
			u.config.count = e.count, u.user = u.user.filter(function(t) {
				return t.openid == e.openid ? !1 : !0
			}), $(".game-userlist-nouser").addClass("hide"), $(".game-userlist-con ul").empty(), u.user.forEach(function(e) {
				$(".game-userlist-con ul").append(a(n.path + "/game/shake/join", e))
			}), $("#join_num").html(u.config.count), $(".game-userlist-con").scrollTop($(".game-userlist-con").height())
		}, v.showUser = function(e) {
			u.config.count = e.length, u.user = e, $(".game-userlist-nouser").addClass("hide"), $(".game-userlist-con ul").empty(), u.user.forEach(function(e) {
				$(".game-userlist-con ul").append(a(n.path + "/game/shake/join", e))
			}), $("#join_num").html(u.config.count), $(".game-userlist-con").scrollTop($(".game-userlist-con").height())
		}, v.bindEvent = function() {
			var e = this;
			$("#shake").on("click", ".start-btn", function() {
				u.config.total = parseInt($("#shakeTime").html());
				if (!/^\d{1,}$/.test(u.config.total) || u.config.total > 2e3 || u.config.total <= 0) {
					r.alert({
						path: n.path,
						content: {
							message: "摇一摇次数要设置0-2000之间的数字"
						}
					});
					return
				}
				if (!u.user.length) {
					r.alert({
						path: n.path,
						content: {
							message: "暂无用户参与，不能开始游戏"
						}
					});
					return
				}
				$(".count-overlay").addClass("show"), e.gameStart(), window.setTimeout(function() {
					$(".count-overlay").removeClass("show"), $(".game-process").removeClass("hide"), $(".game-prepare").addClass("hide"), $(".game-sidebar").addClass("hide"), u.defaults.gameStatus = 1, $(".process-con ul").empty()
				}, 4500)
			}), $("#shake").on("click", ".restart, #reset", function() {
				e.gameReset(), window.setTimeout(function() {
					window.location.reload()
				}, 1e3)
			}), $("#shake").on("click", ".show-list", function() {
				$(".game-result-overlay .visual").addClass("hide"), $(".game-result-overlay .list").removeClass("hide")
			}), $("#shake").on("click", ".show-visual", function() {
				$(".game-result-overlay .visual").removeClass("hide"), $(".game-result-overlay .list").addClass("hide")
			}), $("#shake").on("click", ".minus", function() {
				u.config.total > 0 && (u.config.total -= 10), $("#shakeTime").html(u.config.total)
			}), $("#shake").on("click", ".add", function() {
				u.config.total < 2e3 && (u.config.total += 10), $("#shakeTime").html(u.config.total)
			})
		}, v.unload = function() {}, v.init = function(e) {
			t.register({
				name: "shake",
				before: function() {
					n.prepareData(e), $.when(n.checkLogin()).done(function() {
						$.when(n.getInfo()).done(function() {
							n.ready && n.render()
						})
					})
				},
				controller: function(e) {
					if (n.ready) {
						var t = "http://labs.api.act.qq.com/631007063/qrcode/get_image/?format=png&size=6&msg=" + encodeURIComponent("http://" + window.location.host + "/live/game/shake?campaign_id=" + n.model.params.campaign_id);
						n.model.data = $.extend(n.model.data, {
							shakeQrcode: t,
							shakeTime: u.config.total
						}), l = a(n.path + "/game/shake/layout", n.model.data), v.render()
					}
				},
				unload: function() {
					v.unload()
				}
			}), t.get("shake").controller()
		}, v
	}), define("model/guess", ["require", "base/global", "base/hosts", "base/cache", "base/util", "template"], function(e) {
		var t = e("base/global"),
			n = e("base/hosts"),
			r = e("base/cache"),
			i = e("base/util"),
			s = e("template"),
			o = new Object;
		return o.config = {
			time: 3,
			interval: 1,
			started: 0,
			startTime: 0,
			leftTime: 0
		}, o.collection = new Array, o.setGuessingDuration = function() {
			var e = this;
			e.config.leftTime = e.config.time * 60, r.get("GuessingDuration", {
				minute: e.config.time
			}).done(function(t) {
				t.code || (e.config.startTime = $.now(), e.config.started = 1)
			})
		}, o.reRank = function() {
			var e = this,
				n = function() {
					e.sync = window.setTimeout(function() {
						n()
					}, e.config.interval * 1e3), e.config.started && r.get("GuessingRank", {
						offset: 0,
						limit: 10
					}).done(function(n) {
						if (!n.code) {
							var r = n.data;
							for (var s = 0; s < r.length; s++) r[s].index = s, r[s].head = i.getHead(r[s], t.model.data);
							e.collection = r
						}
					})
				};
			n()
		}, o.getLeftTime = function() {
			var e = this;
			if (!e.config.startTime) return e.config.leftTime;
			var t = $.now() - e.config.startTime;
			return e.config.leftTime - Math.round(t / 1e3)
		}, o.continueGame = function(e) {
			var t = this;
			r.get("GuessingStatus").done(function(n) {
				!n.code && n.data.remain_time && (t.config.startTime = $.now(), t.config.leftTime = n.data.remain_time / 1e3, e.callback())
			})
		}, o
	}), define("controller/guess", ["require", "base/controller", "base/global", "base/util", "base/directive", "base/remote", "model/guess", "template", "vendor/swiper"], function(e) {
		"use strict";
		var t = e("base/controller"),
			n = e("base/global"),
			r = e("base/util"),
			i = e("base/directive"),
			s = e("base/remote"),
			o = e("model/guess"),
			u = e("template"),
			a = e("vendor/swiper"),
			f, l, c, h, p = {},
			d = new Object;
		return d.render = function() {
			var e = this;
			if (!n.isActive("guess")) {
				r.popup({
					content: "石头剪刀布互动游戏功能没有开启"
				});
				return
			}
			$(".viewport").html(f), e.bindEvent(), o.continueGame({
				callback: function() {
					$(".game-prepare, .game-sidebar").addClass("hide"), $(".game-process").removeClass("hide"), $(".game-process ul").empty(), o.config.started = 1, o.reRank(), e.startCountDown()
				}
			})
		}, d.gameStart = function() {
			var e = this;
			o.setGuessingDuration(), o.reRank(), e.startCountDown()
		}, d.gameOver = function(e) {
			o.config.started = 0, $(".game-result-overlay").html(u(n.path + "/game/guess/record", {
				list: o.collection
			})), $(".game-process").addClass("hide"), $(".game-result-overlay").addClass("show")
		}, d.startCountDown = function() {
			var e = this,
				t = function() {
					var r = $(".game-process ul");
					r.empty(), o.collection.length && $.each(o.collection, function(e, t) {
						if (e > 5) return;
						t.index = e, t.top = 5 + e * 125, r.append(u(n.path + "/game/guess/rank", t))
					});
					var i = o.getLeftTime();
					if (i <= 0) {
						$(".process-timer").html(i), e.gameOver();
						return
					}
					$(".process-timer").html(i), e.sync = window.setTimeout(function() {
						t()
					}, 1e3)
				};
			t()
		}, d.bindEvent = function() {
			var e = this;
			$("#guess").on("click", ".start-btn", function() {
				$(".count-overlay").addClass("show"), window.setTimeout(function() {
					$(".count-overlay").removeClass("show"), $(".game-process").removeClass("hide"), $(".game-prepare, .game-sidebar").addClass("hide"), $(".process-con ul").empty(), e.gameStart()
				}, 4500)
			}), $("#guess").on("click", ".restart", function() {
				window.location.reload()
			}), $("#guess").on("click", ".show-list", function() {
				$(".game-result-overlay .visual").addClass("hide"), $(".game-result-overlay .list").removeClass("hide")
			}), $("#guess").on("click", ".show-visual", function() {
				$(".game-result-overlay .visual").removeClass("hide"), $(".game-result-overlay .list").addClass("hide")
			}), $("#guess").on("click", ".minus", function() {
				o.config.time > 0 && (o.config.time -= 1), $("#guessTime").html(o.config.time)
			}), $("#guess").on("click", ".add", function() {
				o.config.time < 100 && (o.config.time += 1), $("#guessTime").html(o.config.time)
			})
		}, d.unload = function() {}, d.init = function(e) {
			t.register({
				name: "guess",
				before: function() {
					n.prepareData(e), $.when(n.checkLogin()).done(function() {
						$.when(n.getInfo()).done(function() {
							n.ready && n.render()
						})
					})
				},
				controller: function(e) {
					if (n.ready) {
						var t = "http://labs.api.act.qq.com/631007063/qrcode/get_image/?format=png&size=6&msg=" + encodeURIComponent("http://" + window.location.host + "/live/game/guessing?campaign_id=" + n.model.params.campaign_id),
							r = $.extend(!0, n.model.data, {
								guessQrcode: t,
								guessTime: o.config.time
							});
						f = u(n.path + "/game/guess/layout", r), d.render()
					}
				},
				unload: function() {
					d.unload()
				}
			}), t.get("guess").controller()
		}, d
	}), require.config({
		paths: {
			bayeux: "vendor/client.min",
			ptlogin: "vendor/ptlogin_v1",
			emopr: "vendor/parser"
		},
		shim: {
			template: {
				exports: "template"
			},
			bayeux: {
				exports: "bayeux"
			},
			ptlogin: {
				exports: "ptlogin"
			},
			emopr: {
				exports: "emopr"
			},
			"vendor/preloader": {
				exports: "vendor/preloader"
			}
		}
	}), require(["base/router", "template", "base/directive", "controller/error", "controller/message", "controller/lottery", "controller/image", "controller/signin", "controller/vote", "controller/brand", "controller/shake", "controller/guess"], function(e, t) {
		var n;
		e.registerRoutes({
			message: {
				path: ":campaign_id/message",
				moduleId: "controller/message"
			},
			image: {
				path: ":campaign_id/image",
				moduleId: "controller/image"
			},
			lottery: {
				path: ":campaign_id/lottery",
				moduleId: "controller/lottery"
			},
			signin: {
				path: ":campaign_id/signin",
				moduleId: "controller/signin"
			},
			vote: {
				path: ":campaign_id/vote",
				moduleId: "controller/vote"
			},
			brand: {
				path: ":campaign_id/brand",
				moduleId: "controller/brand"
			},
			shake: {
				path: ":campaign_id/shake",
				moduleId: "controller/shake"
			},
			guess: {
				path: ":campaign_id/guess",
				moduleId: "controller/guess"
			},
			error: {
				path: "error/:error_id",
				moduleId: "controller/error"
			},
			notFound: {
				path: "*",
				moduleId: "controller/notfound"
			}
		}).init()
	}), define("main", function() {})
})();
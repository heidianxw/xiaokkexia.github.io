<?php
/**
 * 摇一摇跑马模块微站定义
 *
 * @author Meepo_zam
 * @url http://bbs.we7.cc/
 */
defined('IN_IA') or exit('Access Denied');
define('RES', '../addons/meepo_paoma/template/mobile/');
class Meepo_paomaModuleSite extends WeModuleSite {
		public $reply_table = 'meepo_paoma_reply';
		public $activity_table = 'meepo_paoma_activity';
		public $user_table = 'meepo_paoma_user';
    public function doMobilelogin(){
				global $_GPC, $_W;
				$rid = intval($_GPC['rid']);
				$weid = $_W['uniacid'];
				$ridwall = pdo_fetch("SELECT * FROM ".tablename($this->reply_table)." WHERE weid=:weid AND rid = :rid", array(':weid'=>$weid,':rid'=>$rid));
				if(empty($rid)){
				  message('参数错误，请重新进入！');
				}
				include $this->template('login');
	}
	 public function docheckurl(){
				global $_GPC, $_W;
				  return false;
	}
	public function doMobilechecklogin(){
	      global $_GPC, $_W;
				$weid = $_W['uniacid'];
				$rid = intval($_GPC['rid']);
				$ridwall = pdo_fetch("SELECT * FROM ".tablename($this->reply_table)." WHERE weid=:weid AND rid = :rid", array(':weid'=>$weid,':rid'=>$rid));
				if(!empty($_POST['pass'])){
					if($_POST['pass'] == $ridwall['loginpass']){
				       setcookie("Meepo".$rid,$ridwall['loginpass'], time()+3600*4);
		               echo 1;
					}else{
					  echo 0;
					}
		    }else{
				 echo 0;
				}    
	}
	
	public function doMobileindex(){//摇一摇屏幕界面
		global $_GPC, $_W;
		$weid = $_W['uniacid'];
		$rid = intval($_GPC['rid']);
		$ridwall = pdo_fetch("SELECT * FROM ".tablename($this->reply_table)." WHERE weid=:weid AND rid = :rid",array(":weid"=>$weid,":rid"=>$rid));
		if(empty($rid)){
			 message('参数错误 请重新回复！');
		}
		if(empty($ridwall)){
			 message('活动规则不存在');
		}
		if(isset($_COOKIE["Meepo".$rid]) && $_COOKIE["Meepo".$rid] ==$ridwall['loginpass'] ){
	  }else {
		  $url=$this->createMobileUrl('login',array('rid'=>$rid));			
		  header("location:$url");
		  exit;
    }
		$keyword = pdo_fetchcolumn("SELECT content FROM ".tablename('rule_keyword')." WHERE  uniacid='{$weid}' AND module='meepo_paoma' AND rid='{$rid}'");
		$SHAKE_INFO = $ridwall;
		$SHAKE_INFO['slogan'] = "不晓得啥作用";
		if(!empty($ridwall['slogan_list'])){
				if(strexists($ridwall['slogan_list'],"#")){
					$SHAKE_INFO['slogan_list'] = explode('#',$ridwall['slogan_list']); 
				}else{
					$SHAKE_INFO['slogan_list'] = array($ridwall['slogan_list']);
				}
		}
		$had_done = pdo_fetchcolumn("SELECT COUNT(*) FROM ".tablename($this->activity_table)." WHERE rid=:rid AND weid=:weid AND status=:status",array(":rid"=>$rid,":weid"=>$weid,':status'=>2));
		$sql = "SELECT * FROM ".tablename($this->activity_table)." WHERE rid=:rid AND weid=:weid  ORDER BY id ASC";
		$lists = pdo_fetchall($sql,array(":rid"=>$rid,":weid"=>$weid));
		$SHAKE_INFO['rotate_list'] = $lists;
		$SHAKE_INFO = json_encode($SHAKE_INFO);
		$node_js = $this->module['config'];
		$socket_url = $node_js['socket_url'];
		if(empty($socket_url)){
			message('请先配置nodejs服务器参数');
		}
    include $this->template('index');
	}
	public function doWebYyyindex() {
		global $_GPC, $_W;
		checklogin();
		$id = intval($_GPC['id']);
    $url='../app/'.$this->createMobileUrl('Index',array('rid'=>$id));		
		header("location:$url");
		exit;
	}
	public function doMobileOauth(){
		global $_W,$_GPC;
		$weid = $_W['uniacid'];
		$openid = $_W['openid'];
		$rid = intval($_GPC['rid']);
		$rotate_id = intval($_GPC['rotate_id']);
		$reply = pdo_fetch("SELECT * FROM " . tablename($this->reply_table) . " WHERE rid = :rid", array(':rid' => $rid));
 		$code = $_GPC['code'];
		if ($_GPC['code']=="authdeny" || empty($_GPC['code'])){
            message("授权失败,获取不到code");
    }
		load()->func('communication');
		if(!empty($code)) {
			$url = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=".$reply['appid']."&secret=".$reply['secret']."&code=".$code."&grant_type=authorization_code";
			$ret = ihttp_get($url);
						if(!is_error($ret)) {
							    $auth = @json_decode($ret['content'], true);
									if(is_array($auth) && !empty($auth['openid'])) {
										$url='https://api.weixin.qq.com/sns/userinfo?access_token='.$auth['access_token'].'&openid='.$auth['openid'].'&lang=zh_CN';
										$ret = ihttp_get($url);
										$auth = @json_decode($ret['content'], true);
										$user = pdo_fetchcolumn("SELECT `id` FROM ".tablename($this->user_table)." WHERE weid = :weid AND openid = :openid AND rotate_id = :rotate_id AND rid = :rid",array(":weid"=>$_W['uniacid'],':openid'=>$openid,':rotate_id'=>$rotate_id,':rid'=>$rid));
										if(empty($user)){ 
													$data = array();
													$data['weid'] = $_W['uniacid'];
													$data['openid'] = $openid;
													$data['from_user'] = $auth['openid'];
													$data['nickname'] = $auth['nickname'];
													$data['avatar'] = $auth['headimgurl'];
													$data['rotate_id'] = $rotate_id;
													$data['rid'] = $rid;
													pdo_insert($this->user_table,$data);
										}
									
										$forward =$_W['siteroot']."app/".$this->createMobileUrl('yyy',array('rid'=>$rid));
										$forward = str_replace('./','', $forward);
										header("location:$forward");
										exit;
										
									}else{
										die(json_encode($auth));
									}
						}else{
							die(json_encode($ret));
						}
		}
	}
	public function get_follow_fansinfo($openid){
					global $_W,$_GPC;
					
					$access_token = $this->getAccessToken();
					$url = 'https://api.weixin.qq.com/cgi-bin/user/info?access_token='.$access_token.'&openid='.$openid.'&lang=zh_CN';
					load()->func('communication');
					$content = ihttp_request($url);		
					$info = @json_decode($content['content'], true);
					return $info;
		}
		public  function  getAccessToken () {
			global $_W;
			load()->classs('weixin.account');
			$accObj = WeixinAccount::create($_W['acid']);
			$access_token = $accObj->fetch_token();
			return $access_token;
		}

	public function doMobileoauth2(){
	    global $_GPC, $_W;
			$weid = $_W['uniacid'];
			$rid = intval($_GPC['rid']);
			$rotate_id = intval($_GPC['rotate_id']);
			if(empty($rid)){
			   message('参数错误、请重新进入！');
			}
			$reply = pdo_fetch("SELECT * FROM ".tablename($this->reply_table)." WHERE weid=:weid AND rid = :rid LIMIT 1", array(':weid'=>$weid,':rid'=>$rid));
			$openid = $_W['openid'];
			$user = pdo_fetchcolumn("SELECT `id` FROM ".tablename($this->user_table)." WHERE weid = :weid AND openid = :openid AND rotate_id = :rotate_id AND rid = :rid",array(":weid"=>$_W['uniacid'],':openid'=>$openid,':rotate_id'=>$rotate_id,':rid'=>$rid));
				if(empty($user)){ 
							$callback =$_W['siteroot']."app/".$this->createMobileurl('oauth',array('rid'=>$rid,'rotate_id'=>$rotate_id));
							$callback = str_replace('./','',$callback);
							$callback = urlencode($callback);			
							$forward = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=".$reply['appid']."&redirect_uri={$callback}&response_type=code&scope=snsapi_userinfo&state=1#wechat_redirect";
							header('location: ' . $forward);
							exit();
				}else{
						$forward =$_W['siteroot']."app/".$this->createMobileUrl('yyy',array('rid'=>$rid));
            $forward = str_replace('./','', $forward);
					  header("location:$forward");
					  exit;
				}
	}
}
<?php
global $_W,$_GPC;
$reply_table = 'meepo_paoma_reply';
$id = intval($_GPC['id']);
$reply = pdo_fetch("SELECT * FROM " . tablename($reply_table) . " WHERE rid = :rid", array(':rid' =>$id));
if(empty($reply)){
	 message('活动规则不存在！');
}
$paoma_url = str_replace('./','',$_W['siteroot'].'app/'.$this->createMobileUrl('yyy',array('rid'=>$id)));
include $this->template('url');
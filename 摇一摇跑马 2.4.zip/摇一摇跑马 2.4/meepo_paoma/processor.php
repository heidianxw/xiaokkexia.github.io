<?php
/**
 * 摇一摇跑马模块处理程序
 *
 * @author Meepo_zam
 * @url http://bbs.we7.cc/
 */
defined('IN_IA') or exit('Access Denied');

class Meepo_paomaModuleProcessor extends WeModuleProcessor {
	public $reply_table = 'meepo_paoma_reply';
	public $activity_table = 'meepo_paoma_activity';
	public $user_table = 'meepo_paoma_user';
	public function respond() {
		global $_W,$_GPC;
		$content = $this->message['content'];
		$rid = $this->rule;
		return $this->respText('请通过添加图文消息触发！');
	}
}
<?php
global $_W,$_GPC;
$activity_table = 'meepo_paoma_activity';
$user_table = 'meepo_paoma_user';
$weid = intval($_W['uniacid']);
if($_W['isajax']){
	$top10 = $_GPC['top10'];
	$users = $_GPC['users'];
	$rotate_id = intval($_GPC['rotate_id']);
	$rid = intval($_GPC['rid']);
	if(!empty($rid) && !empty($rotate_id) && !empty($users)){
			if(is_array($top10) && !empty($top10)){
					foreach($top10 as $val){
						if(!empty($val)){
							$tmp = explode('|',$val);
							$top10_users[$tmp[0]] = $tmp[2];
						}
					}
			}
			if(is_array($users)){
				foreach($users as $row){
					$data = array();
					$data['point'] = intval($row['count']);
					$data['createtime'] = intval($row['createtime']);
					if(!empty($top10_users) && array_key_exists($row['openid'],$top10_users)){
							$data['createtime'] = intval($top10_users[$row['openid']]);
							pdo_update($user_table,$data,array('weid'=>$weid,'openid'=>$row['openid'],'rotate_id'=>$rotate_id));
					}else{
						pdo_update($user_table,$data,array('weid'=>$weid,'openid'=>$row['openid'],'rotate_id'=>$rotate_id));
					}
				}
			}
			pdo_update($activity_table,array('status'=>2),array('weid'=>$weid,'rid'=>$rid,'id'=>$rotate_id));
	}
	
}
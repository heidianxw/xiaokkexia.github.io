<?php
global $_W,$_GPC;
$weid = $_W['uniacid'];
$rid = intval($_GPC['rid']);
if(empty($rid)){
	message('活动rid错误！');
}
$ridwall = pdo_fetch("SELECT * FROM ".tablename($this->reply_table)." WHERE rid = :rid AND weid=:weid", array(':rid'=>$rid,':weid'=>$weid));	
if(empty($ridwall)){
	message('活动不存在或是已经被删除！');
}
$openid = $_W['openid'];
$url = $ridwall['gz_url'];
if(empty($openid)){
	die('请通过微信访问！');
}
$rotate = pdo_fetch("SELECT * FROM ".tablename($this->activity_table)." WHERE rid = :rid AND weid = :weid  AND status = :status ORDER BY id ASC",array(':rid'=>$rid,':weid'=>$_W['uniacid'],':status'=>'1'));
$rotate_id = $rotate['id'];
if(empty($rotate_id)){
			$rotate = pdo_fetch("SELECT * FROM ".tablename($this->activity_table)." WHERE rid = :rid AND weid = :weid  AND status = :status ORDER BY id ASC",array(':rid'=>$rid,':weid'=>$_W['uniacid'],':status'=>'0'));
			$rotate_id = $rotate['id'];
}
if(empty($rotate_id)){
	message('活动已经全部结束啦！');
}
$user = pdo_fetch("SELECT * FROM ".tablename($this->user_table)." WHERE openid=:openid AND weid=:weid AND rid=:rid AND rotate_id = :rotate_id",array(':openid'=>$openid,':weid'=>$weid,':rid'=>$rid,':rotate_id'=>$rotate_id));
if(empty($user)){
	load()->model('mc');
	$data = array();
	$data['weid'] = $_W['uniacid'];
	$data['openid'] = $openid;
	$data['from_user'] = $openid;
	$data['rotate_id'] = $rotate_id;
	$data['rid'] = $rid;
	if($_W['account']['level']<=3){
		$oauth_user = mc_oauth_userinfo();
		$data['from_user'] = $oauth_user['openid'];
		if (!is_error($oauth_user) && !empty($oauth_user) && is_array($oauth_user)) {
					$userinfo = $oauth_user;
		}else{
					message("借用oauth失败");
		}
	}else{
			/*if($_W['fans']['follow']=='1'){
					$userinfo = $this->get_follow_fansinfo($openid);
					var_dump($openid);
					die;
					if($userinfo['subscribe']!='1'){
							message('获取粉丝信息失败');
						}
			}else{*/
					
						$oauth_user = mc_oauth_userinfo();
						$data['from_user'] = $oauth_user['openid'];
						if (!is_error($oauth_user) && !empty($oauth_user) && is_array($oauth_user)) {
									$userinfo = $oauth_user;
						}else{
									message("借用oauth失败");
						}
					
			//}
	}
	if(!empty($userinfo['avatar'])){
		 $data['avatar'] = $userinfo['avatar'];
	}else{
			if(empty($userinfo['headimgurl'])){
			 $data['avatar'] =  '../addons/meepo_paoma/cdhn80.jpg';
			}else{
				$data['avatar'] = $userinfo['headimgurl'];
			}
		 
	}
	
	if(!empty($userinfo['nickname'])){
		$data['nickname'] = $userinfo['nickname'];
	}else{
		$data['nickname'] = '微信昵称无法识别';
	}
	pdo_insert($this->user_table,$data);
	$newid = pdo_insertid();
	$user = pdo_fetch("SELECT * FROM ".tablename($this->user_table)." WHERE openid=:openid AND id=:id",array(':openid'=>$openid,':id'=>$newid));
}
if(strexists($ridwall['slogan_list'],"#")){
	$ridwall['slogan_list'] = explode('#',$ridwall['slogan_list']); 
}else{
	$ridwall['slogan_list'] = array($ridwall['slogan_list']);
}
$maxshake = $ridwall['maxshake'];
$title = $ridwall['title'];
if($ridwall['awardsame'] == '1' ){
	$had_award = pdo_fetchcolumn("SELECT `id` FROM ".tablename($this->user_table)." WHERE openid = :openid AND rid = :rid AND weid = :weid AND createtime != :createtime",array(':openid'=>$openid,':rid'=>$rid,':weid'=>$weid,':createtime'=>0));
	if(!empty($had_award)){
		message('对不起、本次活动您已经中过奖啦！');
	}
}


  


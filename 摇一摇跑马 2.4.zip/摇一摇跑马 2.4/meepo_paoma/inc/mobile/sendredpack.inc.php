<?php
global $_W,$_GPC;
$weid = $_W['uniacid'];
$openid = $_W['openid'];
$reply_table = 'meepo_paoma_reply';
$activity_table = 'meepo_paoma_activity';
$redpack_table = "meepo_paoma_redpack";
$user_table = 'meepo_paoma_user';
$useragent = addslashes($_SERVER['HTTP_USER_AGENT']);

	$rotate_id = intval($_GPC['rotate_id']);
	$rid = intval($_GPC['rid']);
	$money = intval($_GPC['money']);
	$fee = $money*100;
	$num = intval($_GPC['num']);
	if(!empty($openid) && !empty($rid) && !empty($fee) && !empty($num)){
	 $check_had = pdo_fetchcolumn("SELECT `id` FROM".tablename($redpack_table)." WHERE rid = :rid AND weid = :weid AND rotate_id = :rotate_id AND openid = :openid",array(':rid'=>$rid,':weid'=>$weid,':rotate_id'=>$rotate_id,':openid'=>$openid));
	 if(empty($check_had)){
				$reply=pdo_fetch('SELECT * from '.tablename($reply_table).' where weid=:weid AND rid=:rid',array(':weid'=>$weid,':rid'=>$rid));
				$_desc= empty($reply['_desc']) ? '加微信号 aadzdz 有好事早知道。' : $reply['_desc'];
				if($fee < 100){
								$procResult = array('errno'=>-5,'error'=>'钱包余额必须大于1元');
								
				}else{
						$from_user = pdo_fetchcolumn("SELECT `from_user` FROM ".tablename($user_table)." WHERE weid = :weid AND openid = :openid AND rotate_id = :rotate_id AND rid = :rid",array(":weid"=>$_W['uniacid'],':openid'=>$openid,':rotate_id'=>$rotate_id,':rid'=>$rid));
						if(empty($from_user)){
							$procResult = array('errno'=>-8,'error'=>'此粉丝信息不是通过借用获取！');
							
						}else{
									load()->func('communication');
									$url='https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers';
									$pars = array();				
									$pars['mch_appid'] =$reply['appid'];
									$pars['mchid']=$reply['mchid'];			
									$pars['nonce_str'] =random(32);	
									$pars['partner_trade_no'] =time().random(3,1);	
									$pars['openid'] =$from_user;
									$pars['check_name'] ='NO_CHECK' ;
									$pars['amount'] =$fee;		
									$pars['desc'] =(empty($_desc)?'没什么，就是想送你一个荭包':$_desc);
									$pars['spbill_create_ip'] =$reply['ip'];
									ksort($pars, SORT_STRING);
									$string1 = '';
									foreach ($pars as $k => $v) {
											$string1 .= "{$k}={$v}&";
									}
									$string1 .= "key=".$reply['signkey'];
									$pars['sign'] = strtoupper(md5($string1));
									$xml = array2xml($pars);
									$extras = array();
									$extras['CURLOPT_CAINFO'] =  ATTACHMENT_ROOT ."/images/cert/".$weid."/rootca.pem";
									$extras['CURLOPT_SSLCERT'] =ATTACHMENT_ROOT . "/images/cert/".$weid."/apiclient_cert.pem";
									$extras['CURLOPT_SSLKEY'] =ATTACHMENT_ROOT . "/images/cert/".$weid."/apiclient_key.pem";
									$resp = ihttp_request($url, $xml, $extras);
									if (is_error($resp)) {
											$procResult = array(//http error
											 'errno'=>-2,
											 'error'=>$resp['message'],
											);
									} else {
											$arr=json_decode(json_encode((array) simplexml_load_string($resp['content'])), true);
											$xml = '<?xml version="1.0" encoding="utf-8"?>' . $resp['content'];
											$dom = new \DOMDocument();
											if ($dom->loadXML($xml)) {
													$xpath = new \DOMXPath($dom);
													$code = $xpath->evaluate('string(//xml/return_code)');
													$ret = $xpath->evaluate('string(//xml/result_code)');
													if (strtolower($code) == 'success' && strtolower($ret) == 'success') {
															$procResult =  array('errno'=>0,'error'=>'success');//success insert
															pdo_insert($redpack_table,array("weid"=>$weid,'rid'=>$rid,'rotate_id'=>$rotate_id,'openid'=>$openid,'from_user'=>$from_user,'num'=>$num,'money'=>$money,'createtime'=>time()));
                              if($_W['account']['level'] > 2){
																	$content = "恭喜恭喜、你本轮夺得第".$num."名、".$money."元红包已经成功发放到您微信钱包、请查收！";
																	load()->classs('weixin.account');
																	$accObj= WeixinAccount::create($_W['account']['acid']);
																	$access_token = $accObj->fetch_token();
																	$data = '{
																		"touser":"'.$openid.'",
																		"msgtype":"text",
																		"text":
																		{
																			 "content":"'.$content.'"
																		}
																	}';
																	load()->func('communication');
																	$url = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=".$access_token;
																	$sendmessage = ihttp_post($url, $data);
															}
													} else {
															$error = $xpath->evaluate('string(//xml/err_code_des)');
															$procResult = array('errno'=>-3,'error'=>$error);//错误信息
													}
											} else {
													 $procResult = array('errno'=>-4,'error'=>'未知错误');//未知错误		
											}
									}
						}
				}
	 }else{
			  $procResult = array(//http error
				 'errno'=>-7,
				 'error'=>'您已经领取过了！',
				);
	 }
	}else{
		    $procResult = array(//http error
				 'errno'=>-6,
				 'error'=>'参数错误',
				);
	}
	include $this->template('redpack');

?>
var mysql=require("mysql");
var config = require('./config.js');
//console.log(config.db);
var pool = mysql.createPool(config.db);
var query=function(sql,args,callback){
    pool.getConnection(function(err,conn){
        if(err){
            callback(err,null,null);
        }else{
            conn.query(sql,args,function(qerr,vals,fields){
                //释放连接
                conn.release();
                //事件驱动回调
                callback(qerr,vals,fields);
            });
        }
    });
};

module.exports=query;